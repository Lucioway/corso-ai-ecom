# SETUP — Istruzioni per Claude Code

> **Per l'utente:** apri Claude Code, dai accesso a questa cartella e scrivi:
> *"Leggi SETUP.md e installa il Creative Strategist nel mio sistema, fatto bene,
> deve essere production-grade e pronto all'uso — configura il mio brand e
> verifica tutto."*
> Claude farà il resto seguendo questo file.

---

## Cosa stai installando

**Creative Strategist** — un agente AI che fa da *Senior Creative Strategist +
Copywriter direct-response*. Gli dai un brand e un brief, lui produce creatività
pronta all'uso: **hook, ad copy, headline di landing, sezioni di pagina prodotto
(PDP), email, sequenze email, script VSL, esplorazione di angle**.

Ogni output è **ancorato (grounded)** a due cose:
1. **La verità del brand** (voce, audience, fatti di prodotto, parole vietate) — `memory/brand.md`
2. **Il canone marketing** (framework su desiderio, awareness, offerte, copy) — `knowledge/`

Non inventa mai fatti sul brand: se gli manca un'informazione, **la chiede**.
Migliora nel tempo grazie a un feedback loop (`winners.md` / `losers.md` /
`hypotheses.md`).

| Componente | Dove | Cosa fa |
|---|---|---|
| L'agente (il cervello) | `CreativeStrategist/agent/creative-strategist.md` | Ruolo, workflow, regole dure |
| Il vault del brand | `CreativeStrategist/_brand_/` | Tutto ciò che l'agente sa su UN brand |
| I framework (il prodotto) | `_brand_/knowledge/` | Framework marketing generici, read-only |

Tutto è **file di testo** (Markdown). Nessun database, nessun server, nessuna
chiave API. L'agente gira dentro Claude Code (o qualsiasi LLM che legga
definizioni di agente).

**Documentazione completa:** `GUIDA-MANUALE.md` in questa cartella.

---

## Requisiti

- **Claude Code CLI** installato e loggato (`claude`) — è l'ambiente in cui gira l'agente.
  In alternativa, qualsiasi LLM in cui puoi incollare `creative-strategist.md` come system prompt.
- Nessuna dipendenza da installare: niente Node, niente Python, niente chiavi.
- Un editor di testo per riempire i file del brand (anche Claude Code stesso va bene).

---

## Il tuo compito (Claude Code)

Installa l'agente, configura il **primo brand reale** dell'utente al posto del
placeholder `_brand_`, e verifica che tutto funzioni a regola d'arte.

### Fase 0 — Rileva l'ambiente
Verifica che la CLI `claude` sia installata e loggata. Conferma dove questo
strumento legge le definizioni di agente (per Claude Code: `.claude/agents/`).

### Fase 1 — Installa l'agente
Copia `CreativeStrategist/agent/creative-strategist.md` nella cartella agenti
dello strumento (per Claude Code: `.claude/agents/`). L'agente è **condiviso**:
se gestisci più brand, resta uno solo; cambia solo il vault del brand.

### Fase 2 — Crea il vault del brand reale
Il pacchetto parte con un brand placeholder `_brand_/`. Per il brand dell'utente:
1. Copia `_brand_/` in `<slug-brand>/` (slug minuscolo, es. `acme/`).
2. Apri `<slug-brand>/memory/brand.md` e sostituisci **ogni `TBD`** con i fatti
   reali del brand: missione, voce (lingua, reading grade, tono, punto di vista),
   mercati/canali, posizionamento/USP, prodotto HERO (cosa è, meccanismo, prove,
   prezzi), avatar (età, dolore, desiderio, stadio di awareness/sofisticazione),
   parole vietate e parole preferite.
3. Aggiorna `<slug-brand>/CLAUDE.md`: sostituisci `_brand_` col nome del brand e,
   nella sezione *Customer voice sources*, punta alle fonti reali di linguaggio
   cliente (export recensioni, dump commenti, DM, sondaggi).

> **`brand.md` è la leva.** L'80% della qualità dell'output dipende da questo file.
> Investici il tempo. Se un dato non lo sai, lascia `TBD`: l'agente chiederà invece
> di inventare.

### Fase 3 — Tieni i framework come sono
I file in `knowledge/` sono framework marketing generici e riusabili — sono
**read-only**. Non modificarli. Le fonti private dell'utente vanno (solo se le
ha) in `knowledge/_reference-private/`, che nel pacchetto parte vuoto.

### Fase 4 — Smoke test (NON saltare)
Lancia un brief vero per il brand dell'utente, ad esempio:
```
brand: <slug-brand>
brief: scrivi 5 hook per il prodotto HERO, audience [avatar 1]
deliverable: hook
constraints: italiano, reading grade 6, niente parole vietate
```
Verifica che l'agente:
- legga `brand.md` e i `knowledge/` prima di comporre;
- componga **nella voce del brand**, senza gergo da framework nel testo cliente;
- salvi il file in `<slug-brand>/outputs/<YYYY-MM-DD>-<slug>.md`;
- appenda una riga a `<slug-brand>/memory/log.md`;
- ritorni il path + razionale breve + bullet "framework → decisione".

### Fase 5 — Controllo qualità finale (must)
- **Grounding**: ogni mossa retorica ha un framework dietro (appendice note interne).
- **Voce**: rispetta reading grade, tono e parole vietate di `brand.md`.
- **Niente invenzioni**: nessun fatto/prodotto/claim inventato; i mancanti sono `[VERIFY]`.
- **Pulizia dati**: il vault dell'esempio non contiene dati personali; parte da placeholder.
- **Read-only knowledge**: i framework non sono stati modificati.

### Fase 6 — Consegna
Report all'utente: dove è installato l'agente, lo slug del brand creato, cosa
resta da riempire in `brand.md` (eventuali `TBD`), come lanciare un brief
(Guida §4), e come chiudere il feedback loop (Guida §6).

---

## Regole

- **Production-grade**: niente passi saltati. Se lo smoke test fallisce, fermati e sistema.
- **Non inventare dati**: i fatti del brand li mette l'utente in `brand.md`.
- **Knowledge read-only**: mai modificare i framework.
- **Un brand per volta**: nessuna memoria cross-brand.
- **Leggi la Guida Manuale** per ogni dettaglio prima di cambiare comportamenti.

---

*Pacchetto Creative Strategist v1.0 — pronto per l'installazione.*
