# _reference-private/ — your own private sources (NOT distributed)

This folder is **intentionally empty** in the package.

It exists to show you *where* to put any source material that is **yours and
private** — material you do not want to hand out or resell:

- copywriting books or course transcripts you legally own
- a competitor swipe file
- a paid mentor's SOPs
- any long-form reference you want the agent to ground its work in

## How to use it

1. Drop your private source files here as `.md` (plain text works best for the agent).
2. Add a one-line pointer to each in `wiki/index.md` so the agent can find them.
3. The agent reads these **on demand**, the same way it reads the public
   `knowledge/` frameworks — but you keep them out of anything you share.

## Why it ships empty

Everything in this package is **generic, distributable marketing frameworks**.
Private/copyrighted source material is *yours to add* — it never ships inside a
sellable product. Keep this folder out of any copy you distribute.
