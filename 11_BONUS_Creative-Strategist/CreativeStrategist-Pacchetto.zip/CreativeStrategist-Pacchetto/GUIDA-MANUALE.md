# Creative Strategist — Guida Manuale

Un *Senior Creative Strategist + Copywriter direct-response* che vive dentro un
vault di brand. Gli dai un brand e un brief, lui ti restituisce creatività pronta
all'uso — hook, ad copy, headline, pagine prodotto, email, VSL, angle — sempre
**ancorata** alla verità del tuo brand e a un canone di framework marketing. Non
inventa: se gli manca un fatto, lo chiede. E migliora nel tempo.

---

## Indice

1. [Cos'è il Creative Strategist](#1-cosè-il-creative-strategist)
2. [Requisiti](#2-requisiti)
3. [Installazione e configurazione del brand](#3-installazione-e-configurazione-del-brand)
4. [Come si invoca (il brief)](#4-come-si-invoca-il-brief)
5. [Cosa produce (i deliverable)](#5-cosa-produce-i-deliverable)
6. [Il feedback loop (winners / losers / hypotheses)](#6-il-feedback-loop-winners--losers--hypotheses)
7. [L'architettura a 3 layer](#7-larchitettura-a-3-layer)
8. [I framework inclusi (knowledge)](#8-i-framework-inclusi-knowledge)
9. [Il workflow interno passo-passo](#9-il-workflow-interno-passo-passo)
10. [Struttura dei file](#10-struttura-dei-file)
11. [Personalizzazione](#11-personalizzazione)
12. [Le regole dure (perché esistono)](#12-le-regole-dure-perché-esistono)
13. [Risoluzione problemi](#13-risoluzione-problemi)
14. [FAQ](#14-faq)

---

## 1. Cos'è il Creative Strategist

È un **agente AI** (un file di definizione) che fa il lavoro di uno stratega
creativo senior unito a un copywriter direct-response. La cosa centrale:

- **Non parte da zero.** Ogni output è *grounded* (ancorato) su due fonti: la
  **verità del tuo brand** (`memory/brand.md`) e un **canone di framework
  marketing** (`knowledge/`).
- **Non inventa.** Se per scrivere ha bisogno di un fatto (un prezzo, un
  meccanismo di prodotto, una prova) che non è nel brand, **lo chiede** invece
  di indovinare.
- **Migliora nel tempo.** Un feedback loop registra cosa ha funzionato
  (`winners.md`) e cosa no (`losers.md`), così smette di ripetere i flop e
  riusa i pattern vincenti.

Tutto è in **file di testo (Markdown)**. Nessun database, nessun server, nessuna
chiave API. L'agente gira dentro Claude Code (o qualsiasi LLM in cui incolli la
sua definizione come system prompt).

---

## 2. Requisiti

- **Claude Code CLI** installato e loggato (`claude`), *oppure* qualsiasi LLM in
  cui puoi incollare `agent/creative-strategist.md` come system prompt.
- Nessuna dipendenza: niente Node, niente Python, niente API key.
- Un editor di testo per compilare i file del brand.

---

## 3. Installazione e configurazione del brand

### Passo 1 — Installa l'agente
Copia `CreativeStrategist/agent/creative-strategist.md` dove il tuo strumento
legge gli agenti (per Claude Code: la cartella `.claude/agents/`). L'agente è
**condiviso**: se gestisci più brand resta uno solo, cambia solo il vault.

### Passo 2 — Crea il vault del tuo brand
Il pacchetto parte con un brand placeholder, la cartella `_brand_/`. Per il tuo
brand:
1. Copia `_brand_/` in `<tuo-slug>/` (slug minuscolo: lettere, numeri, trattini —
   es. `acme/`).
2. Aggiorna `<tuo-slug>/CLAUDE.md`: sostituisci `_brand_` col nome reale e, nella
   sezione *Customer voice sources*, punta alle tue fonti di linguaggio cliente.

### Passo 3 — Riempi la verità del brand (il file più importante)
Apri `<tuo-slug>/memory/brand.md` e sostituisci **ogni `TBD`**. È un modello già
strutturato in sezioni:

- **Mission** — una frase: cosa fa il brand per il cliente.
- **Brand voice** — lingua, *reading grade* (es. grado 6 = semplice e diretto),
  tono, punto di vista (you-focused / we-focused).
- **Markets and channels** — domini, mercati, piattaforme ads.
- **Positioning** — categoria, promessa/USP, contro cosa ti deposizioni.
- **Target KPIs** — metrica primaria, cosa definisce una creatività vincente.
- **Products** — il prodotto HERO: cos'è, **meccanismo** (perché funziona — deve
  essere vero, non inventato), prove, formati/prezzi.
- **Audience** — uno o più avatar: età, fascia di reddito, dolore dominante,
  desiderio dominante, stadio di awareness, livello di sofisticazione, identità.
- **Forbidden words** — claim che non puoi/devi fare, parole off-brand.
- **Preferred words** — parole che funzionano (si popolano dai winners).

> **Questa è la leva.** L'80% della qualità dell'output viene da `brand.md`.
> Sii specifico. Se non sai un dato, lascia `TBD`: l'agente chiederà invece di
> inventare.

### Passo 4 — Lascia i framework come sono
I file in `knowledge/` sono **read-only**. Non modificarli (vedi §8 e §12).

### Passo 5 — Lancia il primo brief
Vedi §4. L'agente carica la verità del brand, tira il framework giusto, compone,
e salva l'output in `outputs/`.

---

## 4. Come si invoca (il brief)

Invochi l'agente con un **brief** in 4 campi:

```
brand: <slug>
brief: <cosa scrivere, per quale audience, con quale angle/vincoli>
deliverable: <formato — hook / ad-copy / landing-section / full-pdp / email / email-sequence / vsl / angle-exploration>
constraints: <limiti duri — reading grade, parole vietate, lunghezza, lingua>
```

Se mancano `brand`, `brief` o `deliverable`, l'agente **chiede una volta** prima
di procedere. Non indovina.

**Esempio:**
```
brand: acme
brief: 5 hook per il siero anti-età, audience donne 45-60 scettiche sui risultati
deliverable: hook
constraints: italiano, reading grade 6, niente "miracoloso", max 15 parole l'uno
```

---

## 5. Cosa produce (i deliverable)

| Deliverable | Cosa è |
|---|---|
| **hook** | Ganci d'apertura per ad / video / email |
| **ad-copy** | Testo annuncio completo (Meta / TikTok / Google) |
| **landing-headline** | Headline + sub-headline per landing |
| **landing-section** | Una sezione di pagina (hero, meccanismo, offerta, FAQ…) |
| **full-pdp** | Pagina prodotto completa, sezione per sezione |
| **email** | Una singola email |
| **email-sequence** | Una sequenza (welcome, carrello, lancio…) |
| **vsl** | Script per Video Sales Letter |
| **angle-exploration** | Ricerca di angle: sub-avatar + ragioni-per-comprare |

Per ogni deliverable l'agente:
1. compone **nella voce del brand** (mai gergo da framework nel testo cliente);
2. aggiunge in fondo al file un'**appendice di note interne** che mappa *quale
   framework ha guidato quale decisione* (prova del grounding, mai sulla pagina live);
3. salva in `<brand>/outputs/<YYYY-MM-DD>-<slug>.md`;
4. appende una riga a `<brand>/memory/log.md`;
5. ti ritorna **il path del file + un razionale ≤80 parole + 3-5 bullet
   framework→decisione**. Non incolla la copy nel messaggio: è su disco.

---

## 6. Il feedback loop (winners / losers / hypotheses)

È la parte che fa migliorare l'agente nel tempo — e quella che quasi tutti
saltano.

```
brief ──▶ l'agente compone ──▶ output salvato ──▶ verdetto umano
                                                     │
              ┌──────────────────────────────────────┤
              ▼                  ▼                    ▼
          winners.md         losers.md          patch a brand.md
        (riusa il pattern) (evita il pattern)  (corregge la voce)
              └──────────────┬─────────────────────┘
                             ▼
                  il brief successivo è più intelligente
```

- Quando una creatività **vince**, appendila a `memory/winners.md` (cosa era,
  perché ha vinto, quale framework dietro, pattern riusabile).
- Quando **fallisce**, appendila a `memory/losers.md` con il **perché** (il
  motivo conta più della creatività).
- Le scommesse aperte da testare vanno in `memory/hypotheses.md`; quando si
  risolvono, spostale in winners o losers.

I file sono **append-only** (si aggiunge in fondo, non si riscrive). L'agente li
legge **prima** di comporre brief simili. L'agente **non gestisce** il loop da
solo: il verdetto lo registra un umano (o un orchestratore). Ogni brief finisce
comunque in `memory/log.md`, vinca o perda.

---

## 7. L'architettura a 3 layer

```
LAYER 1 — L'AGENTE (come lavora)
  agent/creative-strategist.md      il ruolo, il workflow, le regole dure

LAYER 2 — IL VAULT DEL BRAND (cosa sa)
  <brand>/CLAUDE.md                 config per-brand + routing
  <brand>/memory/                   verità del brand + feedback loop
  <brand>/knowledge/                i framework marketing (read-only)
  <brand>/wiki/                      indice distillato concetto → fonte
  <brand>/outputs/                  i deliverable salvati

LAYER 3 — IL GRAFO (come naviga) — opzionale, generato
  graphify-out/                     grafo di conoscenza auto-costruito sul vault
```

Puoi far girare l'agente con **solo Layer 1 + 2**. Il Layer 3 (il grafo) è un
power-up opzionale per knowledge base grandi — **non aggiungerlo presto**, finché
il vault non è abbastanza grande da richiederlo bastano le letture di file.

---

## 8. I framework inclusi (knowledge)

I file in `knowledge/` sono framework marketing **generici, riusabili su
qualsiasi brand** e **read-only**:

| File | Cosa copre |
|---|---|
| `Breakthrough-Advertising_Schwartz.md` | Stadi di awareness, sofisticazione di mercato, mass desire |
| `100M-Leads_Hormozi.md` | Lead gen, hook, offerte/valore, scarsità, framework pubblicitari |
| `Copywriting-Fundamentals.md` | Headline, hook, bullet, prove, chiarezza, struttura |
| `Angle-Identifier.md` | Definizione di angle, segmentazione sub-avatar, generazione hook |
| `Printing-Ecom-System.md` | Sistema DTC ecom: ordine landing/funnel, scelta del mercato |

In più, `knowledge/_neutral-summaries/` contiene **6 digest brevi** (riferimento
rapido / layer didattico) distillati dai documenti sopra:
`01-awareness-and-sophistication`, `02-mass-desire-and-emotion`,
`03-offers-and-value`, `04-copywriting-fundamentals`,
`05-angles-and-sub-avatars`, `06-dtc-funnel-and-landing`.

`knowledge/_reference-private/` parte **vuoto**: è dove metti le **tue** fonti
private (libri/corsi che possiedi, swipe file). Restano tue e fuori da qualsiasi
copia che distribuisci.

Quale framework per quale brief (default usato dall'agente):

| Tipo di brief | Letture di knowledge di default |
|---|---|
| hook | Copywriting-Fundamentals (headline+hook), Angle-Identifier |
| ad-copy | Copywriting-Fundamentals, Angle-Identifier, Schwartz (sofisticazione) |
| landing-headline | Schwartz (awareness+sofisticazione), Copywriting-Fundamentals |
| landing-section | Schwartz (reveal meccanismo), Hormozi (offerta), Printing-Ecom |
| full-pdp | Schwartz, Copywriting-Fundamentals (bullet), Hormozi (scarsità), Printing-Ecom |
| email / email-sequence | Copywriting-Fundamentals, Hormozi (urgenza) |
| vsl | Schwartz (sofisticazione), Copywriting-Fundamentals (storytelling) |
| angle-exploration | Angle-Identifier, Schwartz, Hormozi (mass desire) |

---

## 9. Il workflow interno passo-passo

Quando ricevi un brief, l'agente esegue 10 passi:

1. **Valida il brief** — conferma `brand`, `brief`, `deliverable`; se manca, chiede una volta.
2. **Carica la verità del brand** — legge `CLAUDE.md` + `memory/brand.md` (e
   `winners`/`losers` se il brief somiglia a lavori passati). Se `brand.md` è
   ancora pieno di `TBD`, avvisa prima di comporre.
3. **Classifica il brief** — hook / ad-copy / landing / pdp / email / vsl / angle / altro.
4. **Tira il framework governante** — Grep per localizzare il principio, poi legge
   la sezione. *(Non salta mai questo passo: comporre a memoria è il fallimento n.1.)*
5. **Legge i cross-reference del wiki** — 1-3 pagine di `wiki/` che indicizzano i
   framework caricati.
6. **Compone** — nella voce del brand, applicando i framework ma senza farne
   trapelare il gergo nel testo cliente; rispetta ogni vincolo (reading grade,
   parole vietate, lingua, lunghezza).
7. **Appendice note interne** — mappa framework → decisione per ogni mossa
   retorica (visibile al team, mai sulla pagina live).
8. **Salva** — `outputs/<YYYY-MM-DD>-<slug>.md`.
9. **Logga** — appende una riga a `memory/log.md`.
10. **Ritorna** — path + razionale + bullet framework→decisione (niente copy nel messaggio).

---

## 10. Struttura dei file

```
CreativeStrategist/
├── README.md                          ← guida di replica (tecnica)
├── agent/
│   └── creative-strategist.md         ← l'agente (il cervello)
└── _brand_/                           ← RINOMINA col tuo brand (es. acme/)
    ├── CLAUDE.md                      ← config brand: routing + regole output
    ├── memory/
    │   ├── brand.md                   ← verità del brand (voce/audience/prodotto) — IL file chiave
    │   ├── winners.md                 ← creatività che hanno funzionato (append-only)
    │   ├── losers.md                  ← creatività fallite + perché (append-only)
    │   ├── hypotheses.md              ← scommesse aperte da testare
    │   └── log.md                     ← log cronologico brief → output
    ├── knowledge/                     ← i framework marketing (READ-ONLY)
    │   ├── Angle-Identifier.md
    │   ├── Copywriting-Fundamentals.md
    │   ├── Printing-Ecom-System.md
    │   ├── 100M-Leads_Hormozi.md
    │   ├── Breakthrough-Advertising_Schwartz.md
    │   ├── _neutral-summaries/        ← 6 digest brevi di riferimento rapido
    │   └── _reference-private/        ← le TUE fonti private (parte vuoto)
    ├── wiki/
    │   └── index.md                   ← indice distillato concetto → fonte
    └── outputs/
        └── .gitkeep                   ← qui finiscono i deliverable
```

---

## 11. Personalizzazione

- **Aggiungere un brand** — copia `_brand_/` in `<nuovo-slug>/`, riempi `brand.md`,
  aggiorna `CLAUDE.md`. L'agente resta lo stesso.
- **Estendere i framework** — puoi aggiungere tue fonti in `_reference-private/`
  (con un pointer nel `wiki/index.md`). **Non** riscrivere un framework
  esistente in modo da perderne il principio.
- **Cambiare lingua di output** — di serie l'output segue la lingua del brief, a
  meno che `brand.md` non la forzi. Imposta la lingua in *Brand voice*.
- **Regole di mercato** — in `brand.md` puoi mettere regole per-mercato (simboli
  valuta, claim ammessi, fraseggio regionale); l'agente le applica.
- **Sub-avatar** — popola la sezione *Sub-avatars* di `brand.md` nel tempo: ogni
  sub-avatar ha il suo angle distinto.

---

## 12. Le regole dure (perché esistono)

L'agente rispetta regole non negoziabili — e capirne il perché ti fa usare meglio
lo strumento:

1. **Legge sempre il framework prima di comporre.** Comporre a memoria è il modo
   principale in cui un agente "scivola". Le citazioni provano il grounding: se
   non sa nominare il principio dietro una mossa, l'ha inventata.
2. **Non fabbrica specifiche di prodotto** (materiali, percentuali, certificazioni).
   Mancante → lo marca `[VERIFY]` e te lo segnala.
3. **Non rivendica un pattern vincente** che non sia in `winners.md`.
4. **Scrive sempre il file su disco e logga** in `memory/log.md`.
5. **Fornisce sempre l'appendice di grounding** framework → decisione.
6. **Knowledge read-only.** Se l'agente potesse riscrivere i propri framework, col
   tempo li trasformerebbe in poltiglia. Sono bloccati.
7. **Un brand per volta.** Nessuna memoria cross-brand, nessuna autorità esterna.
8. **La verità del brand è sacra a un brand solo.** I framework sono universali e
   riusabili; la voce no.

---

## 13. Risoluzione problemi

| Problema | Soluzione |
|---|---|
| L'agente inventa fatti di prodotto | `brand.md` ha troppi `TBD`. Riempi i fatti veri; ciò che non sai resta `TBD` e l'agente lo chiede. |
| L'output non suona come il brand | La sezione *Brand voice* di `brand.md` è vaga. Specifica reading grade, tono, do/don't, e fai il "read-aloud test". |
| Usa parole che non voglio | Aggiungile a *Forbidden words* in `brand.md`. L'agente si ferma e riscrive se sta per usarle. |
| Non trova il framework giusto | Controlla che i file `knowledge/` siano al loro posto e che `wiki/index.md` li referenzi. |
| Continua a riproporre un flop | Quel pattern non è in `losers.md`. Appendilo col **perché**: l'agente lo legge prima di comporre. |
| Non salva il file | Verifica che la cartella `outputs/` del brand esista (c'è un `.gitkeep`). |
| Risponde nella lingua sbagliata | Imposta la lingua nel `constraints` del brief o in *Brand voice* di `brand.md`. |

---

## 14. FAQ

**Devo saper programmare?**
No. È tutto file di testo Markdown. Configuri il brand scrivendo in `brand.md`,
inviochi l'agente con un brief in linguaggio naturale.

**I miei dati vanno nel cloud?**
I file restano tuoi, in locale. L'elaborazione avviene tramite l'LLM che usi
(Claude Code). Nessun dato di brand viene salvato dall'agente fuori dal vault.

**Funziona per qualsiasi business?**
Sì. I "brand" sono contenitori: ecommerce, agenzia, info-product, personal brand.
I framework sono universali; cambi solo la verità del brand.

**Posso gestire più brand?**
Sì. Una cartella `<brand>/` per ognuno, lo stesso agente per tutti. Nessuna
memoria cross-brand: ogni brand resta isolato.

**Perché i framework sono read-only?**
Per evitare la deriva: un agente che riscrive i propri framework col tempo li
degrada. Le tue fonti private personalizzabili vanno in `_reference-private/`.

**Cos'è il grafo (Layer 3) e mi serve?**
È un power-up opzionale per knowledge base grandi. All'inizio non serve: le
letture di file bastano. Aggiungilo solo quando il vault diventa grande.

**Come faccio a sapere che non sta "allucinando"?**
Ogni output ha un'appendice che mappa *framework → decisione*. Se l'agente non
sa citare il principio dietro una mossa, lo segnala come gap invece di fingere.

---

*Creative Strategist v1.0 — stratega creativo + copywriter direct-response, grounded sul tuo brand.*
