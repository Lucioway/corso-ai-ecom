#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
DIST="carousel-builder"
rm -rf "/tmp/$DIST" "/tmp/$DIST.zip"
mkdir -p "/tmp/$DIST"
rsync -a \
  --exclude '.venv' --exclude '.env' --exclude 'config.json' \
  --exclude 'templates/slides' --exclude 'templates/carousel.rendered.html' \
  --exclude 'templates/assets' --exclude 'templates/prompt.txt' \
  --exclude '__pycache__' --exclude '*.pyc' --exclude '.pytest_cache' --exclude 'tests' \
  --exclude '.DS_Store' \
  ./ "/tmp/$DIST/"
( cd /tmp && zip -rq "$DIST.zip" "$DIST" )
echo "Built /tmp/$DIST.zip"
