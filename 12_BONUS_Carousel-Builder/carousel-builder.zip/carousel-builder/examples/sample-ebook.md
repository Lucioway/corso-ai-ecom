# The Focus Stack: How to Finish What You Start

## The thesis

Most people don't have a discipline problem. They have a *finishing* problem.
Starting is cheap and exciting; finishing is quiet, boring, and where 90% of
projects die. The skill that separates people who ship from people who only
plan is the ability to carry a single task across the finish line before
opening a new one. This short guide gives you a repeatable system — the Focus
Stack — to do exactly that.

## Why finishing breaks down

Four failure modes kill almost every unfinished project:

1. **Too many open loops.** The average knowledge worker juggles 12 unfinished
   tasks at once. Each open loop drains attention even when you aren't working
   on it.
2. **The novelty trap.** A new idea always feels more exciting than the boring
   90%-done project on your desk. So you switch — and reset your progress to
   zero.
3. **Invisible progress.** When you can't *see* movement, motivation collapses.
   Effort without a visible scoreboard feels like effort wasted.
4. **No definition of done.** If "finished" is fuzzy, your brain never gets the
   completion signal, so the task drifts forever.

## The Focus Stack framework

The Focus Stack is a 4-step loop you run on one task at a time.

1. **Stack to one.** Write down every open task, then physically pick ONE. The
   other tasks go on a parked list — out of sight until the active one ships.
2. **Define done.** Write a single sentence that says exactly what "finished"
   looks like. If you can't test it, it isn't done.
3. **Time-box the push.** Work the task in 25-minute blocks. Aim for 4 blocks a
   day on the active task — no more, no less. Consistency beats intensity.
4. **Close the loop out loud.** When the task hits its "done" sentence, mark it
   shipped and tell someone. The visible close trains your brain that finishing
   is the reward.

Then — and only then — you pull the next task off the parked list.

## The numbers that matter

- **1** active task at a time. Never two.
- **4** focus blocks per day on the active task.
- **25** minutes per block — short enough to start, long enough to move.
- **7** days is the maximum a task should sit "almost done." Past that, either
  finish it or kill it.

## The takeaway

You don't need more motivation. You need fewer open loops and a clear
definition of done. Stack to one, push it in blocks, close the loop out loud —
and watch your finish rate climb.
