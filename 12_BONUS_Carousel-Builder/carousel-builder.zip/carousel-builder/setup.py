"""One-time setup: venv + deps + config + smoke test. Run by the agent."""
import json
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).parent
VENV = ROOT / ".venv"
DEPS = ["fal-client", "python-dotenv", "playwright"]


def python_ok():
    return sys.version_info >= (3, 9)


def write_config(path, brand):
    Path(path).write_text(json.dumps({"brand": brand}, indent=2) + "\n")


def write_env(path, fal_key):
    Path(path).write_text(f"FAL_KEY={fal_key}\n")


def create_venv():
    if not VENV.exists():
        subprocess.run([sys.executable, "-m", "venv", str(VENV)], check=True)
    return VENV / "bin" / "python"


def install_deps(py):
    subprocess.run([str(py), "-m", "pip", "install", "--upgrade", "pip"], check=True)
    subprocess.run([str(py), "-m", "pip", "install", *DEPS], check=True)
    try:
        subprocess.run([str(py), "-m", "playwright", "install", "chromium"], check=True)
    except subprocess.CalledProcessError as e:
        print(
            "WARNING: 'playwright install chromium' failed. "
            "Run it manually after setup:\n"
            f"  {py} -m playwright install chromium\n"
            f"  (error: {e})"
        )


def main():
    if not python_ok():
        sys.exit("Python 3.9+ required. Found " + sys.version.split()[0])
    py = create_venv()
    install_deps(py)
    print("\nSetup deps done. The agent will now collect your brand + fal.ai key.")


if __name__ == "__main__":
    main()
