---
name: carousel-builder
description: Build a branded 10-slide Instagram carousel (1080x1350) from a document/ebook the user supplies. Use when the user says "build a carousel", "carousel from this doc/ebook", or runs /carousel-builder.
---

# Carousel Builder

Turns a document/ebook + a prompt into a finished, on-brand 10-slide Instagram
carousel. BYO fal.ai key for the cover image. Works as a global skill OR a
project folder.

## First run — setup (once)

If `config.json` or `.env` is missing, run setup first:

1. `python setup.py` (creates `.venv`, installs fal-client + python-dotenv + playwright + chromium).
2. Ask the user for their **fal.ai key** → write it via the setup helper to `.env`.
3. Ask for **brand**: name, handle, accent color (hex), background color (hex),
   display font (Google Fonts family, e.g. Anton), body font (e.g. DM Sans),
   optional logo path/URL → write to `config.json`.
4. Confirm setup complete.

Never put the fal.ai key in `config.json` or any committed file — only `.env`.

## Build pipeline (each carousel)

1. **Input.** The user supplies a document/ebook/text + a prompt
   ("carousel on chapter 3"). Read the document fully.
2. **Copy.** Extract 10 slides from the document — verbatim or faithfully
   distilled. NEVER invent quotes, numbers, or claims. Show the copy in chat;
   let the user approve/edit.
3. **Author HTML.** Write the 10-slide content into
   `templates/carousel.html`, keeping the `{{TOKENS}}` for brand chrome
   (`{{HANDLE}}`, `{{COVER}}`, `{{LOGO}}`, color/font tokens) intact.
4. **Cover.** Derive an image prompt from the theme → write it to
   `templates/prompt.txt` → run `.venv/bin/python templates/gen_cover.py`.
   Show the cover. STOP. Wait for approval. Regenerate if rejected.
5. **Brand fill.** Run `.venv/bin/python templates/apply_brand.py`
   (fills tokens from `config.json` → `templates/carousel.rendered.html`).
6. **Render.** Run `.venv/bin/python templates/render.py`
   (→ `templates/slides/slide_01..10.png`).
7. **Caption.** Generate an IG caption: hook line, 2-4 value lines,
   CTA `Commenta "<KEYWORD>"` (plain text — no ManyChat wiring), hashtags.

## Slide structure (10, fixed)

S1 HOOK (cover full-bleed + title stack) · S2 PROMISE · S3 PROBLEM ·
S4 STACK · S5 FRAMEWORK · S6 RESET · S7 INPUTS · S8 RULES · S9 SPEC ·
S10 CTA. Keep this skeleton; fill with the user's document content.

## Hard rules

1. No invented quotes/numbers/claims — everything traces to the supplied document.
2. Brand chrome comes from `config.json`, never hardcode colors/handle in content.
3. Cover gate: stop after the cover, wait for approval before rendering.
4. Secrets only in `.env`.
5. Output = `templates/slides/` + paste-ready caption. Do not auto-publish.

## Output contract

Report: slides folder path; the cover prompt used; the IG caption.
