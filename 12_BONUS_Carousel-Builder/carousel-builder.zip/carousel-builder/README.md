# Carousel Builder

Turn any document or ebook into a finished, on-brand 10-slide Instagram
carousel (1080×1350) — copy + cover image + caption — straight from Claude Code.

## Requirements

- Claude Code
- Python 3.9+
- A fal.ai API key (you pay for your own cover images) — https://fal.ai

## Install — Option A: as a Claude Code skill

1. Unzip and copy the `carousel-builder` folder to `~/.claude/skills/`.
2. Open Claude Code and paste:

   > Set up the carousel-builder skill. Run setup.py, then ask me for my
   > fal.ai key and my brand (handle, colors, fonts, logo) and save them.

3. When ready, build a carousel any time with:

   > /carousel-builder build a carousel from this ebook: <paste or attach>

## Install — Option B: as a project folder

1. Unzip `carousel-builder` anywhere.
2. Open Claude Code in that folder and paste:

   > Read SKILL.md and set yourself up: run setup.py, then ask me for my
   > fal.ai key and brand and save them.

3. Build a carousel:

   > Build a carousel from this document: <paste or attach>

## What happens

1. The agent reads your document and drafts 10 slides of copy — you approve.
2. It generates a cover image via fal.ai — you approve.
3. It renders all 10 slides to `templates/slides/` and writes you an IG caption.

No quotes or numbers are invented — everything comes from your document.

## Your data

- Your fal.ai key is stored only in `.env` (never shared, never committed).
- Your brand lives in `config.json` (copy from `config.example.json`).
