"""Render carousel slides to 1080x1350 PNGs via Playwright."""
import asyncio
from pathlib import Path

from playwright.async_api import async_playwright

ROOT = Path(__file__).parent
HTML = ROOT / "carousel.rendered.html"
if not HTML.exists():
    HTML = ROOT / "carousel.html"
OUT = ROOT / "slides"


async def main():
    OUT.mkdir(exist_ok=True)
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        ctx = await browser.new_context(
            viewport={"width": 1100, "height": 1400}, device_scale_factor=2
        )
        page = await ctx.new_page()
        await page.goto(f"file://{HTML.resolve()}")
        await page.wait_for_load_state("networkidle")
        await page.wait_for_timeout(1500)  # font flush
        slides = await page.query_selector_all(".slide")
        print(f"Found {len(slides)} slides")
        for i, slide in enumerate(slides, 1):
            path = OUT / f"slide_{i:02d}.png"
            await slide.screenshot(path=str(path))
            print(f"  → {path.name}")
        await browser.close()
    print(f"\nDone. {len(slides)} PNGs in {OUT}")


if __name__ == "__main__":
    asyncio.run(main())
