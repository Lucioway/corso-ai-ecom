"""Fill {{TOKENS}} in carousel.html from config.json brand block."""
import json
from pathlib import Path

ROOT = Path(__file__).parent


def font_link(display, body):
    fams = "&".join(f"family={f.replace(' ', '+')}" for f in (display, body))
    return f"https://fonts.googleapis.com/css2?{fams}&display=swap"


def _channels(h):
    h = h.lstrip("#")
    return [int(h[i : i + 2], 16) for i in (0, 2, 4)]


def hex_to_rgb(h):
    """'#F5B800' -> '245,184,0' (decimal r,g,b string)."""
    return ",".join(str(c) for c in _channels(h))


def lighten(h, f):
    """Each channel c -> round(c + (255-c)*f); '#RRGGBB' uppercase."""
    return "#" + "".join(f"{round(c + (255 - c) * f):02X}" for c in _channels(h))


def darken(h, f):
    """Each channel c -> round(c*(1-f)); '#RRGGBB' uppercase."""
    return "#" + "".join(f"{round(c * (1 - f)):02X}" for c in _channels(h))


def apply(template, brand):
    logo = brand.get("logo", "")
    logo_tag = f'<img class="brand-logo" src="{logo}">' if logo else ""
    accent = brand["accent"]
    repl = {
        "{{ACCENT}}": accent,
        "{{ACCENT_RGB}}": hex_to_rgb(accent),
        "{{ACCENT_2}}": lighten(accent, 0.18),
        "{{METAL_1}}": lighten(accent, 0.45),
        "{{METAL_2}}": accent.upper(),
        "{{METAL_3}}": darken(accent, 0.30),
        "{{METAL_4}}": darken(accent, 0.55),
        "{{BG}}": brand["bg"],
        "{{FONT_DISPLAY}}": brand["font_display"],
        "{{FONT_BODY}}": brand["font_body"],
        "{{FONT_LINK}}": font_link(brand["font_display"], brand["font_body"]),
        "{{HANDLE}}": brand["handle"],
        "{{COVER}}": "assets/cover.png",
        "{{LOGO}}": logo_tag,
    }
    for k, v in repl.items():
        template = template.replace(k, v)
    return template


def main():
    brand = json.loads((ROOT.parent / "config.json").read_text())["brand"]
    src = (ROOT / "carousel.html").read_text()
    out = ROOT / "carousel.rendered.html"
    out.write_text(apply(src, brand))
    print(f"Wrote {out}")


if __name__ == "__main__":
    main()
