"""Generate the carousel cover via fal.ai Nano Banana Pro. BYO fal.ai key."""
import asyncio
import os
import sys
import urllib.request
from pathlib import Path

from dotenv import dotenv_values

ROOT = Path(__file__).parent
OUT = ROOT / "assets"


def load_key(env_path):
    """fal.ai key from local .env (FAL_KEY), else FAL_KEY env var."""
    vals = dotenv_values(env_path) if Path(env_path).exists() else {}
    key = vals.get("FAL_KEY") or os.environ.get("FAL_KEY")
    if not key:
        raise RuntimeError(
            "Missing fal.ai key. Put FAL_KEY=... in CarouselBuilder/.env "
            "or export FAL_KEY in your shell."
        )
    return key


async def generate(prompt, key):
    import fal_client

    OUT.mkdir(exist_ok=True)
    os.environ["FAL_KEY"] = key
    client = fal_client.AsyncClient(key=key)
    print("Generating cover via fal-ai/nano-banana-pro…")
    result = await client.subscribe(
        "fal-ai/nano-banana-pro",
        arguments={
            "prompt": prompt,
            "aspect_ratio": "4:5",
            "resolution": "4K",
            "num_images": 1,
            "output_format": "png",
        },
    )
    images = result.get("images") or []
    if not images:
        raise RuntimeError(f"fal.ai returned no image: {result}")
    out = OUT / "cover.png"
    urllib.request.urlretrieve(images[0]["url"], out)
    print(f"Saved: {out} ({out.stat().st_size // 1024} KB)")
    return out


def main():
    # The agent writes the image prompt into prompt.txt next to this file.
    prompt_file = ROOT / "prompt.txt"
    if not prompt_file.exists():
        print("No prompt.txt found — write the cover prompt there first.")
        sys.exit(1)
    key = load_key(ROOT.parent / ".env")
    asyncio.run(generate(prompt_file.read_text().strip(), key))


if __name__ == "__main__":
    main()
