# SETUP — Istruzioni per Claude Code

> **Per l'utente:** apri Claude Code, dai accesso a questa cartella e scrivi:
> *"Leggi SETUP.md e installa questo agente, fatto bene — deve essere
> production-grade e vendibile, controlla tutto."*
> Claude farà il resto seguendo questo file.

---

## Cosa stai installando

**Carousel Builder** — un agente per Claude Code che trasforma qualsiasi
documento o ebook in un **carosello Instagram da 10 slide** (1080×1350),
on-brand e pronto da pubblicare: copy + immagine di copertina + caption.

| Componente | Cosa fa |
|---|---|
| Skill / agente | Estrae 10 slide dal documento, autore HTML, genera la copertina, renderizza le slide e scrive la caption |
| `setup.py` | Crea il `.venv`, installa le dipendenze Python, installa Chromium |
| `templates/` | Template HTML del carosello + script di generazione/rendering |

L'agente gira interamente in locale. L'unico servizio esterno è **fal.ai**
(solo per l'immagine di copertina) con la **tua** chiave — paghi solo le tue
copertine. Nessun dato viene committato o condiviso.

**Documentazione completa:** `GUIDA-MANUALE.md` in questa cartella.

---

## Il tuo compito (Claude Code)

Installa, configura e verifica Carousel Builder **a regola d'arte**, pronto per
essere usato e venduto. Adatta ogni comando e percorso all'ambiente reale
(macOS / Linux / Windows) senza chiedere conferme banali.

### Fase 0 — Rileva l'ambiente
Verifica: **Python 3.9+** e la CLI `claude` installata. Su Windows usa
`.venv\Scripts\python.exe` al posto di `.venv/bin/python`.

### Fase 1 — Installa le dipendenze
```bash
cd CarouselBuilder
python setup.py
```
`setup.py` crea `.venv/`, fa l'upgrade di pip e installa **fal-client**,
**python-dotenv**, **playwright**, poi scarica **Chromium** per Playwright. Se
`playwright install chromium` fallisce, eseguilo a mano:
```bash
.venv/bin/python -m playwright install chromium
```

### Fase 2 — Configurazione (chiave + brand)
1. **Chiave fal.ai.** Copia `.env.example` in `.env` e inserisci la chiave
   dell'utente:
   ```bash
   cp .env.example .env
   # .env → FAL_KEY=<chiave fal.ai dell'utente>
   ```
   La chiave si prende su https://fal.ai. **Non** deve finire in `config.json`
   né in nessun file committato — solo in `.env`.
2. **Brand.** Copia `config.example.json` in `config.json` e chiedi all'utente:
   nome, handle Instagram, colore accento (hex), colore sfondo (hex), font
   display (Google Fonts, es. `Anton`), font body (es. `DM Sans`), logo
   opzionale. Scrivi questi valori in `config.json`.

### Fase 3 — Verifica (NON saltare)
```bash
cd CarouselBuilder
.venv/bin/python -m pytest tests/ -q     # i test devono passare
.venv/bin/python templates/apply_brand.py   # scrive carousel.rendered.html dai token brand
.venv/bin/python templates/render.py        # scrive templates/slides/slide_01..10.png
```
Apri una slide PNG e controlla che colori, font e handle siano quelli del brand
configurato. Lo smoke test della copertina richiede credito fal.ai: opzionale in
fase di setup (vedi Fase 4).

### Fase 4 — Primo carosello (smoke test E2E, opzionale)
Usa il documento d'esempio `examples/sample-ebook.md`:
1. Leggi il documento, estrai 10 slide di copy, mostrale all'utente per
   approvazione.
2. Scrivi il copy nei blocchi slide di `templates/carousel.html` (mantieni
   intatti i `{{TOKEN}}` del brand).
3. Deriva un prompt immagine → scrivilo in `templates/prompt.txt` →
   `.venv/bin/python templates/gen_cover.py` → mostra la copertina, **fermati**
   e aspetta l'approvazione.
4. `apply_brand.py` → `render.py` → caption Instagram.

### Fase 5 — Controllo qualità finale (must)
- **Sicurezza:** la chiave fal.ai vive solo in `.env`; `.env` e `config.json`
  non vanno committati (sono già in `.gitignore`).
- **Pulizia dati:** il pacchetto parte con un brand d'esempio ("Acme") e zero
  dati personali. I dati reali li mette l'utente.
- **Niente invenzioni:** quote, numeri e affermazioni tracciano sempre al
  documento fornito. L'agente non pubblica mai automaticamente.
- **Output corretto:** 10 PNG in `templates/slides/` + caption pronta da
  incollare.

### Fase 6 — Consegna
Report all'utente: cosa è installato, come configurare il brand, come si lancia
un carosello, dove finiscono gli output, e cosa richiede la sua attenzione
(chiave fal.ai con credito, login `claude`).

---

## Come si usa (per l'utente finale)

Una volta installato, in Claude Code dentro la cartella:

> *"Costruisci un carosello da questo documento: <incolla o allega>"*

Oppure, se installato come skill globale:

> `/carousel-builder build a carousel from this ebook: <…>`

Output: 10 slide in `templates/slides/` + una caption Instagram.

---

## Regole
- **Production-grade:** niente scorciatoie, niente passi saltati. Se una verifica
  fallisce, fermati e sistema prima di proseguire.
- **Adatta all'OS** senza chiedere (percorsi `.venv` diversi su Windows).
- **Segreti solo in `.env`.** Mai nel codice, mai in `config.json`.
- **Leggi `GUIDA-MANUALE.md`** per ogni dettaglio prima di modificare
  comportamenti.

---

*Pacchetto Carousel Builder — pronto per l'installazione.*
