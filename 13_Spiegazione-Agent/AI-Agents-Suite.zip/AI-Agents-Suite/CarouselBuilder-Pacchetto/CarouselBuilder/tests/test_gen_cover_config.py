import sys
from pathlib import Path

TEMPLATES = Path(__file__).resolve().parent.parent / "templates"
sys.path.insert(0, str(TEMPLATES))
import gen_cover  # noqa: E402


def test_load_key_prefers_env_file(tmp_path, monkeypatch):
    monkeypatch.delenv("FAL_KEY", raising=False)
    env = tmp_path / ".env"
    env.write_text("FAL_KEY=from-file\n")
    assert gen_cover.load_key(env) == "from-file"


def test_load_key_falls_back_to_environ(tmp_path, monkeypatch):
    monkeypatch.setenv("FAL_KEY", "from-environ")
    missing = tmp_path / "nope.env"
    assert gen_cover.load_key(missing) == "from-environ"


def test_load_key_missing_raises(tmp_path, monkeypatch):
    monkeypatch.delenv("FAL_KEY", raising=False)
    missing = tmp_path / "nope.env"
    try:
        gen_cover.load_key(missing)
        assert False, "expected RuntimeError"
    except RuntimeError as e:
        assert "fal.ai key" in str(e).lower()
