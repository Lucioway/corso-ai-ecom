import json
import sys
from pathlib import Path

TEMPLATES = Path(__file__).resolve().parent.parent / "templates"
sys.path.insert(0, str(TEMPLATES))
import apply_brand  # noqa: E402

BRAND = {
    "name": "Acme",
    "handle": "@acme",
    "accent": "#FF0000",
    "bg": "#111111",
    "font_display": "Oswald",
    "font_body": "Inter",
    "logo": "",
}


def test_font_link_builds_google_url():
    url = apply_brand.font_link("DM Sans", "Anton")
    assert url == (
        "https://fonts.googleapis.com/css2?"
        "family=DM+Sans&family=Anton&display=swap"
    )


def test_apply_replaces_all_tokens():
    tpl = (
        "<link href={{FONT_LINK}}>"
        ":root{--accent:{{ACCENT}};--bg:{{BG}};}"
        ".display{font-family:'{{FONT_DISPLAY}}';}"
        ".dm{font-family:'{{FONT_BODY}}';}"
        "<span>{{HANDLE}}</span>"
        "<img src='{{COVER}}'>{{LOGO}}"
    )
    out = apply_brand.apply(tpl, BRAND)
    assert "{{" not in out
    assert "#FF0000" in out
    assert "#111111" in out
    assert "Oswald" in out
    assert "Inter" in out
    assert "@acme" in out
    assert "assets/cover.png" in out


def test_empty_logo_renders_nothing():
    out = apply_brand.apply("{{LOGO}}", {**BRAND, "logo": ""})
    assert out == ""


def test_present_logo_renders_img():
    out = apply_brand.apply("{{LOGO}}", {**BRAND, "logo": "logo.png"})
    assert out == '<img class="brand-logo" src="logo.png">'


def test_hex_to_rgb():
    assert apply_brand.hex_to_rgb("#F5B800") == "245,184,0"
    assert apply_brand.hex_to_rgb("#FF0000") == "255,0,0"
    assert apply_brand.hex_to_rgb("#000000") == "0,0,0"


def test_lighten():
    assert apply_brand.lighten("#F5B800", 0.18) == "#F7C52E"
    assert apply_brand.lighten("#F5B800", 0.45) == "#FAD873"
    assert apply_brand.lighten("#000000", 1.0) == "#FFFFFF"


def test_darken():
    assert apply_brand.darken("#F5B800", 0.30) == "#AC8100"
    assert apply_brand.darken("#F5B800", 0.55) == "#6E5300"
    assert apply_brand.darken("#FFFFFF", 1.0) == "#000000"


def test_apply_derives_full_palette_from_accent():
    out = apply_brand.apply(
        "rgba(var(--accent-rgb),0.4)"
        "--accent-2:{{ACCENT_2}};"
        "{{METAL_1}} {{METAL_2}} {{METAL_3}} {{METAL_4}}"
        "{{ACCENT_RGB}}",
        {**BRAND, "accent": "#F5B800"},
    )
    assert "{{" not in out
    assert "245,184,0" in out  # ACCENT_RGB
    assert "#F7C52E" in out  # ACCENT_2
    assert "#FAD873" in out  # METAL_1
    assert "#F5B800" in out  # METAL_2 (verbatim accent)
    assert "#AC8100" in out  # METAL_3
    assert "#6E5300" in out  # METAL_4


def test_metal_2_uppercases_accent():
    out = apply_brand.apply("{{METAL_2}}", {**BRAND, "accent": "#f5b800"})
    assert out == "#F5B800"
