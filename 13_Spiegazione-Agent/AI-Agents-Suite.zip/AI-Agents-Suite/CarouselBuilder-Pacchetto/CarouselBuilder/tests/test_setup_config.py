import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
import setup as setup_mod  # noqa: E402


def test_write_config_creates_brand_block(tmp_path):
    cfg = tmp_path / "config.json"
    setup_mod.write_config(
        cfg,
        brand={
            "name": "Acme",
            "handle": "@acme",
            "accent": "#FF0000",
            "bg": "#111111",
            "font_display": "Oswald",
            "font_body": "Inter",
            "logo": "",
        },
    )
    data = json.loads(cfg.read_text())
    assert data["brand"]["handle"] == "@acme"
    assert data["brand"]["accent"] == "#FF0000"


def test_write_env_creates_fal_key(tmp_path):
    env = tmp_path / ".env"
    setup_mod.write_env(env, "my-fal-key")
    assert "FAL_KEY=my-fal-key" in env.read_text()


def test_python_ok_true_for_current():
    assert setup_mod.python_ok() is True
