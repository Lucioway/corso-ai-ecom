# Carousel Builder — Guida Manuale

Trasforma qualsiasi documento o ebook in un carosello Instagram da 10 slide
(1080×1350), on-brand e pronto da pubblicare — copy, immagine di copertina e
caption — direttamente da Claude Code. Gira in locale: i tuoi dati restano tuoi,
e l'unico costo esterno sono le immagini di copertina che generi con la tua
chiave fal.ai.

---

## Indice

1. [Cos'è Carousel Builder](#1-cosè-carousel-builder)
2. [Requisiti](#2-requisiti)
3. [Installazione e primo avvio](#3-installazione-e-primo-avvio)
4. [Configurazione: chiave fal.ai e brand](#4-configurazione-chiave-falai-e-brand)
5. [Come funziona: la pipeline](#5-come-funziona-la-pipeline)
6. [Le 10 slide (lo scheletro fisso)](#6-le-10-slide-lo-scheletro-fisso)
7. [Comandi](#7-comandi)
8. [Personalizzare i template](#8-personalizzare-i-template)
9. [Il sistema dei token di brand](#9-il-sistema-dei-token-di-brand)
10. [Struttura dei file](#10-struttura-dei-file)
11. [Output](#11-output)
12. [Regole non negoziabili](#12-regole-non-negoziabili)
13. [Risoluzione problemi](#13-risoluzione-problemi)
14. [FAQ](#14-faq)

---

## 1. Cos'è Carousel Builder

Carousel Builder è un agente per **Claude Code**. Gli dai un documento (un
ebook, un capitolo, un articolo, delle note) e lui produce un carosello
Instagram completo:

- **Copy** — 10 slide estratte fedelmente dal tuo documento (mai inventate).
- **Copertina** — un'immagine generata via fal.ai dal tema del documento.
- **Slide renderizzate** — 10 PNG a 1080×1350, con i colori, i font e l'handle
  del tuo brand.
- **Caption** — un testo pronto da incollare su Instagram (hook, valore, CTA,
  hashtag).

La cosa centrale: il **brand è dichiarativo**. Colori, font, handle e logo
vivono in un unico file `config.json`. Cambi brand = cambi un file, senza
toccare il codice. Il contenuto delle slide arriva sempre dal tuo documento:
l'agente non inventa quote, numeri o affermazioni.

---

## 2. Requisiti

- **Claude Code** (l'agente gira dentro Claude Code).
- **Python 3.9+** (verificato da `setup.py`).
- **Una chiave fal.ai** — la prendi su <https://fal.ai>. Serve solo per
  l'immagine di copertina; paghi le tue copertine. Tutto il resto è gratis.
- Connessione internet (per fal.ai e per scaricare i Google Fonts in fase di
  rendering).

Le dipendenze Python (`fal-client`, `python-dotenv`, `playwright`) e il browser
**Chromium** vengono installati automaticamente da `setup.py` dentro un `.venv`
locale.

---

## 3. Installazione e primo avvio

1. Scompatta la cartella `CarouselBuilder` dove preferisci.
2. Apri **Claude Code** dentro la cartella e di': *"Leggi SETUP.md e installa
   questo agente."* Claude esegue i passi sotto.

Installazione manuale:

```bash
cd CarouselBuilder
python setup.py
```

`setup.py` fa esattamente questo:

1. Controlla che Python sia ≥ 3.9 (altrimenti si ferma).
2. Crea `.venv/` se non esiste.
3. Aggiorna pip e installa `fal-client`, `python-dotenv`, `playwright`.
4. Scarica **Chromium** per Playwright (`playwright install chromium`). Se questo
   passo fallisce, lo stampa come WARNING — eseguilo a mano:
   ```bash
   .venv/bin/python -m playwright install chromium
   ```

> **Nota:** `setup.py` installa solo le dipendenze. La raccolta di chiave e
> brand la guida l'agente (vedi §4).

### Due modi di installare

- **Come skill globale di Claude Code:** copia la cartella in
  `~/.claude/skills/` (rinominandola `carousel-builder` se vuoi). La invochi
  ovunque con `/carousel-builder`.
- **Come cartella di progetto:** lasciala dove vuoi e apri Claude Code lì
  dentro. L'agente legge `SKILL.md` e si configura da solo.

---

## 4. Configurazione: chiave fal.ai e brand

### La chiave fal.ai (file `.env`)

La chiave vive **solo** in `.env`, mai altrove. Parti dal template:

```bash
cp .env.example .env
```

Poi metti la tua chiave:

```
FAL_KEY=la-tua-chiave-fal-ai
```

Lo script di generazione copertina (`gen_cover.py`) legge `FAL_KEY` prima da
`.env`, e in alternativa dalla variabile d'ambiente `FAL_KEY` della shell. Se non
trova nessuna delle due, si ferma con un errore chiaro.

### Il brand (file `config.json`)

Il brand vive in `config.json`. Parti dall'esempio:

```bash
cp config.example.json config.json
```

Struttura (blocco `brand`):

| Campo | Significato | Esempio |
|---|---|---|
| `name` | Nome del brand | `"Acme"` |
| `handle` | Handle Instagram (mostrato in basso a sinistra su ogni slide) | `"@acme"` |
| `accent` | Colore accento (hex) — da qui si deriva tutta la palette | `"#F5B800"` |
| `bg` | Colore di sfondo (hex) | `"#0A0A0A"` |
| `font_display` | Font dei titoli (famiglia Google Fonts) | `"Anton"` |
| `font_body` | Font del corpo (famiglia Google Fonts) | `"DM Sans"` |
| `logo` | Percorso/URL del logo (opzionale; vuoto = nessun logo) | `""` |

> Da `accent` lo script ricava automaticamente accento chiaro/scuro e i quattro
> toni "metallo" usati per gli effetti dei titoli. Cambi un colore, cambia tutta
> la palette in modo coerente.

---

## 5. Come funziona: la pipeline

Ogni carosello segue 7 passi (dal `SKILL.md`):

1. **Input.** Fornisci un documento/ebook/testo + un prompt (es. *"carosello sul
   capitolo 3"*). L'agente legge il documento per intero.
2. **Copy.** Estrae 10 slide — verbatim o distillate fedelmente. **Mai** quote,
   numeri o affermazioni inventate. Mostra il copy in chat: tu approvi o
   modifichi.
3. **Autore HTML.** Scrive le 10 slide dentro `templates/carousel.html`,
   lasciando intatti i `{{TOKEN}}` del brand (`{{HANDLE}}`, `{{COVER}}`,
   `{{LOGO}}`, token di colore e font).
4. **Copertina.** Deriva un prompt immagine dal tema → lo scrive in
   `templates/prompt.txt` → esegue `gen_cover.py` (fal.ai, modello
   `fal-ai/nano-banana-pro`, 4:5, 4K, PNG). Mostra la copertina, **si ferma** e
   aspetta la tua approvazione. Se la rifiuti, rigenera.
5. **Brand fill.** Esegue `apply_brand.py`: riempie i token leggendo
   `config.json` e scrive `templates/carousel.rendered.html`.
6. **Render.** Esegue `render.py`: apre l'HTML in Chromium (Playwright) e
   cattura ogni `.slide` come PNG → `templates/slides/slide_01..10.png`.
7. **Caption.** Genera una caption Instagram: riga hook, 2–4 righe di valore,
   CTA `Commenta "<KEYWORD>"` (testo semplice, nessun automatismo ManyChat),
   hashtag.

Il **cover gate** del passo 4 è una protezione: non si renderizza nulla finché
non approvi la copertina.

---

## 6. Le 10 slide (lo scheletro fisso)

Lo scheletro è fisso a 10 slide; cambia solo il contenuto che arriva dal tuo
documento:

| # | Ruolo | Cosa contiene |
|---|---|---|
| S1 | **HOOK** | Copertina a tutto schermo + titolo |
| S2 | **PROMISE** | La promessa / il beneficio |
| S3 | **PROBLEM** | Il problema che il documento affronta |
| S4 | **STACK** | Gli elementi in gioco |
| S5 | **FRAMEWORK** | Il metodo / framework |
| S6 | **RESET** | Il punto di svolta |
| S7 | **INPUTS** | Cosa serve / input |
| S8 | **RULES** | Le regole |
| S9 | **SPEC** | I numeri / le specifiche |
| S10 | **CTA** | Call to action |

Mantieni questo scheletro; riempilo con i contenuti del documento dell'utente.

---

## 7. Comandi

Si lavora in linguaggio naturale dentro Claude Code. Esempi:

**Avviare un carosello (cartella di progetto):**
> *"Costruisci un carosello da questo documento: <incolla o allega>"*

**Avviare un carosello (skill globale):**
> `/carousel-builder build a carousel from this ebook: <…>`

**Script Python (li lancia l'agente, ma puoi eseguirli a mano):**

```bash
# 1. Genera la copertina (richiede prompt.txt e FAL_KEY)
.venv/bin/python templates/gen_cover.py

# 2. Riempi i token di brand → carousel.rendered.html
.venv/bin/python templates/apply_brand.py

# 3. Renderizza le 10 slide → templates/slides/
.venv/bin/python templates/render.py

# Test
.venv/bin/python -m pytest tests/ -q
```

Su Windows usa `.venv\Scripts\python.exe` al posto di `.venv/bin/python`.

---

## 8. Personalizzare i template

### Il template del carosello

`templates/carousel.html` è il cuore visivo. Contiene 10 blocchi `<div
class="slide ...">`, lo stile CSS (sfondo, grain, font metallici, layout di ogni
slide) e i `{{TOKEN}}` di brand. Quando l'agente costruisce un carosello,
riscrive il **contenuto testuale** dei blocchi slide ma lascia intatti:

- i `{{TOKEN}}` (vengono riempiti da `apply_brand.py`);
- la struttura delle classi (`.slide`, `.tag-tl`, `.handle-bl`, `.chev-br`,
  ecc.) usata da `render.py` per catturare le slide.

Puoi modificare il CSS a mano per cambiare l'estetica (spaziature, dimensioni
dei titoli, layout). **Non** rimuovere la classe `.slide` dai contenitori: è il
selettore che `render.py` usa per fare lo screenshot di ogni slide.

Il file di esempio nel pacchetto è già popolato con un carosello dimostrativo
(brand "Acme") così vedi subito la resa. Verrà sovrascritto al primo carosello
vero.

### La copertina

Il prompt immagine vive in `templates/prompt.txt` (creato al volo dall'agente).
Lo puoi scrivere a mano e rigenerare con `gen_cover.py`. Il modello è
`fal-ai/nano-banana-pro` a 4:5, 4K, PNG; per cambiarlo modifica gli `arguments`
in `gen_cover.py`.

---

## 9. Il sistema dei token di brand

`apply_brand.py` legge il blocco `brand` di `config.json` e sostituisce i token
in `carousel.html` producendo `carousel.rendered.html`. I token disponibili:

| Token | Da dove arriva |
|---|---|
| `{{ACCENT}}` | `accent` verbatim |
| `{{ACCENT_RGB}}` | `accent` convertito in `r,g,b` decimale |
| `{{ACCENT_2}}` | `accent` schiarito del 18% |
| `{{METAL_1}}` | `accent` schiarito del 45% |
| `{{METAL_2}}` | `accent` in MAIUSCOLO |
| `{{METAL_3}}` | `accent` scurito del 30% |
| `{{METAL_4}}` | `accent` scurito del 55% |
| `{{BG}}` | `bg` |
| `{{FONT_DISPLAY}}` | `font_display` |
| `{{FONT_BODY}}` | `font_body` |
| `{{FONT_LINK}}` | URL Google Fonts costruito dai due font |
| `{{HANDLE}}` | `handle` |
| `{{COVER}}` | sempre `assets/cover.png` |
| `{{LOGO}}` | `<img class="brand-logo" src="…">` se `logo` è valorizzato, altrimenti vuoto |

Il punto: definisci **un** colore accento e ottieni una palette coerente
(accento, due varianti, quattro toni "metallo" per gli effetti dei titoli) senza
scegliere a mano sei colori.

---

## 10. Struttura dei file

```
CarouselBuilder/
├── README.md               # panoramica rapida
├── SKILL.md                # contratto dell'agente (pipeline + regole)
├── setup.py                # venv + dipendenze + Chromium
├── .env.example            # template chiave (copia in .env)
├── config.example.json     # template brand (copia in config.json)
├── package.sh              # script per impacchettare una distribuzione
├── .gitignore              # esclude .env, config.json, output, venv
├── examples/
│   └── sample-ebook.md     # documento d'esempio per provare la pipeline
├── templates/
│   ├── carousel.html       # template 10-slide + CSS + {{TOKEN}}
│   ├── apply_brand.py      # riempie i token → carousel.rendered.html
│   ├── gen_cover.py        # genera la copertina via fal.ai
│   └── render.py           # renderizza le slide in PNG via Playwright
└── tests/
    ├── test_apply_brand.py        # palette, token, font link, logo
    ├── test_gen_cover_config.py   # caricamento chiave fal.ai
    └── test_setup_config.py       # scrittura config/env
```

File generati a runtime (non nel pacchetto, esclusi da git):
`.env`, `config.json`, `.venv/`, `templates/prompt.txt`,
`templates/assets/cover.png`, `templates/carousel.rendered.html`,
`templates/slides/`.

---

## 11. Output

Al termine di un carosello ottieni:

- **`templates/slides/slide_01.png … slide_10.png`** — le 10 slide a 1080×1350
  (renderizzate a device scale 2x per nitidezza).
- **Una caption Instagram** stampata in chat, pronta da incollare.
- Il **prompt** usato per la copertina (per riprodurla o iterare).

L'agente **non pubblica mai** automaticamente: l'output è pronto da incollare, lo
posti tu.

---

## 12. Regole non negoziabili

Dal `SKILL.md`, queste regole sono cablate nel comportamento dell'agente:

1. **Niente invenzioni.** Quote, numeri e affermazioni tracciano sempre al
   documento fornito.
2. **Brand dai token.** Colori e handle vengono da `config.json`, mai
   hardcodati nel contenuto delle slide.
3. **Cover gate.** Dopo la copertina ci si ferma e si aspetta l'approvazione
   prima di renderizzare.
4. **Segreti solo in `.env`.** La chiave fal.ai non finisce mai in `config.json`
   né in file committati.
5. **Niente auto-publish.** L'output è `templates/slides/` + caption. Lo pubblichi
   tu.

---

## 13. Risoluzione problemi

**`Missing fal.ai key`** — `gen_cover.py` non trova la chiave. Controlla che
`.env` esista e contenga `FAL_KEY=…`, oppure esporta `FAL_KEY` nella shell.

**`playwright install chromium` fallisce in setup** — eseguilo a mano:
`.venv/bin/python -m playwright install chromium`. Senza Chromium, `render.py`
non può fare gli screenshot.

**`No prompt.txt found`** — `gen_cover.py` ha bisogno di `templates/prompt.txt`.
Scrivi prima il prompt della copertina in quel file (di norma lo fa l'agente).

**`fal.ai returned no image`** — fal.ai non ha restituito immagini: spesso
credito esaurito o chiave non valida. Verifica chiave e saldo su fal.ai.

**Le slide mostrano i `{{TOKEN}}` invece dei colori** — hai renderizzato
`carousel.html` invece di `carousel.rendered.html`. Esegui prima
`apply_brand.py` (che richiede `config.json`). `render.py` usa il file
`.rendered` se esiste.

**I font non si vedono giusti** — i font sono Google Fonts caricati a runtime;
serve connessione internet durante il rendering. `render.py` aspetta
`networkidle` + 1,5s per il flush dei font; con rete lenta puoi aumentare
l'attesa in `render.py`.

**`render.py` trova 0 slide** — hai rimosso o rinominato la classe `.slide` dai
contenitori in `carousel.html`. Ripristinala: è il selettore di cattura.

**Errori dei test** — esegui `.venv/bin/python -m pytest tests/ -q` dalla
cartella `CarouselBuilder`; i test importano gli script per percorso relativo, va
lanciato dalla root del progetto.

---

## 14. FAQ

**Per che piattaforma è il carosello?**
Instagram — 10 slide a 1080×1350 (formato verticale 4:5).

**Da cosa parte?**
Da un documento/ebook/testo che fornisci tu, più un prompt (es. "carosello sul
capitolo 3").

**Devo pagare qualcosa?**
Solo le immagini di copertina, con la tua chiave fal.ai. Copy, rendering e
caption sono gratis e locali.

**Posso usare un mio logo?**
Sì: metti il percorso/URL nel campo `logo` di `config.json`. Vuoto = nessun
logo.

**Posso cambiare estetica (colori, font)?**
Sì, da `config.json` (colori e font) senza toccare codice. Per cambiare layout,
modifica il CSS in `carousel.html`.

**Pubblica lui su Instagram?**
No. Produce slide + caption pronte; le pubblichi tu.

**Posso cambiare il modello di immagine?**
Sì, modificando gli `arguments` di `gen_cover.py` (modello, formato,
risoluzione).

**Funziona offline?**
No: servono fal.ai (copertina) e internet per i Google Fonts in fase di
rendering.

---

*Carousel Builder — guida manuale. Buoni caroselli.*
