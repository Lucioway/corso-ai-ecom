# SETUP — Istruzioni per Claude Code

> **Per l'utente:** apri Claude Code, dai accesso a questa cartella e scrivi:
> *"Leggi SETUP.md e installa FinanceKPI nel mio sistema, fatto bene, deve
> essere production-grade e vendibile — controlla tutto."*
> Claude farà il resto seguendo questo file.

---

## Cosa stai installando

**FinanceKPI** — un toolkit self-hosted di Profit & Loss per negozi Shopify, in
italiano. Legge i dati reali del tuo store (ordini, commissioni, resi) dalle
Shopify Admin API, ci somma il costo della merce (COGS) e ti mostra il margine
vero. Due componenti, **un solo codice**:

| Componente | Porta | Cosa fa |
|---|---|---|
| Dashboard live | 8789 (default) | P&L in tempo reale: vendite, ordini, ad spend, COGS, margine, ROAS, ROAS di break-even |
| Report batch | — | Genera il report P&L giornaliero/settimanale, su richiesta o schedulato |

Entrambi leggono lo **stesso** `config.json` e la stessa logica Shopify+finance
in `core/`. Il codice completo è nella sottocartella **`FinanceKPI/`**. Nessun
database: lo stato sono file (config, cache ordini, xlsx). Le integrazioni
esterne (Drive, Triple Whale, Telegram/WhatsApp, email watcher) sono **tutte
spente di default** e si attivano solo dopo aver inserito le credenziali.

**Documentazione completa:** `GUIDA-MANUALE.md` in questa cartella — leggila per
capire ogni KPI, comando, file e personalizzazione.

---

## Il tuo compito (Claude Code)

Installa, configura e verifica FinanceKPI **a regola d'arte**, pronto per essere
usato e venduto. Adatta ogni comando, percorso e launcher all'ambiente reale
(macOS / Linux / Windows / server cloud) senza chiedere conferme banali.

### Fase 0 — Rileva l'ambiente
- Sistema operativo, versione di **Python** (serve 3.10+, consigliato 3.13) e
  `pip`. Verifica che `python3 -m venv` funzioni.
- Se è un **server cloud**: la dashboard gira come web service; il report batch
  va schedulato (cron/systemd-timer) invece che con launchd. Documenta cosa è
  attivo.

### Fase 1 — Crea un venv e installa le dipendenze
```bash
cd FinanceKPI
python3 -m venv venv && . venv/bin/activate
pip install -r requirements.txt        # set combinato canonico (dashboard + report)
```
`web/requirements.txt` e `report/requirements.txt` sono sottoinsiemi, utili se
deployi un solo componente.

### Fase 2 — Configurazione guidata
Esegui il wizard interattivo:
```bash
./setup.sh
```
Chiede: nome brand, valuta, **Shopify shop URL**, **Shopify Admin API token**
(`shpat_...`), utente/password della dashboard, prefisso file report. Scrive un
unico `config.json` canonico in root e lo copia in `report/config.json` e
`web/config.json` (così report, dashboard e `core/` leggono lo stesso file),
più un `.env` con l'auth dashboard e un session secret generato.

> Tutti i file generati (`config.json`, `report/config.json`, `web/config.json`,
> `.env`) sono **per-installazione** e gitignored: non vanno mai committati né
> condivisi.

**Token Shopify:** in Shopify admin → *Settings → Apps and sales channels →
Develop apps → Create an app → Configure Admin API scopes* (read su Orders,
Products e scope finanziari correlati) → *Install app* → copia l'**Admin API
access token** (`shpat_...`).

### Fase 3 — COGS (porta i tuoi numeri)
Il costo merce lo fornisci **tu**, dal tuo foglio fornitore: lo strumento non
inventa costi. Metti l'`.xlsx`/CSV dei costi nella cartella indicata da
`cogs.supplier_csv_folder` in `config.json`, oppure compila il blocco
`cogs.matrix`. Se per un giorno manca la fonte, quel COGS resta vuoto invece di
essere indovinato. Aiuta l'utente a impostare la prima fonte COGS.

### Fase 4 — Avvia e verifica (NON saltare)
```bash
# Health check auth/config
python cli.py status

# Dashboard live (locale)
python cli.py dashboard --port 8890        # → http://127.0.0.1:8890

# Primo report
python cli.py report --date $(date +%F)
```
Verifica:
- `http://127.0.0.1:8890` → la dashboard carica e chiede il login (`DASHBOARD_USER` / `DASHBOARD_PASS`).
- Senza credenziali → **401**; con credenziali → **200**.
- `GET /healthz` → risposta `ok`.
- Le card KPI si popolano entro 1-2 minuti (scalda la cache ordini al primo giro).
- `python cli.py report` produce un `.xlsx` con tutte le integrazioni opzionali spente.

### Fase 5 — Scheduling (opzionale ma consigliato)
Il report giornaliero si lancia con `run_daily.sh` (delega a `cli.py report`).
Schedulalo: **launchd** su macOS, **systemd timer** o **cron** su Linux, **Task
Scheduler** su Windows. Per il deploy cloud della dashboard segui
`FinanceKPI/DEPLOY.md` (Render, disco persistente per la cache, variabili
d'ambiente `DASHBOARD_*` + `SHOPIFY_*`).

### Fase 6 — Controllo qualità finale (must)
- **Sicurezza**: nessuna chiave/segreto hardcoded; `.env` e `config.json` non
  committati; esponi solo le porte necessarie; se è cloud pubblico, metti auth /
  reverse-proxy davanti alla dashboard.
- **Pulizia dati**: parte senza dati personali — solo placeholder. Conferma con
  `grep -ri` che non ci siano nomi/numeri di terzi.
- **Robustezza**: le integrazioni opzionali spente non fanno crashare il report;
  l'avvio della dashboard non si blocca se le creds Shopify sono assenti/errate.
- **Smoke test end-to-end**: setup → dashboard 200 con login / 401 senza → un
  report giornaliero che produce l'xlsx.

### Fase 7 — Consegna
Scrivi un breve report all'utente: cosa è attivo, URL/porte, come avviare e
fermare, dove mettere il file COGS, come schedulare il report, e qualsiasi cosa
che richieda la sua attenzione (token Shopify, fonte COGS, integrazioni da
abilitare).

---

## Regole

- **Production-grade**: niente scorciatoie, niente passi saltati. Se una verifica
  non passa, fermati e sistemala prima di proseguire.
- **Adatta all'OS**: comandi, percorsi e launcher cambiano per sistema — fallo
  senza chiedere.
- **Non inventare dati**: COGS, credenziali e brand li fornisce l'utente; tu
  prepari la struttura e verifichi che tutto regga.
- **Leggi la Guida Manuale** per ogni dettaglio funzionale prima di modificare
  comportamenti.

---

*Pacchetto FinanceKPI v1.0 — pronto per l'installazione.*
