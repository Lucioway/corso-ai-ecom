"""FX rate provider for the live KPI dashboard.

Fetches daily EUR/USD (and arbitrary EUR→X) rates from Frankfurter.app.
Caches each historical date to disk; today re-fetched on each call.

Used when the shop currency differs from the payout currency (e.g. shop in EUR
but the payment processor pays out in USD). This module exposes the daily
EUR↔USD rate so the dashboard can render the parallel "payout cash" view
alongside the shop-currency canonical P&L.
"""
from __future__ import annotations

import json
import threading
from datetime import date
from pathlib import Path
from typing import Optional

import requests

ROOT = Path(__file__).resolve().parent
CACHE_DIR = ROOT / "cache" / "fx"
CACHE_DIR.mkdir(parents=True, exist_ok=True)

FRANKFURTER = "https://api.frankfurter.app"


class FxRates:
    """Daily EUR-base FX rates with disk + memory cache."""

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._mem: dict[str, dict] = {}  # iso → {currency: rate}
        self.last_error: Optional[str] = None

    def _cache_path(self, d: date) -> Path:
        return CACHE_DIR / f"{d.isoformat()}.json"

    def _load_disk(self, d: date) -> Optional[dict]:
        p = self._cache_path(d)
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return None

    def _save_disk(self, d: date, payload: dict) -> None:
        try:
            self._cache_path(d).write_text(json.dumps(payload), encoding="utf-8")
        except Exception:
            pass

    def get_rates(self, target: date) -> dict:
        """EUR-base rates for `target`. Today: re-fetch always; past: cached."""
        iso = target.isoformat()
        today = date.today()
        is_volatile = target >= today  # today only

        with self._lock:
            if not is_volatile and iso in self._mem:
                return self._mem[iso]
        if not is_volatile:
            disk = self._load_disk(target)
            if disk is not None:
                with self._lock:
                    self._mem[iso] = disk
                return disk

        try:
            r = requests.get(f"{FRANKFURTER}/{iso}", params={"base": "EUR"}, timeout=10)
            r.raise_for_status()
            rates = r.json().get("rates", {}) or {}
            rates["EUR"] = 1.0
            payload = rates
            if not is_volatile:
                self._save_disk(target, payload)
            with self._lock:
                self._mem[iso] = payload
            self.last_error = None
            return payload
        except Exception as e:
            self.last_error = f"{target}: {e}"
            print(f"[FX] {target} fetch failed: {e}")
            # last-resort fallback: latest endpoint
            try:
                r = requests.get(f"{FRANKFURTER}/latest", params={"base": "EUR"}, timeout=10)
                r.raise_for_status()
                rates = r.json().get("rates", {}) or {}
                rates["EUR"] = 1.0
                with self._lock:
                    self._mem[iso] = rates
                return rates
            except Exception as e2:
                self.last_error = f"{target}: {e2}"
                return {"EUR": 1.0, "USD": 0.0}

    def eur_to_usd(self, target: date) -> float:
        """1 EUR → X USD on `target` (e.g. 1.085)."""
        return float(self.get_rates(target).get("USD") or 0.0)

    def info(self) -> dict:
        with self._lock:
            sample = {}
            today = date.today()
            iso = today.isoformat()
            if iso in self._mem:
                u = self._mem[iso].get("USD")
                if u:
                    sample = {"today": iso, "EUR_USD": round(u, 5)}
            return {
                "loaded": True,
                "provider": "frankfurter",
                "cached_days": len(self._mem),
                "last_error": self.last_error,
                **sample,
            }


if __name__ == "__main__":
    from datetime import timedelta
    fx = FxRates()
    for i in range(5):
        d = date.today() - timedelta(days=i)
        print(d, "→ 1 EUR =", fx.eur_to_usd(d), "USD")
    print(fx.info())
