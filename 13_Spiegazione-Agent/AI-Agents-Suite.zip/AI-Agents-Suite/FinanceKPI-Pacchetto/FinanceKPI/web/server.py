#!/usr/bin/env python3
"""KPI Dashboard — real-time finance metrics for a Shopify store.

Brand-agnostic via config.json
(brand/shop_currency/payout_currency/supplier/triple_whale flags).

Uses shared modules (TripleWhaleClient, ShopifyClient).
Supplier + TripleWhale init are gated by config flags so a fresh store can
boot with Shopify-only and ads/cogs added later.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
import re
import threading
import time
import urllib.parse
import urllib.request
from collections import defaultdict
from datetime import date, datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

ROOT = Path(__file__).resolve().parent
CFG_PATH = ROOT / "config.json"
# FA_PATH kept ONLY for optional Supplier wrapping (disabled by default). When
# the path doesn't exist (e.g. Render) and SUPPLIER_ON=False, this is unused.
# Point FA_AGENT_PATH at the report/ agent dir if you enable Supplier COGS.
FA_PATH = Path(os.environ.get(
    "FA_AGENT_PATH",
    str(ROOT.parent / "report"),
))

# Cookie-session auth (replaces HTTP Basic popup).
AUTH_USER = os.environ.get("DASHBOARD_USER") or os.environ.get("FINANCEKPI_USER", "")
AUTH_PASS = os.environ.get("DASHBOARD_PASS") or os.environ.get("FINANCEKPI_PASS", "")
AUTH_ENABLED = bool(AUTH_USER and AUTH_PASS)
SESSION_SECRET = (
    (os.environ.get("DASHBOARD_SESSION_SECRET") or os.environ.get("FINANCEKPI_SESSION_SECRET", "")).strip()
    or hashlib.sha256(("dashboard-v1::" + AUTH_PASS).encode("utf-8")).hexdigest()
)
SESSION_COOKIE = "dashboard_session"
SESSION_TTL_SEC = 30 * 24 * 3600  # 30 days

# Customer Care agent (separate Render service) — read-only KPI proxy (optional).
CC_URL = os.environ.get("CC_URL", "").rstrip("/")
CC_REPORT_TOKEN = os.environ.get("CC_REPORT_TOKEN", "")
_cc_cache = {"ts": 0.0, "data": None}  # ponytail: 5min module cache, CC Claude call is slow

# Local modules — bundled in modules/ (Phase 1 of deploy prep)
from modules.ads_client import TripleWhaleClient  # noqa: E402
from modules.shopify_client import ShopifyClient  # noqa: E402
from supplier_cogs import SupplierCogsSource  # noqa: E402
from fx_converter import FxRates  # noqa: E402
from costs_reader import CostsCache, start_refresh_thread as start_costs_refresh  # noqa: E402
import xlsx_daily_reader  # noqa: E402

PORT = int(os.environ.get("PORT", "8789"))
HOST = os.environ.get("HOST", "127.0.0.1")
TODAY_REFRESH_SEC = 120
DAILY_REFRESH_SEC = 3600
DAYS = 90

# Store launch date — ad spend / Klaviyo for dates strictly before this are
# stripped (those metrics belong to a different store on the same Triple Whale
# / Meta ad account). Override via LAUNCH_DATE env (YYYY-MM-DD).
def _parse_launch_date(s: str) -> date:
    try:
        return date.fromisoformat(s)
    except Exception:
        return date(2026, 5, 13)
LAUNCH_DATE = _parse_launch_date(os.environ.get("LAUNCH_DATE", "2026-05-13"))

# Cache root: DATA_DIR env (cloud persistent disk) or ROOT/cache (local).
_DATA_DIR_ENV = os.environ.get("DATA_DIR", "").strip()
DATA_DIR = Path(_DATA_DIR_ENV).expanduser().resolve() if _DATA_DIR_ENV else (ROOT / "cache")
DATA_DIR.mkdir(parents=True, exist_ok=True)
ORDERS_CACHE_DIR = DATA_DIR / "orders"
FEES_CACHE_DIR = DATA_DIR / "fees"
REFUNDS_CACHE_DIR = DATA_DIR / "refunds"
for d in (ORDERS_CACHE_DIR, FEES_CACHE_DIR, REFUNDS_CACHE_DIR):
    d.mkdir(parents=True, exist_ok=True)

# Metrics cache snapshot — persisted on the data disk so a deploy/restart
# doesn't wipe the daily cache (no more "everything zero" until refetch).
METRICS_CACHE_FILE = DATA_DIR / "metrics_cache.json"

# ── Manual fixed costs (user-entered, persisted on the data disk) ──────────
FIXED_COSTS_FILE = DATA_DIR / "fixed_costs.json"
_FC_LOCK = threading.Lock()

def _load_fixed_costs() -> list:
    try:
        if FIXED_COSTS_FILE.exists():
            return json.loads(FIXED_COSTS_FILE.read_text(encoding="utf-8"))
    except Exception as e:
        print(f"[fixed_costs] load error: {e}", flush=True)
    return []

def _save_fixed_costs(rows: list) -> None:
    with _FC_LOCK:
        FIXED_COSTS_FILE.write_text(json.dumps(rows, ensure_ascii=False, indent=1), encoding="utf-8")

def _fc_effective(rows: list, ym: str):
    """Recurring with forward inheritance: a month uses its OWN entries if it has
    any; otherwise it inherits from the most recent PRIOR month that has entries.
    Returns (entries, source_ym)."""
    own = [r for r in rows if (r.get("date") or "")[:7] == ym]
    if own:
        return own, ym
    priors = sorted({(r.get("date") or "")[:7] for r in rows
                     if (r.get("date") or "")[:7] and (r.get("date") or "")[:7] < ym})
    if priors:
        src = priors[-1]
        return [r for r in rows if (r.get("date") or "")[:7] == src], src
    return [], None

def _reapply_fixed_to_cache() -> None:
    """Recompute fixed_costs_day + net_after_fixed for every cached day from the
    CURRENT fixed costs — no Shopify re-fetch. Called after any fixed-cost change
    so past months update instantly (net_profit stays the operating net)."""
    import calendar as _cal
    rows = _load_fixed_costs()
    try:
        with cache.lock:
            for iso, d in cache.daily.items():
                try:
                    y, m = int(iso[:4]), int(iso[5:7])
                    fx = d.get("fx_eur_usd") or 0
                    usd_eur = (1.0 / fx) if fx else 0.864
                    dim = _cal.monthrange(y, m)[1]
                    eff, _src = _fc_effective(rows, iso[:7])
                    tot = sum((fc.get("amount", 0) * usd_eur if fc.get("currency") == "USD"
                               else fc.get("amount", 0)) for fc in eff)
                    fday = round(tot / dim, 2) if dim else 0.0
                    d["fixed_costs_day"] = fday
                    d["net_after_fixed"] = round((d.get("net_profit") or 0) - fday, 2)
                except Exception:
                    pass
    except Exception as e:
        print(f"[fixed_costs] reapply error: {e}", flush=True)


class Cache:
    def __init__(self) -> None:
        self.lock = threading.Lock()
        self.today: dict = {}
        self.raw_today: dict = {}
        self.daily: dict[str, dict] = {}        # iso -> parsed
        self.raw_daily: dict[str, dict] = {}    # iso -> raw_metrics
        self.updated_at: str | None = None
        self.last_error: str | None = None
        self.cogs_info: dict = {}
        self.fx_info: dict = {}

    def snapshot(self) -> dict:
        with self.lock:
            snap = {
                "updated_at": self.updated_at,
                "last_error": self.last_error,
                "today": self.today,
                "raw_today": self.raw_today,
                "daily": dict(sorted(self.daily.items())),
                "raw_daily": dict(sorted(self.raw_daily.items())),
                "cogs_info": self.cogs_info,
                "fx_info": self.fx_info,
                "brand": BRAND,
                "shop_currency": SHOP_CCY,
                "payout_currency": PAYOUT_CCY,
            }
        snap["costs"] = _build_costs_snapshot()
        return snap

    def save(self) -> None:
        """Persist daily cache to the data disk (atomic). Best-effort."""
        try:
            with self.lock:
                payload = {
                    "updated_at": self.updated_at,
                    "today": self.today,
                    "raw_today": self.raw_today,
                    "daily": self.daily,
                    "raw_daily": self.raw_daily,
                }
            tmp = METRICS_CACHE_FILE.with_suffix(".tmp")
            tmp.write_text(json.dumps(payload), encoding="utf-8")
            tmp.replace(METRICS_CACHE_FILE)
        except Exception:
            pass  # best-effort: on failure we just refetch as before

    def load(self) -> None:
        """Load daily cache from the data disk on startup. Best-effort."""
        try:
            if not METRICS_CACHE_FILE.exists():
                return
            d = json.loads(METRICS_CACHE_FILE.read_text(encoding="utf-8"))
            with self.lock:
                self.updated_at = d.get("updated_at")
                self.today = d.get("today") or {}
                self.raw_today = d.get("raw_today") or {}
                self.daily = d.get("daily") or {}
                self.raw_daily = d.get("raw_daily") or {}
        except Exception:
            pass  # corrupt/missing snapshot → start empty, poller refills


def _config_from_env() -> dict | None:
    """Build a config dict from env vars (cloud mode).
    Returns None if essential secrets are missing → fall back to config.json."""
    sho_url = os.environ.get("SHOPIFY_SHOP_URL", "").strip()
    sho_pwd = os.environ.get("SHOPIFY_API_PASSWORD", "").strip()
    sho_secret = os.environ.get("SHOPIFY_API_SECRET", "").strip()
    # New custom-app auth derives the token from api_key+secret (client_credentials);
    # the static api_password is legacy/optional. Require url + (secret OR password).
    if not (sho_url and (sho_secret or sho_pwd)):
        return None
    cfg: dict = {
        "shopify": {
            "shop_url": sho_url,
            "api_key": os.environ.get("SHOPIFY_API_KEY", "").strip(),
            "api_secret": sho_secret,
            "api_password": sho_pwd,
            "api_version": os.environ.get("SHOPIFY_API_VERSION", "2025-01"),
        },
        "triple_whale": {
            "enabled": bool(os.environ.get("TRIPLE_WHALE_API_KEY", "").strip()),
            "api_key": os.environ.get("TRIPLE_WHALE_API_KEY", "").strip(),
            "shop_url": sho_url,
            "currency": "EUR",
        },
    }
    # Merge static blocks (products/cogs/finance/report/exchange_rates/supplier/
    # supplier_b/google_drive) from config.json — these are non-secret structure.
    if CFG_PATH.exists():
        try:
            local = json.loads(CFG_PATH.read_text(encoding="utf-8"))
            for k in (
                "products", "cogs", "finance", "exchange_rates", "report",
                "supplier", "supplier_b", "supplier_a", "google_drive", "telegram",
                "local_output_dir",
            ):
                if k in local:
                    cfg[k] = local[k]
        except Exception as e:
            print(f"[dashboard] config.json merge failed: {e}")
    # Supplier A secrets via env (cloud mode)
    supplier_email = os.environ.get("SUPPLIER_A_EMAIL", "").strip()
    supplier_pwd = os.environ.get("SUPPLIER_A_PASSWORD", "").strip()
    if supplier_email and supplier_pwd:
        cfg.setdefault("supplier_a", {})
        cfg["supplier_a"]["enabled"] = True
        cfg["supplier_a"]["email"] = supplier_email
        cfg["supplier_a"]["password"] = supplier_pwd
    return cfg


def load_config() -> dict:
    env_cfg = _config_from_env()
    if env_cfg is not None:
        return env_cfg
    return json.loads(CFG_PATH.read_text(encoding="utf-8"))


_CFG = load_config()
BRAND        = (_CFG.get("report") or {}).get("company_name", "Brand").lower()
SHOP_CCY     = (_CFG.get("report") or {}).get("currency", "EUR")
PAYOUT_CCY   = (_CFG.get("report") or {}).get("payout_currency", SHOP_CCY)
SUPPLIER_ON   = bool((_CFG.get("supplier") or {}).get("enabled"))
TW_ON        = bool((_CFG.get("triple_whale") or {}).get("enabled"))
FX_ON        = SHOP_CCY != PAYOUT_CCY
COGS_FIXED_PCT = float((_CFG.get("cogs") or {}).get("fixed_pct") or 0.0)

# Bundle COGS matrix (USD-native): key "primaries_accessories" → cogs_usd
# Source: bundle price list (xlsx) provided per store.
_COGS_MATRIX_RAW = (_CFG.get("cogs") or {}).get("matrix") or {}
COGS_BUNDLE_MATRIX: dict = {}
for _k, _v in _COGS_MATRIX_RAW.items():
    try:
        _c, _b = _k.split("_")
        COGS_BUNDLE_MATRIX[(int(_c), int(_b))] = float(_v)
    except Exception:
        pass
_HINTS = (_CFG.get("cogs") or {}).get("title_hints") or {}
PRIMARY_TITLE_HINT = (_HINTS.get("primary") or "product").lower()
ACCESSORY_TITLE_HINT = (_HINTS.get("accessory") or "accessory").lower()


def _count_primary_accessory(order: dict) -> tuple:
    """Count primary + accessory units in a Shopify order by line_items title match."""
    primaries = accessories = 0
    for li in order.get("line_items") or []:
        title = (li.get("title") or "").lower()
        qty = int(li.get("quantity") or 0)
        if PRIMARY_TITLE_HINT in title:
            primaries += qty
        elif ACCESSORY_TITLE_HINT in title:
            accessories += qty
    return primaries, accessories

cache = Cache()
cache.load()  # restore persisted daily cache so a restart isn't "all zero"
cogs_src = SupplierCogsSource(FA_PATH) if SUPPLIER_ON else None
fx = FxRates() if FX_ON else None
cache.cogs_info = cogs_src.info() if cogs_src else {"source": "none"}
cache.fx_info = fx.info() if fx else {"source": "none", "rate": 1.0}

# ── Supplier A Dropshipping COGS adapter (real per-order COGS) ─────────────────
SUPPLIER_A_ON = bool((_CFG.get("supplier_a") or {}).get("enabled"))
_supplier_a_lock = threading.Lock()
_supplier_a_adapter = None
_supplier_a_init_error: str | None = None

def get_supplier_a_adapter():
    """Lazy init SupplierACogsAdapter (Playwright login on first call)."""
    global _supplier_a_adapter, _supplier_a_init_error
    if not SUPPLIER_A_ON:
        return None
    if _supplier_a_adapter is not None:
        return _supplier_a_adapter
    with _supplier_a_lock:
        if _supplier_a_adapter is not None:
            return _supplier_a_adapter
        try:
            from modules.supplier_a_cogs_adapter import SupplierACogsAdapter
            _supplier_a_adapter = SupplierACogsAdapter(
                _CFG,
                fx_client=None,
                fx_date=date.today(),
                cache_dir=str(DATA_DIR),
            )
            _supplier_a_init_error = None
        except Exception as e:
            _supplier_a_init_error = str(e)
            print(f"[dashboard] Supplier A adapter init failed: {e}", flush=True)
        return _supplier_a_adapter

# Costs reader: pulls fixed (Software Mensili / Team Mensile / Annuali) +
# variable from the "COSTI 2026" sheet. Needs FX
# to convert USD sheet entries → EUR canonical, so always init an FxRates
# even when shop_ccy==payout_ccy.
_costs_fx = fx if fx is not None else FxRates()
costs_cache = CostsCache(fx=_costs_fx)


def _build_costs_snapshot() -> dict:
    """Aggregate fixed + variable costs from the 'COSTI 2026' sheet.
    Shape matches the contract index.html's renderCosts() expects."""
    today = date.today()
    yesterday = today - timedelta(days=1)
    with costs_cache.lock:
        by_day = {
            iso: {
                "extra":    round(v.get("extra", 0.0), 2),
                "shopify":  round(v.get("shopify", 0.0), 2),
                "software": round(v.get("software", 0.0), 2),
                "team":     round(v.get("team", 0.0), 2),
            }
            for iso, v in costs_cache.by_day.items()
        }
        items = list(costs_cache.items)
    return {
        "updated_at": costs_cache.updated_at,
        "last_error": costs_cache.last_error,
        "by_day": by_day,
        "items": items,
        "monthly": costs_cache.monthly(),
        "alloc_by_day": costs_cache.alloc_by_day(),
        "alloc_by_day_split": costs_cache.alloc_by_day_split(),
        "today":     costs_cache.for_day(today),
        "yesterday": costs_cache.for_day(yesterday),
        "p7":  costs_cache.aggregate(7),
        "p14": costs_cache.aggregate(14),
        "p30": costs_cache.aggregate(30),
        "p60": costs_cache.aggregate(60),
        "p90": costs_cache.aggregate(90),
    }


# ── Per-day cache helpers ──────────────────────────────────────────────
def _orders_cache_path(d: date) -> Path:
    return ORDERS_CACHE_DIR / f"{d.isoformat()}.json"


def _fees_cache_path(d: date) -> Path:
    return FEES_CACHE_DIR / f"{d.isoformat()}.json"


def _refunds_cache_path(d: date) -> Path:
    return REFUNDS_CACHE_DIR / f"{d.isoformat()}.json"


def _slim_order(o: dict) -> dict:
    """Keep only the financial fields needed for P&L. All amounts in shop
    currency (EUR) — Shopify auto-converts presentment USD → shop EUR."""
    refund_amt = 0.0
    for r in (o.get("refunds") or []):
        for tx in (r.get("transactions") or []):
            try:
                refund_amt += float(tx.get("amount") or 0)
            except Exception:
                pass
    ship = (o.get("total_shipping_price_set") or {}).get("shop_money") or {}
    presentment = float(((o.get("total_price_set") or {}).get("presentment_money") or {}).get("amount") or 0.0)
    return {
        "id": o.get("id"),
        "name": o.get("name"),
        "financial_status": o.get("financial_status"),
        "billing_address":  {"country_code": (o.get("billing_address") or {}).get("country_code")},
        "shipping_address": {"country_code": (o.get("shipping_address") or {}).get("country_code")},
        "line_items": [
            {
                "product_id": li.get("product_id"),
                "title": li.get("title") or li.get("name"),
                "quantity": li.get("quantity"),
            }
            for li in (o.get("line_items") or [])
        ],
        "total_price":     float(o.get("total_price") or 0),       # EUR (shop)
        "presentment_usd": presentment,                            # USD (customer)
        "total_tax":       float(o.get("total_tax") or 0),
        "total_discounts": float(o.get("total_discounts") or 0),
        "total_shipping":  float(ship.get("amount") or 0),
        "refund_amount":   round(refund_amt, 2),
        "tags":            o.get("tags") or "",
        "cancelled_at":    o.get("cancelled_at"),
        "payment_gateway_names": o.get("payment_gateway_names") or [],
        "_is_reshipment":  bool(o.get("_is_reshipment", False)),
    }


def get_orders_for_day(shopify: ShopifyClient, target: date, force: bool = False) -> list:
    today = date.today()
    is_volatile = (today - target).days <= 1
    p = _orders_cache_path(target)
    if not force and not is_volatile and p.exists():
        try:
            data = json.loads(p.read_text(encoding="utf-8"))
            if data and "presentment_usd" in data[0] and "tags" in data[0]:
                return data
        except Exception:
            pass
    orders = shopify.get_orders_for_date(target)
    slim = [_slim_order(o) for o in orders]
    if not is_volatile:
        try:
            p.write_text(json.dumps(slim), encoding="utf-8")
        except Exception as e:
            print(f"[dashboard] orders cache write {target} failed: {e}")
    return slim


def get_fees_for_day(shopify: ShopifyClient, target: date, order_ids: list, force: bool = False) -> dict:
    today = date.today()
    is_volatile = (today - target).days <= 1
    p = _fees_cache_path(target)
    if not force and not is_volatile and p.exists():
        try:
            return {int(k): float(v) for k, v in json.loads(p.read_text()).items()}
        except Exception:
            pass
    if not order_ids:
        return {}
    raw = shopify.get_fees_for_orders_graphql(order_ids)
    fees = {int(oid): float(d.get("fee") or 0.0) for oid, d in raw.items()}
    if not is_volatile:
        try:
            p.write_text(json.dumps({str(k): v for k, v in fees.items()}))
        except Exception:
            pass
    return fees


def get_refunds_for_day(shopify: ShopifyClient, target: date, force: bool = False) -> float:
    today = date.today()
    is_volatile = (today - target).days <= 1
    p = _refunds_cache_path(target)
    if not force and not is_volatile and p.exists():
        try:
            return float(json.loads(p.read_text()).get("total_refunded", 0.0))
        except Exception:
            pass
    try:
        result = shopify.get_daily_returns_graphql(target)
        total = float(result.get("total_refunded") or 0.0)
        if not is_volatile:
            p.write_text(json.dumps({"total_refunded": total, "count": result.get("refund_count", 0)}))
        return total
    except Exception as e:
        print(f"[dashboard] {target} refunds GraphQL failed: {e}")
        return 0.0


def compute_day_metrics(orders: list, fees: dict, raw_metrics: dict, target: date,
                        refunds_total: float, supplier: dict, fx_eur_usd: float) -> dict:
    """Compute KPIs for one day.

    Sales / orders / gateway fees → Shopify (shop currency EUR)
    Refunds → Shopify GraphQL daily returns
    Ads (Meta/TikTok/Google) + Klaviyo → TW (returned in EUR per config)
    COGS → Supplier API per order (EUR, matches shop)
    NP = sales − refunds − ads − cogs − gateway
    USD cash view = each EUR figure × fx_eur_usd (informational).
    """
    # Pre-launch dates: strip ad spend + Klaviyo (different store on same TW account)
    if target < LAUNCH_DATE:
        raw_metrics = dict(raw_metrics or {})
        for k in (
            "fb_ads_spend", "tiktok_spend",
            "googleAdsSpend", "googleSpend", "ga_adCost",
            "googleAdsPurchaseValue", "googleAdsConversionValue", "googleAdsConvValue",
            "ga_purchaseValue", "ga_conversionValue",
            "googleAdsPurchases", "googleAdsConversions", "googleAdsConv", "ga_conversions",
            "fb_ads_purchase_roas", "tiktok_complete_payment_roas",
            "blendedAds", "totalAdSpend",
            "klaviyoPlacedOrderSales", "totalKlaviyoNetNewSubscribers",
            "totalKlaviyoPlacedOrderTotalPriceCampaigns",
            "totalKlaviyoPlacedOrderTotalPriceFlows",
            "totalKlaviyoPlacedOrder", "klaviyoPlacedOrder",
            "klaviyoPlacedOrderUniqueOrders", "klaviyoPlacedOrders", "totalKlaviyoPlacedOrders",
        ):
            raw_metrics[k] = 0.0

    valid = [o for o in orders if not o.get("_is_reshipment")]

    # ── Subscriptions (Kaching tags) ─────────────────────────────────
    def _tags(o):
        return [t.strip().lower() for t in (o.get("tags") or "").split(",") if t.strip()]
    sub_orders   = [o for o in valid if any("subscription" in t for t in _tags(o))]
    sub_first    = [o for o in sub_orders if any("first order" in t for t in _tags(o))]
    sub_recur    = [o for o in sub_orders if o not in sub_first]
    sub_canc     = [o for o in sub_orders if o.get("cancelled_at")]
    subs_revenue       = sum(float(o.get("total_price") or 0) for o in sub_orders)
    subs_first_revenue = sum(float(o.get("total_price") or 0) for o in sub_first)
    subs_recur_revenue = sum(float(o.get("total_price") or 0) for o in sub_recur)

    sales        = sum(o["total_price"] for o in valid)
    presentment  = sum(o.get("presentment_usd", 0.0) for o in valid)  # actual USD charged
    orders_count = len(valid)
    taxes        = sum(o["total_tax"] for o in valid)
    discounts    = sum(o["total_discounts"] for o in valid)
    ship_revenue = sum(o["total_shipping"] for o in valid)
    refunds      = float(refunds_total or 0.0)
    # Gateway: Shopify GraphQL returns real Shopify Payments per-tx fees.
    # PayPal gateway: real fees extracted from transaction receiptJson (see
    # shopify_client.get_fees_for_orders_graphql). Imputation from config
    # `payment_gateway_fees.paypal` is a fallback for missing receiptJson.
    _pp_rate = float((((_CFG.get("finance") or {}).get("payment_gateway_fees") or {}).get("paypal") or 0.0))
    def _is_paypal(o) -> bool:
        gws = o.get("payment_gateway_names") or []
        if isinstance(gws, list):
            gws = " ".join(str(g) for g in gws)
        return "paypal" in str(gws).lower()
    def _order_fee(o):
        oid = o.get("id")
        f = float(fees.get(int(oid), 0.0)) if oid else 0.0
        if f == 0.0 and _pp_rate > 0 and _is_paypal(o):
            f = float(o.get("total_price") or 0.0) * _pp_rate
        return f

    # Split gateway by payment gateway (Shopify Payments vs PayPal) and track
    # per-bucket revenue + orders for accurate per-bucket fee% calcs.
    sp_rev = 0.0; sp_gw = 0.0; sp_n = 0
    pp_rev = 0.0; pp_gw = 0.0; pp_n = 0
    for o in valid:
        amt = float(o.get("total_price") or 0.0)
        f   = _order_fee(o)
        if _is_paypal(o):
            pp_rev += amt; pp_gw += f; pp_n += 1
        else:
            sp_rev += amt; sp_gw += f; sp_n += 1
    gateway = sp_gw + pp_gw
    aov          = (sales / orders_count) if orders_count else 0.0

    # Ads from TW
    fb     = float(raw_metrics.get("fb_ads_spend") or 0.0)
    tt     = float(raw_metrics.get("tiktok_spend") or 0.0)
    google = float(
        raw_metrics.get("googleAdsSpend")
        or raw_metrics.get("googleSpend")
        or raw_metrics.get("ga_adCost")
        or 0.0
    )
    # Google Ads: strict purchase conversions only (TW UI "Conversion Value" / "Conversions")
    # NOT "All Conversions" — that includes view-through/cross-device and inflates numbers.
    google_revenue = float(raw_metrics.get("googleConversionValue") or 0.0)
    google_orders  = int(float(raw_metrics.get("googleConversions") or 0.0))
    google_roas = (google_revenue / google) if google > 0 else 0.0
    google_cpa  = (google / google_orders) if google_orders > 0 else 0.0
    ads_total = fb + tt + google

    # Klaviyo passthrough
    kl_sales     = float(raw_metrics.get("klaviyoPlacedOrderSales") or 0.0)
    kl_subs_new  = float(raw_metrics.get("totalKlaviyoNetNewSubscribers") or 0.0)
    kl_campaigns = float(raw_metrics.get("totalKlaviyoPlacedOrderTotalPriceCampaigns") or 0.0)
    kl_flows     = float(raw_metrics.get("totalKlaviyoPlacedOrderTotalPriceFlows") or 0.0)
    fb_roas      = float(raw_metrics.get("fb_ads_purchase_roas") or 0.0)
    tt_roas      = float(raw_metrics.get("tiktok_complete_payment_roas") or 0.0)

    # COGS resolution (USD-native shop example, matrix in USD):
    #   1) Supplier per-order (only when supplier enabled — off by default)
    #   2) Bundle matrix per-order (exact COGS for known primary+accessory combos)
    #   3) fixed_pct fallback on order gross for combos NOT in matrix
    cogs_eur = float(supplier.get("total_cogs") or 0.0)
    cogs_source_label = "supplier_api"
    matrix_hits = 0
    matrix_cogs = 0.0
    fallback_cogs = 0.0
    fallback_orders = 0
    by_order = supplier.get("by_order") or {}
    matched_cogs = 0.0
    matched_orders = 0
    if cogs_eur == 0.0:
        # Per-order resolution: matrix first, then fixed_pct fallback
        for o in valid:
            c, b = _count_primary_accessory(o)
            key = (c, b)
            gross = float(o.get("total_price") or 0.0)
            if COGS_BUNDLE_MATRIX and key in COGS_BUNDLE_MATRIX:
                matrix_cogs += COGS_BUNDLE_MATRIX[key]
                matrix_hits += 1
            elif COGS_FIXED_PCT > 0:
                fallback_cogs += max(0.0, gross) * COGS_FIXED_PCT
                fallback_orders += 1
        # Matrix values are USD-native (payout currency). Convert to EUR
        # to align with cogs_eur unit before summing with EUR-native fallback.
        matrix_cogs_eur = (matrix_cogs / fx_eur_usd) if fx_eur_usd else matrix_cogs
        cogs_eur = matrix_cogs_eur + fallback_cogs
        if matrix_hits and fallback_orders:
            cogs_source_label = (
                f"matrix({matrix_hits})+fixed_pct_{int(COGS_FIXED_PCT*100)}({fallback_orders})"
            )
        elif matrix_hits:
            cogs_source_label = f"matrix({matrix_hits})"
        elif fallback_orders:
            cogs_source_label = f"fixed_pct_{int(COGS_FIXED_PCT*100)}({fallback_orders})"
        else:
            cogs_source_label = "no_orders"
    else:
        # Supplier path — keep legacy by-order diagnostics
        for o in valid:
            nm = o.get("name") or ""
            if nm in by_order:
                matched_cogs += by_order[nm]
                matched_orders += 1

    # xlsx Daily override (Drive Giornalieri) — authoritative source when present.
    # Overrides COGS + Gateway to match the daily COGS_DD_MM_YYYY.xlsx exactly.
    xlsx_used = False
    xlsx_meta = None
    try:
        xlsx_data = xlsx_daily_reader.get_overrides(target)
    except Exception as e:
        print(f"[dashboard] xlsx override error {target}: {e}", flush=True)
        xlsx_data = None
    if xlsx_data:
        # The daily report xlsx is EUR-native (report.currency = EUR).
        # The reader's *_usd keys hold the EUR figures verbatim — use directly,
        # NO fx division (the closed P&L is the source of truth).
        cogs_x = xlsx_data.get("cogs_usd")      # EUR
        gw_x   = xlsx_data.get("gateway_usd")   # EUR
        net_x  = xlsx_data.get("net_usd")       # EUR (EXACT NET)
        if cogs_x is not None:
            cogs_eur = float(cogs_x)
        if gw_x is not None:
            new_gateway = float(gw_x)
            # Scale per-bucket gateway to match xlsx total (preserves SP/PayPal split).
            if gateway > 0:
                ratio = new_gateway / gateway
                sp_gw *= ratio
                pp_gw *= ratio
            gateway = new_gateway
        # Client treats `accounting_xlsx` as the EXACT (closed P&L) source.
        cogs_source_label = "accounting_xlsx"
        xlsx_used = True
        xlsx_meta = {
            "source_file": xlsx_data.get("_source_file"),
            "cogs_eur": cogs_x,
            "gateway_eur": gw_x,
            "net_eur": net_x,
        }

    # Net profit & ROAS
    np_eur = sales - refunds - ads_total - cogs_eur - gateway
    # xlsx Daily authoritative net override (matches xlsx EXACT NET 1:1).
    # xlsx already includes revenue + ads + cogs + gateway from the daily P&L
    # so its net is the source of truth. LK ads_total / sales may diverge by
    # FX or TW vs Meta-direct, so we trust the xlsx net.
    if xlsx_used and xlsx_meta and xlsx_meta.get("net_eur") is not None:
        np_eur = float(xlsx_meta["net_eur"])

    # ── Manual fixed costs: apply this month's total / days-in-month to each day ──
    fixed_day_eur = 0.0
    try:
        usd_eur = (1.0 / fx_eur_usd) if fx_eur_usd else 0.864
        ym = target.strftime("%Y-%m")
        import calendar as _cal
        dim = _cal.monthrange(target.year, target.month)[1]
        eff, _src = _fc_effective(_load_fixed_costs(), ym)
        month_total = 0.0
        for fc in eff:
            amt = float(fc.get("amount") or 0)
            month_total += amt * usd_eur if fc.get("currency") == "USD" else amt
        fixed_day_eur = round(month_total / dim, 2) if dim else 0.0
    except Exception as e:
        print(f"[fixed_costs] apply error: {e}", flush=True)

    # np_eur = Operating Net (NO fixed costs). net_after_fixed subtracts them.
    net_after_fixed = round(np_eur - fixed_day_eur, 2)
    nm     = (np_eur / sales) if sales > 0 else 0.0
    roas   = (sales / ads_total) if ads_total > 0 else 0.0

    # USD parallel view (informational — based on EUR×rate, not real Stripe payout)
    usd = (lambda v: round(v * fx_eur_usd, 2)) if fx_eur_usd else (lambda v: 0.0)

    # ── Real-cash USD model ────────────────────────────────────────
    # When the bank receives USD via Stripe payouts. The actual cash entering:
    #   Bank inflow  = customer charges (presentment_usd, real)
    #                  − gateway fees (Stripe takes from USD payout)
    #                  − refunds (Stripe returns to customer in USD)
    # External business costs (ads, cogs) are paid in EUR from EUR account, not USD.
    # So `bank_cash_usd` = pure USD bank deposit per day.
    gateway_usd_real = round(gateway * fx_eur_usd, 2) if fx_eur_usd else 0.0
    refunds_usd_real = round(refunds * fx_eur_usd, 2) if fx_eur_usd else 0.0
    bank_cash_usd    = round(presentment - gateway_usd_real - refunds_usd_real, 2)
    # FX delta: difference between Shopify's EUR→USD conversion and Frankfurter mid-rate
    # (positive = shop_currency conversion gained vs spot). Indicative only.
    expected_eur_at_fx = (presentment / fx_eur_usd) if fx_eur_usd else 0.0
    fx_delta_eur = round(sales - expected_eur_at_fx, 2)

    return {
        "source":            "Shopify+TW(ads/klaviyo)+Supplier(cogs)",
        "start_date":        target.isoformat(),
        "end_date":          target.isoformat(),
        # Sales / orders / aov (EUR canonical)
        "purchase_value":    round(sales, 2),
        "purchases":         orders_count,
        "aov":               round(aov, 2),
        "shipping_revenue":  round(ship_revenue, 2),
        "taxes":             round(taxes, 2),
        "discounts":         round(discounts, 2),
        # Costs
        "spend_eur":         round(ads_total, 2),
        "facebook_spend":    round(fb, 2),
        "tiktok_spend":      round(tt, 2),
        "google_spend":      round(google, 2),
        "google_revenue":    round(google_revenue, 2),
        "google_orders":     google_orders,
        "_schema":           "google_strict_v1",
        "google_roas":       round(google_roas, 4),
        "google_cpa":        round(google_cpa, 2),
        "cogs_eur":          round(cogs_eur, 2),
        "fixed_costs_day":   round(fixed_day_eur, 2),
        "net_after_fixed":   net_after_fixed,
        "cogs_source":       cogs_source_label,
        "xlsx_override":     xlsx_used,
        "xlsx_meta":         xlsx_meta,
        "cogs_matrix_hits":  matrix_hits,
        "cogs_matrix_usd":   round(matrix_cogs, 2),
        "cogs_fallback_orders": fallback_orders,
        "cogs_fallback_usd": round(fallback_cogs, 2),
        "cogs_matched_orders": matched_orders,
        "cogs_supplier_orders": supplier.get("orders", 0),
        "gateway_costs":     round(gateway, 2),
        "gateway_sp_costs":  round(sp_gw, 2),
        "gateway_sp_rev":    round(sp_rev, 2),
        "gateway_sp_orders": sp_n,
        "gateway_pp_costs":  round(pp_gw, 2),
        "gateway_pp_rev":    round(pp_rev, 2),
        "gateway_pp_orders": pp_n,
        "refunds":           round(refunds, 2),
        # Profit
        "net_profit":        round(np_eur, 2),
        "net_margin":        round(nm, 4),
        # ROAS
        "roas":              round(roas, 4),
        "roas_blended":      round(roas, 4),
        "roas_attributed":   round(roas, 4),
        # USD parallel cash view
        "fx_eur_usd":        round(fx_eur_usd, 5),
        "presentment_usd":   round(presentment, 2),  # actual USD charged at checkout
        "purchase_value_usd": usd(sales),
        "spend_usd":         usd(ads_total),
        "cogs_usd":          usd(cogs_eur),
        "gateway_usd":       usd(gateway),
        "gateway_sp_usd":    usd(sp_gw),
        "gateway_pp_usd":    usd(pp_gw),
        "refunds_usd":       usd(refunds),
        "net_profit_usd":    round(float(xlsx_meta["net_usd"]), 2) if (xlsx_used and xlsx_meta and xlsx_meta.get("net_usd") is not None) else usd(np_eur),
        # ── Real bank cash USD (what actually deposits via Stripe payouts) ──
        "bank_cash_usd":     bank_cash_usd,
        "fx_delta_eur":      fx_delta_eur,
        # Channel-level
        "channels": {
            "meta":   {"platform": "Meta Ads", "spend_eur": round(fb, 2),     "roas": round(fb_roas, 4)},
            "tiktok": {"platform": "TikTok",   "spend_eur": round(tt, 2),     "roas": round(tt_roas, 4)},
            "google": {"platform": "Google",   "spend_eur": round(google, 2), "roas": 0},
            "other":  {"platform": "Other",    "spend_eur": 0.0,              "roas": 0},
        },
        # Klaviyo
        "klaviyo_sales":      round(kl_sales, 2),
        "klaviyo_new_subs":   round(kl_subs_new, 0),
        "klaviyo_campaigns":  round(kl_campaigns, 2),
        "klaviyo_flows":      round(kl_flows, 2),
        # ── Subscriptions (Kaching tags from Shopify) ──
        "subs_total":         len(sub_orders),
        "subs_new":           len(sub_first),
        "subs_recurring":     len(sub_recur),
        "subs_cancelled":     len(sub_canc),
        "subs_revenue":       round(subs_revenue, 2),
        "subs_first_revenue": round(subs_first_revenue, 2),
        "subs_recurring_revenue": round(subs_recur_revenue, 2),
        # Failed/Paused require Shopify scope `read_own_subscription_contracts`
        # (may be DENIED on the store's token). Set to None to render as N/A.
        "subs_failed":        None,
        "subs_paused":        None,
    }


def _norm_order_no(s: str) -> str:
    """Strip leading 'B#' / '#' for cross-system order matching."""
    return re.sub(r"^[B#]+", "", str(s or "").strip(), flags=re.IGNORECASE)


# ── Supplier A COGS range computation (real fulfilled + estimated pending) ─────
_supplier_a_cogs_cache: dict[str, tuple[float, dict]] = {}
_SUPPLIER_A_COGS_TTL = 300.0  # 5min


def compute_cogs_supplier_a_range(start: date, end: date) -> dict:
    """Return {totals, bundles, rows} for Supplier A COGS in [start,end].

    Rows are:
      - source=supplier_a_fulfilled : Supplier A state==4 (real per-order USD COGS)
      - source=supplier_a_pending   : Supplier A matched but state<4 (still real per-order COGS)
      - source=estimated    : Shopify order NOT pushed to Supplier A yet → estimate
                              from per-bundle average of FULFILLED rows
                              (fallback to global avg when bundle unseen).
    """
    cache_key = f"{start.isoformat()}_{end.isoformat()}"
    now = time.time()
    cached = _supplier_a_cogs_cache.get(cache_key)
    if cached and (now - cached[0] < _SUPPLIER_A_COGS_TTL):
        return cached[1]

    adapter = get_supplier_a_adapter()
    supplier_rows: list = []
    if adapter and adapter.enabled:
        try:
            supplier_rows = adapter.fetch_orders_range(start, end)
        except Exception as e:
            print(f"[dashboard] Supplier A fetch_orders_range failed: {e}", flush=True)

    # Iterate days, collect Shopify orders + bucket by day for `estimated` rows.
    days = []
    d = start
    while d <= end:
        days.append(d)
        d += timedelta(days=1)

    shop_by_day: dict[str, list] = {}
    shop_by_norm_name: dict[str, dict] = {}
    for day in days:
        p = _orders_cache_path(day)
        if not p.exists():
            continue
        try:
            day_orders = json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            continue
        shop_by_day[day.isoformat()] = day_orders
        for so in day_orders:
            n = _norm_order_no(so.get("name") or "")
            if n:
                shop_by_norm_name[n] = so

    # Build per-bundle real samples from FULFILLED Supplier A rows.
    bundle_real: dict[tuple[int, int], list[float]] = defaultdict(list)
    matched_shop_ids: set = set()
    supplier_enriched: list[dict] = []  # Supplier A rows + matched (primaries,accessories)

    for supplier_a in supplier_rows:
        n = _norm_order_no(supplier_a.get("order") or "")
        so = shop_by_norm_name.get(n) if n else None
        c, b = _count_primary_accessory(so) if so else (0, 0)
        if so and so.get("id") is not None:
            matched_shop_ids.add(so.get("id"))
        if supplier_a.get("fulfilled") and (c or b):
            bundle_real[(c, b)].append(float(supplier_a.get("cogs_usd") or 0.0))
        supplier_enriched.append({"_supplier_a": supplier_a, "_so": so, "_cb": (c, b)})

    # Per-bundle avg + global avg (USD).
    bundle_avg: dict[tuple[int, int], float] = {}
    for k, vals in bundle_real.items():
        if vals:
            bundle_avg[k] = round(sum(vals) / len(vals), 2)
    flat = [v for vs in bundle_real.values() for v in vs]
    global_avg = round(sum(flat) / len(flat), 2) if flat else 0.0

    fx_rate_now = fx.eur_to_usd(end) if fx else 1.0
    fx_rate_now = float(fx_rate_now or 1.0)

    def _eur(usd: float) -> float:
        return round(usd / fx_rate_now, 2) if fx_rate_now else 0.0

    rows_out: list[dict] = []

    # Emit Supplier A rows (real cogs)
    for item in supplier_enriched:
        supplier_a = item["_supplier_a"]; so = item["_so"]; (c, b) = item["_cb"]
        usd = float(supplier_a.get("cogs_usd") or 0.0)
        rows_out.append({
            "date":     supplier_a.get("date") or "",
            "order":    supplier_a.get("order") or "",
            "primaries":   c,
            "accessories":  b,
            "items":    int(supplier_a.get("items") or 0),
            "country":  supplier_a.get("country") or "",
            "cogs_usd": round(usd, 2),
            "cogs_eur": _eur(usd),
            "source":   "supplier_a_fulfilled" if supplier_a.get("fulfilled") else "supplier_a_pending",
            "state":    supplier_a.get("state"),
            "matched_shopify": bool(so),
        })

    # Emit estimated rows for Shopify orders not yet in Supplier A.
    for iso, day_orders in shop_by_day.items():
        for so in day_orders:
            oid = so.get("id")
            if oid in matched_shop_ids:
                continue
            if so.get("_is_reshipment"):
                continue
            c, b = _count_primary_accessory(so)
            key = (c, b)
            est_usd = bundle_avg.get(key, global_avg)
            est_source = "estimated" if (c or b) else "estimated_empty"
            rows_out.append({
                "date":     iso,
                "order":    so.get("name") or "",
                "primaries":   c,
                "accessories":  b,
                "items":    c + b,
                "country":  (so.get("shipping_address") or {}).get("country_code") or "",
                "cogs_usd": round(est_usd, 2),
                "cogs_eur": _eur(est_usd),
                "source":   est_source,
                "state":    None,
                "matched_shopify": True,
                "bundle_samples": len(bundle_real.get(key, [])),
            })

    rows_out.sort(key=lambda r: (r["date"], r["order"]), reverse=True)

    fulfilled = [r for r in rows_out if r["source"] == "supplier_a_fulfilled"]
    pending   = [r for r in rows_out if r["source"] == "supplier_a_pending"]
    estimated = [r for r in rows_out if r["source"].startswith("estimated")]

    def _sum(rs, k): return round(sum(float(r.get(k) or 0.0) for r in rs), 2)

    bundles_table = []
    # Union of bundle keys (real + estimated keys seen)
    est_keys = {(r["primaries"], r["accessories"]) for r in estimated}
    all_keys = sorted(set(bundle_real.keys()) | est_keys)
    for (c, b) in all_keys:
        vals = bundle_real.get((c, b), [])
        est_count = sum(1 for r in estimated if r["primaries"] == c and r["accessories"] == b)
        bundles_table.append({
            "key":       f"{c}_{b}",
            "label":     f"{c}c × {b}b" if (c or b) else "—",
            "primaries":    c,
            "accessories":   b,
            "samples":   len(vals),
            "avg_usd":   round(sum(vals) / len(vals), 2) if vals else None,
            "min_usd":   round(min(vals), 2) if vals else None,
            "max_usd":   round(max(vals), 2) if vals else None,
            "est_count": est_count,
        })

    result = {
        "start":   start.isoformat(),
        "end":     end.isoformat(),
        "fx_rate": round(fx_rate_now, 4) if fx_rate_now else None,
        "supplier_a_enabled": SUPPLIER_A_ON,
        "supplier_a_error":   _supplier_a_init_error,
        "totals": {
            "fulfilled_count": len(fulfilled),
            "pending_count":   len(pending),
            "estimated_count": len(estimated),
            "fulfilled_usd":   _sum(fulfilled, "cogs_usd"),
            "pending_usd":     _sum(pending,   "cogs_usd"),
            "estimated_usd":   _sum(estimated, "cogs_usd"),
            "total_usd":       _sum(rows_out,  "cogs_usd"),
            "fulfilled_eur":   _sum(fulfilled, "cogs_eur"),
            "pending_eur":     _sum(pending,   "cogs_eur"),
            "estimated_eur":   _sum(estimated, "cogs_eur"),
            "total_eur":       _sum(rows_out,  "cogs_eur"),
        },
        "bundles":        bundles_table,
        "global_avg_usd": global_avg,
        "rows":           rows_out,
    }
    _supplier_a_cogs_cache[cache_key] = (now, result)
    return result


def fetch_day(client, shopify: ShopifyClient, target: date) -> tuple[dict, dict]:
    """Single-branch: Shopify + (TW) + (Supplier) + (FX)."""
    raw_metrics: dict = {}
    if client is not None:
        try:
            raw = client._fetch_summary(target, target)
            raw_metrics = client._metrics_to_dict(raw) if raw else {}
        except Exception as e:
            print(f"[dashboard] {target} TW fetch failed: {e}")

    orders = get_orders_for_day(shopify, target)
    fees = {}
    try:
        fees = get_fees_for_day(shopify, target, [o["id"] for o in orders if o.get("id")])
    except Exception as e:
        print(f"[dashboard] {target} fees fetch failed: {e}")
    refunds_total = get_refunds_for_day(shopify, target)
    supplier = cogs_src.get_day(target) if cogs_src else {"orders": 0, "cogs_eur": 0.0, "by_order": {}}
    fx_rate = fx.eur_to_usd(target) if fx else 1.0

    parsed = compute_day_metrics(
        orders, fees, raw_metrics, target,
        refunds_total=refunds_total, supplier=supplier, fx_eur_usd=fx_rate,
    )
    return parsed, raw_metrics


def refresh_today(client, shopify: ShopifyClient) -> None:
    t = date.today()
    parsed, raw_m = fetch_day(client, shopify, t)
    iso = t.isoformat()
    with cache.lock:
        cache.today = parsed
        cache.raw_today = raw_m
        cache.daily[iso] = parsed
        cache.raw_daily[iso] = raw_m
        cache.updated_at = datetime.now(timezone.utc).isoformat()
        cache.last_error = None
        cache.cogs_info = cogs_src.info() if cogs_src else {"source": "none"}
        cache.fx_info = fx.info() if fx else {"source": "none", "rate": 1.0}
    print(
        f"[dashboard] today {iso}: "
        f"sales=€{parsed.get('purchase_value', 0):.2f} "
        f"(${parsed.get('purchase_value_usd', 0):.2f}) "
        f"orders={parsed.get('purchases', 0)} "
        f"roas={parsed.get('roas_blended', 0):.2f} "
        f"fx={parsed.get('fx_eur_usd', 0):.4f}"
    )
    cache.save()


def refresh_daily_30(client, shopify: ShopifyClient, full: bool = False) -> None:
    today = date.today()
    fetched = 0
    for i in range(DAYS):
        d = today - timedelta(days=i)
        iso = d.isoformat()
        if not full and i > 1 and iso in cache.daily:
            cached = cache.daily.get(iso, {})
            # ponytail: re-fetch if TW spend missing (0 ads but real sales = TW gap at fetch time)
            suspicious = (cached.get("spend_eur") or 0) == 0 and (cached.get("purchase_value") or 0) > 0
            # Re-fetch if cached entry lacks new google fields (post 2026-06-07 strict-conv bump)
            if cached.get("_schema") == "google_strict_v1" and not suspicious:
                continue
        parsed, raw_m = fetch_day(client, shopify, d)
        with cache.lock:
            cache.daily[iso] = parsed
            cache.raw_daily[iso] = raw_m
        fetched += 1
        time.sleep(0.15)
    if fetched:
        print(f"[dashboard] backfill {DAYS}d → {fetched} day(s) refetched")
        cache.save()


def get_cc_kpis() -> dict:
    """Proxy the CC agent's token-gated /api/cc-report (KPIs + Claude-written
    analysis, generated by the Claude that already lives in the CC service).
    No login: gated by CC_REPORT_TOKEN. 5min cached (Claude call is slow)."""
    now = time.time()
    if _cc_cache["data"] is not None and now - _cc_cache["ts"] < 300:
        return _cc_cache["data"]
    url = f"{CC_URL}/api/cc-report?token={urllib.parse.quote(CC_REPORT_TOKEN)}"
    with urllib.request.urlopen(url, timeout=60) as r:
        rep = json.loads(r.read().decode())
    ins = rep.get("insights") or {}
    stats = rep.get("stats") or []
    sent = ins.get("total_sent") or 0
    perfect = ins.get("perfect_drafts") or 0
    data = {
        "total_drafts": ins.get("total_drafts") or 0,
        "total_sent": sent,
        "total_discarded": ins.get("total_discarded") or 0,
        "avg_similarity": ins.get("avg_similarity") or 0,
        "perfect_drafts": perfect,
        "perfect_pct": round(perfect / sent * 100) if sent else 0,
        "categories": sorted(stats, key=lambda c: c.get("total", 0), reverse=True),
        "ops": rep.get("ops") or {},
        "analysis": rep.get("analysis") or "",
    }
    _cc_cache["ts"] = now
    _cc_cache["data"] = data
    return data


_shopify_client: ShopifyClient | None = None
_tw_client: TripleWhaleClient | None = None
_client_lock = threading.Lock()


def get_client():
    global _tw_client
    if not TW_ON:
        return None
    with _client_lock:
        if _tw_client is None:
            cfg = load_config()
            _tw_client = TripleWhaleClient(cfg)
        return _tw_client


def get_shopify() -> ShopifyClient:
    global _shopify_client
    with _client_lock:
        if _shopify_client is None:
            cfg = load_config()
            _shopify_client = ShopifyClient(cfg)
        return _shopify_client


def poller() -> None:
    client = get_client()
    shopify = get_shopify()
    # Initial costs sheet pull (background thread also covers this, but we want
    # it warm before first poll tick).
    try:
        costs_cache.refresh()
    except Exception as e:
        print(f"[dashboard] costs initial refresh error: {e}")
    try:
        refresh_daily_30(client, shopify, full=True)
    except Exception as e:
        with cache.lock:
            cache.last_error = f"backfill: {e}"
        print(f"[dashboard] backfill error: {e}")

    last_daily = time.time()
    while True:
        try:
            refresh_today(client, shopify)
            # Sync costs sheet on every poll tick (2 min) so cost edits in
            # the COSTI 2026 Google Sheet show up live on the dashboard.
            try:
                costs_cache.refresh()
            except Exception as e:
                print(f"[dashboard] costs refresh error: {e}")
            if time.time() - last_daily > DAILY_REFRESH_SEC:
                refresh_daily_30(client, shopify, full=False)
                last_daily = time.time()
        except Exception as e:
            with cache.lock:
                cache.last_error = f"poll: {e}"
            print(f"[dashboard] poll error: {e}")
        time.sleep(TODAY_REFRESH_SEC)


def _b64url(b: bytes) -> str:
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode("ascii")


def _b64url_decode(s: str) -> bytes:
    pad = "=" * (-len(s) % 4)
    return base64.urlsafe_b64decode(s + pad)


def _sign_token(user: str, ttl: int = SESSION_TTL_SEC) -> str:
    expiry = int(time.time()) + ttl
    payload = f"{user}|{expiry}".encode("utf-8")
    sig = hmac.new(SESSION_SECRET.encode("utf-8"), payload, hashlib.sha256).digest()
    return f"{_b64url(payload)}.{_b64url(sig)}"


def _verify_token(token: str) -> str | None:
    if not token or "." not in token:
        return None
    try:
        p_b64, s_b64 = token.split(".", 1)
        payload = _b64url_decode(p_b64)
        sig = _b64url_decode(s_b64)
    except Exception:
        return None
    expected = hmac.new(SESSION_SECRET.encode("utf-8"), payload, hashlib.sha256).digest()
    if not hmac.compare_digest(sig, expected):
        return None
    try:
        user, expiry_str = payload.decode("utf-8").split("|", 1)
        if int(expiry_str) < int(time.time()):
            return None
        return user
    except Exception:
        return None


_PUBLIC_PATHS = {"/healthz", "/login", "/logout", "/favicon.ico"}


def _is_public(path: str) -> bool:
    return path.split("?", 1)[0] in _PUBLIC_PATHS


LOGIN_HTML = """<!doctype html>
<html lang="en"><head>
<meta charset="utf-8">
<title>FinanceKPI Dashboard</title>
<meta name="viewport" content="width=device-width,initial-scale=1">
<style>
  :root { color-scheme: dark; }
  * { box-sizing: border-box; }
  body { margin: 0; min-height: 100vh; display: grid; place-items: center;
         background: #0a0a0a; color: #e8e8e8;
         font: 14px/1.5 -apple-system, BlinkMacSystemFont, 'SF Pro Text', system-ui, sans-serif; }
  .card { width: 320px; padding: 28px; background: #131313; border: 1px solid #232323;
          border-radius: 14px; box-shadow: 0 8px 40px rgba(0,0,0,.5); }
  h1 { margin: 0 0 4px; font-size: 18px; letter-spacing: .02em; font-weight: 600; }
  p.sub { margin: 0 0 22px; color: #888; font-size: 12px; }
  label { display: block; font-size: 11px; color: #999; text-transform: uppercase;
          letter-spacing: .08em; margin: 14px 0 6px; }
  input { width: 100%; padding: 10px 12px; background: #0a0a0a; border: 1px solid #2a2a2a;
          border-radius: 8px; color: #fff; font: inherit; outline: none; }
  input:focus { border-color: #c89968; }
  button { width: 100%; margin-top: 18px; padding: 11px; background: #c89968; color: #0a0a0a;
           border: 0; border-radius: 8px; font: inherit; font-weight: 600; cursor: pointer; }
  button:hover { background: #d8a878; }
  .err { margin: 14px 0 0; padding: 10px 12px; background: #2a1414; border: 1px solid #5a2424;
         border-radius: 8px; color: #ff8b8b; font-size: 12px; }
</style>
</head><body>
<form class="card" method="POST" action="/login">
  <h1>FinanceKPI Dashboard</h1>
  <p class="sub">Sign in to continue</p>
  __ERROR__
  <label for="u">User</label>
  <input id="u" name="user" autocomplete="username" autofocus required>
  <label for="p">Password</label>
  <input id="p" name="pass" type="password" autocomplete="current-password" required>
  <button type="submit">Sign in</button>
</form>
</body></html>
"""


def _render_login(error: str | None = None) -> bytes:
    err_html = f'<div class="err">{error}</div>' if error else ""
    return LOGIN_HTML.replace("__ERROR__", err_html).encode("utf-8")


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *args, **kwargs) -> None:
        return

    # ── session helpers ───────────────────────────────────────────────────
    def _session_user(self) -> str | None:
        cookie = self.headers.get("Cookie", "")
        for part in cookie.split(";"):
            k, _, v = part.strip().partition("=")
            if k == SESSION_COOKIE:
                return _verify_token(v)
        return None

    def _set_session_cookie(self, token: str) -> str:
        return (
            f"{SESSION_COOKIE}={token}; Path=/; Max-Age={SESSION_TTL_SEC}; "
            f"HttpOnly; Secure; SameSite=Lax"
        )

    def _clear_session_cookie(self) -> str:
        return f"{SESSION_COOKIE}=; Path=/; Max-Age=0; HttpOnly; Secure; SameSite=Lax"

    def _check_auth(self) -> bool:
        if not AUTH_ENABLED or _is_public(self.path):
            return True
        if self._session_user():
            return True
        if self.path.startswith("/api/"):
            self.send_response(401)
            self.send_header("Content-Length", "0")
            self.end_headers()
            return False
        self.send_response(302)
        self.send_header("Location", "/login")
        self.send_header("Content-Length", "0")
        self.end_headers()
        return False

    # ── routes ────────────────────────────────────────────────────────────
    def do_GET(self) -> None:
        if self.path.split("?", 1)[0] == "/login":
            self._serve_login()
            return
        if self.path == "/logout":
            self._handle_logout()
            return
        if not self._check_auth():
            return
        if self.path in ("/", "/index.html"):
            self._send_file("index.html", "text/html; charset=utf-8")
        elif self.path == "/api/metrics":
            body = json.dumps(cache.snapshot(), default=str).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/api/refresh":
            try:
                refresh_today(get_client(), get_shopify())
                ok, err = True, None
            except Exception as e:
                ok, err = False, str(e)
            body = json.dumps({"ok": ok, "error": err, "snapshot": cache.snapshot()}, default=str).encode("utf-8")
            self.send_response(200 if ok else 500)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/api/refresh-all":
            # Force full 30d backfill (re-fetches every cached day)
            try:
                refresh_daily_30(get_client(), get_shopify(), full=True)
                refresh_today(get_client(), get_shopify())
                ok, err = True, None
            except Exception as e:
                ok, err = False, str(e)
            body = json.dumps({"ok": ok, "error": err, "days_refreshed": DAYS, "snapshot": cache.snapshot()}, default=str).encode("utf-8")
            self.send_response(200 if ok else 500)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/healthz":
            body = b"ok"
            self.send_response(200)
            self.send_header("Content-Type", "text/plain")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        elif self.path == "/favicon.ico":
            self.send_response(204)
            self.send_header("Content-Length", "0")
            self.end_headers()
        elif self.path.split("?", 1)[0] == "/api/debug-orders":
            # Per-order breakdown for one date (default yesterday): gateway, gross, fee, fee%, country.
            try:
                qs = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
                target = date.fromisoformat(qs.get("date", [""])[0]) if qs.get("date") else date.today() - timedelta(days=1)
                shopify = get_shopify()
                orders = get_orders_for_day(shopify, target)
                fees = {}
                try:
                    fees = get_fees_for_day(shopify, target, [o["id"] for o in orders if o.get("id")])
                except Exception as e:
                    print(f"[debug-orders] fees fetch failed: {e}")
                rows = []
                sp_rev = sp_fee = 0.0; sp_n = 0
                pp_rev = pp_fee = 0.0; pp_n = 0
                for o in orders:
                    if o.get("_is_reshipment"):
                        continue
                    oid = o.get("id")
                    gross = float(o.get("total_price") or 0.0)
                    fee = float(fees.get(int(oid), 0.0)) if oid else 0.0
                    gw_name = (o.get("gateway") or "")
                    payment_gws = o.get("payment_gateway_names") or []
                    is_pp = ("paypal" in str(gw_name).lower()) or any("paypal" in str(g).lower() for g in payment_gws)
                    country = ((o.get("billing_address") or {}).get("country_code")
                               or (o.get("shipping_address") or {}).get("country_code") or "—")
                    fee_pct = (fee / gross * 100) if gross > 0 else 0.0
                    rows.append({
                        "order_no":   o.get("name") or o.get("order_number"),
                        "gross_eur":  round(gross, 2),
                        "fee_eur":    round(fee, 2),
                        "fee_pct":    round(fee_pct, 3),
                        "gateway":    "paypal" if is_pp else (gw_name or "shopify_payments"),
                        "country":    country,
                        "currency":   o.get("currency"),
                        "presentment_currency": (o.get("presentment_currency_rate") and o.get("currency")) or "—",
                    })
                    if is_pp:
                        pp_rev += gross; pp_fee += fee; pp_n += 1
                    else:
                        sp_rev += gross; sp_fee += fee; sp_n += 1
                payload = {
                    "date": target.isoformat(),
                    "total_orders": len(rows),
                    "sp_summary":   {"orders": sp_n, "rev_eur": round(sp_rev, 2), "fee_eur": round(sp_fee, 2), "fee_pct": round(sp_fee/sp_rev*100, 3) if sp_rev > 0 else 0},
                    "pp_summary":   {"orders": pp_n, "rev_eur": round(pp_rev, 2), "fee_eur": round(pp_fee, 2), "fee_pct": round(pp_fee/pp_rev*100, 3) if pp_rev > 0 else 0},
                    "blended_fee_pct": round((sp_fee+pp_fee)/(sp_rev+pp_rev)*100, 3) if (sp_rev+pp_rev) > 0 else 0,
                    "rows": rows,
                }
                body = json.dumps(payload, default=str, indent=2).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception as e:
                body = json.dumps({"error": str(e)}).encode("utf-8")
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
        elif self.path.split("?", 1)[0] == "/api/tw-raw":
            # Debug: dump raw TW metrics for a target date (default: yesterday).
            try:
                qs = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
                target = date.fromisoformat(qs.get("date", [""])[0]) if qs.get("date") else date.today() - timedelta(days=1)
                client = get_client()
                raw = client._fetch_summary(target, target)
                metrics = client._metrics_to_dict(raw) if raw else {}
                google_keys = {k: v for k, v in metrics.items() if "oogle" in k or k.lower().startswith("ga_") or "googleAds" in k}
                klaviyo_keys = {k: v for k, v in metrics.items() if "laviyo" in k.lower()}
                payload = {
                    "date": target.isoformat(),
                    "total_keys": len(metrics),
                    "google_keys": google_keys,
                    "klaviyo_keys": klaviyo_keys,
                    "all_metric_ids": sorted(metrics.keys()),
                }
                body = json.dumps(payload, default=str, indent=2).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception as e:
                body = json.dumps({"error": str(e)}).encode("utf-8")
                self.send_response(500)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
        elif self.path.split("?", 1)[0] == "/api/cogs-supplier_a":
            try:
                qs = urllib.parse.parse_qs(self.path.split("?", 1)[1] if "?" in self.path else "")
                today = date.today()
                try:
                    start_d = date.fromisoformat(qs.get("start", [""])[0]) if qs.get("start") else today - timedelta(days=6)
                except Exception:
                    start_d = today - timedelta(days=6)
                try:
                    end_d = date.fromisoformat(qs.get("end", [""])[0]) if qs.get("end") else today
                except Exception:
                    end_d = today
                result = compute_cogs_supplier_a_range(start_d, end_d)
                body = json.dumps(result, default=str).encode("utf-8")
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception as e:
                self.send_error(500, f"cogs-supplier_a error: {e}")
        elif self.path == "/api/bundles":
            try:
                p = ROOT / "bundles.json"
                body = p.read_bytes() if p.exists() else b"{}"
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception as e:
                self.send_error(500, f"bundles read error: {e}")
        elif self.path == "/api/cogs-bundles":
            try:
                cogs = _CFG.get("cogs") or {}
                payload = {
                    "detail": cogs.get("matrix_detail") or {},
                    "matrix": cogs.get("matrix") or {},
                    "supplier_b": cogs.get("supplier_b") or {},
                    "source": cogs.get("_matrix_source") or "",
                }
                body = json.dumps(payload).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception as e:
                self.send_error(500, f"cogs-bundles error: {e}")
        elif self.path == "/api/fixed-costs":
            try:
                body = json.dumps({"items": _load_fixed_costs()}).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception as e:
                self.send_error(500, f"fixed-costs error: {e}")
        elif self.path == "/api/cc":
            try:
                body = json.dumps(get_cc_kpis()).encode()
                self.send_response(200)
                self.send_header("Content-Type", "application/json")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
            except Exception as e:
                body = json.dumps({"error": str(e)}).encode("utf-8")
                self.send_response(502)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                self.wfile.write(body)
        elif self.path == "/api/config/app":
            # Brand/app name for the frontend header. APP_NAME env wins, then
            # config report.company_name, then a generic fallback.
            name = os.environ.get("APP_NAME", "")
            if not name:
                try:
                    name = (_CFG.get("report", {}) or {}).get("company_name", "") if isinstance(_CFG, dict) else ""
                except Exception:
                    name = ""
            body = json.dumps({"app_name": name or "FinanceKPI"}).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        else:
            self.send_error(404)

    def do_POST(self) -> None:
        if self.path == "/login":
            self._handle_login()
            return
        if self.path == "/logout":
            self._handle_logout()
            return
        if self.path == "/api/fixed-costs/seed":
            if not self._check_auth():
                return
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                data = json.loads(self.rfile.read(length) or b"{}")
            except Exception:
                data = {}
            ym = (data.get("ym") or "")[:7]
            rows = _load_fixed_costs()
            own = [r for r in rows if (r.get("date") or "")[:7] == ym]
            if ym and not own:
                eff, _src = _fc_effective(rows, ym)
                import uuid
                first = ym + "-01"
                for r in eff:
                    rows.append({
                        "id": uuid.uuid4().hex[:10],
                        "amount": r.get("amount", 0), "currency": r.get("currency", "EUR"),
                        "date": first, "task": r.get("task", ""), "category": r.get("category", "software"),
                        "created": datetime.now(timezone.utc).isoformat(timespec="seconds"),
                    })
                _save_fixed_costs(rows)
                _reapply_fixed_to_cache()
            body = json.dumps({"ok": True, "items": rows}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        if self.path in ("/api/fixed-costs", "/api/fixed-costs/delete", "/api/fixed-costs/edit"):
            if not self._check_auth():
                return
            try:
                length = int(self.headers.get("Content-Length", "0") or 0)
                data = json.loads(self.rfile.read(length) or b"{}")
            except Exception:
                data = {}
            rows = _load_fixed_costs()

            def _norm_cur(v):
                c = (v or "EUR").upper()
                return c if c in ("EUR", "USD") else "EUR"

            def _norm_amt(v):
                try:
                    return round(float(v or 0), 2)
                except Exception:
                    return 0.0

            def _norm_cat(v):
                c = (v or "software").lower()
                return c if c in ("software", "team") else "software"

            if self.path == "/api/fixed-costs/delete":
                rows = [r for r in rows if r.get("id") != data.get("id")]
            elif self.path == "/api/fixed-costs/edit":
                for r in rows:
                    if r.get("id") == data.get("id"):
                        if "amount" in data:   r["amount"] = _norm_amt(data["amount"])
                        if "currency" in data: r["currency"] = _norm_cur(data["currency"])
                        if "date" in data:     r["date"] = (data["date"] or "")[:10]
                        if "task" in data:     r["task"] = str(data["task"] or "").strip()[:200]
                        if "category" in data: r["category"] = _norm_cat(data["category"])
                        break
            else:
                import uuid
                rows.append({
                    "id":       uuid.uuid4().hex[:10],
                    "amount":   _norm_amt(data.get("amount")),
                    "currency": _norm_cur(data.get("currency")),
                    "date":     (data.get("date") or "")[:10],
                    "task":     str(data.get("task") or "").strip()[:200],
                    "category": _norm_cat(data.get("category")),
                    "created":  datetime.now(timezone.utc).isoformat(timespec="seconds"),
                })
            _save_fixed_costs(rows)
            _reapply_fixed_to_cache()
            body = json.dumps({"ok": True, "items": rows}).encode()
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
            return
        self.send_error(404)

    # ── login / logout handlers ───────────────────────────────────────────
    def _serve_login(self, error: str | None = None, status: int = 200) -> None:
        if AUTH_ENABLED and self._session_user() and not error:
            self.send_response(302)
            self.send_header("Location", "/")
            self.send_header("Content-Length", "0")
            self.end_headers()
            return
        body = _render_login(error)
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Cache-Control", "no-store")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _handle_login(self) -> None:
        try:
            length = int(self.headers.get("Content-Length", "0") or 0)
        except ValueError:
            length = 0
        raw = self.rfile.read(length) if length > 0 else b""
        form = urllib.parse.parse_qs(raw.decode("utf-8", errors="ignore"))
        user = (form.get("user", [""])[0] or "").strip()
        pwd = form.get("pass", [""])[0] or ""
        ok_user = hmac.compare_digest(user.encode("utf-8"), AUTH_USER.encode("utf-8"))
        ok_pass = hmac.compare_digest(pwd.encode("utf-8"), AUTH_PASS.encode("utf-8"))
        if not (AUTH_ENABLED and ok_user and ok_pass):
            self._serve_login(error="Wrong user or password.", status=401)
            return
        token = _sign_token(user)
        self.send_response(302)
        self.send_header("Location", "/")
        self.send_header("Set-Cookie", self._set_session_cookie(token))
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _handle_logout(self) -> None:
        self.send_response(302)
        self.send_header("Location", "/login")
        self.send_header("Set-Cookie", self._clear_session_cookie())
        self.send_header("Content-Length", "0")
        self.end_headers()

    def _send_file(self, name: str, ctype: str) -> None:
        p = ROOT / name
        if not p.exists():
            self.send_error(404)
            return
        body = p.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        # Always serve fresh HTML/JS — avoid stale cached dashboard.
        self.send_header("Cache-Control", "no-store, must-revalidate")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)


def main() -> None:
    t = threading.Thread(target=poller, daemon=True, name="tw-poller")
    t.start()
    start_costs_refresh(costs_cache)
    httpd = ThreadingHTTPServer((HOST, PORT), Handler)
    print(f"[dashboard] http://{HOST}:{PORT}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\n[dashboard] bye")


if __name__ == "__main__":
    main()
