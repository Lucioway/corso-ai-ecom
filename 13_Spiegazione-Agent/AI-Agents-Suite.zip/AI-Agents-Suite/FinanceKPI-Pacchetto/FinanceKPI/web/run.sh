#!/usr/bin/env bash
# FinanceKPI web launcher — optionally reuses a shared venv (set VENV_DIR).
set -euo pipefail

cd "$(dirname "$0")"

# Point VENV_DIR at a venv to reuse its interpreter; otherwise system python3.
VENV_DIR="${VENV_DIR:-}"

if [ -n "$VENV_DIR" ] && [ -f "$VENV_DIR/venv/bin/python3" ]; then
  PY="$VENV_DIR/venv/bin/python3"
elif [ -n "$VENV_DIR" ] && [ -f "$VENV_DIR/.venv/bin/python3" ]; then
  PY="$VENV_DIR/.venv/bin/python3"
else
  PY="python3"
fi

echo "[FinanceKPI] using python: $PY"
exec "$PY" server.py
