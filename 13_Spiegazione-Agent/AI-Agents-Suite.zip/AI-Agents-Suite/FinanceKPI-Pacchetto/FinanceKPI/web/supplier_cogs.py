"""Supplier COGS source for the live KPI dashboard.

Pulls per-day orders from Supplier API (already aligned to the Shopify shop
currency) and aggregates COGS. Caches historical days to disk; today + yesterday
always re-fetched (late attribution / refund processing).

Wraps the report agent's SupplierDownloader — zero duplication. Optional: only
used when `supplier.enabled` is set in config.
"""
from __future__ import annotations

import json
import sys
import threading
from datetime import date
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parent
CACHE_DIR = ROOT / "cache" / "supplier"
CACHE_DIR.mkdir(parents=True, exist_ok=True)


class SupplierCogsSource:
    """Fetch + cache Supplier per-order COGS keyed by Shopify order name."""

    def __init__(self, agent_path: Path) -> None:
        self.agent_path = Path(agent_path)
        if str(self.agent_path) not in sys.path:
            sys.path.insert(0, str(self.agent_path))
        from modules.supplier_downloader import SupplierDownloader  # noqa: E402
        cfg = json.loads((self.agent_path / "config.json").read_text(encoding="utf-8"))
        self._client = SupplierDownloader(cfg)
        self._lock = threading.Lock()
        self._mem: dict[str, dict] = {}  # iso → {by_order, total_cogs, total_price, items}
        self.last_error: Optional[str] = None

    def _cache_path(self, d: date) -> Path:
        return CACHE_DIR / f"{d.isoformat()}.json"

    def _load_disk(self, d: date) -> Optional[dict]:
        p = self._cache_path(d)
        if not p.exists():
            return None
        try:
            return json.loads(p.read_text(encoding="utf-8"))
        except Exception:
            return None

    def _save_disk(self, d: date, payload: dict) -> None:
        try:
            self._cache_path(d).write_text(json.dumps(payload), encoding="utf-8")
        except Exception as e:
            print(f"[SupplierCogs] cache write {d} failed: {e}")

    def get_day(self, target: date, force: bool = False) -> dict:
        """Return aggregated metrics for `target`:
            {
              "by_order": {orderName: cogs_eur},
              "total_cogs": float (EUR, shop currency),
              "total_price": float (EUR, gross price from Supplier, sanity check),
              "items": int,
              "orders": int,
              "_complete": bool,
            }
        Today + yesterday: always re-fetch (volatile).
        """
        iso = target.isoformat()
        today = date.today()
        is_volatile = (today - target).days <= 1

        with self._lock:
            if not force and not is_volatile and iso in self._mem:
                return self._mem[iso]
        if not force and not is_volatile:
            disk = self._load_disk(target)
            if disk is not None:
                with self._lock:
                    self._mem[iso] = disk
                return disk

        if not self._client.enabled:
            self.last_error = "supplier credentials missing in config"
            return self._empty(iso)

        try:
            orders = self._client.fetch_orders_range(target, target)
        except Exception as e:
            self.last_error = f"{target}: {e}"
            print(f"[SupplierCogs] {target} fetch failed: {e}")
            return self._empty(iso)

        by_order: dict[str, float] = {}
        total_cogs = 0.0
        total_price = 0.0
        items = 0
        for o in orders or []:
            name = o.get("shopifyOrderName") or ""
            sub = 0.0
            for it in o.get("orderItems", []) or []:
                c = float(it.get("cogs") or 0.0)
                p = float(it.get("price") or 0.0)
                q = int(it.get("quantity") or 1)
                sub += c
                total_cogs += c
                total_price += p * q
                items += 1
            if name:
                by_order[name] = round(by_order.get(name, 0.0) + sub, 2)

        payload = {
            "by_order":    by_order,
            "total_cogs":  round(total_cogs, 2),
            "total_price": round(total_price, 2),
            "items":       items,
            "orders":      len(orders or []),
            "_complete":   bool(orders),
        }

        if not is_volatile:
            self._save_disk(target, payload)
        with self._lock:
            self._mem[iso] = payload
        self.last_error = None
        return payload

    def _empty(self, iso: str) -> dict:
        return {
            "by_order": {},
            "total_cogs": 0.0,
            "total_price": 0.0,
            "items": 0,
            "orders": 0,
            "_complete": False,
        }

    def info(self) -> dict:
        with self._lock:
            return {
                "loaded": True,
                "source": "supplier_api",
                "cached_days": len(self._mem),
                "last_error": self.last_error,
            }


if __name__ == "__main__":
    import os
    from datetime import timedelta
    src = SupplierCogsSource(Path(os.environ.get("FA_AGENT_PATH", "../report")))
    today = date.today()
    for i in range(7):
        d = today - timedelta(days=i)
        x = src.get_day(d)
        print(f"  {d}  orders={x['orders']:3d}  items={x['items']:3d}  "
              f"cogs=€{x['total_cogs']:>8.2f}  price=€{x['total_price']:>8.2f}")
