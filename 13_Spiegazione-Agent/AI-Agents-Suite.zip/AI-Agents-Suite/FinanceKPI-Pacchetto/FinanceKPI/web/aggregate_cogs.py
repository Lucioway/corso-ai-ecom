"""Re-aggregate per-bundle COGS from all Drive Giornalieri xlsx Orders sheets.

Parses each xlsx's `Orders DD-MM` sheet, counts primaries/accessories per order
from the Detail column, buckets by (primaries, accessories) tuple, computes
mean per-order COGS USD per bucket, and writes:
  - bundles.json (full 19-row catalog with totals + sample counts)
  - config.json["cogs"]["matrix"] (only buckets with samples)

Run from the web/ directory:
    python3 aggregate_cogs.py
"""
from __future__ import annotations

import io
import json
import re
import sys
from collections import defaultdict
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from xlsx_daily_reader import _list_folder, _download_xlsx  # noqa: E402
from openpyxl import load_workbook  # noqa: E402

ROOT = Path(__file__).resolve().parent
BUNDLES_PATH = ROOT / "bundles.json"
CONFIG_PATH = ROOT / "config.json"

UNIT_PRIMARY_USD = 2.25
UNIT_ACCESSORY_USD = 2.22

# Detail token: e.g. "1x Variant Name" or "2x Accessory Name"
TOKEN_RE = re.compile(r"(\d+)\s*[x×]\s*(.+)", re.IGNORECASE)
FX_LABEL_RE = re.compile(r"fx\s*([0-9]+(?:\.[0-9]+)?)", re.IGNORECASE)


def _accessory_re() -> re.Pattern:
    """Build the accessory-matching regex from config (cogs.title_hints.accessory).

    Configure the keyword(s) that identify the secondary/accessory line item in
    a bundle. Default is the neutral word "accessory" — edit your config to match
    your own product titles. Multiple keywords can be space-separated.
    """
    keyword = "accessory"
    try:
        if CONFIG_PATH.exists():
            cfg = json.loads(CONFIG_PATH.read_text())
            kw = ((cfg.get("cogs") or {}).get("title_hints") or {}).get("accessory")
            if kw and str(kw).strip():
                keyword = str(kw).strip()
    except Exception:
        pass
    alt = "|".join(re.escape(w) for w in keyword.split() if w) or "accessory"
    return re.compile(alt, re.IGNORECASE)


ACCESSORY_RE = _accessory_re()


def _read_fx(wb) -> float | None:
    """Pull USD→EUR fx from Analysis sheet label 'EXACT NET (EUR) — fx X.XXXX'."""
    if "Analysis" not in wb.sheetnames:
        return None
    for row in wb["Analysis"].iter_rows(values_only=True):
        if not row or row[0] is None:
            continue
        label = str(row[0]).strip()
        if label.startswith("EXACT NET (EUR)"):
            m = FX_LABEL_RE.search(label)
            if m:
                try:
                    return float(m.group(1))
                except ValueError:
                    return None
    return None


def parse_detail(detail: str) -> tuple[int, int]:
    """Return (primaries, accessories) count from a Detail cell."""
    primaries = 0
    accessories = 0
    if not detail:
        return 0, 0
    for raw in str(detail).split(";"):
        m = TOKEN_RE.match(raw.strip())
        if not m:
            continue
        qty = int(m.group(1))
        name = m.group(2).strip()
        if ACCESSORY_RE.search(name):
            accessories += qty
        else:
            primaries += qty
    return primaries, accessories


def aggregate():
    idx = _list_folder()
    dates = sorted(idx.keys())
    print(f"[aggregate_cogs] Processing {len(dates)} xlsx files: {dates[0]} → {dates[-1]}")

    # buckets store per-order (usd, eur) tuples
    buckets: dict[tuple[int, int], list[tuple[float, float]]] = defaultdict(list)
    total_orders = 0
    skipped = 0
    fx_sum = 0.0
    fx_n = 0

    for iso in dates:
        file_id, _ = idx[iso]
        try:
            xb = _download_xlsx(file_id)
            wb = load_workbook(io.BytesIO(xb), data_only=True, read_only=True)
        except Exception as e:
            print(f"  ! {iso}: download/load error {e}")
            continue
        fx = _read_fx(wb)
        if not fx:
            print(f"  ! {iso}: no fx found in Analysis — skipping")
            continue
        fx_sum += fx
        fx_n += 1
        orders_sheet = next((s for s in wb.sheetnames if s.startswith("Orders")), None)
        if not orders_sheet:
            print(f"  ! {iso}: no Orders sheet")
            continue
        ws = wb[orders_sheet]
        rows = list(ws.iter_rows(values_only=True))
        if not rows:
            continue
        header = rows[0]
        try:
            detail_i = header.index("Detail")
            cogs_i = header.index("COGS €")
        except ValueError:
            print(f"  ! {iso}: missing columns")
            continue
        day_orders = 0
        for r in rows[1:]:
            if not r or not r[0]:
                continue
            detail = r[detail_i]
            cogs = r[cogs_i]
            if cogs is None:
                skipped += 1
                continue
            try:
                cogs_usd = float(cogs)
            except (TypeError, ValueError):
                skipped += 1
                continue
            if cogs_usd <= 0:
                skipped += 1
                continue
            c, b = parse_detail(detail)
            if c == 0 and b == 0:
                skipped += 1
                continue
            cogs_eur = cogs_usd / fx
            buckets[(c, b)].append((cogs_usd, cogs_eur))
            day_orders += 1
        total_orders += day_orders
        print(f"  ✓ {iso} ({orders_sheet}): {day_orders} orders, fx {fx:.4f}")

    fx_mean = fx_sum / fx_n if fx_n else 1.0
    print(f"\n[aggregate_cogs] Total orders: {total_orders}, skipped: {skipped}")
    print(f"[aggregate_cogs] Buckets observed: {len(buckets)}, mean fx USD→EUR: {fx_mean:.4f}")
    return buckets, total_orders, dates, fx_mean


def update_bundles(buckets, total_orders, dates, fx_mean):
    # Define the full 19-row catalog
    # (row_id, display_label, product_qty, accessory_qty). Rename the labels to
    # match your own product/accessory bundles.
    catalog = [
        (1,  "1 product",                  1, 0),
        (2,  "1 product + 1 accessory",    1, 1),
        (3,  "1 product + 2 accessories",  1, 2),
        (4,  "2 products",                 2, 0),
        (5,  "2 products + 1 accessory",   2, 1),
        (6,  "2 products + 2 accessories", 2, 2),
        (7,  "3 products",                 3, 0),
        (8,  "3 products + 1 accessory",   3, 1),
        (9,  "3 products + 2 accessories", 3, 2),
        (10, "4 products",                 4, 0),
        (11, "4 products + 1 accessory",   4, 1),
        (12, "4 products + 2 accessories", 4, 2),
        (13, "5 products",                 5, 0),
        (14, "5 products + 1 accessory",   5, 1),
        (15, "5 products + 2 accessories", 5, 2),
        (16, "6 products",                 6, 0),
        (17, "6 products + 1 accessory",   6, 1),
        (18, "6 products + 2 accessories", 6, 2),
        (19, "1 accessory (only)",         0, 1),
    ]

    unit_primary_eur = UNIT_PRIMARY_USD / fx_mean
    unit_accessory_eur = UNIT_ACCESSORY_USD / fx_mean

    bundles_list = []
    for n, label, c, b in catalog:
        merce_usd = round(c * UNIT_PRIMARY_USD + b * UNIT_ACCESSORY_USD, 2)
        merce_eur = round(c * unit_primary_eur + b * unit_accessory_eur, 2)
        samples = buckets.get((c, b), [])
        if samples:
            mean_usd = sum(s[0] for s in samples) / len(samples)
            mean_eur = sum(s[1] for s in samples) / len(samples)
            total_usd = round(mean_usd, 2)
            total_eur = round(mean_eur, 2)
            ship_usd = round(mean_usd - merce_usd, 2)
            ship_eur = round(mean_eur - merce_eur, 2)
            cnt = len(samples)
        else:
            total_usd = ship_usd = None
            total_eur = ship_eur = None
            cnt = 0
        bundles_list.append({
            "n": n,
            "label": label,
            "primaries": c,
            "accessories": b,
            "merce_eur": merce_eur,
            "ship_eur": ship_eur,
            "total_eur": total_eur,
            "merce_usd": merce_usd,
            "ship_usd": ship_usd,
            "total_usd": total_usd,
            "sample_orders": cnt,
        })

    bundles_out = {
        "_source": f"Daily COGS xlsx aggregate — {len(dates)} days ({dates[0]} → {dates[-1]}), {total_orders} orders parsed",
        "_note": (
            f"Costo merce: primary $2.25/u, accessory $2.22/u (catalogo Supplier A). "
            f"Shipping = mean per-order COGS (Drive Giornalieri) − merce. "
            f"EUR computed via per-day fx (mean USD→EUR {fx_mean:.4f}). "
            f"'null' = combo non ancora osservata."
        ),
        "_updated_at": date.today().isoformat(),
        "fx_mean_usd_eur": round(fx_mean, 4),
        "unit_cost_eur": {"primary": round(unit_primary_eur, 4), "accessory": round(unit_accessory_eur, 4)},
        "unit_cost_usd": {"primary": UNIT_PRIMARY_USD, "accessory": UNIT_ACCESSORY_USD},
        "bundles": bundles_list,
    }

    BUNDLES_PATH.write_text(json.dumps(bundles_out, indent=2, ensure_ascii=False) + "\n")
    print(f"\n[aggregate_cogs] Wrote {BUNDLES_PATH}")
    return bundles_list


def update_config_matrix(bundles_list, dates, total_orders):
    cfg = json.loads(CONFIG_PATH.read_text())
    matrix = {}
    for row in bundles_list:
        if row["total_usd"] is None:
            continue
        key = f"{row['primaries']}_{row['accessories']}"
        matrix[key] = row["total_usd"]

    cfg["cogs"]["matrix"] = matrix
    cfg["cogs"]["_matrix_note"] = (
        f"Aggregate per-order COGS from Daily xlsx Drive Giornalieri "
        f"({len(dates)} days {dates[0].replace('2026-','').replace('-','/')}–"
        f"{dates[-1].replace('2026-','').replace('-','/')}, {total_orders} orders). "
        f"Key = primaries_accessories (count). Value = USD. "
        f"Primary $2.25/u + accessory $2.22/u + mean observed shipping."
    )
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2, ensure_ascii=False) + "\n")
    print(f"[aggregate_cogs] Wrote {CONFIG_PATH} matrix ({len(matrix)} buckets)")


if __name__ == "__main__":
    buckets, total_orders, dates, fx_mean = aggregate()
    bundles_list = update_bundles(buckets, total_orders, dates, fx_mean)

    print("\n[aggregate_cogs] Per-bundle summary (EUR / USD):")
    for row in bundles_list:
        if row["sample_orders"] > 0:
            print(f"  {row['label']:<30} → €{row['total_eur']:>6.2f} / ${row['total_usd']:>6.2f} "
                  f"(merce €{row['merce_eur']:>5.2f} + ship €{row['ship_eur']:>5.2f}) "
                  f"× {row['sample_orders']} orders")
        else:
            print(f"  {row['label']:<30} → no samples (theoretical merce €{row['merce_eur']:.2f})")

    update_config_matrix(bundles_list, dates, total_orders)
    print("\n[aggregate_cogs] Done.")
