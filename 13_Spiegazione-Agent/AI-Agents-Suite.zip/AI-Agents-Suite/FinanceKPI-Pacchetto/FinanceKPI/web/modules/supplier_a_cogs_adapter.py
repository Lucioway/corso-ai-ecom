"""
Supplier A COGS Adapter — Supplier-compatible interface for monthly_report.

Wraps `supplier_a_cogs.SupplierACogsClient` to expose the same `fetch_orders_range(start, end)`
interface used by the `SupplierDownloader`, so `monthly.py` can swap one
for the other without touching downstream Excel generation logic.

Row shape (the store pays Supplier A in USD — USD is primary):
    {
      "date":     "YYYY-MM-DD",
      "order":    orderNumber (str),
      "country":  ISO-2 code,
      "items":    int (total qty),
      "cogs_usd": float USD (raw from Supplier A API),
      "cogs_eur": float EUR (USD → EUR via fx_client at fx_date),
      "cogs":     alias of cogs_usd (back-compat for downstream code that
                  expects single `cogs` key).
    }
"""
from __future__ import annotations

from datetime import date
from typing import Optional

from modules.supplier_a_cogs import SupplierACogsClient, _order_cogs_usd


class SupplierACogsAdapter:
    """Date-range adapter on top of SupplierACogsClient."""

    def __init__(self, config: dict, fx_client=None, fx_date: Optional[date] = None,
                 cache_dir: str = "cache"):
        self.client = SupplierACogsClient(config, cache_dir=cache_dir)
        self.fx_client = fx_client
        self.fx_date = fx_date or date.today()
        self.enabled = self.client.enabled

    def fetch_orders_range(self, start: date, end: date) -> list[dict]:
        """Return Supplier-shaped COGS rows for Supplier A orders in [start, end]."""
        if not self.enabled:
            return []

        # Pull all Supplier A orders (incl. freeze records → real shipping cost).
        records = self.client.refresh_orders(use_cache_hours=0.5)
        freeze_idx = self.client._freeze_by_platform_id

        rows = []
        for supplier_a in records:
            created = (supplier_a.get("orderCreatedAt") or "")[:10]
            if not created:
                continue
            try:
                d = date.fromisoformat(created)
            except Exception:
                continue
            if d < start or d > end:
                continue

            pid = str(supplier_a.get("platformOrderId") or "")
            freeze = freeze_idx.get(pid)
            cogs = _order_cogs_usd(supplier_a, freeze_shipping_cents=freeze)

            total_usd = cogs["total_cogs_usd"]
            qty = sum(int(it.get("qty", 1)) for it in cogs["items"]) or 1

            if self.fx_client is not None:
                cogs_eur = self.fx_client.convert_to_eur(
                    total_usd, "USD", self.fx_date)
            else:
                cogs_eur = total_usd  # last-resort fallback

            # Supplier A state is a dict {"value": int, "label": str}
            st = supplier_a.get("state")
            if isinstance(st, dict):
                state = int(st.get("value") or 0)
            else:
                try:
                    state = int(st or 0)
                except (TypeError, ValueError):
                    state = 0
            # 1=Unfulfilled, 2=Paid, 3=Processing, 4=Success (shipped/fulfilled)
            rows.append({
                "date":     created,
                "order":    str(supplier_a.get("orderNumber") or ""),
                "country":  cogs.get("country_code") or "",
                "items":    qty,
                "cogs_usd": round(total_usd, 2),
                "cogs_eur": round(cogs_eur, 2),
                "cogs":     round(total_usd, 2),  # back-compat alias = USD
                "state":    state,
                "fulfilled": state == 4,
            })

        rows.sort(key=lambda r: (r["date"], r["order"]))
        return rows
