"""xlsx Daily P&L reader.

Reads <prefix>_COGS_DD_MM_YYYY.xlsx files (prefix from config) from the
configured daily Drive folder and returns authoritative COGS / gateway /
net values per day.

Used as source of truth override for compute_day_metrics when the daily
Drive report exists. Falls back silently to the internal calc when xlsx
missing.

xlsx columns labeled with '€' but values may be in the store's payout
currency. Conversion to EUR via the fx encoded in the report
('EXACT NET (EUR) — fx X.XXXX' row).
"""
from __future__ import annotations

import io
import json
import re
import threading
import time
from datetime import date
from pathlib import Path

# Daily reports Drive folder (override with your own folder ID)
FOLDER_ID = "1qOabZf6rZxGgt4CGc-UaghSdY65vL52M"


def _report_prefix() -> str:
    """Read report.file_prefix from web/config.json (same source as server.py)."""
    try:
        cfg = json.loads((Path(__file__).resolve().parent / "config.json")
                         .read_text(encoding="utf-8"))
    except Exception:
        cfg = {}
    return (cfg.get("report", {}) or {}).get("file_prefix", "Report_COGS")


_PREFIX = _report_prefix()

# In-memory caches
_FILE_INDEX_CACHE: dict = {"ts": 0.0, "data": {}}   # date_iso → (file_id, modifiedTime)
_FILE_INDEX_TTL = 300  # 5 min

_OVERRIDE_CACHE: dict = {}  # date_iso → {"ts": float, "modifiedTime": str, "data": dict}
_OVERRIDE_TTL = 600  # 10 min

_LOCK = threading.Lock()

_FILENAME_RE = re.compile(
    rf"{re.escape(_PREFIX)}_(\d{{2}})_(\d{{2}})_(\d{{4}})\.xlsx", re.IGNORECASE
)
_FX_LABEL_RE = re.compile(r"fx\s*([0-9]+(?:\.[0-9]+)?)", re.IGNORECASE)


def _drive_service():
    """Build Drive v3 service using the existing costs_reader SA loader."""
    from googleapiclient.discovery import build
    from costs_reader import _load_sa_credentials
    creds = _load_sa_credentials(["https://www.googleapis.com/auth/drive.readonly"])
    return build("drive", "v3", credentials=creds, cache_discovery=False)


def _list_folder() -> dict:
    """List xlsx files in Giornalieri, return {iso_date: (file_id, modifiedTime)}."""
    now = time.time()
    with _LOCK:
        if now - _FILE_INDEX_CACHE["ts"] < _FILE_INDEX_TTL and _FILE_INDEX_CACHE["data"]:
            return _FILE_INDEX_CACHE["data"]
    try:
        svc = _drive_service()
        # Reports live in Giornalieri root AND in monthly subfolders (e.g.
        # "2026-06 Giugno"). Search the root + every subfolder one level down.
        parents = [FOLDER_ID]
        subs = svc.files().list(
            q=f"'{FOLDER_ID}' in parents and trashed=false and "
              "mimeType='application/vnd.google-apps.folder'",
            fields="files(id)", pageSize=200,
            supportsAllDrives=True, includeItemsFromAllDrives=True,
        ).execute().get("files", [])
        parents += [s["id"] for s in subs]

        files = []
        for pid in parents:
            files += svc.files().list(
                q=f"'{pid}' in parents and trashed=false and mimeType="
                  "'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'",
                fields="files(id,name,modifiedTime)",
                pageSize=200,
                supportsAllDrives=True,
                includeItemsFromAllDrives=True,
            ).execute().get("files", [])
    except Exception as e:
        print(f"[xlsx_daily_reader] list error: {e}", flush=True)
        return {}
    idx = {}
    for f in files:
        m = _FILENAME_RE.search(f["name"])
        if not m:
            continue
        dd, mm, yyyy = m.group(1), m.group(2), m.group(3)
        iso = f"{yyyy}-{mm}-{dd}"
        idx[iso] = (f["id"], f.get("modifiedTime", ""))
    with _LOCK:
        _FILE_INDEX_CACHE["ts"] = now
        _FILE_INDEX_CACHE["data"] = idx
    return idx


def _download_xlsx(file_id: str) -> bytes:
    from googleapiclient.http import MediaIoBaseDownload
    svc = _drive_service()
    fh = io.BytesIO()
    req = svc.files().get_media(fileId=file_id)
    dl = MediaIoBaseDownload(fh, req)
    done = False
    while not done:
        _, done = dl.next_chunk()
    fh.seek(0)
    return fh.read()


def _parse_analysis_sheet(xlsx_bytes: bytes) -> dict | None:
    """Extract COGS, Gateway, EXACT NET, fx from the Analysis sheet.

    Returns dict with USD-native values:
        {revenue_usd, cogs_usd, ads_usd, gateway_usd, net_usd,
         net_eur, fx_used, orders}
    Or None if parsing fails.
    """
    try:
        from openpyxl import load_workbook
    except ImportError:
        return None
    try:
        wb = load_workbook(io.BytesIO(xlsx_bytes), data_only=True, read_only=True)
    except Exception as e:
        print(f"[xlsx_daily_reader] load error: {e}", flush=True)
        return None
    if "Analysis" not in wb.sheetnames:
        return None
    ws = wb["Analysis"]
    out = {
        "revenue_usd": None, "cogs_usd": None, "ads_usd": None,
        "gateway_usd": None, "net_usd": None, "net_eur": None,
        "fx_used": None, "orders": None,
    }
    for row in ws.iter_rows(values_only=True):
        if not row or row[0] is None:
            continue
        label = str(row[0]).strip()
        val = row[1] if len(row) > 1 else None
        if isinstance(val, (int, float)):
            v = float(val)
            if label == "Revenue (Total Sales)":
                out["revenue_usd"] = v
            elif label == "Orders":
                out["orders"] = int(v)
            elif label == "TOTAL COGS":
                out["cogs_usd"] = v
            elif label == "TOTAL ADV":
                out["ads_usd"] = v
            elif label == "TOTAL GATEWAY":
                out["gateway_usd"] = v
            elif label == "EXACT NET":
                out["net_usd"] = v
            elif label.startswith("EXACT NET (EUR)"):
                out["net_eur"] = v
                m = _FX_LABEL_RE.search(label)
                if m:
                    try:
                        out["fx_used"] = float(m.group(1))
                    except ValueError:
                        pass
    if out["cogs_usd"] is None or out["gateway_usd"] is None:
        return None
    return out


def get_overrides(target: date) -> dict | None:
    """Return xlsx-derived overrides for `target` date, or None if no report.

    Caches per (date, modifiedTime). Refreshes if Drive file changes.
    """
    iso = target.isoformat()
    idx = _list_folder()
    if iso not in idx:
        return None
    file_id, mtime = idx[iso]
    with _LOCK:
        cached = _OVERRIDE_CACHE.get(iso)
    now = time.time()
    if (cached and cached.get("modifiedTime") == mtime
            and now - cached.get("ts", 0) < _OVERRIDE_TTL):
        return cached["data"]
    try:
        xlsx = _download_xlsx(file_id)
    except Exception as e:
        print(f"[xlsx_daily_reader] download error {iso}: {e}", flush=True)
        return cached["data"] if cached else None
    parsed = _parse_analysis_sheet(xlsx)
    if not parsed:
        return cached["data"] if cached else None
    parsed["_source_file"] = f"{_PREFIX}_{target.strftime('%d_%m_%Y')}.xlsx"
    parsed["_file_id"] = file_id
    with _LOCK:
        _OVERRIDE_CACHE[iso] = {"ts": now, "modifiedTime": mtime, "data": parsed}
    return parsed
