"""Costs reader.

Reads monthly fixed + variable costs from the "USER" sheet, tab
"COSTI 2026". Layout per month section (single tab, month name in col A
starts each section, e.g. "MAGGIO 2026"):

    Row 0   "MAGGIO 2026"
    Row 1   "COSTI VARIABILI" ........ "COSTI FISSI"
    Row 2   Person A | Person B | Person C | Software Mensili | Team Mensile | Annuali
    Row 3   Data | Cost | Dettagli | Data | Cost | Dettagli | Data | Cost | Dettagli
            (blank col J) Details | Cost | Payments  (×3 fissi blocks)
    Row 4.. line items
    ...     TOT row (col A == 'TOT')
    Row     TOTALE row

The sheet may log costs in USD ($). This module converts USD→EUR using the
FxRates frankfurter cache so the rest of the dashboard stays EUR-canonical.

Public API exposes the CostsCache surface (by_day / monthly /
alloc_by_day_split / alloc_by_day / aggregate / refresh) so server.py can
swap straight in.
"""
from __future__ import annotations

import calendar
import json
import os
import re
import threading
import time
from datetime import date, datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

ROOT = Path(__file__).resolve().parent
SHEET_ID = "1FroT3qWWiw4_hiVgbMUTB0Jrqtx5Vx-oyDNVXBi0ZYI"
TABS = ["COSTI 2026"]

# Service account file — local fallback (cloud uses GOOGLE_SERVICE_ACCOUNT_JSON env).
# Lives in the report runtime of the unified finance agent.
_DEFAULT_SA_FILE = ROOT.parent / "report" / "google_service_account.json"

# Cache file (local; cloud can override via DATA_DIR env var).
_DATA_DIR_ENV = os.environ.get("DATA_DIR", "").strip()
if _DATA_DIR_ENV:
    CACHE_FILE = Path(_DATA_DIR_ENV).expanduser() / "extra_costs.json"
else:
    CACHE_FILE = ROOT / "cache" / "extra_costs.json"

REFRESH_SEC = 3600  # 1 hour

ITALIAN_MONTH = {
    "gennaio": 1, "febbraio": 2, "marzo": 3, "aprile": 4, "maggio": 5,
    "giugno": 6, "luglio": 7, "agosto": 8, "settembre": 9, "ottobre": 10,
    "novembre": 11, "dicembre": 12,
}
_DATE_DDMMYY = re.compile(r"(\d{1,2})[./\-](\d{1,2})(?:[./\-](\d{2,4}))?")
_USD_PREFIX = re.compile(r"^\s*\$")

# UI category buckets (must match index.html's render contract).
MONTHLY_CATEGORIES = (
    "extra", "shopify", "software", "software_mensile", "team_mensile",
)


def _empty_day() -> dict:
    return {"extra": 0.0, "shopify": 0.0, "software": 0.0, "team": 0.0, "details": []}


def _load_sa_credentials(scopes: list[str]):
    """SA from GOOGLE_SERVICE_ACCOUNT_JSON (raw or base64) / _FILE (path) /
    default file. Render-friendly: paste the JSON file content directly OR
    base64-encode if your secret manager mangles newlines."""
    import base64 as _b64
    from google.oauth2.service_account import Credentials
    inline = os.environ.get("GOOGLE_SERVICE_ACCOUNT_JSON", "").strip()
    if inline:
        # Try raw JSON first; if it doesn't parse, try base64 → JSON.
        try:
            return Credentials.from_service_account_info(json.loads(inline), scopes=scopes)
        except (json.JSONDecodeError, ValueError):
            try:
                decoded = _b64.b64decode(inline).decode("utf-8")
                return Credentials.from_service_account_info(json.loads(decoded), scopes=scopes)
            except Exception as e:
                raise RuntimeError(f"GOOGLE_SERVICE_ACCOUNT_JSON parse failed (tried raw + base64): {e}")
    file_env = os.environ.get("GOOGLE_SERVICE_ACCOUNT_FILE", "").strip()
    if file_env:
        return Credentials.from_service_account_file(file_env, scopes=scopes)
    return Credentials.from_service_account_file(str(_DEFAULT_SA_FILE), scopes=scopes)


def _parse_money(s) -> tuple[float, str]:
    """Coerce '$50.00' / '€ 1.234,56' / 50 → (amount, currency). Currency defaults USD."""
    if s is None:
        return 0.0, "USD"
    if isinstance(s, (int, float)):
        return float(s), "USD"
    s = str(s).strip()
    if not s or s == "-":
        return 0.0, "USD"
    ccy = "USD"
    if "€" in s:
        ccy = "EUR"
    elif "£" in s:
        ccy = "GBP"
    elif "$" in s:
        ccy = "USD"
    for ch in ("$", "€", "£", " ", "\xa0"):
        s = s.replace(ch, "")
    if not s:
        return 0.0, ccy
    # european format: "." thousands, "," decimal
    if "," in s and "." in s:
        s = s.replace(".", "").replace(",", ".")
    elif "," in s:
        s = s.replace(",", ".")
    try:
        return float(s), ccy
    except ValueError:
        return 0.0, ccy


def _parse_date(s, default_year: int, default_month: Optional[int]) -> Optional[date]:
    """Parse '5/12/2026' / '12.5' / '12-05-2026' → date. Falls back to (default_year, default_month, day) for day-only."""
    if not s:
        return None
    s = str(s).strip()
    if not s or s.lower() in ("tot", "totale", "-"):
        return None
    m = _DATE_DDMMYY.match(s)
    if m:
        d = int(m.group(1))
        mo = int(m.group(2))
        yr_s = m.group(3)
        if yr_s:
            yr = int(yr_s)
            if yr < 100:
                yr += 2000
        else:
            yr = default_year
        # Heuristic: if first number > 12 treat as DD/MM, else assume DD/MM (Italian convention)
        try:
            return date(yr, mo, d)
        except ValueError:
            # swap if maybe US M/D/Y
            try:
                return date(yr, d, mo)
            except ValueError:
                return None
    # bare day number
    if s.isdigit() and default_month is not None:
        try:
            return date(default_year, default_month, int(s))
        except ValueError:
            return None
    return None


def _month_from_header(cell: str) -> tuple[Optional[int], Optional[int]]:
    """'MAGGIO 2026' / 'Giugno 2026' → (month, year). Returns (None,None) if no match."""
    if not cell:
        return None, None
    s = str(cell).strip().lower()
    # tokens
    parts = re.split(r"[\s\-]+", s)
    mo = None
    yr = None
    for p in parts:
        if p in ITALIAN_MONTH:
            mo = ITALIAN_MONTH[p]
        elif p.isdigit() and len(p) == 4:
            yr = int(p)
    return mo, yr


# Header tokens used to locate column groups inside a month section.
# The trailing ".+" matches any person/column header, so the variable-cost
# columns can be named however the merchant labels them in the sheet.
_VARIABLE_PERSON_HEADER = re.compile(r"^(.+)$", re.IGNORECASE)
_FISSI_BLOCKS = {
    "software mensili": "software_mensile",
    "team mensile":     "team_mensile",
    "annuali":          "annuali",
}


def _locate_blocks(header_row: list[str]) -> dict:
    """Given the row containing 'Software Mensili' / 'Team Mensile' / 'Annuali' /
    person-name labels, return dict mapping block_kind → start_col_index.

    Variable blocks: persons are detected as non-empty cells that are NOT
    'COSTI VARIABILI' / fissi headers. Each occupies 3 columns: Data, Cost, Dettagli.

    Fissi blocks: each occupies 3 columns: Details, Cost, Payments.
    """
    out = {"variables": [], "software_mensile": None, "team_mensile": None, "annuali": None}
    n = len(header_row)
    for ci, raw in enumerate(header_row):
        s = (raw or "").strip().lower()
        if not s:
            continue
        if s in _FISSI_BLOCKS:
            out[_FISSI_BLOCKS[s]] = ci
        elif s in ("costi variabili", "costi fissi"):
            continue
        else:
            # treat as person name → variable cost block start
            out["variables"].append((ci, raw.strip()))
    return out


def _convert_to_eur(amount: float, ccy: str, fx, target: date) -> float:
    """Store NATIVE USD (no conversion). Sheet is USD, payout is USD,
    dashboard cards display USD directly. This function intentionally returns
    the input amount unchanged — only kept for signature compatibility."""
    return amount


def fetch_costs(verbose: bool = False, fx=None) -> tuple[dict, list]:
    """Returns (by_day, items).
    by_day: {iso: {extra, shopify, software, team, details}}
    items:  [{start, end, category, amount, detail, tab}, ...] in EUR.
    """
    from googleapiclient.discovery import build

    creds = _load_sa_credentials(
        ["https://www.googleapis.com/auth/spreadsheets.readonly"]
    )
    svc = build("sheets", "v4", credentials=creds)

    by_day: dict[str, dict] = {}
    items: list[dict] = []

    for tab in TABS:
        try:
            res = svc.spreadsheets().values().get(
                spreadsheetId=SHEET_ID, range=f"'{tab}'!A1:S400"
            ).execute()
        except Exception as e:
            print(f"[costs_reader] {tab} fetch failed: {e}")
            continue
        rows = res.get("values", [])
        if not rows:
            continue

        # Locate month sections: rows where col A matches month name pattern.
        month_starts: list[tuple[int, int, int]] = []  # (row_idx, month, year)
        for ri, r in enumerate(rows):
            if not r:
                continue
            mo, yr = _month_from_header(r[0])
            if mo and yr:
                month_starts.append((ri, mo, yr))

        # Parse each section: [start_ri, next_start_ri or EOF)
        for idx, (start_ri, mo, yr) in enumerate(month_starts):
            end_ri = month_starts[idx + 1][0] if idx + 1 < len(month_starts) else len(rows)
            _parse_section(rows, start_ri, end_ri, mo, yr, tab, by_day, items, fx, verbose)

    return by_day, items


def _parse_section(rows, start_ri, end_ri, mo, yr, tab, by_day, items, fx, verbose):
    """Parse one month section: rows[start_ri..end_ri)."""
    # Find the column-header row (the row with 'Software Mensili' / person names).
    blocks = None
    header_ri = None
    for ri in range(start_ri, min(start_ri + 6, end_ri)):
        row = rows[ri] if ri < len(rows) else []
        if any((c or "").strip().lower() in _FISSI_BLOCKS for c in row):
            blocks = _locate_blocks(row)
            header_ri = ri
            break
    if blocks is None or header_ri is None:
        if verbose:
            print(f"[costs_reader] {tab} section {yr}-{mo:02d}: no headers")
        return

    last_day = calendar.monthrange(yr, mo)[1]
    month_start_iso = f"{yr:04d}-{mo:02d}-01"
    month_end_iso = f"{yr:04d}-{mo:02d}-{last_day:02d}"

    # Walk data rows from header_ri+2 (skip header + sub-header) until end of section
    data_start = header_ri + 2
    person_extra_total = 0.0
    sw_mensile_total = 0.0
    team_mensile_total = 0.0
    annuali_lines: list[tuple[float, str]] = []  # (eur_amount, detail) yearly

    for ri in range(data_start, end_ri):
        row = rows[ri] if ri < len(rows) else []
        if not row:
            continue
        # Per-block TOT row: variable-block uses col A == 'TOT', fissi-blocks check own col.
        first = (row[0] or "").strip().lower() if row else ""
        is_variable_tot = first == "tot"  # exact match — excludes 'TOTALE' grand-total

        # ── Variable cost blocks (3 cols each: Data, Cost, Dettagli) ──
        for col_idx, person in blocks["variables"]:
            if col_idx + 1 >= len(row):
                continue
            date_cell = row[col_idx] if col_idx < len(row) else ""
            cost_cell = row[col_idx + 1] if (col_idx + 1) < len(row) else ""
            detail_cell = row[col_idx + 2] if (col_idx + 2) < len(row) else ""
            # skip TOT rows for variable items
            if (date_cell or "").strip().lower().startswith("tot"):
                continue
            amt_raw, ccy = _parse_money(cost_cell)
            if amt_raw <= 0:
                continue
            d = _parse_date(date_cell, yr, mo)
            if not d:
                # fallback to first of month if no date but cost present
                d = date(yr, mo, 1)
            eur = _convert_to_eur(amt_raw, ccy, fx, d)
            iso = d.isoformat()
            bd = by_day.setdefault(iso, _empty_day())
            bd["extra"] += eur
            label = f"{person}: {detail_cell or '—'}"
            bd["details"].append(f"extra:€{eur:.2f} — {label[:80]}")
            items.append({
                "start": iso, "end": iso, "category": "extra",
                "amount": round(eur, 2), "detail": label[:120], "tab": tab,
            })
            person_extra_total += eur

        # Per-block TOT row read: each fissi block has its own 'TOT' label in
        # its Details column (col ci). Only read when row[ci] == 'TOT' (exact)
        # — excludes the grand-total rows 'TOTALE'/'Totale Mese'.
        for kind in ("software_mensile", "team_mensile", "annuali"):
            ci = blocks.get(kind)
            if ci is None:
                continue
            label_cell = (row[ci] or "").strip().lower() if ci < len(row) else ""
            if label_cell != "tot":
                continue
            cost_cell = row[ci + 1] if (ci + 1) < len(row) else ""
            amt_raw, ccy = _parse_money(cost_cell)
            if amt_raw <= 0:
                continue
            eur = _convert_to_eur(amt_raw, ccy, fx, date(yr, mo, 1))
            if kind == "software_mensile":
                sw_mensile_total += eur
            elif kind == "team_mensile":
                team_mensile_total += eur
            else:
                annuali_lines.append((eur, "Annuali (TOT)"))

    # Emit monthly aggregate items (matches MONTHLY_CATEGORIES contract)
    if sw_mensile_total > 0:
        items.append({
            "start": month_start_iso, "end": month_end_iso,
            "category": "software_mensile",
            "amount": round(sw_mensile_total, 2),
            "detail": "Software Mensili (totale)", "tab": tab,
        })
    if team_mensile_total > 0:
        items.append({
            "start": month_start_iso, "end": month_end_iso,
            "category": "team_mensile",
            "amount": round(team_mensile_total, 2),
            "detail": "Team Mensile (totale)", "tab": tab,
        })
    # Annuali → distribute over the entire calendar year (Jan 1 .. Dec 31 of yr).
    # Folded into software_mensile bucket (UI has no separate 'annual' card).
    if annuali_lines:
        yr_start = date(yr, 1, 1).isoformat()
        yr_end = date(yr, 12, 31).isoformat()
        total_annuale = sum(a for a, _ in annuali_lines)
        if total_annuale > 0:
            items.append({
                "start": yr_start, "end": yr_end,
                "category": "software_mensile",
                "amount": round(total_annuale, 2),
                "detail": "Annuali (totale anno)", "tab": tab,
            })

    if verbose:
        print(
            f"[costs_reader] {yr}-{mo:02d}: "
            f"extra=€{person_extra_total:.2f} "
            f"sw_mensile=€{sw_mensile_total:.2f} "
            f"team_mensile=€{team_mensile_total:.2f} "
            f"annuali_items={len(annuali_lines)}"
        )


class CostsCache:
    """Hourly-refreshed in-memory costs index, persisted to disk."""

    def __init__(self, fx=None) -> None:
        self.lock = threading.Lock()
        self.by_day: dict[str, dict] = {}
        self.items: list[dict] = []
        self.updated_at: Optional[str] = None
        self.last_error: Optional[str] = None
        self._fx = fx
        self._load_disk()

    def _load_disk(self) -> None:
        if CACHE_FILE.exists():
            try:
                payload = json.loads(CACHE_FILE.read_text(encoding="utf-8"))
                self.by_day = payload.get("by_day", {})
                self.items = payload.get("items", [])
                self.updated_at = payload.get("updated_at")
            except Exception as e:
                print(f"[costs_reader] disk cache load failed: {e}")

    def _save_disk(self) -> None:
        try:
            CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
            payload = {"by_day": self.by_day, "items": self.items, "updated_at": self.updated_at}
            CACHE_FILE.write_text(json.dumps(payload, indent=2), encoding="utf-8")
        except Exception as e:
            print(f"[costs_reader] disk cache write failed: {e}")

    def refresh(self) -> None:
        try:
            data, items = fetch_costs(fx=self._fx)
            with self.lock:
                self.by_day = data
                self.items = items
                self.updated_at = datetime.now(timezone.utc).isoformat()
                self.last_error = None
            self._save_disk()
            print(f"[costs_reader] refreshed: {len(data)} day-buckets, {len(items)} items")
        except Exception as e:
            with self.lock:
                self.last_error = str(e)
            print(f"[costs_reader] refresh error: {e}")

    def for_day(self, d: date) -> dict:
        with self.lock:
            return self.by_day.get(d.isoformat(), _empty_day())

    def monthly(self) -> dict:
        """Per-month rollup, same shape as CostsCache.monthly()."""
        out: dict[str, dict] = {}
        with self.lock:
            items = list(self.items)
        for it in items:
            try:
                s = date.fromisoformat(it["start"])
                e = date.fromisoformat(it["end"])
            except (KeyError, ValueError):
                continue
            if e < s:
                continue
            total_days = (e - s).days + 1
            per = float(it["amount"]) / total_days
            cat = it["category"]
            cur = s
            while cur <= e:
                ym = cur.strftime("%Y-%m")
                m = out.setdefault(ym, {k: 0.0 for k in MONTHLY_CATEGORIES})
                if cat in MONTHLY_CATEGORIES:
                    m[cat] = m.get(cat, 0.0) + per
                cur += timedelta(days=1)
        for ym, m in out.items():
            yr, mo = (int(x) for x in ym.split("-"))
            dim = calendar.monthrange(yr, mo)[1]
            total = sum(m[k] for k in MONTHLY_CATEGORIES)
            for k in MONTHLY_CATEGORIES:
                m[k] = round(m[k], 2)
            m["team"] = m["team_mensile"]  # UI alias
            m["total"] = round(total, 2)
            m["days_in_month"] = dim
            m["alloc_per_day"] = round(total / dim, 2)
        return out

    def alloc_by_day_split(self) -> dict:
        """Hybrid daily breakdown: {iso: {extra, shopify, software, team, total}}."""
        out: dict[str, dict] = {}
        m = self.monthly()
        with self.lock:
            for ym, info in m.items():
                yr, mo = (int(x) for x in ym.split("-"))
                dim = info["days_in_month"] or 1
                sw_alloc = (info.get("software_mensile") or 0) / dim
                team_alloc = (info.get("team_mensile") or 0) / dim
                for d in range(1, dim + 1):
                    iso = date(yr, mo, d).isoformat()
                    bd = self.by_day.get(iso) or _empty_day()
                    row = {
                        "extra":    round(bd.get("extra", 0) or 0, 2),
                        "shopify":  round(bd.get("shopify", 0) or 0, 2),
                        "software": round((bd.get("software", 0) or 0) + sw_alloc, 2),
                        "team":     round(team_alloc, 2),
                    }
                    row["total"] = round(
                        row["extra"] + row["shopify"] + row["software"] + row["team"], 2
                    )
                    out[iso] = row
        return out

    def alloc_by_day(self) -> dict:
        return {iso: row["total"] for iso, row in self.alloc_by_day_split().items()}

    def aggregate(self, days: int) -> dict:
        today = date.today()
        split = self.alloc_by_day_split()
        sums = {k: 0.0 for k in ("extra", "shopify", "software", "team")}
        n_days = 0
        for i in range(days):
            iso = (today - timedelta(days=i)).isoformat()
            row = split.get(iso)
            if not row:
                continue
            has_amt = False
            for k in sums:
                v = row.get(k, 0) or 0
                sums[k] += v
                if v > 0:
                    has_amt = True
            if has_amt:
                n_days += 1
        out = {k: round(v, 2) for k, v in sums.items()}
        out["total"] = round(sum(sums.values()), 2)
        out["days_with_data"] = n_days
        return out


def start_refresh_thread(cache: CostsCache) -> None:
    def loop() -> None:
        while True:
            cache.refresh()
            time.sleep(REFRESH_SEC)

    t = threading.Thread(target=loop, daemon=True, name="costs-refresh")
    t.start()


if __name__ == "__main__":
    from fx_converter import FxRates
    fx = FxRates()
    c = CostsCache(fx=fx)
    data, items = fetch_costs(verbose=True, fx=fx)
    c.by_day = data
    c.items = items
    print(f"\n=== Buckets: {len(data)} days, {len(items)} items ===")
    for it in items:
        print(f"  {it['start']}→{it['end']}  {it['category']:18s}  €{it['amount']:>8.2f}  {it['detail'][:60]}")
    print("\n=== Monthly rollup ===")
    for ym, m in sorted(c.monthly().items()):
        print(f"  {ym}: extra=€{m['extra']:.2f}  software_mensile=€{m['software_mensile']:.2f}  team_mensile=€{m['team_mensile']:.2f}  total=€{m['total']:.2f}  /day=€{m['alloc_per_day']:.2f}")
