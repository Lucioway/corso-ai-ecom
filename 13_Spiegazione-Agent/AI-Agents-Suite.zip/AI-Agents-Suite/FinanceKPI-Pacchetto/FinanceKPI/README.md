# FinanceKPI

A self-hosted profit & loss toolkit for Shopify stores. Two pieces share one
codebase:

- **Live dashboard** — a real-time P&L view (sales, orders, ad spend, COGS,
  margin, ROAS, break-even ROAS) served from your own machine or a cloud host.
- **Report batch** — a daily / weekly report generator you run on demand or on
  a schedule, producing per-day P&L with COGS folded in.

Both read the same `config.json` and the same `core/` Shopify + finance logic.

---

## Quickstart (3 steps)

```bash
# 1. Install dependencies (the root requirements.txt is the canonical, combined set)
pip install -r requirements.txt

# 2. Run the interactive setup wizard (writes config.json + .env)
./setup.sh

# 3. Start the dashboard, or run a report
python cli.py dashboard --port 8890
python cli.py report --date 2026-01-31
```

That's it. The wizard asks for your brand name, currency, Shopify shop URL,
Shopify Admin API token, and dashboard login, then writes everything for you.

---

## Setup wizard

`./setup.sh` collects your details and writes a single canonical
`config.json` at the repo root, then copies it to `report/config.json` and
`web/config.json` so the report batch, the dashboard, and `core/` all read the
**same** config. It also writes a `.env` with your dashboard login and a freshly
generated session secret.

You can re-run it at any time; it asks before overwriting an existing
`config.json`. The generated `config.json` / `.env` files are per-install and
are gitignored — they are never meant to be committed or shared.

Prefer to do it by hand? Copy `report/config.example.json` to `config.json`,
fill in the `shopify` block plus `report.company_name`, then copy that file to
`report/config.json` and `web/config.json`. Copy `.env.example` to `.env` and
fill in the dashboard credentials.

### Getting a Shopify Admin API token

In Shopify admin: **Settings → Apps and sales channels → Develop apps →
Create an app → Configure Admin API scopes** (grant read access to Orders,
Products, and related finance scopes), then **Install app** and copy the
**Admin API access token** (it starts with `shpat_`). Paste it into the wizard.

---

## Running

```bash
# Live dashboard (defaults to port 8789 if --port is omitted)
python cli.py dashboard --port 8890

# Daily report for a specific date
python cli.py report --date 2026-01-31

# Daily + weekly
python cli.py report --date 2026-01-31 --week

# A range of dates
python cli.py report-range --from 2026-01-01 --to 2026-01-31

# Auth / config health check
python cli.py status
```

The dashboard prompts for the `DASHBOARD_USER` / `DASHBOARD_PASS` you set during
setup. It reads live order, fee, and refund data from the Shopify Admin API for
the store in your `config.json`, caches it locally, and renders the P&L view.

---

## COGS — bring your own numbers

Cost of goods is supplied by **you**, from your own supplier spreadsheet — the
tool does not invent costs. Drop your supplier COGS `.xlsx` (or CSV) into the
folder named by `cogs.supplier_csv_folder` in `config.json`, or fill in the
`cogs.matrix` block directly. Expected CSV naming is described inline in
`config.example.json`. If a cost source is missing for a day, that day's COGS is
left blank rather than guessed.

Optional supplier integrations (e.g. a dropshipping portal) exist but are
**off** by default; enable them only after filling in their credentials.

---

## Optional integrations (all off by default)

`config.json` ships with these blocks set to `"enabled": false`. Turn one on
only after you fill in its credentials:

- **Google Drive** — upload reports to a Drive folder.
- **Triple Whale** — pull blended ad metrics.
- **Telegram / WhatsApp** — push the daily recap to a chat.
- **Email watcher** — auto-download the supplier COGS file from Gmail.

Each block carries an inline `_note` / `_instructions` field explaining what to
fill in.

---

## Requirements

- Python 3.10+ (3.13 recommended)
- A Shopify store with an Admin API custom app token
- `pip install -r requirements.txt` (root file — the combined dependency set;
  `web/requirements.txt` and `report/requirements.txt` are subsets used when
  deploying just one component)

---

## Deploying

See [DEPLOY.md](DEPLOY.md) for hosting the dashboard on a cloud platform with a
persistent disk.

---

## License

Commercial license — see [LICENSE.txt](LICENSE.txt).
