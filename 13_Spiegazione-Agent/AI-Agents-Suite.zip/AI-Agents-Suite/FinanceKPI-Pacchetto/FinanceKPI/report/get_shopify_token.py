#!/usr/bin/env python3
"""
Ottieni il token Shopify Admin API (una tantum)
Esegui: python3 get_shopify_token.py
"""
import json, requests, webbrowser, urllib.parse

config = json.load(open("config.json"))
shop       = config["shopify"]["shop_url"]
client_id  = config["shopify"]["api_key"]
secret     = config["shopify"]["api_password"]  # qui metti il Secret shpss_...

SCOPES = "read_orders,read_transactions,read_products"
REDIRECT = "https://example.com"

# Step 1 — Apri URL autorizzazione
auth_url = (
    f"https://{shop}/admin/oauth/authorize"
    f"?client_id={client_id}"
    f"&scope={SCOPES}"
    f"&redirect_uri={REDIRECT}"
)
print("\n1. Si aprirà il browser — clicca 'Install app'")
print("2. Verrai reindirizzato a example.com (pagina non trovata — è normale)")
print("3. Copia l'URL completo dalla barra del browser e incollalo qui\n")
input("Premi INVIO per aprire il browser...")
webbrowser.open(auth_url)

redirect_url = input("\nIncolla l'URL dalla barra del browser: ").strip()

# Step 2 — Estrai il code
parsed = urllib.parse.urlparse(redirect_url)
params = urllib.parse.parse_qs(parsed.query)
code = params.get("code", [None])[0]

if not code:
    print("❌ Nessun 'code' trovato nell'URL. Riprova.")
    exit(1)

# Step 3 — Scambia code per access token
r = requests.post(
    f"https://{shop}/admin/oauth/access_token",
    json={"client_id": client_id, "client_secret": secret, "code": code}
)

if r.status_code == 200:
    token = r.json()["access_token"]
    print(f"\n✅ Token ottenuto: {token[:15]}...")

    # Salva nel config.json
    config["shopify"]["api_password"] = token
    with open("config.json", "w") as f:
        json.dump(config, f, indent=2)
    print("✅ config.json aggiornato con il nuovo token!")
    print("\nOra puoi eseguire: python3 test_connections.py")
else:
    print(f"❌ Errore: {r.status_code} — {r.text}")
