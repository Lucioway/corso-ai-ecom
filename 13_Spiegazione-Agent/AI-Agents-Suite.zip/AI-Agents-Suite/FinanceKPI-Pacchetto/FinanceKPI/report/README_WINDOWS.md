# Finance Agent — Windows Portable

Cartella **self-contained**: Python embedded + wheels inclusi. Zero installazione.

## Come usarla

1. Copia l'intera cartella `FinanceDaily/` su qualsiasi PC Windows (64-bit).
2. Doppio click su uno dei file `.bat`:

| File | Cosa fa |
|---|---|
| `run.bat` | Genera report di **ieri**. Doppio click e via. |
| `run_date.bat` | Chiede una data e genera il report per quella data. |
| `run_bot.bat` | Avvia il bot Telegram (schedule automatico 07:00 + comandi `/runnow`). |

## Esempi da terminale (cmd/PowerShell)

```cmd
run.bat                              REM report di ieri
run.bat --date 2026-04-16            REM data specifica
run.bat --week                       REM giornaliero + settimanale
run.bat --week-only --sp-csv sp.csv  REM solo settimanale
run.bat --revenue 12500.00           REM override Total Sales manuale
```

## Struttura

```
FinanceDaily/
├── run.bat                 ← doppio click (report ieri)
├── run_date.bat            ← doppio click (scegli data)
├── run_bot.bat             ← bot Telegram
├── main.py                 ← entry point
├── config.json             ← credenziali Shopify/TW/Drive/Telegram/Supplier
├── .env                    ← env vars (FINANCE_BOT_TOKEN, TELEGRAM_CHAT_ID, ...)
├── google_service_account.json
├── modules/                ← logica (shopify, ads, cogs, drive, ...)
├── shared/                 ← stub logger
├── logs/                   ← log auto-generati
└── win_runtime/
    └── python/             ← Python 3.13.1 embedded + Lib/site-packages (wheels)
```

## Requisiti target PC

- Windows 10/11 **64-bit**
- ~80 MB spazio
- Connessione internet (per API Shopify, Triple Whale, Google Drive, Telegram)

**NON serve** installare Python, pip, venv, librerie. È tutto dentro `win_runtime/`.

## Credenziali — attenzione

`config.json` e `.env` contengono **secret** (API key, token). Non condividere la cartella pubblicamente.

## Troubleshooting

**"Python embedded non trovato"**
- La cartella `win_runtime/python/` è incompleta o mancante. Ricopia tutta la cartella.

**Errori SSL / certificati**
- La cartella `win_runtime/python/Lib/site-packages/certifi/` deve esistere. Verifica che non sia stata saltata in copia.

**Il bot Telegram non risponde**
- Controlla `FINANCE_BOT_TOKEN` in `.env`.
- Controlla che nessun altro PC/NAS stia facendo polling sullo stesso bot token (conflitto).

**Fuso orario sbagliato**
- Il bot usa `Europe/Rome` hardcoded. Il PC può essere in qualsiasi timezone.

## Aggiornamento wheels / Python

Se servono pacchetti aggiornati, da un Mac/Linux con pip:

```bash
pip install --target win_runtime/python/Lib/site-packages \
  --platform win_amd64 --only-binary=:all: \
  --python-version 3.13 --implementation cp --abi cp313 \
  --upgrade -r requirements.txt
```
