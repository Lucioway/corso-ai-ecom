#!/bin/zsh
cd "$(dirname "$0")"

# Check if Rose sent the price email, only run if found
/Library/Developer/CommandLineTools/usr/bin/python3 -c "
from modules.email_watcher import EmailWatcher
import json, sys

config = json.load(open('config.json'))
watcher = EmailWatcher(config)
path = watcher.download_latest_supplier_csv('/tmp/finance_daily_cogs')
if not path:
    print('[run.sh] ❌ No price file from Rose — skipping report.')
    sys.exit(1)
print(f'[run.sh] ✅ Price file found: {path}')

# Write path to temp file for main.py to pick up
with open('/tmp/finance_daily_cogs/.supplier_path', 'w') as f:
    f.write(path)
"

if [ $? -ne 0 ]; then
    exit 0
fi

SUPPLIER_CSV=$(cat /tmp/finance_daily_cogs/.supplier_path)
/Library/Developer/CommandLineTools/usr/bin/python3 main.py --supplier-csv "$SUPPLIER_CSV" "$@"
