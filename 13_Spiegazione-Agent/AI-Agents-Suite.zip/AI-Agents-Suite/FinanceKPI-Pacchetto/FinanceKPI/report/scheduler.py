#!/usr/bin/env python3
"""
FinanceAgent Scheduler — Avvio automatico giornaliero alle 16:00.

Logica:
  1. Ogni giorno alle 16:00 controlla se Rose ha mandato l'email con il CSV prezzi
  2. Se trovata → lancia il report completo
  3. Se non trovata → manda Telegram "Rose non ha inviato l'email" e STOP

Trigger manuale:
  python scheduler.py --run-now              # Cerca email e lancia report
  python scheduler.py --run-now --skip-email  # Lancia report senza email (fallback matrice)

Uso:
  python scheduler.py                # Avvia scheduler (gira in background)
"""

import json
import os
import subprocess
import sys
import time
from datetime import date, datetime, timedelta
from pathlib import Path

import requests

# Assicura che il CWD sia la cartella del progetto
PROJECT_DIR = Path(__file__).resolve().parent
os.chdir(PROJECT_DIR)
sys.path.insert(0, str(PROJECT_DIR))

# Carica .env
try:
    from dotenv import load_dotenv
    load_dotenv(PROJECT_DIR / ".env")
except ImportError:
    pass

from modules.email_watcher import EmailWatcher

PYTHON = sys.executable
MAIN_PY = str(PROJECT_DIR / "main.py")
CONFIG_PATH = str(PROJECT_DIR / "config.json")
LOG_FILE = str(PROJECT_DIR / "logs" / "scheduler.log")

# Scheduling config
DAILY_HOUR = 16  # Esecuzione alle 16:00
TIMEZONE = "Europe/Rome"


def log(msg: str):
    """Log con timestamp su file e stdout."""
    ts = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    try:
        os.makedirs(os.path.dirname(LOG_FILE), exist_ok=True)
        with open(LOG_FILE, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception as e:
        print(f"[LOG] Errore scrittura log: {e}", flush=True)


def load_config() -> dict:
    with open(CONFIG_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def send_telegram(config: dict, message: str):
    """Invia messaggio Telegram."""
    tg_token = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    tg_chat_id = os.environ.get("TELEGRAM_CHAT_ID", "")
    if not tg_token or not tg_chat_id:
        log("  ⚠️  Telegram non configurato (mancano env vars)")
        return
    try:
        resp = requests.post(
            f"https://api.telegram.org/bot{tg_token}/sendMessage",
            data={
                "chat_id": tg_chat_id,
                "text": message,
                "parse_mode": "Markdown",
            },
            timeout=10,
        )
        if resp.json().get("ok"):
            log("  📱 Telegram inviato!")
        else:
            log(f"  ⚠️  Telegram error: {resp.text}")
    except Exception as e:
        log(f"  ⚠️  Telegram error: {e}")


def check_rose_email(config: dict) -> str | None:
    """Controlla se l'email di Rose con il CSV è arrivata. Ritorna il path o None."""
    try:
        watcher = EmailWatcher(config)
        csv_path = watcher.download_latest_supplier_csv("/tmp/finance_daily_cogs")
        return csv_path
    except Exception as e:
        log(f"  ⚠️  Errore check email: {e}")
        return None


def run_report(supplier_csv: str = None):
    """Lancia main.py con o senza CSV fornitore."""
    cmd = [
        PYTHON, MAIN_PY,
        "--config", CONFIG_PATH,
    ]
    if supplier_csv:
        cmd.extend(["--supplier-csv", supplier_csv])

    log(f"  🚀 Lancio report: {' '.join(cmd)}")
    result = subprocess.run(cmd, capture_output=False, text=True)
    if result.returncode == 0:
        log("  ✅ Report completato con successo!")
    else:
        log(f"  ❌ Report fallito (exit code {result.returncode})")
    return result.returncode


def daily_job():
    """Job giornaliero: cerca email Rose, se non trovata manda Telegram e stop."""
    today = date.today()
    log(f"═══ FinanceAgent — Job giornaliero {today.strftime('%d/%m/%Y')} ═══")

    config = load_config()

    log("  📬 Cerco email di Rose...")
    csv_path = check_rose_email(config)

    if csv_path:
        log(f"  ✅ CSV trovato: {os.path.basename(csv_path)}")
        run_report(csv_path)
    else:
        log("  ❌ Email di Rose non trovata.")
        send_telegram(
            config,
            "⚠️ *FinanceAgent* — Rose non ha inviato l'email con il CSV prezzi oggi.\n"
            "Usa il comando manuale quando disponibile."
        )


def manual_run(skip_email: bool = False):
    """Trigger manuale: cerca email (o skip) e lancia report."""
    today = date.today()
    log(f"═══ FinanceAgent — Trigger manuale {today.strftime('%d/%m/%Y')} ═══")

    config = load_config()

    if skip_email:
        log("  ⏭️  Skip email — lancio report con matrice COGS config")
        run_report()
        return

    log("  📬 Cerco email di Rose...")
    csv_path = check_rose_email(config)

    if csv_path:
        log(f"  ✅ CSV trovato: {os.path.basename(csv_path)}")
        run_report(csv_path)
    else:
        log("  ❌ Email non trovata — lancio report con matrice COGS config")
        run_report()


def seconds_until(hour: int, minute: int = 0) -> float:
    """Calcola i secondi fino alla prossima occorrenza di HH:MM."""
    now = datetime.now()
    target = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if target <= now:
        target += timedelta(days=1)
    return (target - now).total_seconds()


def scheduler_loop():
    """Loop infinito: ogni giorno alle 16:00 lancia il job."""
    log("🟢 FinanceAgent Scheduler avviato")
    log(f"   Esecuzione giornaliera alle {DAILY_HOUR:02d}:00")

    while True:
        wait = seconds_until(DAILY_HOUR, 0)
        next_run = datetime.now() + timedelta(seconds=wait)
        log(f"⏰ Prossima esecuzione: {next_run.strftime('%Y-%m-%d %H:%M')}")
        time.sleep(wait)
        daily_job()


def main():
    import argparse
    parser = argparse.ArgumentParser(description="FinanceAgent Scheduler")
    parser.add_argument("--run-now", action="store_true",
                        help="Trigger manuale: cerca email e lancia report subito")
    parser.add_argument("--skip-email", action="store_true",
                        help="Con --run-now: salta il check email, usa matrice COGS")
    args = parser.parse_args()

    if args.run_now:
        manual_run(skip_email=args.skip_email)
    else:
        scheduler_loop()


if __name__ == "__main__":
    main()
