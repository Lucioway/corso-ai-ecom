#!/usr/bin/env python3
"""
Finance Daily — Test Connessioni
Esegui dal terminale:
  cd <repo>/report
  python3 test_connections.py
"""
import json, sys

print("\n" + "="*55)
print("  Finance Daily — Test Connessioni")
print("="*55)

# ── Config ────────────────────────────────────────────────────
try:
    config = json.load(open("config.json"))
    print("\n✅ config.json caricato")
except Exception as e:
    print(f"\n❌ config.json: {e}")
    sys.exit(1)

# ── Test 1: Shopify ───────────────────────────────────────────
print("\n[1/3] 🛒 Test Shopify API...")
try:
    import requests
    shop  = config["shopify"]["shop_url"]
    token = config["shopify"]["api_password"]
    r = requests.get(
        f"https://{shop}/admin/api/2024-01/shop.json",
        headers={"X-Shopify-Access-Token": token},
        timeout=10
    )
    if r.status_code == 200:
        name = r.json()["shop"]["name"]
        print(f"   ✅ Connesso! Store: {name}")
    elif r.status_code == 401:
        print(f"   ❌ Token non valido (401) — controlla api_password in config.json")
    elif r.status_code == 403:
        print(f"   ❌ Permessi insufficienti (403) — aggiungi read_orders all'app")
    else:
        print(f"   ⚠️  Status: {r.status_code} — {r.text[:100]}")
except Exception as e:
    print(f"   ❌ Errore: {e}")

# ── Test 2: Shopify Ordini ieri ───────────────────────────────
print("\n[2/3] 📦 Test recupero ordini (ieri)...")
try:
    from datetime import date, timedelta
    ieri = date.today() - timedelta(days=1)
    r = requests.get(
        f"https://{shop}/admin/api/2024-01/orders/count.json",
        headers={"X-Shopify-Access-Token": token},
        params={
            "created_at_min": f"{ieri}T00:00:00+00:00",
            "created_at_max": f"{ieri}T23:59:59+00:00",
            "status": "any"
        },
        timeout=10
    )
    if r.status_code == 200:
        count = r.json().get("count", 0)
        print(f"   ✅ Ordini {ieri.strftime('%d/%m/%Y')}: {count} ordini trovati")
    else:
        print(f"   ⚠️  Status: {r.status_code}")
except Exception as e:
    print(f"   ❌ Errore: {e}")

# ── Test 3: Triple Whale ──────────────────────────────────────
print("\n[3/3] 🐋 Test Triple Whale API...")
try:
    tw_key  = config["triple_whale"]["api_key"]
    tw_shop = config["triple_whale"]["shop_url"]
    from datetime import date, timedelta
    ieri = date.today() - timedelta(days=1)
    r = requests.post(
        "https://api.triplewhale.com/api/v2/summary-page/get-data",
        headers={"x-api-key": tw_key, "Content-Type": "application/json"},
        json={
            "shopDomain": tw_shop,
            "start": ieri.strftime("%Y-%m-%d"),
            "end": ieri.strftime("%Y-%m-%d"),
            "currency": "EUR",
        },
        timeout=15
    )
    if r.status_code == 200:
        data = r.json()
        spend = data.get("totalAdSpend", data.get("spend", "N/A"))
        print(f"   ✅ Connesso! Spend ieri: €{spend}")
    elif r.status_code == 401:
        print(f"   ❌ API key non valida (401) — controlla triple_whale.api_key")
    elif r.status_code == 403:
        print(f"   ❌ Permessi insufficienti — controlla gli scopes dell'API key TW")
    else:
        print(f"   ⚠️  Status: {r.status_code} — {r.text[:200]}")
except Exception as e:
    print(f"   ❌ Errore: {e}")

print("\n" + "="*55)
print("  Test completati.")
print("="*55 + "\n")
