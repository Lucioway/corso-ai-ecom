"""
Report Generator — Finance Agent v2.0
Generates the daily Excel report with REAL transaction data:
  - Exact gateway fees (from Shopify transactions)
  - Customer currency, original amount, exchange rate
  - Actual payment method (Card Visa, Klarna, PayPal, etc.)

Tabs:
  1. Analysis  (P&L, KPI, COGS breakdown, highlights/concerns, trend)
  2. Orders    (full detail per order — real fees, currency, method)
  3. Products  (breakdown by product category)
  4. Countries (breakdown by country)
  5. Subscriptions (daily sub orders detail)
  6. Subscription Analytics (LTV, CAC, MRR, projections)
  7. Meta Campaigns (if data available)
"""
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter
from datetime import date
from collections import defaultdict


# ── Palette colori ────────────────────────────────────────────────────────────
HDR_FILL  = PatternFill("solid", start_color="1F3864")
ALT_FILL  = PatternFill("solid", start_color="EBF2FA")
OK_FILL   = PatternFill("solid", start_color="C6EFCE")
WARN_FILL = PatternFill("solid", start_color="FFEB9C")
ERR_FILL  = PatternFill("solid", start_color="FFC7CE")
WHITE     = PatternFill("solid", start_color="FFFFFF")
BLUE_FILL = PatternFill("solid", start_color="BDD7EE")
DARK_HDR  = PatternFill("solid", start_color="2E4D91")
SECTION   = PatternFill("solid", start_color="D9E1F2")

ROAS_RED    = PatternFill("solid", start_color="FF4444")
ROAS_YELLOW = PatternFill("solid", start_color="FFD700")
ROAS_GREEN  = PatternFill("solid", start_color="70AD47")
ROAS_BLUE   = PatternFill("solid", start_color="4472C4")

HDR_FONT   = Font(name="Arial", bold=True, color="FFFFFF", size=10)
BODY_FONT  = Font(name="Arial", size=10)
BOLD_FONT  = Font(name="Arial", bold=True, size=10)
TITLE_FONT = Font(name="Arial", bold=True, size=14, color="1F3864")
KPI_FONT   = Font(name="Arial", bold=True, size=11)

THIN   = Side(style="thin", color="BFBFBF")
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)

# Default formats are EUR; for USD-mode reports we override at runtime via _set_currency()
FMT_EUR  = '#,##0.00 "€";[Red]-#,##0.00 "€";"-"'
FMT_PCT  = '0.0%;[Red]-0.0%;"-"'
FMT_NUM  = '#,##0;-#,##0;"-"'
FMT_ROAS = '0.00"x"'
FMT_DATE = 'DD/MM/YYYY'
FMT_RATE = '0.000000'
FMT_NUM2 = '#,##0.00;-#,##0.00;"-"'
FMT_USD  = '#,##0.00 "$";[Red]-#,##0.00 "$";"-"'


def _set_currency(symbol: str):
    """Switch the global EUR format string to use the given currency symbol ($, £, etc.)."""
    global FMT_EUR
    FMT_EUR = '#,##0.00 "' + symbol + '";[Red]-#,##0.00 "' + symbol + '";"-"'

# ── ISO 3166-1 alpha-2 → full English country name ───────────────────────────
COUNTRY_NAMES = {
    "AT": "Austria", "AU": "Australia", "BE": "Belgium", "BG": "Bulgaria",
    "BR": "Brazil", "CA": "Canada", "CH": "Switzerland", "CL": "Chile",
    "CN": "China", "CO": "Colombia", "CY": "Cyprus", "CZ": "Czechia",
    "DE": "Germany", "DK": "Denmark", "EE": "Estonia", "ES": "Spain",
    "FI": "Finland", "FR": "France", "GB": "United Kingdom", "GR": "Greece",
    "HR": "Croatia", "HU": "Hungary", "IE": "Ireland", "IL": "Israel",
    "IN": "India", "IS": "Iceland", "IT": "Italy", "JP": "Japan",
    "LT": "Lithuania", "LU": "Luxembourg", "LV": "Latvia", "MA": "Morocco",
    "MT": "Malta", "MX": "Mexico", "NL": "Netherlands", "NO": "Norway",
    "NZ": "New Zealand", "PH": "Philippines", "PL": "Poland", "PT": "Portugal",
    "RO": "Romania", "RS": "Serbia", "SA": "Saudi Arabia", "SE": "Sweden",
    "SG": "Singapore", "SI": "Slovenia", "SK": "Slovakia", "TR": "Türkiye",
    "UA": "Ukraine", "US": "United States", "ZA": "South Africa",
}


def _country_name(code: str) -> str:
    """Return the English country name for an ISO alpha-2 code; falls back to the code."""
    if not code:
        return "—"
    code = code.strip().upper()
    return COUNTRY_NAMES.get(code, code)


# ── Mappa keyword → categoria prodotto ────────────────────────────────────────
CATEGORY_KEYWORDS = {
    "AntiOx":   ["antiox", "antioxidant"],
}


def _get_product_category(title: str) -> str:
    t = (title or "").lower()
    for cat, keywords in CATEGORY_KEYWORDS.items():
        for kw in keywords:
            if kw in t:
                return cat
    # Fallback: use the first 25 chars of the actual product title
    return (title or "Unknown")[:25]


def _order_category(order: dict) -> str:
    cats = set()
    for line in order.get("line_items", []):
        c = _get_product_category(line.get("title", ""))
        if c != "Other":
            cats.add(c)
    if not cats:
        return "Other"
    if len(cats) == 1:
        return list(cats)[0]
    return "Mix (" + "+".join(sorted(cats)) + ")"


# ── Helpers di cella ──────────────────────────────────────────────────────────
def _h(ws, r, c, v, w=None):
    cell = ws.cell(row=r, column=c, value=v)
    cell.font = HDR_FONT
    cell.fill = HDR_FILL
    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    cell.border = BORDER
    if w:
        ws.column_dimensions[get_column_letter(c)].width = max(
            ws.column_dimensions[get_column_letter(c)].width, w)
    return cell


def _c(ws, r, c, v, fmt=None, fill=None, bold=False, align="left"):
    cell = ws.cell(row=r, column=c, value=v)
    cell.font = BOLD_FONT if bold else BODY_FONT
    cell.border = BORDER
    cell.alignment = Alignment(horizontal=align, vertical="center")
    if fmt:
        cell.number_format = fmt
    if fill:
        cell.fill = fill
    return cell


def _roas_fill(roas: float, thresholds: dict) -> PatternFill:
    if roas >= thresholds.get("blue", 2.20):
        return ROAS_BLUE
    elif roas >= thresholds.get("green", 2.20):
        return ROAS_GREEN
    elif roas >= thresholds.get("yellow", 1.80):
        return ROAS_GREEN
    elif roas >= thresholds.get("red", 1.50):
        return ROAS_YELLOW
    return ROAS_RED


def _roas_emoji(roas: float, thresholds: dict) -> str:
    if roas >= thresholds.get("blue", 2.20):
        return "🔵"
    elif roas >= thresholds.get("green", 1.80):
        return "🟢"
    elif roas >= thresholds.get("yellow", 1.50):
        return "🟡"
    return "🔴"


def _freeze(ws, r, c):
    ws.freeze_panes = ws.cell(row=r, column=c)


# ── Fee gateway: USA DATI REALI da Stripe payout (preferito) o GraphQL ──────
def _order_real_fee(order: dict, config: dict) -> float:
    """
    Returns the REAL gateway fee for an order in the report currency.
    Priority:
      1. _payout_fee from Stripe balance transaction (incl. FX conversion fee)
         — converted into report currency if needed
      2. _gateway_fee from Shopify GraphQL (card processing fee only, in shop currency)
      3. Estimated fallback
    """
    target_cur = config.get("report", {}).get("currency", "EUR")
    fx = config.get("_fx_eur_usd") or config.get("report", {}).get("fx_fallback_eur_usd", 1.0)

    payout_fee = order.get("_payout_fee", 0) or 0
    payout_cur = order.get("_payout_currency")
    if payout_fee > 0 and payout_cur:
        if payout_cur == target_cur:
            return round(float(payout_fee), 2)
        # Convert USD → EUR (or vice versa)
        if payout_cur == "USD" and target_cur == "EUR" and fx:
            return round(float(payout_fee) / fx, 2)
        if payout_cur == "EUR" and target_cur == "USD" and fx:
            return round(float(payout_fee) * fx, 2)

    real_fee = order.get("_gateway_fee", 0)
    if real_fee > 0:
        return real_fee

    revenue = float(order.get("_gross_revenue", 0))
    default_rate = config.get("finance", {}).get("payment_gateway_fees", {}).get("default", 0.04)
    return round(revenue * default_rate, 2)


def _fee_is_real(order: dict) -> bool:
    """True if fee comes from real Stripe data (payout or GraphQL transaction)."""
    return (order.get("_payout_fee", 0) > 0) or (order.get("_gateway_fee", 0) > 0)


# ── Subscription detection (Kaching Subscriptions) ───────────────────────────
def _order_tags(order: dict) -> list:
    raw = order.get("tags", "") or ""
    return [t.strip() for t in raw.split(",") if t.strip()]


def _is_subscription_order(order: dict) -> bool:
    """True if the order contains a Kaching subscription."""
    tags = [t.lower() for t in _order_tags(order)]
    return any("subscription" in t for t in tags)


def _is_first_subscription(order: dict) -> bool:
    """True if this is the first order of a subscription (acquisition)."""
    tags = [t.lower() for t in _order_tags(order)]
    return any("first order" in t for t in tags)


def _is_recurring_subscription(order: dict) -> bool:
    """True if this is a recurring subscription order (not the first)."""
    return _is_subscription_order(order) and not _is_first_subscription(order)


def _is_cancelled_subscription(order: dict) -> bool:
    """True if a subscription order has been cancelled."""
    return _is_subscription_order(order) and bool(order.get("cancelled_at"))


def compute_subscription_kpis(orders: list, config: dict = None) -> dict:
    """
    Aggregates subscription KPIs from a list of enriched orders.
    Returns a dict ready for both the report Excel tab and the Telegram recap.
    """
    config = config or {}
    sub_orders   = [o for o in orders if _is_subscription_order(o)]
    first_orders = [o for o in sub_orders if _is_first_subscription(o)]
    recur_orders = [o for o in sub_orders if not _is_first_subscription(o)]
    cancelled    = [o for o in sub_orders if _is_cancelled_subscription(o)]

    n_total       = len(orders)
    n_sub         = len(sub_orders)
    n_first       = len(first_orders)
    n_recur       = len(recur_orders)
    n_cancelled   = len(cancelled)
    sub_pct       = (n_sub / n_total) if n_total > 0 else 0

    sub_revenue   = sum(float(o.get("_gross_revenue", 0) or 0) for o in sub_orders)
    first_revenue = sum(float(o.get("_gross_revenue", 0) or 0) for o in first_orders)
    recur_revenue = sum(float(o.get("_gross_revenue", 0) or 0) for o in recur_orders)
    sub_cogs      = sum((o.get("_cogs_data") or {}).get("total_cogs", 0) for o in sub_orders)
    sub_fees      = sum(_order_real_fee(o, config) for o in sub_orders)
    sub_net       = sub_revenue - sub_cogs - sub_fees

    return {
        "n_total":         n_total,
        "n_sub":           n_sub,
        "n_first":         n_first,
        "n_recur":         n_recur,
        "n_cancelled":     n_cancelled,
        "sub_pct":         sub_pct,
        "sub_revenue":     round(sub_revenue, 2),
        "first_revenue":   round(first_revenue, 2),
        "recur_revenue":   round(recur_revenue, 2),
        "sub_cogs":        round(sub_cogs, 2),
        "sub_fees":        round(sub_fees, 2),
        "sub_net":         round(sub_net, 2),
        "sub_aov":         round(sub_revenue / n_sub, 2) if n_sub else 0,
        "first_aov":       round(first_revenue / n_first, 2) if n_first else 0,
        "recur_aov":       round(recur_revenue / n_recur, 2) if n_recur else 0,
        "sub_cogs_pct":    (sub_cogs / sub_revenue) if sub_revenue else 0,
        "sub_net_pct":     (sub_net  / sub_revenue) if sub_revenue else 0,
    }


# ── Generatore Highlights (no targets per ora) ────────────────────────────────
def _build_punti(roas_blend, meta_roas, tiktok_roas, cogs_pct,
                 n_orders, uv, total_adv, revenue_nt, net, fin):
    fav = []
    fav.append(f"{n_orders} orders today")
    fav.append(f"ROAS Blended {roas_blend:.2f}x")
    if meta_roas > 0:
        fav.append(f"Meta ROAS {meta_roas:.2f}x")
    if tiktok_roas > 0:
        fav.append(f"TikTok ROAS {tiktok_roas:.2f}x")
    fav.append(f"COGS {cogs_pct*100:.1f}%")
    if revenue_nt > 0:
        adv_pct = total_adv / revenue_nt
        fav.append(f"Ads {adv_pct*100:.1f}% of revenue")
    fav.append(f"Net per order €{uv:.2f}")
    return fav, []


# ══════════════════════════════════════════════════════════════════════════════
# TAB 1 — ANALISI (P&L + KPI)
# ══════════════════════════════════════════════════════════════════════════════
def build_analisi_sheet(ws, orders: list, tw_data: dict, cogs_daily: dict,
                        config: dict, report_date: date, meta_campaigns: list = None,
                        daily_returns: dict = None, revenue_override: float = None):
    ws.title = "Analysis"
    fin   = config.get("finance", {})
    rep   = config.get("report", {})
    thr   = fin.get("roas_color_thresholds", {"red": 1.50, "yellow": 1.80, "green": 2.20})

    # ── Calculate order metrics (exclude reshipments from revenue) ──────────
    paid_orders = [o for o in orders if not o.get("_is_reshipment", False)]
    n_orders    = len(paid_orders)
    # Gross revenue = sum of total_price (EUR) for the day's orders (includes shipping+tax, after discounts)
    shopify_order_revenue = sum(float(o.get("_shop_amount", 0)) for o in paid_orders)
    total_tax   = sum(float(o.get("_tax", 0)) for o in paid_orders)

    # Returns processed today (from any order, not just today's)
    daily_returns_total = (daily_returns or {}).get("total_refunded", 0)
    daily_returns_count = (daily_returns or {}).get("refund_count", 0)

    # REAL GATEWAY FEES (no longer estimated!)
    total_gw    = sum(_order_real_fee(o, config) for o in paid_orders)
    n_real_fees = sum(1 for o in paid_orders if _fee_is_real(o))
    n_estimated = n_orders - n_real_fees

    # ── Revenue: Shopify Total Sales ──
    if revenue_override:
        total_gross  = revenue_override
    else:
        total_gross  = round(shopify_order_revenue - daily_returns_total, 2)
    revenue_nt   = total_gross  # Shopify Total Sales

    # ── Fee breakdown by payment method ──
    fee_by_method = defaultdict(lambda: {"count": 0, "revenue": 0.0, "fee": 0.0})
    for o in paid_orders:
        method = o.get("_payment_method", "Unknown")
        fee_by_method[method]["count"] += 1
        fee_by_method[method]["revenue"] += float(o.get("_gross_revenue", 0))
        fee_by_method[method]["fee"] += _order_real_fee(o, config)

    # COGS
    total_cogs  = cogs_daily.get("total_cogs", 0)
    base_cogs   = cogs_daily.get("base_cogs", 0)
    cogs_pct    = total_cogs / revenue_nt if revenue_nt > 0 else 0

    # ADV
    meta_spend   = tw_data.get("channels", {}).get("meta",   {}).get("spend_eur", 0)
    tiktok_spend = tw_data.get("channels", {}).get("tiktok", {}).get("spend_eur", 0)
    total_adv    = tw_data.get("spend_eur", meta_spend + tiktok_spend)
    meta_roas    = tw_data.get("channels", {}).get("meta",   {}).get("roas", 0)
    tiktok_roas  = tw_data.get("channels", {}).get("tiktok", {}).get("roas", 0)
    roas_attr    = tw_data.get("roas_attributed", 0)
    roas_blend   = tw_data.get("roas_blended",   0)

    # P&L (returns already subtracted in revenue = Total Sales)
    gross_profit = revenue_nt - total_cogs
    ebitda       = gross_profit - total_gw
    net          = ebitda - total_adv
    net_pct      = net / revenue_nt if revenue_nt > 0 else 0
    aov          = revenue_nt / n_orders if n_orders > 0 else 0
    uv           = net / n_orders if n_orders > 0 else 0
    gw_pct_real  = total_gw / revenue_nt if revenue_nt > 0 else 0.04
    be_roas      = round(1 / (1 - cogs_pct - gw_pct_real), 2) if (1 - cogs_pct - gw_pct_real) > 0 else 99

    # ── Layout ─────────────────────────────────────────────────────────────────
    ws.column_dimensions["A"].width = 36
    ws.column_dimensions["B"].width = 16
    ws.column_dimensions["C"].width = 14
    ws.column_dimensions["D"].width = 14
    ws.column_dimensions["E"].width = 14

    r = 1
    company = rep.get("company_name", "Company")
    t = ws.cell(r, 1, f"{company} — Daily P&L   {report_date.strftime('%d %B %Y')}")
    t.font = TITLE_FONT
    ws.merge_cells(f"A{r}:E{r}")
    ws.row_dimensions[r].height = 28
    r += 2

    # ── KPI ROW ──
    kpi_labels = ["ROAS Blended", "ROAS Meta", "ROAS TikTok", "AOV", "Net per Order", "BE ROAS"]
    kpi_values = [roas_blend, meta_roas, tiktok_roas, aov, uv, be_roas]
    kpi_fmts   = [FMT_ROAS, FMT_ROAS, FMT_ROAS, FMT_EUR, FMT_EUR, FMT_ROAS]

    for c, (lbl, val, fmt) in enumerate(zip(kpi_labels, kpi_values, kpi_fmts), 1):
        lc = ws.cell(r, c, lbl)
        lc.font = Font(name="Arial", bold=True, size=9, color="666666")
        lc.alignment = Alignment(horizontal="center")
        r += 1
        vc = ws.cell(r, c, val)
        vc.font = KPI_FONT
        vc.number_format = fmt
        vc.alignment = Alignment(horizontal="center")
        vc.border = BORDER
        if c <= 3:
            vc.fill = _roas_fill(val, thr)
            vc.font = Font(name="Arial", bold=True, size=11, color="FFFFFF")
        elif c == 5:
            vc.fill = OK_FILL if val >= fin.get("target_uv_min", 15) else WARN_FILL
        elif c == 6:
            vc.fill = OK_FILL
        r -= 1

    r += 3

    # ── P&L TABLE ──
    def sec(row, title):
        c = ws.cell(row, 1, title)
        c.font = Font(name="Arial", bold=True, size=11, color="1F3864")
        c.fill = SECTION
        ws.merge_cells(f"A{row}:C{row}")
        c.alignment = Alignment(horizontal="left")

    def prow(row, label, val, fmt=FMT_EUR, hl=None, pct_val=None):
        ws.cell(row, 1, label).font = BODY_FONT
        ws.cell(row, 1).border = BORDER
        v = ws.cell(row, 2, val)
        v.number_format = fmt
        v.font = BOLD_FONT
        v.border = BORDER
        v.alignment = Alignment(horizontal="right")
        if hl:
            v.fill = hl
        if pct_val is not None:
            p = ws.cell(row, 3, pct_val)
            p.number_format = FMT_PCT
            p.font = BODY_FONT
            p.border = BORDER
            p.alignment = Alignment(horizontal="right")

    ws.cell(r, 2, "Amount (€)").font = HDR_FONT
    ws.cell(r, 2).fill = HDR_FILL
    ws.cell(r, 2).alignment = Alignment(horizontal="center")
    ws.cell(r, 3, "% Revenue").font = HDR_FONT
    ws.cell(r, 3).fill = HDR_FILL
    ws.cell(r, 3).alignment = Alignment(horizontal="center")
    r += 1

    sec(r, "REVENUE"); r += 1
    prow(r, "Revenue (Total Sales)",  revenue_nt,   hl=BLUE_FILL, pct_val=1.0); r += 1
    prow(r, "Orders",              n_orders,     fmt=FMT_NUM); r += 1
    prow(r, "AOV",                 aov); r += 2

    sec(r, "COGS (Cost of Goods Sold)"); r += 1
    prow(r, "COGS Base (supplier)", base_cogs,  pct_val=base_cogs/revenue_nt if revenue_nt else 0); r += 1
    # Thank You Cards and Branded Bags removed
    cogs_fill = OK_FILL if cogs_pct <= 0.25 else (WARN_FILL if cogs_pct <= 0.30 else ERR_FILL)
    prow(r, "TOTAL COGS", total_cogs, hl=cogs_fill, pct_val=cogs_pct); r += 1
    prow(r, "Gross Profit", gross_profit, pct_val=gross_profit/revenue_nt if revenue_nt else 0); r += 2

    sec(r, "ADV (Meta + TikTok via Triple Whale)"); r += 1
    prow(r, f"Meta Ads (ROAS {meta_roas:.2f}x {_roas_emoji(meta_roas, thr)})", meta_spend,
         pct_val=meta_spend/revenue_nt if revenue_nt else 0); r += 1
    prow(r, f"TikTok Ads (ROAS {tiktok_roas:.2f}x {_roas_emoji(tiktok_roas, thr)})", tiktok_spend,
         pct_val=tiktok_spend/revenue_nt if revenue_nt else 0); r += 1
    prow(r, "TOTAL ADV", total_adv, hl=WARN_FILL, pct_val=total_adv/revenue_nt if revenue_nt else 0); r += 2

    # ── GATEWAY — BREAKDOWN BY PAYMENT METHOD (real fees) ──
    fee_source = "REAL" if n_real_fees > n_estimated else "ESTIMATED"
    sec(r, f"PAYMENT GATEWAY ({fee_source} fees — {n_real_fees}/{n_orders} from transactions)"); r += 1

    # Show fees by payment method
    for method in sorted(fee_by_method.keys(), key=lambda m: -fee_by_method[m]["fee"]):
        md = fee_by_method[method]
        fee_pct = md["fee"] / md["revenue"] if md["revenue"] > 0 else 0
        label = f"{method} ({md['count']} orders, {fee_pct*100:.2f}%)"
        prow(r, label, md["fee"], pct_val=md["fee"]/revenue_nt if revenue_nt else 0); r += 1

    prow(r, "TOTAL GATEWAY", total_gw, pct_val=total_gw/revenue_nt if revenue_nt else 0); r += 1
    if daily_returns_total > 0:
        prow(r, f"Returns processed today ({daily_returns_count} refunds)", daily_returns_total,
             pct_val=daily_returns_total/shopify_order_revenue if shopify_order_revenue else 0); r += 1
        ws.cell(r - 1, 1).font = Font(name="Arial", italic=True, size=9, color="888888")
    r += 1

    sec(r, "RESULT"); r += 1
    net_fill = OK_FILL if net >= 0 else ERR_FILL
    # Direction-aware alt-currency line: `net` is already in target_cur.
    # target_cur=EUR → show USD = net*fx. target_cur=USD → show EUR = net/fx.
    target_cur = rep.get("currency", "EUR")
    fx_eur_usd = config.get("_fx_eur_usd") or rep.get("fx_fallback_eur_usd", 1.08)
    if target_cur == "USD":
        alt_label, alt_fmt = "EUR", FMT_EUR
        net_alt = net / fx_eur_usd if fx_eur_usd else 0
        uv_alt  = uv  / fx_eur_usd if fx_eur_usd else 0
    else:
        alt_label, alt_fmt = "USD", FMT_USD
        net_alt = net * fx_eur_usd
        uv_alt  = uv  * fx_eur_usd
    prow(r, "EBITDA", ebitda, pct_val=ebitda/revenue_nt if revenue_nt else 0); r += 1
    prow(r, "EXACT NET", net, hl=net_fill, pct_val=net_pct); r += 1
    prow(r, f"EXACT NET ({alt_label}) — fx {fx_eur_usd:.4f}", net_alt, fmt=alt_fmt, hl=net_fill); r += 1
    prow(r, "Net per Order", uv); r += 1
    prow(r, f"Net per Order ({alt_label})", uv_alt, fmt=alt_fmt); r += 1
    prow(r, "BE ROAS", be_roas, fmt=FMT_ROAS); r += 2

    # ── SUPPLIER INVOICE NOTE ──
    sec(r, "📦 Supplier Invoice Note"); r += 1
    cogs_info = [
        f"COGS Base: €{base_cogs:.2f}",
        f"TOTAL COGS: €{total_cogs:.2f} ({cogs_pct*100:.1f}%)",
    ]
    for info in cogs_info:
        if info:
            cell = ws.cell(r, 1, info)
            cell.font = BODY_FONT
            cell.border = BORDER
            r += 1
    r += 1

    # ── HIGHLIGHTS only (concerns removed) ──
    favorevoli, _ = _build_punti(
        roas_blend, meta_roas, tiktok_roas, cogs_pct, n_orders, uv,
        total_adv, revenue_nt, net, fin
    )

    if favorevoli:
        sec(r, "✅ HIGHLIGHTS"); r += 1
        for txt in favorevoli:
            c = ws.cell(r, 1, f"    {txt}")
            c.font = Font(name="Arial", size=10, color="375623")
            c.fill = PatternFill("solid", start_color="E2EFDA")
            c.border = BORDER
            ws.merge_cells(f"A{r}:E{r}")
            r += 1
        r += 1

    # ── META CAMPAIGNS ──
    if meta_campaigns:
        sec(r, "📣 Meta Campaigns (color coded)"); r += 1
        camp_hdrs = [("Campaign", 30), ("Spend", 12), ("Revenue", 12), ("ROAS", 10),
                     ("Purchases", 10), ("CPA", 10), ("% Budget", 10), ("🎨", 6)]
        for c, (h, w) in enumerate(camp_hdrs, 1):
            _h(ws, r, c, h, w)
        r += 1
        total_camp_spend = sum(float(c.get("spend", 0)) for c in meta_campaigns)
        for camp in sorted(meta_campaigns, key=lambda x: -float(x.get("spend", 0))):
            spend   = float(camp.get("spend", 0))
            rev     = float(camp.get("purchase_value", camp.get("revenue", 0)))
            roas    = float(camp.get("roas", rev / spend if spend > 0 else 0))
            purch   = int(camp.get("purchases", 0))
            cpa     = spend / purch if purch > 0 else 0
            budget_pct = spend / total_camp_spend if total_camp_spend > 0 else 0
            cf      = _roas_fill(roas, thr)
            emoji   = _roas_emoji(roas, thr)
            vals = [camp.get("name", ""), spend, rev, roas, purch, cpa, budget_pct, emoji]
            fmts = [None, FMT_EUR, FMT_EUR, FMT_ROAS, FMT_NUM, FMT_EUR, FMT_PCT, None]
            for c, (v, fmt) in enumerate(zip(vals, fmts), 1):
                fill = cf if c in (4, 8) else (ALT_FILL if r % 2 == 0 else WHITE)
                _c(ws, r, c, v, fmt, fill, bold=(c == 4))
            r += 1
        r += 1

    _freeze(ws, 4, 1)

    return {
        "gross": total_gross, "revenue_net_tax": revenue_nt,
        "shopify_order_revenue": shopify_order_revenue,
        "daily_returns": daily_returns_total,
        "cogs": total_cogs, "cogs_pct": cogs_pct, "base_cogs": base_cogs,
        "gross_profit": gross_profit,
        "meta_adv": meta_spend, "tiktok_adv": tiktok_spend, "total_adv": total_adv,
        "fees": total_gw, "fees_real_count": n_real_fees, "fees_estimated_count": n_estimated,
        "refunds": daily_returns_total,
        "net": net, "net_margin_pct": net_pct,
        "net_alt": net_alt, "uv_alt": uv_alt,
        "alt_currency": alt_label, "fx_eur_usd": fx_eur_usd,
        "target_currency": target_cur,
        "aov": aov, "uv": uv, "be_roas": be_roas,
        "roas_attributed": roas_attr, "roas_blended": roas_blend,
        "meta_roas": meta_roas, "tiktok_roas": tiktok_roas,
        "n_orders": n_orders,
        "purchase_value": total_gross,
        "gross_margin_pct": gross_profit / revenue_nt if revenue_nt > 0 else 0,
    }


# ══════════════════════════════════════════════════════════════════════════════
# TAB 2 — ORDINI (dettaglio completo con fee reali, valuta, metodo pagamento)
# ══════════════════════════════════════════════════════════════════════════════
def build_ordini_sheet(ws, orders: list, config: dict, report_date: date):
    ws.title = f"Orders {report_date.strftime('%d-%m')}"

    headers = [
        ("Order", 14),
        ("Country", 18),
        ("Product", 22),
        ("Detail", 26),
        ("Qty", 5),
        ("Customer Currency", 10),
        ("Original Amount", 14),
        ("Exchange Rate", 10),
        ("Revenue EUR", 13),
        ("Shipping EUR", 11),
        ("COGS €", 11),
        ("COGS %", 8),
        ("Payment Method", 16),
        ("Gateway Fee €", 11),
        ("Fee %", 7),
        ("Net Pre-Ads €", 14),
        ("Margin %", 9),
        ("Discount €", 10),
        ("Financial Status", 14),
        ("Payout Cur", 10),
        ("Gross Payout", 13),
        ("Fee Payout", 12),
        ("Net Payout", 13),
    ]
    for c, (h, w) in enumerate(headers, 1):
        _h(ws, 1, c, h, w)
    _freeze(ws, 2, 1)
    thr = config.get("finance", {}).get("roas_color_thresholds", {"red": 1.50, "yellow": 1.80, "green": 2.20})

    r = 2
    for order in orders:
        country = _country_name(order.get("billing_address", {}).get("country_code", ""))
        revenue = float(order.get("_gross_revenue", 0))
        shipping = float(order.get("_shipping", 0))
        fee = _order_real_fee(order, config)
        is_real = _fee_is_real(order)
        cogs_data = order.get("_cogs_data", {})
        cogs = cogs_data.get("total_cogs", 0)
        cogs_pct_val = cogs / revenue if revenue > 0 else 0
        fee_pct = fee / revenue if revenue > 0 else 0
        net_pre = revenue - cogs - fee
        margin_pct = net_pre / revenue if revenue > 0 else 0
        discount = float(order.get("_discount", 0))
        fill = ALT_FILL if r % 2 == 0 else WHITE
        cogs_fill = ERR_FILL if cogs_pct_val > 0.30 else (WARN_FILL if cogs_pct_val > 0.25 else OK_FILL)

        # Customer currency and original amount
        cust_currency = order.get("_customer_currency", "EUR")
        cust_amount = order.get("_customer_amount", revenue)
        ex_rate = order.get("_exchange_rate", 1.0)

        # Payment method
        payment_method = order.get("_payment_method", "Unknown")

        # Financial status
        fin_status = order.get("financial_status", "paid")

        product_names = ", ".join(
            set(l.get("title", "")[:20] for l in order.get("line_items", []))
        ) or ""
        detail = "; ".join(
            f"{l.get('quantity', 1)}× {(l.get('variant_title') or l.get('title') or '')[:20]}"
            for l in order.get("line_items", [])
        )
        total_qty = sum(int(l.get("quantity", 1)) for l in order.get("line_items", []))

        # Real Stripe payout (USD or EUR depending on Stripe routing)
        payout_cur   = order.get("_payout_currency") or "—"
        payout_gross = order.get("_payout_gross", 0) or 0
        payout_fee   = order.get("_payout_fee", 0) or 0
        payout_net   = order.get("_payout_net", 0) or 0
        payout_fmt   = (
            '#,##0.00 "' + payout_cur + '"' if payout_cur in ("USD", "EUR") else FMT_NUM2
        )

        vals_fmts = [
            (order.get("name", order.get("id")), None),      # 1 Ordine
            (country, None),                                   # 2 Paese
            (product_names, None),                             # 3 Prodotto
            (detail, None),                                    # 4 Dettaglio
            (total_qty, FMT_NUM),                              # 5 Qty
            (cust_currency, None),                             # 6 Valuta Cliente
            (cust_amount, FMT_NUM2),                            # 7 Importo Originale
            (ex_rate, FMT_RATE if cust_currency != "EUR" else None),  # 8 Tasso Cambio
            (revenue, FMT_EUR),                                # 9 Revenue EUR
            (shipping, FMT_EUR),                               # 10 Spedizione EUR
            (cogs, FMT_EUR),                                   # 11 COGS
            (cogs_pct_val, FMT_PCT),                           # 12 COGS %
            (payment_method, None),                            # 13 Metodo Pagamento
            (fee, FMT_EUR),                                    # 14 Fee Gateway (REAL)
            (fee_pct, FMT_PCT),                                # 15 Fee %
            (net_pre, FMT_EUR),                                # 16 Net Pre-Ads
            (margin_pct, FMT_PCT),                             # 17 Margine %
            (discount, FMT_EUR),                               # 18 Sconto
            (fin_status.replace("_", " ").title(), None),      # 19 Stato
            (payout_cur, None),                                # 20 Payout currency
            (payout_gross, payout_fmt),                        # 21 Payout gross
            (payout_fee, payout_fmt),                          # 22 Payout fee
            (payout_net, payout_fmt),                          # 23 Payout net
        ]
        usd_fill = OK_FILL if payout_cur == "USD" else (WARN_FILL if payout_cur == "—" else fill)
        for c, (v, fmt) in enumerate(vals_fmts, 1):
            if c == 12:
                f = cogs_fill
            elif c == 16:
                f = OK_FILL if net_pre >= 0 else ERR_FILL
            elif c in (20, 21, 22, 23):
                f = usd_fill
            else:
                f = fill
            _c(ws, r, c, v, fmt, f, bold=(c == 16 or c == 23))
        r += 1


# ══════════════════════════════════════════════════════════════════════════════
# TAB 3 — BREAKDOWN PRODOTTO
# ══════════════════════════════════════════════════════════════════════════════
def _bundle_signature(order: dict) -> tuple:
    """
    Returns (primary_qty, accessory_qty, other_qty) per order.
    Matches the store's SKUs by product title keyword.
    """
    # Edit these keyword lists to match YOUR product titles. "primary" = the
    # primary product, "accessory" = the secondary item/accessory; everything else
    # falls into "other". Keywords are matched as lowercase substrings.
    primary_keywords = ("product",)
    accessory_keywords = ("accessory",)
    primary = accessory = other = 0
    for li in order.get("line_items", []) or []:
        title = (li.get("title") or li.get("name") or "").lower()
        qty = int(li.get("quantity", 1) or 1)
        if any(k in title for k in primary_keywords):
            primary += qty
        elif any(k in title for k in accessory_keywords):
            accessory += qty
        else:
            other += qty
    return (primary, accessory, other)


def _bundle_label(sig: tuple) -> str:
    primary, accessory, other = sig
    parts = []
    if primary:
        parts.append(f"{primary}× Primary")
    if accessory:
        parts.append(f"{accessory}× Accessory")
    if other:
        parts.append(f"{other}× Other")
    return " + ".join(parts) if parts else "Empty"


def build_prodotti_sheet(ws, orders: list, config: dict, report_date: date):
    ws.title = "Product Breakdown"
    agg = defaultdict(lambda: {"orders": 0, "revenue": 0.0, "cogs": 0.0, "gw": 0.0,
                                "primary_units": 0, "accessory_units": 0})
    fin = config.get("finance", {})
    thr = fin.get("roas_color_thresholds", {"red": 1.50, "yellow": 1.80, "green": 2.20})

    for order in orders:
        sig     = _bundle_signature(order)
        label   = _bundle_label(sig)
        revenue = float(order.get("_gross_revenue", 0))
        fee     = _order_real_fee(order, config)
        cogs    = order.get("_cogs_data", {}).get("total_cogs", 0)
        agg[label]["orders"]      += 1
        agg[label]["revenue"]     += revenue
        agg[label]["cogs"]        += cogs
        agg[label]["gw"]          += fee
        agg[label]["primary_units"] += sig[0]
        agg[label]["accessory_units"] += sig[1]

    # Sort: by revenue desc, "Empty"/"Other"-only last
    def _sort_key(item):
        label, d = item
        is_misc = label in ("Empty",) or label.endswith("× Other")
        return (is_misc, -d["revenue"])
    sorted_cats = sorted(agg.items(), key=_sort_key)
    total_orders = max(sum(d["orders"] for d in agg.values()), 1)

    title_cell = ws.cell(1, 1, f"  BUNDLE BREAKDOWN — {report_date.strftime('%d/%m/%Y')}  ")
    title_cell.font = Font(name="Arial", bold=True, size=12, color="FFFFFF")
    title_cell.fill = HDR_FILL
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.merge_cells("A1:J1")
    ws.row_dimensions[1].height = 22

    headers = [
        ("Bundle", 28), ("Orders", 9), ("% Mix", 8),
        ("Revenue €", 13), ("COGS €", 11), ("COGS %", 9),
        ("Gateway €", 11), ("Net Profit €", 14), ("Margin %", 10), ("AOV €", 10),
    ]
    for c, (h, w) in enumerate(headers, 1):
        _h(ws, 2, c, h, w)
    _freeze(ws, 3, 1)

    r = 3
    for cat, d in sorted_cats:
        rev  = d["revenue"]
        cogs = d["cogs"]
        gw   = d["gw"]
        net  = rev - cogs - gw
        cogs_pct   = cogs / rev if rev > 0 else 0
        margin_pct = net / rev if rev > 0 else 0
        aov        = rev / d["orders"] if d["orders"] > 0 else 0
        fill       = ALT_FILL if r % 2 == 0 else WHITE
        cogs_fill  = ERR_FILL if cogs_pct > 0.30 else (WARN_FILL if cogs_pct > 0.25 else OK_FILL)
        vals_fmts = [
            (cat, None), (d["orders"], FMT_NUM),
            (d["orders"] / total_orders, FMT_PCT),
            (rev, FMT_EUR), (cogs, FMT_EUR), (cogs_pct, FMT_PCT),
            (gw, FMT_EUR), (net, FMT_EUR), (margin_pct, FMT_PCT),
            (aov, FMT_EUR),
        ]
        for c, (v, fmt) in enumerate(vals_fmts, 1):
            f = cogs_fill if c == 6 else fill
            _c(ws, r, c, v, fmt, f, bold=(c in [4, 8]))
        r += 1

    r += 1

    # ── BE ROAS by bundle ──
    be_title = ws.cell(r, 1, "  BREAK-EVEN ROAS BY BUNDLE  ")
    be_title.font = Font(name="Arial", bold=True, size=11, color="1F3864")
    be_title.fill = SECTION
    be_title.alignment = Alignment(horizontal="left", vertical="center")
    ws.merge_cells(f"A{r}:J{r}")
    ws.row_dimensions[r].height = 20
    r += 1

    be_hdrs = [
        ("Bundle", 28), ("COGS %", 9), ("GW %", 8),
        ("Fixed Costs %", 13), ("BE ROAS", 10), ("Margin at ROAS 2x", 16),
    ]
    for c, (h, w) in enumerate(be_hdrs, 1):
        _h(ws, r, c, h, w)
    r += 1

    be_rows = []
    for cat, d in sorted_cats:
        if d["revenue"] == 0:
            continue
        rev  = d["revenue"]
        cogs = d["cogs"]
        gw   = d["gw"]
        cogs_pct   = cogs / rev if rev > 0 else 0
        gw_pct     = gw / rev if rev > 0 else 0.04
        fixed_pct  = cogs_pct + gw_pct
        be_roas    = round(1 / (1 - fixed_pct), 4) if (1 - fixed_pct) > 0 else 99
        margin_2x  = 1 - fixed_pct - 0.5
        be_rows.append((cat, cogs_pct, gw_pct, fixed_pct, be_roas, margin_2x))

    be_rows.sort(key=lambda x: x[4])

    for cat, cogs_pct, gw_pct, fixed_pct, be_roas, margin_2x in be_rows:
        fill = ALT_FILL if r % 2 == 0 else WHITE
        be_fill = OK_FILL if be_roas < 1.45 else (WARN_FILL if be_roas < 1.55 else ERR_FILL)
        vals_fmts = [
            (cat, None), (cogs_pct, FMT_PCT), (gw_pct, FMT_PCT),
            (fixed_pct, FMT_PCT), (be_roas, FMT_ROAS), (max(margin_2x, 0), FMT_PCT),
        ]
        for c, (v, fmt) in enumerate(vals_fmts, 1):
            f = be_fill if c == 5 else fill
            _c(ws, r, c, v, fmt, f, bold=(c == 5))
        r += 1


# ══════════════════════════════════════════════════════════════════════════════
# TAB 4 — BREAKDOWN PAESE
# ══════════════════════════════════════════════════════════════════════════════
def build_paesi_sheet(ws, orders: list, config: dict, report_date: date):
    ws.title = "Country Breakdown"
    agg = defaultdict(lambda: {"orders": 0, "revenue": 0.0, "cogs": 0.0, "gw": 0.0, "refunds": 0.0})

    for order in orders:
        country = _country_name(order.get("billing_address", {}).get("country_code", "N/A"))
        revenue = float(order.get("_gross_revenue", 0))
        fee     = _order_real_fee(order, config)
        cogs    = order.get("_cogs_data", {}).get("total_cogs", 0)
        ref     = float(order.get("_total_refunded", 0))
        agg[country]["orders"]  += 1
        agg[country]["revenue"] += revenue
        agg[country]["cogs"]    += cogs
        agg[country]["gw"]      += fee
        agg[country]["refunds"] += ref

    headers = [
        ("Country", 20), ("Orders", 9), ("% Orders", 9),
        ("Revenue €", 12), ("% Revenue", 9), ("COGS €", 11), ("COGS %", 9),
        ("Gateway €", 11), ("Refunds €", 11), ("Net Profit €", 14), ("Margin %", 10), ("AOV €", 10),
    ]
    for c, (h, w) in enumerate(headers, 1):
        _h(ws, 1, c, h, w)
    _freeze(ws, 2, 1)

    total_orders = max(sum(d["orders"] for d in agg.values()), 1)
    total_rev    = max(sum(d["revenue"] for d in agg.values()), 0.01)

    for r, (country, d) in enumerate(sorted(agg.items(), key=lambda x: -x[1]["revenue"]), 2):
        rev  = d["revenue"]
        cogs = d["cogs"]
        gw   = d["gw"]
        ref  = d["refunds"]
        net  = rev - cogs - gw - ref
        cogs_pct   = cogs / rev if rev > 0 else 0
        margin_pct = net / rev if rev > 0 else 0
        aov  = rev / d["orders"] if d["orders"] > 0 else 0
        fill = ALT_FILL if r % 2 == 0 else WHITE
        cogs_fill = ERR_FILL if cogs_pct > 0.30 else (WARN_FILL if cogs_pct > 0.25 else OK_FILL)
        vals_fmts = [
            (country, None), (d["orders"], FMT_NUM),
            (d["orders"] / total_orders, FMT_PCT),
            (rev, FMT_EUR), (rev / total_rev, FMT_PCT),
            (cogs, FMT_EUR), (cogs_pct, FMT_PCT),
            (gw, FMT_EUR), (ref, FMT_EUR),
            (net, FMT_EUR), (margin_pct, FMT_PCT), (aov, FMT_EUR),
        ]
        for c, (v, fmt) in enumerate(vals_fmts, 1):
            f = cogs_fill if c == 7 else fill
            _c(ws, r, c, v, fmt, f, bold=(c == 10))


# ══════════════════════════════════════════════════════════════════════════════
# TAB 5 — META CAMPAIGNS
# ══════════════════════════════════════════════════════════════════════════════
def build_meta_sheet(ws, campaigns: list, ad_sets: list, ads: list, config: dict):
    ws.title = "Meta Campaigns"
    fin = config.get("finance", {})
    thr = fin.get("roas_color_thresholds", {"red": 1.50, "yellow": 1.80, "green": 2.20})

    def write_section(start_row, data, level="campaign"):
        title = ws.cell(start_row, 1, f"{'Campaigns' if level=='campaign' else 'Ad Sets' if level=='adset' else 'Ads'}")
        title.font = Font(name="Arial", bold=True, size=12, color="1F3864")
        title.fill = SECTION
        ws.merge_cells(f"A{start_row}:I{start_row}")
        start_row += 1

        hdrs = [("Name", 32), ("Spend €", 12), ("Revenue €", 12), ("ROAS", 10),
                ("Purchases", 10), ("CPA €", 10), ("% Budget", 9), ("🎨", 6)]
        if level == "ad":
            hdrs += [("Hook Rate%", 11), ("Hold Rate%", 11), ("CTR%", 9), ("CVR%", 9)]
        for c, (h, w) in enumerate(hdrs, 1):
            _h(ws, start_row, c, h, w)
        start_row += 1

        total_spend = sum(float(d.get("spend", 0)) for d in data)
        for row_data in sorted(data, key=lambda x: -float(x.get("spend", 0))):
            spend = float(row_data.get("spend", 0))
            rev   = float(row_data.get("purchase_value", row_data.get("revenue", 0)))
            roas  = float(row_data.get("roas", rev / spend if spend > 0 else 0))
            purch = int(row_data.get("purchases", 0))
            cpa   = spend / purch if purch > 0 else 0
            bpct  = spend / total_spend if total_spend > 0 else 0
            emoji = _roas_emoji(roas, thr)
            cf    = _roas_fill(roas, thr)
            fill  = ALT_FILL if start_row % 2 == 0 else WHITE

            vals = [row_data.get("name", ""), spend, rev, roas, purch, cpa, bpct, emoji]
            fmts = [None, FMT_EUR, FMT_EUR, FMT_ROAS, FMT_NUM, FMT_EUR, FMT_PCT, None]
            if level == "ad":
                vals += [row_data.get("hook_rate", 0), row_data.get("hold_rate", 0),
                         row_data.get("ctr", 0), row_data.get("cvr", 0)]
                fmts += [FMT_PCT, FMT_PCT, FMT_PCT, FMT_PCT]

            for c, (v, fmt) in enumerate(zip(vals, fmts), 1):
                f = cf if c in (4, 8) else fill
                _c(ws, start_row, c, v, fmt, f, bold=(c == 4))
            start_row += 1

        return start_row + 1

    r = 1
    if campaigns:
        r = write_section(r, campaigns, "campaign")
    if ad_sets:
        r = write_section(r, ad_sets, "adset")
    if ads:
        r = write_section(r, ads, "ad")

    _freeze(ws, 2, 1)


# ══════════════════════════════════════════════════════════════════════════════
# GENERATORE PRINCIPALE
# ══════════════════════════════════════════════════════════════════════════════
# ══════════════════════════════════════════════════════════════════════════════
# TAB — COGS CATALOG (per product × qty × country)
# ══════════════════════════════════════════════════════════════════════════════
def build_cogs_catalog_sheet(ws, supplier_orders: list, report_date: date,
                              fee_pct: float = 0.062):
    """
    Per (product × qty × country) aggregates revenue, COGS, fees, net and
    shows BE ROAS + margin at ROAS 1.75 / 2.0 / 2.5.
    `supplier_orders` are the raw orders from SupplierDownloader.fetch_orders_range().
    `fee_pct` is the avg payment processor fee (default 6.2% — Stripe USD avg).
    """
    ws.title = "COGS Catalog"

    catalog = defaultdict(lambda: {
        "n_orders":  0,
        "n_pieces":  0,
        "revenue":   0.0,
        "cogs":      0.0,
    })
    for order in supplier_orders or []:
        country_code = order.get("shippingCountryCode", "??") or "??"
        country = _country_name(country_code)
        # Order-level revenue (totalPrice = what the customer actually paid)
        try:
            order_rev = float(order.get("totalPrice", 0) or 0)
        except (TypeError, ValueError):
            order_rev = 0.0
        items = order.get("orderItems", [])
        if not items:
            continue
        # Distribute revenue across line items proportionally to (qty * unit price)
        weights = [int(it.get("quantity", 0) or 0) * float(it.get("price", 0) or 0)
                   for it in items]
        total_w = sum(weights) or 1.0
        for it, w in zip(items, weights):
            product = it.get("title", "Unknown")
            qty = int(it.get("quantity", 0) or 0)
            cogs = float(it.get("cogs", 0) or 0)
            if qty <= 0:
                continue
            line_rev = order_rev * (w / total_w)
            key = (product, qty, country)
            catalog[key]["n_orders"]  += 1
            catalog[key]["n_pieces"]  += qty
            catalog[key]["revenue"]   += line_rev
            catalog[key]["cogs"]      += cogs

    # ── Title ──
    title_cell = ws.cell(1, 1, f"  COGS CATALOG — per offer (qty × country)  ")
    title_cell.font = Font(name="Arial", bold=True, size=12, color="FFFFFF")
    title_cell.fill = HDR_FILL
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.merge_cells("A1:N1")
    ws.row_dimensions[1].height = 22

    sub_cell = ws.cell(2, 1,
        f"Source: Supplier | Date: {report_date.strftime('%d/%m/%Y')} "
        f"| Fees applied: {fee_pct*100:.2f}%  "
        f"| Margin formula: 1 - COGS% - Fees% - 1/ROAS")
    sub_cell.font = Font(name="Arial", italic=True, size=9, color="666666")
    ws.merge_cells("A2:N2")

    # ── Headers ──
    headers = [
        ("Product", 32),
        ("Qty", 6),
        ("Country", 18),
        ("Orders", 8),
        ("Avg Price €", 12),
        ("Avg COGS €", 12),
        ("COGS %", 9),
        ("Avg Fees €", 11),
        ("Avg Net €", 12),
        ("Net %", 9),
        ("BE ROAS", 10),
        ("Mgn @1.75x", 11),
        ("Mgn @2.0x", 11),
        ("Mgn @2.5x", 11),
    ]
    r = 3
    for c, (h, w) in enumerate(headers, 1):
        _h(ws, r, c, h, w)
    r += 1
    _freeze(ws, r, 4)

    if not catalog:
        ws.cell(r, 1, "No Supplier data available.").font = BOLD_FONT
        return

    sorted_keys = sorted(catalog.keys(), key=lambda k: (k[0], k[1], k[2]))
    for (product, qty, country) in sorted_keys:
        d = catalog[(product, qty, country)]
        n   = d["n_orders"]
        rev = d["revenue"]
        cog = d["cogs"]
        avg_rev  = rev / n if n else 0
        avg_cogs = cog / n if n else 0
        avg_fees = avg_rev * fee_pct
        avg_net  = avg_rev - avg_cogs - avg_fees
        cogs_pct = avg_cogs / avg_rev if avg_rev else 0
        net_pct  = avg_net  / avg_rev if avg_rev else 0
        denom    = 1 - cogs_pct - fee_pct
        be_roas  = round(1 / denom, 2) if denom > 0 else 99.0

        def _mgn_at_roas(roas: float) -> float:
            return 1 - cogs_pct - fee_pct - (1.0 / roas)

        m175 = _mgn_at_roas(1.75)
        m200 = _mgn_at_roas(2.00)
        m250 = _mgn_at_roas(2.50)

        fill = ALT_FILL if r % 2 == 0 else WHITE
        cogs_fill = ERR_FILL if cogs_pct > 0.30 else (WARN_FILL if cogs_pct > 0.25 else OK_FILL)
        net_fill  = OK_FILL if net_pct >= 0 else ERR_FILL

        def _mfill(m):
            return OK_FILL if m >= 0.10 else (WARN_FILL if m >= 0 else ERR_FILL)

        vals = [
            (product[:50], None, fill),
            (qty, FMT_NUM, fill),
            (country, None, fill),
            (n, FMT_NUM, fill),
            (avg_rev, FMT_EUR, fill),
            (avg_cogs, FMT_EUR, fill),
            (cogs_pct, FMT_PCT, cogs_fill),
            (avg_fees, FMT_EUR, fill),
            (avg_net, FMT_EUR, net_fill),
            (net_pct, FMT_PCT, net_fill),
            (be_roas, FMT_ROAS, fill),
            (m175, FMT_PCT, _mfill(m175)),
            (m200, FMT_PCT, _mfill(m200)),
            (m250, FMT_PCT, _mfill(m250)),
        ]
        for c, (v, fmt, f) in enumerate(vals, 1):
            _c(ws, r, c, v, fmt, f,
               bold=(c in (5, 9, 11)),
               align="center" if c in (2, 4) else ("right" if c >= 5 else "left"))
        r += 1

    # ── Summary ──
    r += 1
    summary_cell = ws.cell(r, 1, f"Total unique combinations: {len(catalog)}")
    summary_cell.font = BOLD_FONT
    ws.merge_cells(f"A{r}:N{r}")


# ══════════════════════════════════════════════════════════════════════════════
# TAB — SUBSCRIPTIONS
# ══════════════════════════════════════════════════════════════════════════════
def build_subscriptions_sheet(ws, orders: list, config: dict, report_date: date):
    ws.title = "Subscriptions"
    k = compute_subscription_kpis(orders, config)
    sub_orders   = [o for o in orders if _is_subscription_order(o)]
    n_sub         = k["n_sub"]
    n_first       = k["n_first"]
    n_recur       = k["n_recur"]
    n_cancelled   = k["n_cancelled"]
    sub_pct       = k["sub_pct"]
    sub_revenue   = k["sub_revenue"]
    first_revenue = k["first_revenue"]
    recur_revenue = k["recur_revenue"]
    sub_cogs      = k["sub_cogs"]
    sub_fees      = k["sub_fees"]
    sub_net       = k["sub_net"]
    sub_aov       = k["sub_aov"]
    first_aov     = k["first_aov"]
    recur_aov     = k["recur_aov"]
    sub_margin    = k["sub_net_pct"]
    sub_cogs_pct  = k["sub_cogs_pct"]

    # ── Title ──
    title_cell = ws.cell(1, 1, f"  SUBSCRIPTIONS — {report_date.strftime('%d/%m/%Y')}  ")
    title_cell.font = Font(name="Arial", bold=True, size=12, color="FFFFFF")
    title_cell.fill = HDR_FILL
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.merge_cells("A1:H1")
    ws.row_dimensions[1].height = 22

    # ── KPI section ──
    r = 3
    kpi_title = ws.cell(r, 1, "  KEY METRICS  ")
    kpi_title.font = Font(name="Arial", bold=True, size=11, color="1F3864")
    kpi_title.fill = SECTION
    kpi_title.alignment = Alignment(horizontal="left", vertical="center")
    ws.merge_cells(f"A{r}:H{r}")
    ws.row_dimensions[r].height = 20
    r += 1

    kpi_rows = [
        ("Total Subscription Orders",       n_sub,        FMT_NUM),
        ("% of Daily Orders",               sub_pct,      FMT_PCT),
        ("New Subscribers (First Order)",   n_first,      FMT_NUM),
        ("Recurring Renewals",              n_recur,      FMT_NUM),
        ("Cancelled today",                 n_cancelled,  FMT_NUM),
        ("",                                "",           None),
        ("Subscription Revenue",            sub_revenue,  FMT_EUR),
        ("  ↳ from New Subscribers",        first_revenue, FMT_EUR),
        ("  ↳ from Recurring",              recur_revenue, FMT_EUR),
        ("Subscription COGS",               sub_cogs,     FMT_EUR),
        ("Subscription Gateway Fees",       sub_fees,     FMT_EUR),
        ("Subscription NET Profit",         sub_net,      FMT_EUR),
        ("",                                "",           None),
        ("Subscription AOV",                sub_aov,      FMT_EUR),
        ("  ↳ New Subscriber AOV",          first_aov,    FMT_EUR),
        ("  ↳ Recurring AOV",               recur_aov,    FMT_EUR),
        ("Subscription COGS %",             sub_cogs_pct, FMT_PCT),
        ("Subscription Net Margin %",       sub_margin,   FMT_PCT),
    ]
    ws.column_dimensions["A"].width = 36
    ws.column_dimensions["B"].width = 18
    for label, value, fmt in kpi_rows:
        if label == "":
            r += 1
            continue
        c1 = ws.cell(r, 1, label)
        c1.font = BOLD_FONT
        c1.alignment = Alignment(horizontal="left", vertical="center")
        c1.border = BORDER
        c2 = ws.cell(r, 2, value)
        c2.font = KPI_FONT
        c2.alignment = Alignment(horizontal="right", vertical="center")
        c2.border = BORDER
        if fmt:
            c2.number_format = fmt
        r += 1

    r += 2

    # ── Order detail ──
    if not sub_orders:
        no_data = ws.cell(r, 1, "No subscription orders today.")
        no_data.font = BOLD_FONT
        return

    detail_title = ws.cell(r, 1, "  SUBSCRIPTION ORDER DETAIL  ")
    detail_title.font = Font(name="Arial", bold=True, size=11, color="1F3864")
    detail_title.fill = SECTION
    detail_title.alignment = Alignment(horizontal="left", vertical="center")
    ws.merge_cells(f"A{r}:H{r}")
    ws.row_dimensions[r].height = 20
    r += 1

    headers = [
        ("Order", 12), ("Type", 14), ("Customer", 26), ("Email", 30),
        ("Country", 10), ("Product", 32), ("Revenue €", 13), ("Net €", 13),
    ]
    for c, (h, w) in enumerate(headers, 1):
        _h(ws, r, c, h, w)
    r += 1
    _freeze(ws, r, 1)

    sorted_subs = sorted(sub_orders,
                         key=lambda o: (not _is_first_subscription(o),
                                        o.get("name", "")))

    for order in sorted_subs:
        sub_type = "🆕 New" if _is_first_subscription(order) else "🔁 Recurring"
        cust = order.get("customer", {}) or {}
        first_name = cust.get("first_name", "") or ""
        last_name  = cust.get("last_name", "") or ""
        full_name  = f"{first_name} {last_name}".strip() or "—"
        email      = cust.get("email", "") or order.get("email", "") or "—"
        ship       = order.get("shipping_address", {}) or {}
        country    = _country_name(ship.get("country_code", ""))

        line_items = order.get("line_items", []) or []
        product = line_items[0].get("title", "") if line_items else "—"
        if len(line_items) > 1:
            product += f" (+{len(line_items)-1})"

        revenue = float(order.get("_gross_revenue", 0))
        cogs    = order.get("_cogs_data", {}).get("total_cogs", 0)
        fee     = _order_real_fee(order, config)
        net     = revenue - cogs - fee

        fill = ALT_FILL if r % 2 == 0 else WHITE
        type_fill = OK_FILL if "New" in sub_type else BLUE_FILL

        _c(ws, r, 1, order.get("name", "?"), fill=fill, bold=True)
        _c(ws, r, 2, sub_type, fill=type_fill, bold=True, align="center")
        _c(ws, r, 3, full_name, fill=fill)
        _c(ws, r, 4, email, fill=fill)
        _c(ws, r, 5, country, fill=fill, align="center")
        _c(ws, r, 6, product, fill=fill)
        _c(ws, r, 7, revenue, FMT_EUR, fill, bold=True, align="right")
        _c(ws, r, 8, net, FMT_EUR, fill, bold=True, align="right")
        r += 1


# ══════════════════════════════════════════════════════════════════════════════
# TAB — SUBSCRIPTION ANALYTICS
# ══════════════════════════════════════════════════════════════════════════════
def build_subscription_analytics_sheet(ws, orders: list, config: dict, report_date: date):
    """
    Subscription Analytics — compact dashboard layout:
      Row 1:    Title bar
      Rows 3-20:  LEFT  = KPI Summary (green)  |  RIGHT = Assumptions (yellow editable)
      Rows 22-30: Storico Iscrizioni (today's data + revenue breakdown)
      Rows 32+:   Proiezione Forward ORIZZONTALE (mesi = colonne, metriche = righe)
    """
    ws.title = "Subscription Analytics"

    # ── Compute subscription data from today's orders ──
    k = compute_subscription_kpis(orders, config)
    sub_orders = [o for o in orders if _is_subscription_order(o)]

    # ── Parametri (defaults / config overrides) ──
    sub_cfg = config.get("subscription_analytics", {})
    subscription_price = sub_cfg.get("subscription_price", k["sub_aov"] or 39.90)
    cogs_per_unit      = sub_cfg.get("cogs_per_unit",
                                      round(k["sub_cogs"] / k["n_sub"], 2) if k["n_sub"] else 12.0)
    fee_pct            = sub_cfg.get("fee_pct", 0.062)
    monthly_churn_rate = sub_cfg.get("monthly_churn_rate", 0.075)
    avg_lifetime_months = sub_cfg.get("avg_lifetime_months", 12)
    projection_months  = sub_cfg.get("projection_months", 24)

    # Calcoli derivati
    fee_per_unit          = round(subscription_price * fee_pct, 2)
    gross_profit_per_unit = round(subscription_price - cogs_per_unit - fee_per_unit, 2)
    gross_margin_pct      = (gross_profit_per_unit / subscription_price) if subscription_price else 0

    ltv_net   = round(gross_profit_per_unit * (1 / monthly_churn_rate), 2) if monthly_churn_rate > 0 else 0
    ltv_gross = round(subscription_price * (1 / monthly_churn_rate), 2) if monthly_churn_rate > 0 else 0

    total_adv = config.get("_today_total_adv", 0)
    n_first = k["n_first"]
    cac = round(total_adv / n_first, 2) if n_first > 0 and total_adv > 0 else sub_cfg.get("cac_estimate", 0)
    payback_months = round(cac / gross_profit_per_unit, 1) if gross_profit_per_unit > 0 and cac > 0 else 0
    ltv_cac_ratio = round(ltv_net / cac, 2) if cac > 0 else 0
    annual_churn = round(1 - (1 - monthly_churn_rate) ** 12, 4)

    n_recur_today     = k["n_recur"]
    n_cancelled_today = k["n_cancelled"]
    n_first_today     = k["n_first"]
    active_est        = n_recur_today + n_first_today
    mrr_today         = round(active_est * subscription_price, 2)
    gp_today          = round(active_est * gross_profit_per_unit, 2)
    arr_today         = round(mrr_today * 12, 2)

    # Pre-calcolo proiezioni
    new_per_month = max(n_first_today * 30, sub_cfg.get("new_subs_per_month", 30))
    proj_data = []
    _active = active_est if active_est > 0 else sub_cfg.get("starting_active_subs", 10)
    _cumul_rev = 0.0
    _cumul_gp  = 0.0
    mrr_m12 = 0.0
    mrr_m24 = 0.0
    for _m in range(1, max(projection_months, 24) + 1):
        _churned = round(_active * monthly_churn_rate)
        _active  = max(_active + new_per_month - _churned, 0)
        _mrr     = round(_active * subscription_price, 2)
        _gp      = round(_active * gross_profit_per_unit, 2)
        _cumul_rev += _mrr
        _cumul_gp  += _gp
        proj_data.append({
            "active": _active, "mrr": _mrr, "gp": _gp,
            "cumul_rev": round(_cumul_rev, 2),
        })
        if _m == 12:
            mrr_m12 = _mrr
        if _m == 24:
            mrr_m24 = _mrr

    # ── Stili ──
    BOX_FILL   = PatternFill("solid", start_color="E2EFDA")
    PARAM_FILL = PatternFill("solid", start_color="FFF2CC")
    GREY_FILL  = PatternFill("solid", start_color="F2F2F2")
    ACCENT     = PatternFill("solid", start_color="D6E4F0")

    # ── Column widths ──
    ws.column_dimensions["A"].width = 36
    ws.column_dimensions["B"].width = 16
    ws.column_dimensions["C"].width = 3   # spacer
    ws.column_dimensions["D"].width = 36
    ws.column_dimensions["E"].width = 16

    # Helper
    def _kv(r, cl, cv, label, value, fmt=None, fill=None, note=None):
        """Write a label+value pair, optionally with a note in the next col."""
        c1 = ws.cell(r, cl, label)
        c1.font = BOLD_FONT
        c1.alignment = Alignment(horizontal="left", vertical="center")
        c1.border = BORDER
        if fill:
            c1.fill = fill
        c2 = ws.cell(r, cv, value)
        c2.font = KPI_FONT
        c2.alignment = Alignment(horizontal="right", vertical="center")
        c2.border = BORDER
        if fmt:
            c2.number_format = fmt
        if fill:
            c2.fill = fill
        if note:
            cn = ws.cell(r, cv + 1, note)
            cn.font = Font(name="Arial", italic=True, size=8, color="888888")

    # ══════════════════════════════════════════════════════════════════════════
    # TITOLO
    # ══════════════════════════════════════════════════════════════════════════
    title_cell = ws.cell(1, 1, f"  ABBONAMENTI — Analisi del {report_date.strftime('%d/%m/%Y')}  ")
    title_cell.font = Font(name="Arial", bold=True, size=13, color="FFFFFF")
    title_cell.fill = HDR_FILL
    title_cell.alignment = Alignment(horizontal="left", vertical="center")
    ws.merge_cells("A1:E1")
    ws.row_dimensions[1].height = 28

    # ══════════════════════════════════════════════════════════════════════════
    # SEZIONE 1 — QUANTO VALE UN ABBONATO?  (sinistra)
    # SEZIONE 2 — PARAMETRI                  (destra, editabili)
    # ══════════════════════════════════════════════════════════════════════════
    r = 3

    # Headers
    s1 = ws.cell(r, 1, "  QUANTO VALE UN ABBONATO?  ")
    s1.font = Font(name="Arial", bold=True, size=11, color="FFFFFF")
    s1.fill = PatternFill("solid", start_color="548235")
    s1.alignment = Alignment(horizontal="left", vertical="center")
    ws.merge_cells(f"A{r}:B{r}")

    s2 = ws.cell(r, 4, "  PARAMETRI (modifica i valori in giallo)  ")
    s2.font = Font(name="Arial", bold=True, size=11, color="FFFFFF")
    s2.fill = PatternFill("solid", start_color="BF8F00")
    s2.alignment = Alignment(horizontal="left", vertical="center")
    ws.merge_cells(f"D{r}:E{r}")
    ws.row_dimensions[r].height = 24
    r += 1

    # LEFT — Valore abbonato
    rl = r
    left_rows = [
        ("Ricavo per abbonamento",         subscription_price,     FMT_EUR,  BOX_FILL, "quanto paga il cliente"),
        ("Costo prodotto",                 cogs_per_unit,          FMT_EUR,  BOX_FILL, "materia prima + spedizione"),
        ("Commissioni pagamento",          fee_per_unit,           FMT_EUR,  BOX_FILL, "Stripe/PayPal/Klarna"),
        ("Guadagno netto per ordine",      gross_profit_per_unit,  FMT_EUR,  BOX_FILL, "ricavo - costi - commissioni"),
        None,
        ("Valore cliente nel tempo (LTV)", ltv_net,                FMT_EUR,  BOX_FILL, "guadagno totale per abbonato"),
        ("Costo per acquisire 1 cliente",  cac,                    FMT_EUR,  BOX_FILL, "spesa ADV / nuovi iscritti"),
        ("Mesi per rientrare del costo",   payback_months,         '0.0',    BOX_FILL, "dopo quanti mesi sei in pari"),
        ("Rapporto LTV / CAC",             ltv_cac_ratio,          '0.00"x"', BOX_FILL, "> 3x = ottimo"),
    ]

    for item in left_rows:
        if item is None:
            rl += 1
            continue
        label, value, fmt, fill, hint = item
        _kv(rl, 1, 2, label, value, fmt, fill, hint)
        rl += 1

    # RIGHT — Parametri editabili
    ra = r
    right_rows = [
        ("Prezzo abbonamento medio",  subscription_price,   FMT_EUR,  True,  "da ordini di oggi"),
        ("Costo prodotto per pezzo",  cogs_per_unit,        FMT_EUR,  True,  "COGS unitario"),
        ("% commissioni pagamento",   fee_pct,              FMT_PCT,  True,  "media gateway"),
        None,
        ("% clienti che cancellano / mese", monthly_churn_rate, FMT_PCT, True, "benchmark DTC: 7.5%"),
        ("Durata media abbonamento",  avg_lifetime_months,  FMT_NUM,  True,  "in mesi"),
        None,
        ("Costo acquisizione cliente", cac,                 FMT_EUR,  True,  "ADV / nuovi iscritti"),
        ("Nuovi iscritti stimati / mese", new_per_month,    FMT_NUM,  True,  "per le proiezioni"),
    ]

    for item in right_rows:
        if item is None:
            ra += 1
            continue
        label, value, fmt, editable, hint = item
        _kv(ra, 4, 5, label, value, fmt, PARAM_FILL if editable else None, hint)
        ra += 1

    r = max(rl, ra) + 2

    # ══════════════════════════════════════════════════════════════════════════
    # SEZIONE 3 — SITUAZIONE DI OGGI
    # ══════════════════════════════════════════════════════════════════════════
    sec_s = ws.cell(r, 1, "  SITUAZIONE DI OGGI  ")
    sec_s.font = Font(name="Arial", bold=True, size=11, color="FFFFFF")
    sec_s.fill = HDR_FILL
    sec_s.alignment = Alignment(horizontal="left", vertical="center")
    ws.merge_cells(f"A{r}:E{r}")
    ws.row_dimensions[r].height = 22
    r += 1

    # Due colonne affiancate: sinistra = ordini, destra = soldi
    # LEFT — Ordini
    ord_title = ws.cell(r, 1, "Ordini Abbonamento")
    ord_title.font = Font(name="Arial", bold=True, size=10, color="1F3864")
    ord_title.fill = ACCENT
    ws.merge_cells(f"A{r}:B{r}")

    rev_title = ws.cell(r, 4, "Ricavi e Costi")
    rev_title.font = Font(name="Arial", bold=True, size=10, color="1F3864")
    rev_title.fill = ACCENT
    ws.merge_cells(f"D{r}:E{r}")
    r += 1

    rl = r
    ord_rows = [
        ("Nuovi iscritti oggi",        n_first_today,       FMT_NUM),
        ("Rinnovi ricevuti",           n_recur_today,       FMT_NUM),
        ("Cancellazioni",              n_cancelled_today,   FMT_NUM),
        ("Abbonati attivi (stima)",    active_est,          FMT_NUM),
    ]
    for label, value, fmt in ord_rows:
        _kv(rl, 1, 2, label, value, fmt)
        rl += 1

    ra = r
    rev_rows = [
        ("Incasso da nuovi",       k["first_revenue"],  FMT_EUR),
        ("Incasso da rinnovi",     k["recur_revenue"],  FMT_EUR),
        ("Totale incassato",       k["sub_revenue"],    FMT_EUR),
        ("Costi prodotto",         k["sub_cogs"],       FMT_EUR),
        ("Commissioni",            k["sub_fees"],       FMT_EUR),
        ("Profitto netto oggi",    k["sub_net"],        FMT_EUR),
    ]
    for label, value, fmt in rev_rows:
        fill = None
        if "Profitto" in label:
            fill = OK_FILL if value >= 0 else ERR_FILL
        _kv(ra, 4, 5, label, value, fmt, fill)
        ra += 1

    r = max(rl, ra) + 1

    # Riepilogo mensile stimato
    _kv(r, 1, 2, "Ricavo mensile stimato (MRR)", mrr_today, FMT_EUR, ACCENT)
    _kv(r, 4, 5, "Ricavo annuale stimato (ARR)", arr_today, FMT_EUR, ACCENT)
    r += 1
    _kv(r, 1, 2, "Margine lordo %", gross_margin_pct, FMT_PCT, ACCENT)
    _kv(r, 4, 5, "Churn annuale", annual_churn, FMT_PCT, ACCENT)
    r += 3

    # ══════════════════════════════════════════════════════════════════════════
    # SEZIONE 4 — COME CRESCERANNO GLI ABBONAMENTI (proiezione 24 mesi)
    # ══════════════════════════════════════════════════════════════════════════
    sec_p = ws.cell(r, 1, "  COME CRESCERANNO GLI ABBONAMENTI NEI PROSSIMI 24 MESI  ")
    sec_p.font = Font(name="Arial", bold=True, size=11, color="FFFFFF")
    sec_p.fill = HDR_FILL
    sec_p.alignment = Alignment(horizontal="left", vertical="center")
    end_col = get_column_letter(min(projection_months, len(proj_data)) + 1)
    ws.merge_cells(f"A{r}:{end_col}{r}")
    ws.row_dimensions[r].height = 22
    r += 1

    note_p = ws.cell(r, 1,
        f"Ipotesi: {new_per_month} nuovi iscritti/mese, "
        f"{monthly_churn_rate*100:.1f}% cancellano ogni mese, "
        f"partendo da {_active if active_est <= 0 else active_est} abbonati attivi")
    note_p.font = Font(name="Arial", italic=True, size=9, color="666666")
    ws.merge_cells(f"A{r}:{end_col}{r}")
    r += 1

    # Tabella orizzontale: solo 3 milestone (Mese 3, 6, 12) + poi M13-M24 compatti
    # Prima riga: header mesi
    _h(ws, r, 1, "", 36)
    n_months = min(projection_months, len(proj_data))
    for m in range(n_months):
        col = m + 2
        cell = ws.cell(r, col, f"Mese {m+1}")
        cell.font = HDR_FONT
        cell.fill = HDR_FILL
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = BORDER
        ws.column_dimensions[get_column_letter(col)].width = 13
    r += 1
    _freeze(ws, r, 2)

    # Righe metriche — italiano semplice
    metric_rows = [
        ("Abbonati attivi",            "active",    FMT_NUM,  True),
        ("Ricavo mensile (MRR)",       "mrr",       FMT_EUR,  True),
        ("Profitto mensile",           "gp",        FMT_EUR,  False),
        ("Ricavo cumulato totale",     "cumul_rev", FMT_EUR,  False),
    ]

    for label, key, fmt, bold in metric_rows:
        lbl_cell = ws.cell(r, 1, label)
        lbl_cell.font = BOLD_FONT
        lbl_cell.border = BORDER
        lbl_cell.fill = SECTION
        lbl_cell.alignment = Alignment(horizontal="left", vertical="center")

        for m in range(n_months):
            col = m + 2
            val = proj_data[m][key]
            fill = ALT_FILL if m % 2 == 0 else WHITE
            _c(ws, r, col, val, fmt, fill, bold=bold, align="right")
        r += 1

    # Riga finale evidenziata: confronto M12 vs M24
    r += 1
    summary_cell = ws.cell(r, 1, "  RIEPILOGO PROIEZIONE  ")
    summary_cell.font = Font(name="Arial", bold=True, size=10, color="1F3864")
    summary_cell.fill = ACCENT
    ws.merge_cells(f"A{r}:E{r}")
    r += 1

    proj_summary = [
        ("Ricavo mensile tra 1 anno",   mrr_m12,                  FMT_EUR),
        ("Ricavo mensile tra 2 anni",   mrr_m24,                  FMT_EUR),
        ("Ricavo annuale stimato (M12)", round(mrr_m12 * 12, 2),  FMT_EUR),
    ]
    for label, value, fmt in proj_summary:
        _kv(r, 1, 2, label, value, fmt, BOX_FILL)
        r += 1


def convert_orders_to_currency(orders: list, tw_data: dict, cogs_daily: dict,
                               config: dict, fx_rate: float):
    """
    In-place conversion of all monetary fields from EUR to the report currency.
    Strategy:
      - For each order: use the REAL payout amount/fee from Stripe if currency
        matches, otherwise multiply EUR by `fx_rate`.
      - COGS (matrix-based): multiply by `fx_rate`.
      - Ads spend (Meta): multiply by `fx_rate`.
      - Daily totals: recalculated from converted orders.
    """
    if not fx_rate or fx_rate == 1.0:
        return  # nothing to do (already in target currency)

    target_cur = config.get("report", {}).get("currency", "EUR")

    # Per-order conversion
    for o in orders:
        payout_cur = o.get("_payout_currency")
        if payout_cur == target_cur and o.get("_payout_gross"):
            # Use REAL payout amounts
            o["_gross_revenue"] = o["_payout_gross"]
            o["_shop_amount"]   = o["_payout_gross"]
            o["_gateway_fee"]   = o["_payout_fee"]
        else:
            # Convert EUR → target via FX rate
            old_rev = float(o.get("_gross_revenue", 0) or 0)
            o["_gross_revenue"] = round(old_rev * fx_rate, 2)
            old_shop = float(o.get("_shop_amount", 0) or 0)
            if old_shop > 0:
                o["_shop_amount"] = round(old_shop * fx_rate, 2)
            old_fee = float(o.get("_gateway_fee", 0) or 0)
            if old_fee > 0:
                o["_gateway_fee"] = round(old_fee * fx_rate, 2)
            # also update line item prices for category breakdowns
            for line in o.get("line_items", []):
                try:
                    line["price"] = round(float(line.get("price", 0)) * fx_rate, 4)
                except (TypeError, ValueError):
                    pass
            old_total = float(o.get("total_price", 0) or 0)
            o["total_price"] = round(old_total * fx_rate, 2)

        # Convert COGS (always in source currency = EUR before this step)
        cd = o.get("_cogs_data") or {}
        if cd:
            for k in ("total_cogs", "base_cogs"):
                if k in cd:
                    cd[k] = round(cd[k] * fx_rate, 2)
            for itm in cd.get("items", []):
                if "cogs_base" in itm:
                    itm["cogs_base"] = round(itm["cogs_base"] * fx_rate, 4)
                if "selling_price" in itm:
                    itm["selling_price"] = round(itm["selling_price"] * fx_rate, 4)
            for sk in ("thank_you_cards", "branded_bag"):
                if sk in cd.get("surcharges", {}):
                    cd["surcharges"][sk] = round(cd["surcharges"][sk] * fx_rate, 4)
            o["_cogs_data"] = cd

    # Daily COGS aggregate
    if cogs_daily:
        for k in ("total_cogs", "base_cogs",
                  "thank_you_cards", "branded_bags", "total_surcharges"):
            if k in cogs_daily:
                cogs_daily[k] = round(cogs_daily[k] * fx_rate, 2)

    # Ads spend (Meta returns EUR; convert to USD)
    if tw_data:
        for k in ("spend_eur", "purchase_value"):
            if k in tw_data:
                tw_data[k] = round(tw_data[k] * fx_rate, 2)
        for ch_data in tw_data.get("channels", {}).values():
            if "spend_eur" in ch_data:
                ch_data["spend_eur"] = round(ch_data["spend_eur"] * fx_rate, 2)


def generate_daily_report(
    orders: list,
    tw_data: dict,
    cogs_daily: dict,
    config: dict,
    report_date: date,
    output_path: str,
    meta_campaigns: list = None,
    meta_ad_sets: list = None,
    meta_ads: list = None,
    daily_returns: dict = None,
    revenue_override: float = None,
    supplier_catalog_orders: list = None,
) -> dict:
    """
    Generates the daily Excel report v2.0.
    File: <prefix>_COGS_DD_MM_YYYY.xlsx
    Tabs: Analysis | Orders | Product Breakdown | Country Breakdown |
          Subscriptions | COGS Catalog | [Meta Campaigns]
    """
    # ── Currency setup (conversion is now done upstream in main.py) ───────────
    rep_cfg    = config.get("report", {})
    cur_symbol = rep_cfg.get("currency_symbol", "€")
    _set_currency(cur_symbol)

    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    ws_analisi = wb.create_sheet()
    kpis = build_analisi_sheet(ws_analisi, orders, tw_data, cogs_daily, config, report_date, meta_campaigns,
                               daily_returns=daily_returns, revenue_override=revenue_override)

    ws_ordini = wb.create_sheet()
    build_ordini_sheet(ws_ordini, orders, config, report_date)

    ws_prod = wb.create_sheet()
    build_prodotti_sheet(ws_prod, orders, config, report_date)

    ws_paesi = wb.create_sheet()
    build_paesi_sheet(ws_paesi, orders, config, report_date)

    ws_subs = wb.create_sheet()
    build_subscriptions_sheet(ws_subs, orders, config, report_date)

    ws_sub_analytics = wb.create_sheet()
    build_subscription_analytics_sheet(ws_sub_analytics, orders, config, report_date)

    # Compute observed fee % from today's orders (real Stripe data)
    obs_fee_pct = 0.062  # default 6.2%
    try:
        tot_rev = sum(float(o.get("_gross_revenue", 0) or 0) for o in orders)
        tot_fee = sum(_order_real_fee(o, config) for o in orders)
        if tot_rev > 0:
            obs_fee_pct = tot_fee / tot_rev
    except Exception:
        pass

    ws_cat = wb.create_sheet()
    build_cogs_catalog_sheet(ws_cat, supplier_catalog_orders or [], report_date,
                              fee_pct=obs_fee_pct)

    if meta_campaigns or meta_ad_sets or meta_ads:
        ws_meta = wb.create_sheet()
        build_meta_sheet(ws_meta, meta_campaigns or [], meta_ad_sets or [], meta_ads or [], config)

    wb.save(output_path)
    return kpis
