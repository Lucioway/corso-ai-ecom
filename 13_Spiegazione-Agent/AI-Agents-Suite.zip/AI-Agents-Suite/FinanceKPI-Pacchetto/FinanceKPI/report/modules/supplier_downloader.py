"""
Supplier COGS Downloader — FinanceAgent

Downloads daily COGS data directly from Supplier API (supplier.example.com).
Uses NextAuth.js credentials login + REST API for order data.

API endpoints:
  POST /api/auth/callback/credentials  — login
  GET  /api/shops/order-counts         — order counts per shop
  GET  /api/orders?shopId=&startDate=&endDate=  — order details with COGS
"""
import csv
import os
import requests
from datetime import date
from typing import Optional


class SupplierDownloader:
    def __init__(self, config: dict):
        cfg = config.get("supplier", {})
        self._enabled_flag = cfg.get("enabled", True)
        self.email = cfg.get("email", "")
        self.password = cfg.get("password", "")
        self.base_url = cfg.get("base_url", "https://supplier.example.com")
        self.shop_id = cfg.get("shop_id", "")
        self._session: Optional[requests.Session] = None

    @property
    def enabled(self) -> bool:
        # Respect the explicit config flag AND require credentials to be present.
        return bool(self._enabled_flag and self.email and self.password)

    def _get_session(self) -> requests.Session:
        if self._session:
            return self._session

        s = requests.Session()

        # Step 1: Get CSRF token
        r = s.get(f"{self.base_url}/api/auth/csrf", timeout=15)
        r.raise_for_status()
        csrf = r.json().get("csrfToken", "")

        # Step 2: Login via NextAuth credentials callback
        r = s.post(
            f"{self.base_url}/api/auth/callback/credentials",
            data={
                "csrfToken": csrf,
                "email": self.email,
                "password": self.password,
                "redirect": "false",
                "json": "true",
            },
            headers={"Content-Type": "application/x-www-form-urlencoded"},
            timeout=15,
        )
        r.raise_for_status()

        # Verify login success
        if "__Secure-next-auth.session-token" not in {c.name for c in s.cookies}:
            raise RuntimeError("Supplier login failed — no session token received")

        self._session = s
        return s

    def _resolve_shop_id(self, s: requests.Session, target_date: date) -> str:
        """Find the shop UUID if not configured. Picks the shop with the most orders."""
        if self.shop_id:
            return self.shop_id

        d_str = target_date.isoformat()
        r = s.get(
            f"{self.base_url}/api/shops/order-counts",
            params={"startDate": d_str, "endDate": d_str},
            timeout=15,
        )
        r.raise_for_status()
        counts = r.json()

        if not counts:
            raise RuntimeError("No shops found in Supplier")

        # Pick shop with the most orders for the day; on a single-shop account
        # this will simply be the only shop available.
        top_id = max(counts, key=lambda k: counts[k])
        self.shop_id = top_id
        return top_id

    def fetch_orders_range(self, start_date: date, end_date: date) -> list:
        """
        Fetch raw orders from Supplier for a date range.
        Returns the list of orders (each with shopifyOrderName, shippingCountryCode,
        orderItems with cogs/quantity/price).
        """
        s = self._get_session()
        shop_id = self._resolve_shop_id(s, end_date)
        r = s.get(
            f"{self.base_url}/api/orders",
            params={
                "shopId": shop_id,
                "startDate": start_date.isoformat(),
                "endDate":   end_date.isoformat(),
            },
            timeout=120,
        )
        r.raise_for_status()
        data = r.json()
        return data.get("orders", data) if isinstance(data, dict) else data

    def download_cogs_csv(self, target_date: date, output_dir: str) -> str:
        """
        Download COGS data from Supplier API and save as CSV.
        Returns path to the saved CSV file.
        """
        s = self._get_session()
        shop_id = self._resolve_shop_id(s, target_date)

        d_str = target_date.isoformat()
        r = s.get(
            f"{self.base_url}/api/orders",
            params={"shopId": shop_id, "startDate": d_str, "endDate": d_str},
            timeout=60,
        )
        r.raise_for_status()
        data = r.json()
        orders = data.get("orders", data) if isinstance(data, dict) else data

        if not orders:
            raise RuntimeError(f"No Supplier orders for {d_str}")

        # Build CSV rows matching the format cogs_reader expects:
        # orderName, shopifyProductId, quantity, price, cogs
        rows = []
        total_cogs = 0.0
        for order in orders:
            order_name = order.get("shopifyOrderName", "")
            country = order.get("shippingCountryCode", "")
            for item in order.get("orderItems", []):
                cogs_val = item.get("cogs", 0) or 0
                total_cogs += float(cogs_val)
                rows.append({
                    "orderName": order_name,
                    "shopifyProductId": item.get("shopifyProductId", ""),
                    "quantity": item.get("quantity", 1),
                    "price": item.get("price", 0),
                    "cogs": cogs_val,
                    "shippingCountryCode": country,
                })

        # Save CSV
        os.makedirs(output_dir, exist_ok=True)
        dd_mm_yyyy = target_date.strftime("%d.%m.%Y")
        csv_path = os.path.join(output_dir, f"cogs {dd_mm_yyyy}.csv")

        with open(csv_path, "w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=[
                "orderName", "shopifyProductId", "quantity", "price", "cogs",
                "shippingCountryCode",
            ])
            writer.writeheader()
            writer.writerows(rows)

        print(f"[Supplier] ✅ {len(orders)} orders, {len(rows)} items, "
              f"Total COGS: €{total_cogs:.2f} → {os.path.basename(csv_path)}")
        return csv_path
