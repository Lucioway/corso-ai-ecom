"""
Exchange Rates - Currency conversion to EUR.
Uses Frankfurter.app (free, no API key required).
"""
import logging
import requests
from datetime import date
from functools import lru_cache


class ExchangeRateClient:
    BASE_URL = "https://api.frankfurter.app"

    def __init__(self, config: dict):
        self.base_currency = config.get("exchange_rates", {}).get("base_currency", "EUR")
        self._cache = {}

    def get_rates_for_date(self, target_date: date) -> dict:
        """Returns exchange rates for a specific date (base: EUR)."""
        date_str = target_date.strftime("%Y-%m-%d")
        if date_str in self._cache:
            return self._cache[date_str]

        try:
            resp = requests.get(
                f"{self.BASE_URL}/{date_str}",
                params={"base": self.base_currency},
                timeout=10,
            )
            resp.raise_for_status()
            rates = resp.json().get("rates", {})
            rates["EUR"] = 1.0
            self._cache[date_str] = rates
            return rates
        except Exception as e:
            logging.debug("Errore fetch tassi di cambio: %s", e)
            return {"EUR": 1.0}

    def convert_to_eur(self, amount: float, currency: str, target_date: date) -> float:
        """Converts an amount to EUR at the exchange rate of the specified date."""
        if currency == "EUR" or currency is None:
            return round(amount, 2)
        rates = self.get_rates_for_date(target_date)
        if currency not in rates:
            return round(amount, 2)
        rate = rates[currency]
        return round(amount / rate, 2)

    def get_rate(self, currency: str, target_date: date) -> float:
        """Returns the exchange rate from currency to EUR."""
        if currency == "EUR":
            return 1.0
        rates = self.get_rates_for_date(target_date)
        rate = rates.get(currency, 1.0)
        return round(1 / rate, 6)
