"""
Meta Marketing API Client — Retrieves ADV spend data directly from Meta.

Uses the Meta Marketing API v21.0 to fetch ad account insights (spend, impressions,
clicks, purchases, ROAS) for a given date or date range.

Documentation: https://developers.facebook.com/docs/marketing-api/insights
"""
import requests
from datetime import date
from typing import Optional


API_VERSION = "v21.0"
BASE_URL = f"https://graph.facebook.com/{API_VERSION}"

# Fields to request from Meta Insights API
INSIGHTS_FIELDS = [
    "spend",
    "impressions",
    "clicks",
    "cpc",
    "ctr",
    "actions",
    "action_values",
    "purchase_roas",
]


class MetaAdsClient:
    """
    Client for Meta Marketing API.
    Retrieves ad spend, ROAS, and attribution data from Meta Ads.
    """

    def __init__(self, config: dict):
        cfg = config.get("meta_ads", {})
        self.enabled = cfg.get("enabled", False)
        self.ad_account_id = cfg.get("ad_account_id", "")
        self.access_token = cfg.get("access_token", "")

        if self.ad_account_id and not self.ad_account_id.startswith("act_"):
            self.ad_account_id = f"act_{self.ad_account_id}"

    def _fetch_insights(self, start_date: date, end_date: date) -> dict:
        """
        Calls the Meta Insights API for the given date range.
        Returns the raw JSON response.
        """
        if not self.enabled or not self.access_token or not self.ad_account_id:
            return {}

        url = f"{BASE_URL}/{self.ad_account_id}/insights"
        params = {
            "fields": ",".join(INSIGHTS_FIELDS),
            "time_range": f'{{"since":"{start_date.isoformat()}","until":"{end_date.isoformat()}"}}',
            "access_token": self.access_token,
        }

        try:
            resp = requests.get(url, params=params, timeout=30)
            resp.raise_for_status()
            data = resp.json().get("data", [])
            return data[0] if data else {}
        except requests.HTTPError as e:
            print(f"[MetaAds] ⚠️ HTTP Error {e.response.status_code}: {e.response.text[:200]}")
            return {}
        except Exception as e:
            print(f"[MetaAds] ⚠️ API call error: {e}")
            return {}

    @staticmethod
    def _extract_action(raw: dict, action_type: str, field: str = "actions") -> float:
        """Extract a specific action value from the actions list."""
        actions = raw.get(field, [])
        if not actions:
            return 0.0
        for action in actions:
            if action.get("action_type") == action_type:
                try:
                    return float(action.get("value", 0))
                except (TypeError, ValueError):
                    return 0.0
        return 0.0

    def _parse_insights(self, raw: dict, start_date: date, end_date: date) -> dict:
        """
        Converts the raw Meta API response into the standard format
        used by the Finance Agent (compatible with Triple Whale format).
        """
        if not raw:
            return self._empty_result(start_date, end_date)

        spend = float(raw.get("spend", 0))
        impressions = int(raw.get("impressions", 0))
        clicks = int(raw.get("clicks", 0))
        cpc = float(raw.get("cpc", 0))
        ctr = float(raw.get("ctr", 0))

        # Purchases and purchase value
        purchases = int(self._extract_action(raw, "purchase"))
        purchase_value = self._extract_action(raw, "purchase", field="action_values")

        # ROAS from purchase_roas field
        roas_list = raw.get("purchase_roas", [])
        roas = 0.0
        if roas_list:
            for r in roas_list:
                if r.get("action_type") == "omni_purchase":
                    roas = float(r.get("value", 0))
                    break
            if roas == 0.0 and roas_list:
                roas = float(roas_list[0].get("value", 0))

        # Fallback ROAS calculation
        if roas == 0.0 and spend > 0 and purchase_value > 0:
            roas = purchase_value / spend

        cpa = spend / purchases if purchases > 0 else 0.0

        return {
            "source": "Meta Marketing API",
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "platform": "Meta Ads (Facebook/Instagram)",
            "spend_eur": spend,
            "purchase_value": purchase_value,
            "purchases": purchases,
            "roas": roas,
            "roas_attributed": roas,
            "roas_blended": roas,
            "cpa": cpa,
            "impressions": impressions,
            "clicks": clicks,
            "sessions": 0,
            "cpc": cpc,
            "ctr": ctr,
            "ncr": 0.0,
            "channels": {
                "meta": {
                    "platform": "Meta Ads (Facebook/Instagram)",
                    "spend_eur": spend,
                    "roas": roas,
                },
                "tiktok": {"platform": "TikTok Ads", "spend_eur": 0.0, "roas": 0},
                "google": {"platform": "Google Ads", "spend_eur": 0.0, "roas": 0},
                "other": {"platform": "Other channels", "spend_eur": 0.0, "roas": 0},
            },
        }

    def _empty_result(self, start_date: date, end_date: date) -> dict:
        return {
            "source": "Meta Marketing API",
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "platform": "Meta Ads (Facebook/Instagram)",
            "spend_eur": 0.0, "purchase_value": 0.0, "purchases": 0,
            "roas": 0.0, "roas_attributed": 0.0, "roas_blended": 0.0,
            "cpa": 0.0, "impressions": 0, "clicks": 0, "sessions": 0,
            "cpc": 0.0, "ctr": 0.0, "ncr": 0.0,
            "channels": {
                "meta": {"platform": "Meta Ads (Facebook/Instagram)", "spend_eur": 0.0, "roas": 0},
                "tiktok": {"platform": "TikTok Ads", "spend_eur": 0.0, "roas": 0},
                "google": {"platform": "Google Ads", "spend_eur": 0.0, "roas": 0},
                "other": {"platform": "Other channels", "spend_eur": 0.0, "roas": 0},
            },
        }

    # ── Public API (same interface as TripleWhaleClient) ─────────────────────
    def get_daily_data(self, target_date: date) -> dict:
        """Retrieves Meta ADV metrics for a specific date."""
        raw = self._fetch_insights(target_date, target_date)
        result = self._parse_insights(raw, target_date, target_date)
        print(f"[MetaAds] 📊 {target_date} — Spend: €{result['spend_eur']:.2f} | "
              f"Purchases: {result['purchases']} | ROAS: {result['roas']:.2f}x")
        return result

    def get_date_range_data(self, start_date: date, end_date: date) -> dict:
        """Retrieves Meta ADV metrics for a date range."""
        raw = self._fetch_insights(start_date, end_date)
        result = self._parse_insights(raw, start_date, end_date)
        days = (end_date - start_date).days + 1
        print(f"[MetaAds] 📊 {start_date}→{end_date} ({days}d) — "
              f"Spend: €{result['spend_eur']:.2f} | ROAS: {result['roas']:.2f}x")
        return result

    # ── Backward compatibility aliases ───────────────────────────────────────
    def get_daily_spend(self, target_date: date) -> dict:
        return self.get_daily_data(target_date)

    def get_date_range_spend(self, start_date: date, end_date: date) -> dict:
        return self.get_date_range_data(start_date, end_date)
