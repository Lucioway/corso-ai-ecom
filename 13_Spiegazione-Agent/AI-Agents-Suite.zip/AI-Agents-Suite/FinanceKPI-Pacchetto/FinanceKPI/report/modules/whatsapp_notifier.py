"""
WhatsApp Notifier — Finance Agent
Sends daily KPI recap via WhatsApp Web (Selenium + Chrome).
Uses the same persistent Chrome profile as ToDo_Organizer agent.
"""
import logging
import subprocess
import time
from datetime import date
from pathlib import Path

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException

logger = logging.getLogger(__name__)

WHATSAPP_WEB_URL = "https://web.whatsapp.com"
PAGE_LOAD_TIMEOUT = 60
CHAT_LOAD_TIMEOUT = 15

# Stesso profilo Chrome dell'altro agent WhatsApp
DEFAULT_CHROME_PROFILE = str(Path.home() / ".finance-agent" / "chrome-profile")

SELECTORS = {
    "chatlist": '#pane-side',
    "msg_input": 'div#main footer div[contenteditable="true"]',
}
CHAT_TITLE_XPATH = '//span[@title="{chat_name}"]'


def _format_eur(value: float) -> str:
    """Format number as Italian-style EUR: 13.595,38"""
    s = f"{value:,.2f}"
    return s.replace(",", "X").replace(".", ",").replace("X", ".")


def _build_message(kpis: dict, cogs_daily: dict, target_date: date) -> str:
    """Build the WhatsApp recap message from KPIs."""
    net = kpis.get("net", 0)
    net_pct = kpis.get("net_margin_pct", 0) * 100
    icon = "\u2705" if net >= 0 else "\U0001f534"
    cogs_pct = cogs_daily.get("cogs_pct", 0) * 100
    roas = kpis.get("roas_blended", 0)

    return (
        f"\U0001f4ca *Daily Recap \u2014 {target_date.strftime('%d/%m/%Y')}*\n"
        f"\n"
        f"\U0001f6d2 Ordini: {kpis.get('n_orders', 0)}\n"
        f"\U0001f4b0 Revenue: \u20ac{_format_eur(kpis.get('gross', 0))}\n"
        f"\U0001f4e6 COGS: \u20ac{_format_eur(cogs_daily.get('total_cogs', 0))} ({cogs_pct:.1f}%)\n"
        f"\U0001f4e3 ADV: \u20ac{_format_eur(kpis.get('total_adv', 0))}\n"
        f"\U0001f4b5 Net: \u20ac{_format_eur(net)} ({net_pct:.1f}%) {icon}\n"
        f"\U0001f4c8 ROAS: {roas:.2f}x"
    )


def _send_whatsapp_message(chat_name: str, message: str, chrome_profile: str) -> bool:
    """Open Chrome, navigate to WhatsApp Web, find group/chat, send message."""
    Path(chrome_profile).mkdir(parents=True, exist_ok=True)

    options = Options()
    options.add_argument(f"--user-data-dir={chrome_profile}")
    options.add_argument("--no-sandbox")
    options.add_argument("--disable-dev-shm-usage")

    driver = None
    try:
        driver = webdriver.Chrome(options=options)
        driver.get(WHATSAPP_WEB_URL)

        logger.info("Attendo caricamento WhatsApp Web...")
        WebDriverWait(driver, PAGE_LOAD_TIMEOUT).until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, SELECTORS["chatlist"])
            )
        )
        logger.info("WhatsApp Web connesso!")
        time.sleep(3)

        # Click directly on the chat/group by title
        chat_element = WebDriverWait(driver, CHAT_LOAD_TIMEOUT).until(
            EC.presence_of_element_located(
                (By.XPATH, CHAT_TITLE_XPATH.format(chat_name=chat_name))
            )
        )
        chat_element.click()
        time.sleep(2)

        # Find message input in footer
        msg_box = WebDriverWait(driver, CHAT_LOAD_TIMEOUT).until(
            EC.presence_of_element_located(
                (By.CSS_SELECTOR, SELECTORS["msg_input"])
            )
        )
        msg_box.click()
        time.sleep(0.3)

        # Paste via clipboard for full emoji/Unicode support
        subprocess.run(["pbcopy"], input=message.encode("utf-8"), check=True)
        msg_box.send_keys(Keys.COMMAND, "v")
        time.sleep(1)
        msg_box.send_keys(Keys.ENTER)
        time.sleep(2)

        logger.info(f"Messaggio inviato a '{chat_name}'")
        return True

    except TimeoutException:
        logger.error("Timeout WhatsApp Web. Scansiona il QR code e riprova.")
        return False
    except WebDriverException as e:
        logger.error(f"Errore Chrome: {e}")
        return False
    except Exception as e:
        logger.error(f"Errore invio WhatsApp: {e}")
        return False
    finally:
        if driver:
            try:
                driver.quit()
            except Exception as e:
                logger.debug("Errore chiusura driver WhatsApp: %s", e)


def send_daily_recap(kpis: dict, cogs_daily: dict, config: dict, target_date: date):
    """
    Send the daily KPI recap to the configured WhatsApp group/chat.
    Opens Chrome, sends via WhatsApp Web, then closes.
    """
    wa_cfg = config.get("whatsapp", {})
    if not wa_cfg.get("enabled", False):
        return

    chat_name = wa_cfg.get("group_name", "")
    if not chat_name:
        print("  \u26a0\ufe0f  WhatsApp: group_name mancante nel config.")
        return

    chrome_profile = wa_cfg.get("chrome_profile", DEFAULT_CHROME_PROFILE)
    message = _build_message(kpis, cogs_daily, target_date)

    print(f"\n  \U0001f4f1 Sending WhatsApp recap to '{chat_name}'...")
    success = _send_whatsapp_message(chat_name, message, chrome_profile)
    if success:
        print(f"      \u2705 Messaggio inviato!")
    else:
        print(f"      \u26a0\ufe0f  Invio fallito. Controlla che WhatsApp Web sia loggato.")
