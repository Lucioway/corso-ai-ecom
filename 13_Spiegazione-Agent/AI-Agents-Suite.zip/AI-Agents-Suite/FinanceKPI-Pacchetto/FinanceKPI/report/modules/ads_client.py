"""Shim → canonical implementation lives in core/ads_client.py."""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))
from core.ads_client import *  # noqa: F401,F403
