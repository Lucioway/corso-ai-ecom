"""
COGS Reader — Finance Agent

Manages 3 COGS sources (in order of priority):
  1. Daily supplier CSV (Supplier) → precise COGS per order
  2. Country × product × quantity matrix → calculation from config
  3. Triple Whale COGS % (23%) → total fallback

Also manages:
  - Thank You Cards (€0.02/pc)
  - Branded bags (€0.06/order)
  - Order vs supplier quotation comparison
"""
import pandas as pd
import os
from typing import Optional


# Map Shopify Product ID → product name
PRODUCT_ID_MAP = {
    "15938584150365": "AntiOx",
}

# Product names from order line item title (fallback)
PRODUCT_TITLE_MAP = {
    "antiox":     "AntiOx",
    "antioxidant": "AntiOx",
}


def _product_from_id(product_id: str) -> str:
    return PRODUCT_ID_MAP.get(str(product_id).strip(), "Other")


def _product_from_title(title: str) -> str:
    t = (title or "").lower()
    for kw, name in PRODUCT_TITLE_MAP.items():
        if kw in t:
            return name
    return "Other"


def _matrix_cogs(matrix: dict, product: str, country: str, qty: int) -> float:
    """
    Calculate COGS from the config matrix for a product/country/quantity.
    qty: number of pieces (1-5+; above 5 uses the price for 5 as an estimate)
    """
    prod_data = matrix.get(product, matrix.get("Other", {}))
    prices = prod_data.get(country, prod_data.get("DEFAULT", [0, 0, 0, 0, 0]))
    if not prices:
        return 0.0
    idx = min(qty - 1, len(prices) - 1)
    val = prices[idx] if idx >= 0 else 0
    # If qty exceeds the max price list, estimate proportionally
    if qty > len(prices):
        last_price = prices[-1]
        prev_price = prices[-2] if len(prices) > 1 else last_price
        per_extra = last_price - prev_price
        val = last_price + per_extra * (qty - len(prices))
    return float(val) if val else 0.0


class COGSReader:
    def __init__(self, config: dict):
        self.config     = config
        self.cfg        = config.get("cogs", {})
        self.fin        = config.get("finance", {})
        self.products   = config.get("products", {})
        self.matrix     = self.cfg.get("matrix", {})
        self.tw_cogs_pct = self.cfg.get("tw_cogs_pct", 0.23)
        self.thank_you_card     = 0  # Removed
        self.branded_bag        = 0  # Removed
        self._supplier_df: Optional[pd.DataFrame] = None
        self._load_supplier_csv()

        # Supplier A Dropshipping precise per-order COGS (highest priority source)
        self._supplier_a_client = None
        self._supplier_a_usd_eur = None
        self._supplier_a_fixed_pct = self.cfg.get("fixed_pct", 0.0)
        supplier_cfg = config.get("supplier_a") or config.get("supplier_b") or {}
        if supplier_cfg.get("enabled"):
            try:
                from modules.supplier_a_cogs import SupplierACogsClient
                self._supplier_a_client = SupplierACogsClient(config)
                self._supplier_a_client.refresh_orders(
                    states=supplier_cfg.get("states_to_fetch", [1, 2, 3]),
                    use_cache_hours=supplier_cfg.get("cache_hours", 0.5),
                )
                self._supplier_a_usd_eur = self._fetch_usd_eur_rate()
                print(f"[COGS] ✅ Supplier A client active (USD→EUR rate {self._supplier_a_usd_eur:.5f})")
            except Exception as e:
                print(f"[COGS] ⚠️ Supplier A init failed ({e}); falling back to matrix/fixed_pct")
                self._supplier_a_client = None

    # ── USD → EUR conversion ────────────────────────────────────────────────────
    def _fetch_usd_eur_rate(self) -> float:
        """Fetch live USD→EUR rate from ECB (via Frankfurter). Falls back to config."""
        try:
            import requests
            resp = requests.get("https://api.frankfurter.dev/v1/latest?from=USD&to=EUR", timeout=10)
            resp.raise_for_status()
            rate = resp.json()["rates"]["EUR"]
            return float(rate)
        except Exception as e:
            fallback = self.config.get("exchange_rates", {}).get("manual_rates", {}).get("USD", 0.92)
            print(f"[COGS] ⚠️ ECB rate unavailable ({e}), using fallback: {fallback}")
            return fallback

    # ── Supplier CSV loading ───────────────────────────────────────────────────
    def _load_supplier_csv(self):
        path = self.cfg.get("supplier_csv_path", "fornitore_giornaliero.csv")
        if not os.path.exists(path):
            return
        try:
            if path.endswith((".xlsx", ".xls")):
                df = pd.read_excel(path)
            else:
                df = pd.read_csv(path, dtype={"orderName": str, "shopifyProductId": str})
            # Normalize column names
            df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]

            # Detect supplier format: Supplier price.xlsx has "name" + "price" columns
            # where "price" is the supplier COGS in USD (only on the first row of each order)
            if "name" in df.columns and "price" in df.columns and "lineitem_quantity" in df.columns:
                # Supplier format: aggregate COGS per order from first row only
                order_cogs = df[df["price"].notna()][["name", "price"]].copy()
                order_cogs.columns = ["ordername", "cogs"]
                order_cogs["ordername"] = order_cogs["ordername"].astype(str)

                # Convert USD → EUR using live ECB rate
                usd_eur = self._fetch_usd_eur_rate()
                order_cogs["cogs"] = (order_cogs["cogs"] * usd_eur).round(4)

                self._supplier_df = order_cogs
                print(f"[COGS] ✅ Supplier XLSX loaded (Supplier format): {len(order_cogs)} orders, USD→EUR @ {usd_eur:.5f}")
            else:
                self._supplier_df = df
                print(f"[COGS] ✅ Supplier CSV loaded: {len(df)} rows")
        except Exception as e:
            print(f"[COGS] ⚠️ Error loading supplier CSV: {e}")

    def load_supplier_csv_from_path(self, path: str):
        """Load the supplier CSV from a specific path (for use from main.py)."""
        self.cfg["supplier_csv_path"] = path
        self._supplier_df = None
        self._load_supplier_csv()

    def has_supplier_csv(self) -> bool:
        return self._supplier_df is not None and not self._supplier_df.empty

    # ── COGS lookup from supplier CSV ─────────────────────────────────────────
    def _get_supplier_cogs_for_order(self, order_name: str) -> Optional[float]:
        """
        Look up the total COGS for an order in the supplier file.
        Supports both Supplier CSV (orderName/cogs) and Supplier XLSX (name/price).
        """
        if not self.has_supplier_csv():
            return None
        df = self._supplier_df
        # Normalize: strip "#" and "LS" prefix so "#LS20336" and "#20336" both become "20336"
        import re
        name_clean = re.sub(r'^#?(LS)?', '', str(order_name).strip(), flags=re.IGNORECASE)
        name_col = next((c for c in ["ordername", "order_name", "name"] if c in df.columns), None)
        if not name_col:
            return None
        matches = df[
            df[name_col].astype(str).apply(lambda x: re.sub(r'^#?(LS)?', '', x.strip(), flags=re.IGNORECASE)) == name_clean
        ]
        if matches.empty:
            return None
        # Sum all COGS from the order rows
        cogs_col = next((c for c in ["cogs", "cost", "total_cost", "price"] if c in matches.columns), None)
        if cogs_col:
            return float(matches[cogs_col].sum())
        return None

    def get_supplier_csv_rows_for_order(self, order_name: str) -> list:
        """Return the supplier CSV rows for an order (for detailed comparison)."""
        if not self.has_supplier_csv():
            return []
        df = self._supplier_df
        name_clean = str(order_name).replace("#", "").strip()
        matches = df[
            df.get("ordername", df.get("order_name", pd.Series())).str.replace("#", "", regex=False).str.strip() == name_clean
        ]
        return matches.to_dict("records")

    # ── COGS calculation per order ─────────────────────────────────────────────
    def calculate_order_cogs(self, order: dict) -> dict:
        """
        Calculate COGS for a single Shopify order.
        Priority:
          1. Supplier CSV (if loaded and has a match)
          2. Country × product × quantity matrix
          3. TW COGS % × order revenue

        Always adds:
          - Thank You Cards (€0.02 × qty)
          - Branded bags (€0.06/order)

        Returns dict with: total_cogs, base_cogs, surcharges, source, items[]
        """
        order_name = str(order.get("name", order.get("id", "")))
        country    = order.get("billing_address", {}).get("country_code", "DEFAULT")
        revenue    = float(order.get("_gross_revenue", 0))

        items = []
        base_cogs = 0.0
        source = "matrix"

        # 1. Supplier A Dropshipping API (precise per-order, USD → EUR)
        supplier_data = None
        if self._supplier_a_client is not None:
            supplier_data = self._supplier_a_client.get_cogs_for_shopify_order(order)

        if supplier_data is not None:
            usd_eur = self._supplier_a_usd_eur or 0.92
            base_cogs = round(supplier_data["total_cogs_usd"] * usd_eur, 4)
            source = "supplier_api"
            for it in supplier_data["items"]:
                items.append({
                    "product":       it["name"],
                    "sku":           it["sku"],
                    "country":       supplier_data["country_code"],
                    "qty":           it["qty"],
                    "selling_price": 0.0,  # filled below from line_items
                    "cogs_base":     round(it["line_cost_usd"] * usd_eur, 4),
                    "cogs_pct":      0.0,
                    "source":        "supplier_api",
                })
            # Add shipping as separate pseudo-item for traceability
            if supplier_data["shipping_cost_usd"]:
                items.append({
                    "product":       "Shipping",
                    "sku":           "SUPPLIER_A_SHIPPING",
                    "country":       supplier_data["country_code"],
                    "qty":           1,
                    "selling_price": 0.0,
                    "cogs_base":     round(supplier_data["shipping_cost_usd"] * usd_eur, 4),
                    "cogs_pct":      0.0,
                    "source":        "supplier_api",
                })

        # 2. Supplier CSV
        elif (supplier_cogs := self._get_supplier_cogs_for_order(order_name)) is not None:
            base_cogs = supplier_cogs
            source = "supplier_csv"
        else:
            # 2. Matrix — aggregate qty per product across all line items,
            #    then look up the matrix once per product with the total qty.
            #    This handles bundles where each piece is a separate line item with qty=1.
            from collections import defaultdict
            agg = defaultdict(lambda: {"qty": 0, "revenue": 0.0, "skus": []})
            for line in order.get("line_items", []):
                pid    = str(line.get("product_id", ""))
                title  = line.get("title", line.get("name", ""))
                qty    = int(line.get("quantity", 1))
                price  = float(line.get("price", 0)) * qty
                product_name = _product_from_id(pid) if pid else _product_from_title(title)
                agg[product_name]["qty"]     += qty
                agg[product_name]["revenue"] += price
                if line.get("sku"):
                    agg[product_name]["skus"].append(line.get("sku"))

            for product_name, data in agg.items():
                total_qty = data["qty"]
                total_rev = data["revenue"]
                line_cogs = _matrix_cogs(self.matrix, product_name, country, total_qty)
                base_cogs += line_cogs
                items.append({
                    "product":       product_name,
                    "sku":           ",".join(data["skus"]),
                    "country":       country,
                    "qty":           total_qty,
                    "selling_price": total_rev,
                    "cogs_base":     line_cogs,
                    "cogs_pct":      line_cogs / total_rev if total_rev > 0 else 0,
                    "source":        "matrix",
                })

            # 3. Fallback TW COGS %
            if base_cogs == 0 and revenue > 0:
                base_cogs = revenue * self.tw_cogs_pct
                source = "tw_pct"

        # Surcharges and extra costs
        total_qty = sum(int(l.get("quantity", 1)) for l in order.get("line_items", []))
        cards_cost = self.thank_you_card * total_qty
        bag_cost   = self.branded_bag

        surcharges = {
            "thank_you_cards":  round(cards_cost, 4),
            "branded_bag":      round(bag_cost, 4),
        }
        total_surcharges = cards_cost + bag_cost

        total_cogs = round(base_cogs + total_surcharges, 2)

        return {
            "total_cogs":   total_cogs,
            "base_cogs":    round(base_cogs, 2),
            "surcharges":   surcharges,
            "source":       source,
            "items":        items,
            "cogs_pct":     total_cogs / revenue if revenue > 0 else 0,
        }

    # ── Total daily COGS calculation ──────────────────────────────────────────
    def calculate_daily_cogs(self, orders: list) -> dict:
        """
        Calculate aggregated COGS for the entire day.
        Returns structure for P&L and Analysis tab.
        """
        total_base = 0.0
        total_surcharges = 0.0
        per_order = []

        for order in orders:
            result = self.calculate_order_cogs(order)
            total_base       += result["base_cogs"]
            total_surcharges += result["surcharges"]["thank_you_cards"] + result["surcharges"]["branded_bag"]
            order["_cogs_data"] = result
            per_order.append(result)

        total_cogs = round(total_base + total_surcharges, 2)

        total_revenue = sum(float(o.get("_gross_revenue", 0)) for o in orders if not o.get("_is_reshipment", False))
        source_counts = {}
        for r in per_order:
            s = r["source"]
            source_counts[s] = source_counts.get(s, 0) + 1

        return {
            "total_cogs":          total_cogs,
            "base_cogs":           round(total_base, 2),
            "thank_you_cards":     round(sum(r["surcharges"]["thank_you_cards"] for r in per_order), 2),
            "branded_bags":        round(sum(r["surcharges"]["branded_bag"] for r in per_order), 2),
            "total_surcharges":    round(total_surcharges, 2),
            "cogs_pct":            total_cogs / total_revenue if total_revenue > 0 else 0,
            "source_breakdown":    source_counts,
            "tw_cogs_pct_used":    self.tw_cogs_pct,
        }

    # ── Orders vs Supplier Quotation Comparison ────────────────────────────────
    def build_supplier_comparison(self, orders: list) -> list:
        """Compare each order line with the supplier price matrix."""
        target_cogs = self.fin.get("target_cogs_pct", 0.25)
        comparison = []

        for order in orders:
            country  = order.get("billing_address", {}).get("country_code", "DEFAULT")
            order_id = order.get("name", order.get("id"))

            for line in order.get("line_items", []):
                pid   = str(line.get("product_id", ""))
                title = line.get("title", line.get("name", ""))
                qty   = int(line.get("quantity", 1))
                price = float(line.get("price", 0))
                total_selling = price * qty
                product_name  = _product_from_id(pid) if pid else _product_from_title(title)

                quoted_unit  = _matrix_cogs(self.matrix, product_name, country, 1)
                quoted_total = _matrix_cogs(self.matrix, product_name, country, qty)
                supplier_row = self.get_supplier_csv_rows_for_order(str(order_id))
                actual_cogs  = float(supplier_row[0].get("cogs", 0)) if supplier_row else None

                margin = total_selling - (actual_cogs or quoted_total)
                cogs_used = actual_cogs if actual_cogs is not None else quoted_total
                cogs_pct  = cogs_used / total_selling if total_selling > 0 else 0

                comparison.append({
                    "order_id":          order_id,
                    "country":           country,
                    "product":           product_name,
                    "qty":               qty,
                    "selling_price_unit": price,
                    "total_selling":     total_selling,
                    "quoted_unit":       quoted_unit,
                    "quoted_total":      quoted_total,
                    "actual_cogs":       actual_cogs,
                    "cogs_used":         cogs_used,
                    "gross_margin":      margin,
                    "cogs_pct":          cogs_pct,
                    "cogs_ok":           cogs_pct <= target_cogs,
                    "source":            "csv" if actual_cogs is not None else "matrix",
                })

        return comparison

    # ── BE ROAS ────────────────────────────────────────────────────────────────
    def calc_be_roas(self, cogs_pct: float, gateway_pct: float = 0.04) -> float:
        """Break-Even ROAS = 1 / (1 - COGS% - Gateway%)"""
        denominator = 1 - cogs_pct - gateway_pct
        if denominator <= 0:
            return 999.0
        return round(1 / denominator, 2)
