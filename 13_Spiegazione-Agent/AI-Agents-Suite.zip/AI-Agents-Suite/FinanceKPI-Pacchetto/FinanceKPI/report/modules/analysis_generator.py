"""
Analysis Generator — Finance Agent
Generates the daily/weekly HTML analysis document with:
  - Key KPIs (Revenue, COGS, ROAS, UV, BE ROAS, Number of Orders)
  - Detailed P&L
  - ADV per channel (Meta vs TikTok with color coding)
  - Favorable / critical points (configurable thresholds)
  - Trend & recommendations
  - PayPal Reserve Hold note (cash flow, not P&L)
"""
from datetime import date
from typing import Optional


# ── Helpers ──────────────────────────────────────────────────────────────────

def _pct(v: float) -> str:
    return f"{v*100:.1f}%"

def _eur(v: float) -> str:
    sign = "" if v >= 0 else "-"
    return f"{sign}€{abs(v):,.2f}"

def _x(v: float) -> str:
    return f"{v:.2f}x"

def _roas_color(roas: float) -> str:
    """HTML color of the ROAS badge."""
    if roas >= 2.20:   return "#4472C4"   # Blu
    elif roas >= 1.80: return "#70AD47"   # Verde
    elif roas >= 1.50: return "#FFD700"   # Giallo
    return "#FF4444"                       # Rosso

def _roas_emoji(roas: float) -> str:
    if roas >= 2.20:   return "🔵"
    elif roas >= 1.80: return "🟢"
    elif roas >= 1.50: return "🟡"
    return "🔴"

def _roas_label(roas: float) -> str:
    if roas >= 2.20:   return "SCALE AGGRESSIVELY"
    elif roas >= 1.80: return "SCALE"
    elif roas >= 1.50: return "MONITOR"
    return "TURN OFF / RESTRUCTURE"

def _badge(text: str, color: str, text_color: str = "#fff") -> str:
    return (f'<span style="background:{color};color:{text_color};'
            f'font-weight:bold;padding:3px 10px;border-radius:12px;'
            f'font-size:0.85em">{text}</span>')


# ── Assessment ───────────────────────────────────────────────────────────────

def _assess_cogs(pct: float) -> tuple:
    """(label, color, desc)"""
    if pct <= 0.22:
        return ("✅ EXCELLENT", "green",
                f"COGS at {_pct(pct)} — well below the 25-30% target. Excellent cost management.")
    elif pct <= 0.25:
        return ("✅ ON TARGET", "green",
                f"COGS at {_pct(pct)} — in line with the 25% target. Maintain this level.")
    elif pct <= 0.30:
        return ("⚠️ WARNING", "orange",
                f"COGS at {_pct(pct)} — between 25-30%: acceptable range but needs monitoring. "
                f"Check product mix.")
    else:
        return ("🔴 CRITICAL", "red",
                f"COGS at {_pct(pct)} — above 30%: urgent action needed. "
                f"Renegotiate with supplier or revise pricing.")


def _assess_roas(roas: float) -> tuple:
    """(label, desc)"""
    if roas >= 2.20:
        return ("🔵 EXCELLENT", f"ROAS {_x(roas)} — scale budget aggressively.")
    elif roas >= 1.80:
        return ("🟢 GOOD", f"ROAS {_x(roas)} — profitable campaigns. Scale carefully.")
    elif roas >= 1.50:
        return ("🟡 WARNING", f"ROAS {_x(roas)} — just above BE ROAS. Optimize targeting and creatives.")
    return ("🔴 CRITICAL", f"ROAS {_x(roas)} — campaigns at a loss. Pause or restructure immediately.")


def _assess_net_margin(pct: float) -> tuple:
    if pct >= 0.25:
        return ("✅ EXCELLENT", f"Net margin {_pct(pct)} — excellent profitability.")
    elif pct >= 0.15:
        return ("✅ GOOD", f"Net margin {_pct(pct)} — solid profitability.")
    elif pct >= 0.05:
        return ("⚠️ LOW", f"Net margin {_pct(pct)} — thin margin. Watch costs carefully.")
    elif pct >= 0:
        return ("⚠️ MINIMAL", f"Net margin {_pct(pct)} — nearly break-even. Urgent cost review needed.")
    return ("🔴 LOSS", f"Net margin {_pct(pct)} — day at a loss. Immediate analysis required.")


def _assess_uv(uv: float, target: float = 15.0) -> tuple:
    if uv >= target * 1.5:
        return ("✅ EXCELLENT", f"UV {_eur(uv)} — excellent unit profit.")
    elif uv >= target:
        return ("✅ ON TARGET", f"UV {_eur(uv)} — above the minimum target of {_eur(target)}.")
    elif uv >= 0:
        return ("⚠️ BELOW TARGET", f"UV {_eur(uv)} — below the target of {_eur(target)} per order.")
    return ("🔴 NEGATIVE", f"UV {_eur(uv)} — every order is generating a loss.")


# ── HTML generator ────────────────────────────────────────────────────────────

def generate_analysis_html(kpis: dict, config: dict, report_date: date,
                            output_path: str, period_label: str = "DAILY"):
    """
    Generates the HTML analysis document.

    Expected keys in `kpis`:
      gross, revenue_net_tax, cogs, cogs_pct, base_cogs,
      gross_profit, gross_margin_pct,
      meta_adv, tiktok_adv, total_adv, meta_roas, tiktok_roas,
      fees, refunds, net, net_margin_pct,
      aov, uv, be_roas, roas_attributed, roas_blended,
      n_orders, purchase_value, paypal_reserve_hold (opt)
    """
    company   = config.get("report", {}).get("company_name", "Company")
    fin       = config.get("finance", {})
    target_cogs   = fin.get("target_cogs_pct", 0.25)
    target_uv     = fin.get("target_uv_min", 15.0)
    gw_pct_blend  = fin.get("payment_gateway_fees", {}).get("shopify_payments_blended", 0.0376)
    sp_share      = fin.get("shopify_payments_share", 0.84)
    pp_share      = fin.get("paypal_share", 0.16)
    pp_fee_pct    = fin.get("payment_gateway_fees", {}).get("paypal", 0.057)
    pp_reserve    = fin.get("paypal_reserve_pct", 0.15)

    # ── Extract KPIs ────────────────────────────────────────────────────────────
    gross        = kpis.get("gross", 0)
    revenue_nt   = kpis.get("revenue_net_tax", 0)
    total_cogs   = kpis.get("cogs", 0)
    cogs_pct     = kpis.get("cogs_pct", 0)
    base_cogs    = kpis.get("base_cogs", 0)
    gross_profit = kpis.get("gross_profit", 0)
    meta_adv     = kpis.get("meta_adv", 0)
    tiktok_adv   = kpis.get("tiktok_adv", 0)
    total_adv    = kpis.get("total_adv", meta_adv + tiktok_adv)
    meta_roas    = kpis.get("meta_roas", 0)
    tiktok_roas  = kpis.get("tiktok_roas", 0)
    fees         = kpis.get("fees", 0)
    refunds      = kpis.get("refunds", 0)
    net          = kpis.get("net", 0)
    net_pct      = kpis.get("net_margin_pct", 0)
    aov          = kpis.get("aov", 0)
    uv           = kpis.get("uv", 0)
    be_roas      = kpis.get("be_roas", 0)
    roas_attr    = kpis.get("roas_attributed", 0)
    roas_blend   = kpis.get("roas_blended", 0)
    n_orders     = kpis.get("n_orders", 0)
    pp_hold      = kpis.get("paypal_reserve_hold", 0)
    tax          = gross - revenue_nt

    # ── Assessment ────────────────────────────────────────────────────────────
    cogs_lbl, _, cogs_desc     = _assess_cogs(cogs_pct)
    roas_lbl, roas_desc        = _assess_roas(roas_blend if roas_blend > 0 else roas_attr)
    net_lbl,  net_desc         = _assess_net_margin(net_pct)
    uv_lbl,   uv_desc          = _assess_uv(uv, target_uv)

    # ── Favorable / critical points ────────────────────────────────────────────
    punti_fav  = []
    punti_crit = []

    if cogs_pct <= 0.25:
        punti_fav.append(f"COGS below target: {_pct(cogs_pct)} ≤ 25%.")
    elif cogs_pct <= 0.30:
        punti_fav.append(f"COGS in acceptable range: {_pct(cogs_pct)} (25-30%).")
    else:
        punti_crit.append(f"COGS off target: {_pct(cogs_pct)} — goal ≤ 30%. Urgent analysis needed.")

    effective_roas = roas_blend or roas_attr
    if effective_roas >= 2.20:
        punti_fav.append(f"Excellent ROAS {_x(effective_roas)} 🔵 — scale budget aggressively.")
    elif effective_roas >= 1.80:
        punti_fav.append(f"Solid ROAS {_x(effective_roas)} 🟢 — profitable campaigns.")
    elif effective_roas >= 1.50:
        punti_crit.append(f"ROAS in yellow zone {_x(effective_roas)} 🟡 — monitor closely. BE ROAS: {_x(be_roas)}.")
    else:
        punti_crit.append(f"Critical ROAS {_x(effective_roas)} 🔴 — campaigns at net loss. BE ROAS: {_x(be_roas)}.")

    if net >= 0:
        punti_fav.append(f"Profitable day: {_eur(net)} ({_pct(net_pct)}) — UV {_eur(uv)}/order.")
    else:
        punti_crit.append(f"Day at a loss: {_eur(net)}. Urgent cost structure analysis needed.")

    if uv >= target_uv:
        punti_fav.append(f"UV {_eur(uv)} — above target of {_eur(target_uv)} per order.")
    else:
        punti_crit.append(f"UV {_eur(uv)} — below target of {_eur(target_uv)} per order.")

    if n_orders > 0:
        punti_fav.append(f"{n_orders} orders with AOV {_eur(aov)}.")

    if refunds > 0:
        ref_rate = refunds / gross if gross > 0 else 0
        if ref_rate > 0.05:
            punti_crit.append(f"High refunds: {_eur(refunds)} ({_pct(ref_rate)}). Check product quality.")
        else:
            punti_fav.append(f"Contained refunds: {_eur(refunds)} ({_pct(ref_rate)} of gross).")

    if total_adv > 0 and revenue_nt > 0:
        adv_pct = total_adv / revenue_nt
        if adv_pct > 0.45:
            punti_crit.append(f"ADV spend very high: {_pct(adv_pct)} of revenue ({_eur(total_adv)}).")
        elif adv_pct < 0.30:
            punti_fav.append(f"ADV spend contained: {_pct(adv_pct)} of revenue ({_eur(total_adv)}).")

    if meta_roas > 0 and tiktok_roas > 0:
        better = "Meta" if meta_roas >= tiktok_roas else "TikTok"
        punti_fav.append(f"{better} performs better today "
                         f"(Meta {_x(meta_roas)} vs TikTok {_x(tiktok_roas)}).")

    if pp_hold > 0:
        punti_crit.append(
            f"PayPal Reserve Hold: {_eur(pp_hold)} held (~15%). "
            f"Impact on cash flow only, NOT P&L — released in ~30 days.")

    # ── Trend text ────────────────────────────────────────────────────────────
    positive = net >= 0
    trend_text = (
        f"{'Positive' if positive else 'Negative'} day with {n_orders} orders | "
        f"Net revenue {_eur(revenue_nt)} | Blended ROAS {_x(roas_blend)}. "
        f"COGS at {_pct(cogs_pct)} (target ≤ 25%). "
        f"Net margin {_eur(net)} ({_pct(net_pct)}), UV {_eur(uv)}/order."
    )
    if positive:
        next_action = (
            "Continue with current campaigns. "
            f"{'Scale Meta budget (ROAS ' + _x(meta_roas) + ').' if meta_roas >= 1.80 else ''} "
            f"{'Scale TikTok (ROAS ' + _x(tiktok_roas) + ').' if tiktok_roas >= 1.80 else ''}"
        )
    else:
        next_action = (
            "Review cost structure. "
            f"{'Turn off campaigns below ROAS 1.5x.' if effective_roas < 1.50 else 'Optimize targeting.'} "
            f"Check product mix and COGS."
        )

    # ── HTML items ────────────────────────────────────────────────────────────
    fav_html  = "".join(f"<li>{p}</li>" for p in punti_fav)  or "<li>No favorable points detected.</li>"
    crit_html = "".join(f"<li>{p}</li>" for p in punti_crit) or "<li>No critical points detected. ✅</li>"

    sp_fees_eur = fees * sp_share
    pp_fees_eur = fees * pp_share
    adv_meta_pct   = meta_adv / revenue_nt if revenue_nt > 0 else 0
    adv_tiktok_pct = tiktok_adv / revenue_nt if revenue_nt > 0 else 0
    adv_total_pct  = total_adv / revenue_nt if revenue_nt > 0 else 0
    fees_pct   = fees / revenue_nt if revenue_nt > 0 else 0
    refunds_pct = refunds / revenue_nt if revenue_nt > 0 else 0

    cogs_ok_color  = "#276221" if cogs_pct <= 0.25 else ("#9C5700" if cogs_pct <= 0.30 else "#9C0006")
    net_color      = "#276221" if net >= 0 else "#9C0006"
    uv_color       = "#276221" if uv >= target_uv else "#9C5700"

    meta_badge   = _roas_emoji(meta_roas) if meta_roas > 0 else "—"
    tiktok_badge = _roas_emoji(tiktok_roas) if tiktok_roas > 0 else "—"
    blend_badge  = _roas_emoji(roas_blend) if roas_blend > 0 else "—"

    pp_hold_row = ""
    if pp_hold > 0:
        pp_hold_row = f"""
  <tr style="background:#FFF3E0">
    <td>💰 PayPal Reserve Hold (~15%) <em>— solo cash flow</em></td>
    <td style="color:#E65100;font-weight:bold">{_eur(pp_hold)}</td>
    <td style="color:#999">—</td>
    <td style="background:#FFE0B2;color:#E65100;font-size:0.8em">CASH FLOW</td>
  </tr>"""

    html = f"""<!DOCTYPE html>
<html lang="it">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{company} — Finance Analysis {period_label} — {report_date.strftime('%d/%m/%Y')}</title>
<style>
  * {{ box-sizing: border-box; margin: 0; padding: 0; }}
  body {{ font-family: 'Segoe UI', Arial, sans-serif; background: #F0F4FA; color: #222; padding: 24px; }}
  .container {{ max-width: 960px; margin: 0 auto; }}
  h1 {{ color: #1F3864; border-bottom: 3px solid #1F3864; padding-bottom: 10px; margin-bottom: 20px; }}
  h1 span {{ font-size: 0.55em; color: #555; display: block; margin-top: 4px; font-weight: normal; }}
  h2 {{ color: #2E4D91; margin: 28px 0 12px; border-left: 5px solid #2E4D91; padding-left: 10px; font-size: 1.1em; }}
  .kpi-grid {{ display: grid; grid-template-columns: repeat(3, 1fr); gap: 14px; margin: 16px 0; }}
  @media (max-width: 600px) {{ .kpi-grid {{ grid-template-columns: 1fr 1fr; }} }}
  .kpi {{ background: #fff; border-radius: 10px; padding: 16px; box-shadow: 0 2px 8px rgba(0,0,0,.08); text-align: center; }}
  .kpi .val {{ font-size: 1.7em; font-weight: bold; color: #1F3864; }}
  .kpi .lbl {{ font-size: 0.8em; color: #777; margin-top: 4px; }}
  .kpi.pos .val {{ color: #276221; }}
  .kpi.neg .val {{ color: #9C0006; }}
  .kpi.warn .val {{ color: #9C5700; }}
  .kpi.blue .val {{ color: #1F3864; }}
  table {{ width: 100%; border-collapse: collapse; margin: 12px 0; background: #fff; border-radius: 8px; overflow: hidden; box-shadow: 0 1px 4px rgba(0,0,0,.06); }}
  th {{ background: #1F3864; color: #fff; padding: 10px 14px; text-align: left; font-size: 0.9em; }}
  td {{ padding: 8px 14px; border-bottom: 1px solid #E8EDF5; font-size: 0.9em; }}
  tr:last-child td {{ border-bottom: none; }}
  tr:nth-child(even) td {{ background: #F5F8FD; }}
  .badge-ok {{ background: #C6EFCE; color: #276221; font-weight: bold; padding: 2px 9px; border-radius: 10px; font-size: 0.8em; }}
  .badge-warn {{ background: #FFEB9C; color: #9C5700; font-weight: bold; padding: 2px 9px; border-radius: 10px; font-size: 0.8em; }}
  .badge-err {{ background: #FFC7CE; color: #9C0006; font-weight: bold; padding: 2px 9px; border-radius: 10px; font-size: 0.8em; }}
  .badge-blue {{ background: #BDD7EE; color: #1F3864; font-weight: bold; padding: 2px 9px; border-radius: 10px; font-size: 0.8em; }}
  .total-row {{ background: #1F3864 !important; color: #fff; font-weight: bold; }}
  .total-row td {{ background: #1F3864 !important; color: #fff !important; font-weight: bold; }}
  ul {{ list-style: disc; padding-left: 22px; line-height: 1.9; }}
  ul li {{ margin-bottom: 4px; font-size: 0.95em; }}
  .trend-box {{ background: #EBF2FA; border-left: 5px solid #2E4D91; padding: 16px 20px; border-radius: 6px; margin: 12px 0; font-size: 0.95em; line-height: 1.7; }}
  .section-sep {{ border: none; border-top: 2px solid #D9E1F2; margin: 24px 0; }}
  .footer {{ margin-top: 36px; font-size: 0.75em; color: #999; text-align: center; padding: 12px; }}
  @media print {{ body {{ background: #fff; padding: 10px; }} .kpi {{ box-shadow: none; border: 1px solid #ccc; }} }}
</style>
</head>
<body>
<div class="container">

<h1>📊 Finance Analysis {period_label}
  <span>{company} — {report_date.strftime('%A %d %B %Y')}</span>
</h1>

<!-- KPI GRID -->
<h2>⚡ Key KPIs</h2>
<div class="kpi-grid">
  <div class="kpi {'pos' if net >= 0 else 'neg'}">
    <div class="val">{_eur(net)}</div>
    <div class="lbl">EXACT NET</div>
  </div>
  <div class="kpi">
    <div class="val">{_eur(gross)}</div>
    <div class="lbl">Gross Revenue</div>
  </div>
  <div class="kpi">
    <div class="val">{_eur(revenue_nt)}</div>
    <div class="lbl">Net Revenue (ex VAT)</div>
  </div>
  <div class="kpi {'warn' if cogs_pct > 0.25 else 'pos'}">
    <div class="val" style="color:{cogs_ok_color}">{_pct(cogs_pct)}</div>
    <div class="lbl">% COGS (target ≤ 25%)</div>
  </div>
  <div class="kpi">
    <div class="val" style="color:{_roas_color(roas_blend or roas_attr)}">{blend_badge} {_x(roas_blend or roas_attr)}</div>
    <div class="lbl">ROAS Blended</div>
  </div>
  <div class="kpi">
    <div class="val">{n_orders}</div>
    <div class="lbl">Number of Orders</div>
  </div>
  <div class="kpi">
    <div class="val">{_eur(aov)}</div>
    <div class="lbl">AOV (Average Order Value)</div>
  </div>
  <div class="kpi {'pos' if uv >= target_uv else 'warn'}">
    <div class="val" style="color:{uv_color}">{_eur(uv)}</div>
    <div class="lbl">UV (Profit/Order) — target > {_eur(target_uv)}</div>
  </div>
  <div class="kpi blue">
    <div class="val">{_x(be_roas)}</div>
    <div class="lbl">BE ROAS (Break-Even)</div>
  </div>
</div>

<!-- P&L -->
<h2>💰 Income Statement</h2>
<table>
  <tr><th>Item</th><th>Amount (EUR)</th><th>% Net Revenue</th><th>Assessment</th></tr>
  <tr><td><strong>Gross Revenue</strong></td><td><strong>{_eur(gross)}</strong></td><td>—</td><td>—</td></tr>
  <tr><td>&nbsp;&nbsp;&nbsp;↳ VAT / Taxes</td><td>{_eur(tax)}</td><td>{_pct(tax/gross if gross else 0)}</td><td>—</td></tr>
  <tr><td><strong>Net Revenue (ex VAT)</strong></td><td><strong>{_eur(revenue_nt)}</strong></td><td>100%</td><td>—</td></tr>
  <tr><td>Base COGS (supplier)</td><td>{_eur(base_cogs)}</td><td>{_pct(base_cogs/revenue_nt if revenue_nt else 0)}</td><td>—</td></tr>
  <tr><td><strong>TOTAL COGS</strong></td><td><strong>{_eur(total_cogs)}</strong></td><td><strong>{_pct(cogs_pct)}</strong></td>
      <td><span class="{'badge-ok' if cogs_pct<=0.25 else ('badge-warn' if cogs_pct<=0.30 else 'badge-err')}">{cogs_lbl}</span></td></tr>
  <tr><td>Gross Profit</td><td>{_eur(gross_profit)}</td><td>{_pct(gross_profit/revenue_nt if revenue_nt else 0)}</td><td>—</td></tr>
  <tr><td>Meta Ads {meta_badge}</td><td>{_eur(meta_adv)}</td><td>{_pct(adv_meta_pct)}</td>
      <td><span style="color:{_roas_color(meta_roas)};font-weight:bold">{_x(meta_roas) if meta_roas>0 else '—'} {_roas_label(meta_roas) if meta_roas>0 else ''}</span></td></tr>
  <tr><td>TikTok Ads {tiktok_badge}</td><td>{_eur(tiktok_adv)}</td><td>{_pct(adv_tiktok_pct)}</td>
      <td><span style="color:{_roas_color(tiktok_roas)};font-weight:bold">{_x(tiktok_roas) if tiktok_roas>0 else '—'} {_roas_label(tiktok_roas) if tiktok_roas>0 else ''}</span></td></tr>
  <tr><td><strong>Total ADV</strong></td><td><strong>{_eur(total_adv)}</strong></td><td><strong>{_pct(adv_total_pct)}</strong></td><td>—</td></tr>
  <tr><td>Fee Shopify Payments (~{gw_pct_blend*100:.1f}%)</td><td>{_eur(sp_fees_eur)}</td><td>{_pct(sp_fees_eur/revenue_nt if revenue_nt else 0)}</td><td>—</td></tr>
  <tr><td>Fee PayPal (~{pp_fee_pct*100:.1f}%)</td><td>{_eur(pp_fees_eur)}</td><td>{_pct(pp_fees_eur/revenue_nt if revenue_nt else 0)}</td><td>—</td></tr>
  <tr><td>Gateway TOTAL</td><td>{_eur(fees)}</td><td>{_pct(fees_pct)}</td><td>—</td></tr>
  <tr><td>Refunds</td><td>{_eur(refunds)}</td><td>{_pct(refunds_pct)}</td><td>—</td></tr>
  {pp_hold_row}
  <tr class="total-row">
    <td>EXACT NET</td>
    <td>{_eur(net)}</td>
    <td>{_pct(net_pct)}</td>
    <td>{net_lbl}</td>
  </tr>
  <tr class="total-row">
    <td>UV (Profit / Number of Orders)</td>
    <td>{_eur(uv)}/order</td>
    <td>—</td>
    <td>{uv_lbl}</td>
  </tr>
</table>

<!-- ADV Performance -->
<h2>📣 ADV Performance per Channel</h2>
<table>
  <tr><th>Channel</th><th>Spend (EUR)</th><th>% ADV Budget</th><th>ROAS</th><th>Action</th></tr>
  <tr>
    <td>Meta Ads (Facebook / Instagram)</td>
    <td>{_eur(meta_adv)}</td>
    <td>{_pct(meta_adv/total_adv if total_adv else 0)}</td>
    <td style="color:{_roas_color(meta_roas)};font-weight:bold">{meta_badge} {_x(meta_roas) if meta_roas else '—'}</td>
    <td><span style="color:{_roas_color(meta_roas)}">{_roas_label(meta_roas) if meta_roas else '—'}</span></td>
  </tr>
  <tr>
    <td>TikTok Ads</td>
    <td>{_eur(tiktok_adv)}</td>
    <td>{_pct(tiktok_adv/total_adv if total_adv else 0)}</td>
    <td style="color:{_roas_color(tiktok_roas)};font-weight:bold">{tiktok_badge} {_x(tiktok_roas) if tiktok_roas else '—'}</td>
    <td><span style="color:{_roas_color(tiktok_roas)}">{_roas_label(tiktok_roas) if tiktok_roas else '—'}</span></td>
  </tr>
  <tr class="total-row">
    <td>TOTAL ADV</td>
    <td>{_eur(total_adv)}</td>
    <td>100%</td>
    <td style="color:{'#fff'}">{blend_badge} {_x(roas_blend or roas_attr)}</td>
    <td>BE ROAS: {_x(be_roas)}</td>
  </tr>
</table>

<!-- COGS Detail -->
<h2>📦 Supplier Invoice Note (COGS Breakdown)</h2>
<table>
  <tr><th>Item</th><th>Amount</th><th>Detail</th></tr>
  <tr><td>Base COGS (product + shipping)</td><td><strong>{_eur(base_cogs)}</strong></td><td>from country × product × qty matrix or supplier CSV</td></tr>
  <tr><td>Thank You Cards</td><td>{_eur(kpis.get("thank_you_cards", 0))}</td><td>€0.02 × qty</td></tr>
  <tr><td>Branded Bags</td><td>{_eur(kpis.get("branded_bags", 0))}</td><td>€0.06 × orders</td></tr>
  <tr class="total-row"><td>TOTAL COGS</td><td>{_eur(total_cogs)}</td><td>{_pct(cogs_pct)} of net revenue</td></tr>
</table>

<hr class="section-sep">

<!-- Punti Favorevoli -->
<h2>✅ Favorable Points</h2>
<ul>{fav_html}</ul>

<!-- Punti Critici -->
<h2>⚠️ Critical Points</h2>
<ul>{crit_html}</ul>

<!-- Trend -->
<h2>📉 Trend & Recommendations</h2>
<div class="trend-box">
  <p><strong>Summary:</strong> {trend_text}</p>
  <p style="margin-top:10px"><strong>Recommended action:</strong> {next_action}</p>
  <p style="margin-top:10px">
    <strong>COGS:</strong> {cogs_desc}<br>
    <strong>ROAS:</strong> {roas_desc}<br>
    <strong>Net:</strong> {net_desc}<br>
    <strong>UV:</strong> {uv_desc}
  </p>
</div>

<div class="footer">
  Automatically generated by {company} Finance Agent &mdash; {report_date.strftime('%d/%m/%Y')}
</div>

</div>
</body>
</html>"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)

    return html
