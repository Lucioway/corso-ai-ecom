"""
Quotes Checker — Finance Agent

Confronta i COGS reali del fornitore (Supplier XLSX, USD) con le quote
concordate (Quotes XLSX, USD) per ogni ordine Shopify.
Genera un report Excel con le discrepanze e un summary per Telegram.
"""

import os
import re
from datetime import date
from typing import Optional

import openpyxl
import pandas as pd
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

from modules.cogs_reader import (
    PRODUCT_ID_MAP,
    PRODUCT_TITLE_MAP,
    _product_from_id,
    _product_from_title,
)

# ── Country name → ISO code ──────────────────────────────────────────────────

COUNTRY_NAME_TO_CODE = {
    "Australia": "AU", "Austria": "AT", "Belgium": "BE", "Bulgaria": "BG",
    "Canada": "CA", "Croatia": "HR", "Cyprus": "CY", "Czech Republic": "CZ",
    "Denmark": "DK", "Estonia": "EE", "Finland": "FI", "France": "FR",
    "Germany": "DE", "Greece": "GR", "Hungary": "HU", "Ireland": "IE",
    "Italy": "IT", "Latvia": "LV", "Lithuania": "LT", "Luxembourg": "LU",
    "Malta": "MT", "Netherlands": "NL", "New Zealand": "NZ", "Norway": "NO",
    "Poland": "PL", "Portugal": "PT", "Romania": "RO", "Slovakia": "SK",
    "Slovenia": "SI", "Spain": "ES", "Sweden": "SE", "Switzerland": "CH",
    "United Kingdom": "GB", "United States": "US",
}

CODE_TO_COUNTRY = {v: k for k, v in COUNTRY_NAME_TO_CODE.items()}

# Prodotti coperti dalle quote
QUOTED_PRODUCTS = {"Bra", "Leggings", "Jeans"}

# Sheet config: sheet_name → list of qty columns (in order)
SHEET_QTY_MAP = {
    "Bra":      [1, 3, 4],
    "Leggings": [1, 3],
    "Jeans":    [1, 2, 3, 4],
}


# ── Helpers ───────────────────────────────────────────────────────────────────

def _normalize_order_name(name: str) -> str:
    """Strip #, LS prefix → bare number."""
    s = str(name).strip().lstrip("#")
    if s.upper().startswith("LS"):
        s = s[2:]
    return s


def _parse_cell_value(val) -> Optional[float]:
    """Convert a cell value to float, or None if not a valid number."""
    if val is None:
        return None
    if isinstance(val, (int, float)):
        return float(val)
    s = str(val).strip()
    if s in ("", "—", "---", "-", "TBD", "N/A"):
        return None
    try:
        return float(s.replace(",", "."))
    except ValueError:
        return None


def find_latest_quotes_file(quotes_dir: str) -> Optional[str]:
    """Find the most recent XLSX in the Quotes/ directory."""
    if not os.path.isdir(quotes_dir):
        return None
    xlsx_files = [
        os.path.join(quotes_dir, f)
        for f in os.listdir(quotes_dir)
        if f.endswith(".xlsx") and not f.startswith("~$")
    ]
    if not xlsx_files:
        return None
    return max(xlsx_files, key=os.path.getmtime)


# ── QuotesChecker ─────────────────────────────────────────────────────────────

class QuotesChecker:

    def __init__(self, quotes_path: str, config: dict):
        self.quotes_path = quotes_path
        self.config = config
        self._quotes: dict = {}   # {product: {country_code: {qty: price_usd}}}
        self._combos: dict = {}   # {country_code: {combo_key: price_usd}}
        self._load_quotes()

    # ── Load quotes XLSX ──────────────────────────────────────────────────

    def _load_quotes(self):
        """Parse the Quotes XLSX into a nested dict."""
        wb = openpyxl.load_workbook(self.quotes_path, data_only=True)

        for product, qty_cols in SHEET_QTY_MAP.items():
            if product not in wb.sheetnames:
                continue
            ws = wb[product]
            product_quotes = {}

            # Row 1 = title, Row 2 = headers, Row 3+ = data
            for row in ws.iter_rows(min_row=3, max_row=ws.max_row, values_only=True):
                country_name = row[0]
                if not country_name or not isinstance(country_name, str):
                    continue
                country_name = country_name.strip()
                code = COUNTRY_NAME_TO_CODE.get(country_name)
                if not code:
                    continue

                # Last column = Source
                source = str(row[-1] or "").strip()
                if "Mancante" in source:
                    # All values are missing for this row
                    continue

                prices = {}
                for i, qty in enumerate(qty_cols):
                    val = _parse_cell_value(row[1 + i])
                    if val is not None:
                        prices[qty] = val

                if prices:
                    product_quotes[code] = prices

            self._quotes[product] = product_quotes

        # ── Parse Summary sheet for combo prices ─────────────────────────
        # Columns: Country, Bra 1pc, Bra 3pc, Leg 1pc, Leg 3pc,
        #          Jeans 1pc, Jeans 3pc, 1B+1J, 1B+1L, 1B+1J+1L
        if "Summary" in wb.sheetnames:
            ws_sum = wb["Summary"]
            # Combo columns: col 8 = 1B+1J, col 9 = 1B+1L, col 10 = 1B+1J+1L
            combo_keys = [
                (7, "Bra:1+Jeans:1"),
                (8, "Bra:1+Leggings:1"),
                (9, "Bra:1+Jeans:1+Leggings:1"),
            ]
            for row in ws_sum.iter_rows(min_row=3, max_row=ws_sum.max_row, values_only=True):
                country_name = row[0]
                if not country_name or not isinstance(country_name, str):
                    continue
                code = COUNTRY_NAME_TO_CODE.get(country_name.strip())
                if not code:
                    continue
                combos = {}
                for col_idx, combo_key in combo_keys:
                    val = _parse_cell_value(row[col_idx])
                    if val is not None:
                        combos[combo_key] = val
                if combos:
                    self._combos[code] = combos

        wb.close()
        n_combos = sum(len(v) for v in self._combos.values())
        total = sum(len(v) for v in self._quotes.values())
        print(f"[QuotesCheck] Loaded quotes: {total} country entries "
              f"({', '.join(f'{k}:{len(v)}' for k, v in self._quotes.items())})"
              f" + {n_combos} combo prices")

    # ── Load raw USD from supplier XLSX ───────────────────────────────────

    def _load_supplier_usd(self, supplier_path: str) -> dict:
        """Read Supplier XLSX and return {normalized_order_name: total_usd}."""
        if supplier_path.endswith((".xlsx", ".xls")):
            df = pd.read_excel(supplier_path)
        else:
            df = pd.read_csv(supplier_path, dtype=str)

        df.columns = [c.strip().lower().replace(" ", "_") for c in df.columns]

        if "name" in df.columns and "price" in df.columns:
            # Supplier format
            order_cogs = df[df["price"].notna()][["name", "price"]].copy()
            order_cogs["name"] = order_cogs["name"].astype(str).apply(_normalize_order_name)
            order_cogs["price"] = pd.to_numeric(order_cogs["price"], errors="coerce")
            order_cogs = order_cogs.dropna(subset=["price"])
            return dict(zip(order_cogs["name"], order_cogs["price"]))
        elif "ordername" in df.columns and "cogs" in df.columns:
            # Supplier format — COGS already in EUR, not comparable in USD
            # Return empty → quotes check will be skipped for these orders
            return {}
        return {}

    # ── Lookup expected price ─────────────────────────────────────────────

    def get_expected_cogs_usd(self, product: str, country_code: str, qty: int):
        """
        Look up expected quote for a single line item.
        Returns (price_usd | None, status).
        """
        if product not in QUOTED_PRODUCTS:
            return None, "not_quoted_product"

        product_quotes = self._quotes.get(product, {})
        if not product_quotes:
            return None, "no_quote"

        country_prices = product_quotes.get(country_code)
        if not country_prices:
            return None, "no_quote"

        price = country_prices.get(qty)
        if price is not None:
            return price, "ok"

        return None, "qty_not_quoted"

    # ── Combo lookup ────────────────────────────────────────────────────

    def _get_combo_price(self, product_qtys: dict, country_code: str) -> Optional[float]:
        """Check if this multi-product order matches a known combo price."""
        country_combos = self._combos.get(country_code)
        if not country_combos:
            return None
        # Build combo key: sorted product:qty pairs, only for quoted products
        parts = []
        for product in sorted(product_qtys.keys()):
            if product in QUOTED_PRODUCTS:
                parts.append(f"{product}:{product_qtys[product]}")
        if len(parts) < 2:
            return None  # Not a multi-product combo
        combo_key = "+".join(parts)
        return country_combos.get(combo_key)

    # ── Check single order ────────────────────────────────────────────────

    def check_order(self, order: dict, actual_usd: Optional[float]) -> dict:
        """Compare actual supplier COGS vs expected quotes for one order.

        Aggregates line items by product (Shopify splits variants into separate
        line items), then looks up the bundled quote for the total qty per product.
        """
        order_name = order.get("name", "?")
        country_code = (order.get("billing_address") or {}).get("country_code", "??")
        country_name = CODE_TO_COUNTRY.get(country_code, country_code)

        # Step 1: aggregate total qty per product
        product_qtys: dict[str, int] = {}
        for line in order.get("line_items", []):
            pid = str(line.get("product_id", "")).strip()
            title = line.get("title", "")
            qty = int(line.get("quantity", 1))
            product = _product_from_id(pid) if pid else _product_from_title(title)
            product_qtys[product] = product_qtys.get(product, 0) + qty

        # Step 2: determine if we have an EXACT quote for this entire order
        # Rule: only compare if we have a quote that covers ALL products in the order.
        # Rose gives one price per order — we can't split quoted vs unquoted products.
        #
        # - Multi-product → only compare if exact combo quote exists
        # - Single product type → only compare if exact product/country/qty quote exists
        #   AND there are no other (unquoted) products in the order

        line_items_detail = []
        total_expected = 0.0
        can_compare = False

        has_unquoted_products = any(p not in QUOTED_PRODUCTS for p in product_qtys)
        quoted_products = {p: q for p, q in product_qtys.items() if p in QUOTED_PRODUCTS}
        n_quoted_types = len(quoted_products)

        if has_unquoted_products or n_quoted_types > 1:
            # Multi-product or mixed with unquoted → ONLY compare with exact combo
            combo_price = self._get_combo_price(product_qtys, country_code)
            if combo_price is not None and not has_unquoted_products:
                total_expected = combo_price
                can_compare = True
                for product, total_qty in product_qtys.items():
                    line_items_detail.append({
                        "product": product,
                        "qty": total_qty,
                        "expected_usd": None,
                        "status": "combo",
                    })
            else:
                for product, total_qty in product_qtys.items():
                    line_items_detail.append({
                        "product": product,
                        "qty": total_qty,
                        "expected_usd": None,
                        "status": "skipped",
                    })
        elif n_quoted_types == 1:
            # Single quoted product type, no unquoted products
            product = list(quoted_products.keys())[0]
            total_qty = quoted_products[product]
            expected, status = self.get_expected_cogs_usd(product, country_code, total_qty)
            line_items_detail.append({
                "product": product,
                "qty": total_qty,
                "expected_usd": expected,
                "status": status,
            })
            if expected is not None:
                total_expected = expected
                can_compare = True
        else:
            # No quoted products at all
            for product, total_qty in product_qtys.items():
                line_items_detail.append({
                    "product": product,
                    "qty": total_qty,
                    "expected_usd": None,
                    "status": "not_quoted_product",
                })

        # Step 3: determine order-level status
        if actual_usd is None:
            status = "NO_SUPPLIER"
            difference = 0.0
            diff_pct = 0.0
        elif not can_compare:
            status = "SKIPPED"
            difference = 0.0
            diff_pct = 0.0
        else:
            difference = (actual_usd or 0) - total_expected
            diff_pct = (difference / total_expected * 100) if total_expected > 0 else 0
            tolerance = max(0.10, total_expected * 0.01)

            if abs(difference) <= tolerance:
                status = "OK"
            else:
                status = "WRONG"

        # Build product summary string
        products_str = ", ".join(
            f"{it['product']}×{it['qty']}" for it in line_items_detail
        )

        return {
            "order_name": order_name,
            "country_code": country_code,
            "country_name": country_name,
            "products": products_str,
            "total_qty": sum(it["qty"] for it in line_items_detail),
            "line_items": line_items_detail,
            "total_expected_usd": round(total_expected, 2) if can_compare else None,
            "total_actual_usd": round(actual_usd, 2) if actual_usd is not None else None,
            "difference_usd": round(difference, 2),
            "difference_pct": round(diff_pct, 1),
            "status": status,
        }

    # ── Check all orders ──────────────────────────────────────────────────

    def check_all_orders(self, orders: list, supplier_path: str) -> dict:
        """Main entry point: check all orders against quotes."""
        supplier_usd = self._load_supplier_usd(supplier_path)
        print(f"[QuotesCheck] Supplier USD data: {len(supplier_usd)} orders")

        results = []
        ok_count = 0
        wrong_count = 0
        skipped_count = 0
        no_supplier_count = 0
        total_overcharge = 0.0
        total_undercharge = 0.0

        for order in orders:
            norm_name = _normalize_order_name(order.get("name", ""))
            actual_usd = supplier_usd.get(norm_name)

            result = self.check_order(order, actual_usd)
            results.append(result)

            st = result["status"]
            if st == "OK":
                ok_count += 1
            elif st == "WRONG":
                wrong_count += 1
                diff = result["difference_usd"]
                if diff > 0:
                    total_overcharge += diff
                else:
                    total_undercharge += diff
            elif st == "SKIPPED":
                skipped_count += 1
            elif st == "NO_SUPPLIER":
                no_supplier_count += 1

        compared = ok_count + wrong_count
        summary = {
            "total_checked": len(results),
            "compared": compared,
            "ok_count": ok_count,
            "wrong_count": wrong_count,
            "skipped_count": skipped_count,
            "no_supplier_count": no_supplier_count,
            "total_overcharge_usd": round(total_overcharge, 2),
            "total_undercharge_usd": round(total_undercharge, 2),
        }

        print(f"[QuotesCheck] Results: {compared} compared ({ok_count} OK, {wrong_count} WRONG), "
              f"{skipped_count} skipped (no exact quote), "
              f"{no_supplier_count} no supplier")

        return {"results": results, "summary": summary}

    # ── Generate Excel report ─────────────────────────────────────────────

    def generate_quotes_check_report(
        self, check_results: dict, report_date: date, output_path: str
    ):
        """Generate the Quotes Check Excel report."""
        wb = openpyxl.Workbook()
        results = check_results["results"]
        summary = check_results["summary"]

        # ── Styles ────────────────────────────────────────────────────────
        header_font = Font(bold=True, size=11, color="FFFFFF")
        header_fill = PatternFill("solid", fgColor="2C3E50")
        title_font = Font(bold=True, size=14, color="2C3E50")
        subtitle_font = Font(bold=True, size=11, color="2C3E50")
        ok_fill = PatternFill("solid", fgColor="D5F5E3")
        wrong_fill = PatternFill("solid", fgColor="FADBD8")
        partial_fill = PatternFill("solid", fgColor="FEF9E7")
        no_data_fill = PatternFill("solid", fgColor="F2F3F4")
        border = Border(
            left=Side(style="thin", color="D5D8DC"),
            right=Side(style="thin", color="D5D8DC"),
            top=Side(style="thin", color="D5D8DC"),
            bottom=Side(style="thin", color="D5D8DC"),
        )
        money_fmt = '#,##0.00'
        pct_fmt = '0.0%'

        # ── Sheet 1: Summary ──────────────────────────────────────────────
        ws = wb.active
        ws.title = "Summary"
        ws.sheet_properties.tabColor = "2C3E50"

        ws.merge_cells("A1:F1")
        ws["A1"] = f"Quotes Check — {report_date.strftime('%d/%m/%Y')}"
        ws["A1"].font = title_font

        ws.merge_cells("A2:F2")
        ws["A2"] = f"Quotes file: {os.path.basename(self.quotes_path)}"
        ws["A2"].font = Font(italic=True, size=9, color="7F8C8D")

        row = 4
        metrics = [
            ("Ordini totali", summary["total_checked"]),
            ("Confrontati (quota esatta disponibile)", summary["compared"]),
            ("OK", summary["ok_count"]),
            ("WRONG", summary["wrong_count"]),
            ("Skipped (no quota esatta)", summary["skipped_count"]),
            ("No Supplier (no prezzo fornitore)", summary["no_supplier_count"]),
            ("", ""),
            ("Overcharge totale (USD)", f"${summary['total_overcharge_usd']:+.2f}"),
            ("Undercharge totale (USD)", f"${summary['total_undercharge_usd']:.2f}"),
        ]
        for label, val in metrics:
            ws.cell(row=row, column=1, value=label).font = subtitle_font
            cell = ws.cell(row=row, column=2, value=val)
            if label == "WRONG" and isinstance(val, int) and val > 0:
                cell.font = Font(bold=True, color="E74C3C", size=11)
            elif label == "OK":
                cell.font = Font(bold=True, color="27AE60", size=11)
            row += 1

        # Wrong orders summary table
        wrong_orders = [r for r in results if r["status"] == "WRONG"]
        if wrong_orders:
            row += 1
            ws.cell(row=row, column=1, value="Ordini con discrepanza:").font = subtitle_font
            row += 1
            for col_idx, header in enumerate(["Ordine", "Paese", "Prodotti", "Actual $", "Expected $", "Diff $"], 1):
                c = ws.cell(row=row, column=col_idx, value=header)
                c.font = header_font
                c.fill = header_fill
                c.border = border
            row += 1
            for wo in wrong_orders:
                ws.cell(row=row, column=1, value=wo["order_name"]).border = border
                ws.cell(row=row, column=2, value=wo["country_code"]).border = border
                ws.cell(row=row, column=3, value=wo["products"]).border = border
                c = ws.cell(row=row, column=4, value=wo["total_actual_usd"])
                c.number_format = money_fmt
                c.border = border
                c = ws.cell(row=row, column=5, value=wo["total_expected_usd"])
                c.number_format = money_fmt
                c.border = border
                c = ws.cell(row=row, column=6, value=wo["difference_usd"])
                c.number_format = '+#,##0.00;-#,##0.00'
                c.border = border
                c.font = Font(color="E74C3C" if wo["difference_usd"] > 0 else "2980B9")
                row += 1

        # Column widths
        ws.column_dimensions["A"].width = 38
        ws.column_dimensions["B"].width = 14
        ws.column_dimensions["C"].width = 22
        ws.column_dimensions["D"].width = 14
        ws.column_dimensions["E"].width = 14
        ws.column_dimensions["F"].width = 14

        # ── Sheet 2: Order Details ────────────────────────────────────────
        ws2 = wb.create_sheet("Order Details")
        ws2.sheet_properties.tabColor = "3498DB"

        headers = [
            "Order Name", "Country", "Products", "Qty",
            "Actual USD", "Expected USD", "Diff USD", "Diff %", "Status",
        ]
        for col_idx, h in enumerate(headers, 1):
            c = ws2.cell(row=1, column=col_idx, value=h)
            c.font = header_font
            c.fill = header_fill
            c.border = border
            c.alignment = Alignment(horizontal="center")

        ws2.freeze_panes = "A2"

        for i, r in enumerate(results, start=2):
            status = r["status"]
            if status == "OK":
                fill = ok_fill
            elif status in ("WRONG", "PARTIAL_WRONG"):
                fill = wrong_fill
            elif status in ("PARTIAL",):
                fill = partial_fill
            else:
                fill = no_data_fill

            row_data = [
                r["order_name"],
                r["country_code"],
                r["products"],
                r["total_qty"],
                r["total_actual_usd"],
                r["total_expected_usd"],
                r["difference_usd"] if status not in ("NO_SUPPLIER", "NO_QUOTE") else None,
                r["difference_pct"] / 100 if status not in ("NO_SUPPLIER", "NO_QUOTE") else None,
                status,
            ]
            for col_idx, val in enumerate(row_data, 1):
                c = ws2.cell(row=i, column=col_idx, value=val)
                c.fill = fill
                c.border = border
                if col_idx in (5, 6, 7):
                    c.number_format = money_fmt
                elif col_idx == 8 and val is not None:
                    c.number_format = pct_fmt
                if col_idx == 9:
                    c.alignment = Alignment(horizontal="center")
                    if status in ("WRONG", "PARTIAL_WRONG"):
                        c.font = Font(bold=True, color="E74C3C")
                    elif status == "OK":
                        c.font = Font(bold=True, color="27AE60")

        # Column widths
        widths = [14, 10, 28, 6, 14, 14, 12, 10, 16]
        for idx, w in enumerate(widths, 1):
            ws2.column_dimensions[get_column_letter(idx)].width = w

        wb.save(output_path)
        print(f"[QuotesCheck] Report saved: {os.path.basename(output_path)}")
