"""
Email Watcher — Finance Agent
Automatically downloads the supplier CSV from the Gmail inbox.

Required setup (one-time only):
  1. Go to https://myaccount.google.com/apppasswords
  2. Create an App Password for "Mail" → copy the 16-character password
  3. Enter email and app_password in config.json → "email_watcher" section
  4. Enable IMAP in Gmail: Settings → See all settings
     → Forwarding and POP/IMAP → Enable IMAP

How it works:
  - Searches for unread emails from the supplier sender (configurable)
  - Filters for .csv attachments received in the last N hours (default 36h)
  - Downloads the CSV to the tmp folder and returns the path
  - Marks the message as read to avoid downloading it again
"""
import imaplib
import email
import email.message
import os
import re
from datetime import datetime, timedelta, timezone
from email.header import decode_header
from pathlib import Path
from typing import Optional


class EmailWatcher:
    def __init__(self, config: dict):
        cfg = config.get("email_watcher", {})
        self.enabled          = cfg.get("enabled", False)
        self.gmail_address    = cfg.get("gmail_address", "")
        self.app_password     = cfg.get("app_password", "")
        self.supplier_sender  = cfg.get("supplier_sender", "")   # e.g. "orders@your-supplier.com"
        self.subject_filter   = cfg.get("subject_filter", "")    # keyword in subject (optional)
        self.max_age_hours    = cfg.get("max_age_hours", 36)      # search emails from the last 36h
        self.imap_host        = cfg.get("imap_host", "imap.gmail.com")
        self.imap_port        = cfg.get("imap_port", 993)
        self.download_dir     = cfg.get("download_dir", "/tmp/finance_supplier_csv")

    # ── IMAP Connection ───────────────────────────────────────────────────────

    def _connect(self) -> imaplib.IMAP4_SSL:
        """Opens an IMAP4 SSL connection to Gmail."""
        conn = imaplib.IMAP4_SSL(self.imap_host, self.imap_port)
        conn.login(self.gmail_address, self.app_password)
        return conn

    # ── Email header decoding ────────────────────────────────────────────────

    @staticmethod
    def _decode_header_str(raw_header: str) -> str:
        parts = decode_header(raw_header or "")
        decoded = []
        for data, charset in parts:
            if isinstance(data, bytes):
                decoded.append(data.decode(charset or "utf-8", errors="replace"))
            else:
                decoded.append(str(data))
        return " ".join(decoded)

    # ── Supplier email search ────────────────────────────────────────────────

    def _build_search_criteria(self) -> str:
        """
        Builds the IMAP query to find supplier emails.
        Searches for unread (UNSEEN) + sender + date (SINCE yesterday).
        """
        # IMAP SINCE uses DD-Mon-YYYY format
        since_date = (datetime.now() - timedelta(hours=self.max_age_hours)).strftime("%d-%b-%Y")
        criteria_parts = [f'SINCE "{since_date}"']

        if self.supplier_sender:
            criteria_parts.append(f'FROM "{self.supplier_sender}"')

        if self.subject_filter:
            criteria_parts.append(f'SUBJECT "{self.subject_filter}"')

        # Search both read and unread (avoids missing already-seen emails)
        return "(" + " ".join(criteria_parts) + ")"

    def _get_csv_attachment(self, msg: email.message.Message) -> Optional[tuple]:
        """
        Extracts the first CSV attachment from the email message.
        Returns (filename, bytes) or None if not found.
        """
        for part in msg.walk():
            content_disp = part.get("Content-Disposition", "")
            content_type = part.get_content_type()
            filename_raw = part.get_filename()

            if not filename_raw:
                continue

            filename = self._decode_header_str(filename_raw)

            # Consider CSV and Excel by both content-type and file extension
            fname_lower = filename.lower()
            is_data_file = (
                "csv" in content_type.lower()
                or "spreadsheet" in content_type.lower()
                or "excel" in content_type.lower()
                or fname_lower.endswith(".csv")
                or fname_lower.endswith(".xlsx")
                or fname_lower.endswith(".xls")
                or fname_lower.endswith(".txt")
            )

            # Skip tracking files — we only want the price/cost file
            if "tracking" in fname_lower:
                continue

            if is_data_file and ("attach" in content_disp.lower() or not content_disp):
                payload = part.get_payload(decode=True)
                if payload:
                    return filename, payload

        return None

    # ── CSV Download ───────────────────────────────────────────────────────────

    def download_latest_supplier_csv(self, output_dir: Optional[str] = None) -> Optional[str]:
        """
        Searches the Gmail inbox for the most recent supplier email with a CSV attachment.
        If found, downloads the CSV and returns the local path.
        Returns None if not found or on error.

        Args:
            output_dir: folder where to save the CSV (uses download_dir from config if None)
        """
        if not self.enabled:
            return None

        if not self.gmail_address or not self.app_password:
            print("[EmailWatcher] ⚠️  Gmail not configured (gmail_address or app_password missing)")
            return None

        save_dir = output_dir or self.download_dir
        os.makedirs(save_dir, exist_ok=True)

        try:
            print(f"[EmailWatcher] 📬 Connecting to Gmail ({self.gmail_address})...")
            conn = self._connect()
            conn.select("INBOX")

            criteria = self._build_search_criteria()
            _, msg_nums = conn.search(None, criteria)

            if not msg_nums or not msg_nums[0]:
                print(f"[EmailWatcher] ℹ️  No supplier email in the last {self.max_age_hours}h")
                conn.logout()
                return None

            # Sort by most recent (last element of the list)
            ids = msg_nums[0].split()
            print(f"[EmailWatcher] 📩 Found {len(ids)} matching emails")

            # Iterate from most recent to oldest
            for msg_id in reversed(ids):
                _, data = conn.fetch(msg_id, "(RFC822)")
                raw_email = data[0][1]
                msg = email.message_from_bytes(raw_email)

                subject = self._decode_header_str(msg.get("Subject", ""))
                sender  = msg.get("From", "")
                date_hdr = msg.get("Date", "")
                print(f"[EmailWatcher]   → {date_hdr[:16]} | {sender[:40]} | {subject[:50]}")

                csv_data = self._get_csv_attachment(msg)
                if csv_data:
                    filename, payload = csv_data
                    # Safe naming: remove special characters
                    safe_name = re.sub(r'[^\w\-_\.]', '_', filename)
                    csv_path = os.path.join(save_dir, safe_name)
                    with open(csv_path, "wb") as f:
                        f.write(payload)
                    print(f"[EmailWatcher] ✅ CSV downloaded: {safe_name} ({len(payload):,} bytes)")
                    conn.logout()
                    return csv_path
                else:
                    print(f"[EmailWatcher]   ℹ️  No CSV in this message, trying next...")

            print("[EmailWatcher] ℹ️  No CSV found in matching emails")
            conn.logout()
            return None

        except imaplib.IMAP4.error as e:
            print(f"[EmailWatcher] ⚠️  IMAP error: {e}")
            print("               Check gmail_address and app_password in config.json")
            return None
        except Exception as e:
            print(f"[EmailWatcher] ⚠️  Error: {e}")
            return None


# ── Helper for direct use from main.py ──────────────────────────────────────────

def fetch_supplier_csv_from_email(config: dict, output_dir: Optional[str] = None) -> Optional[str]:
    """
    Convenience function: creates an EmailWatcher and downloads the CSV.
    Returns the path of the downloaded CSV, or None.
    """
    watcher = EmailWatcher(config)
    return watcher.download_latest_supplier_csv(output_dir)
