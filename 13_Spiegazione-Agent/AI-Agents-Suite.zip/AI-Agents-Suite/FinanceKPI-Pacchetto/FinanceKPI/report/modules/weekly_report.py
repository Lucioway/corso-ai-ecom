"""
Weekly Report Generator — Finance Agent

Generates TWO separate Excel files for the week (Saturday → Friday):
  1. ShopifyPayments_<company>_DD-DDMon.xlsx
     Tabs: Daily Summary | Payments | Refunds+Chargebacks | Payment Methods | Currencies

  2. PayPal_<company>_DD-DDMon.xlsx
     Tabs: Daily Summary | Payments | Refunds+Disputes | Currencies

Required inputs:
  - sp_csv_path: CSV export from Shopify Admin → Finances → Shopify Payments Transactions
  - pp_csv_path: CSV export from PayPal Business → Reports
  - orders: Shopify orders list (for EUR conversion of PayPal values in foreign currency)
"""
import logging
import os
import re
from datetime import date, timedelta, datetime
from collections import defaultdict
from typing import Optional

import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from .report_generator import (
    _h, _c, _freeze,
    FMT_EUR, FMT_PCT, FMT_NUM, FMT_DATE,
    HDR_FILL, ALT_FILL, OK_FILL, WARN_FILL, ERR_FILL, WHITE, SECTION,
    HDR_FONT, BODY_FONT, BOLD_FONT, TITLE_FONT, BORDER,
)


# ── Helpers ──────────────────────────────────────────────────────────────────

PAYPAL_SHOP_ID = "90660110676"

PAYPAL_EXCLUDE_TYPES = {
    "reserve hold", "reserve release", "general authorization",
    "preapproved payment", "currency conversion", "currency conversion (debit)",
    "currency conversion (credit)", "transfer", "withdrawal",
    "general withdrawal", "general credit", "interest credit",
}

DAYS_IT = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]


def _norm_col(s: str) -> str:
    """Normalizes CSV column names."""
    return re.sub(r'[^a-z0-9]', '_', s.strip().lower()).strip('_')


def _parse_date_flex(s) -> Optional[date]:
    """Tries various date formats."""
    if pd.isna(s) or not s:
        return None
    s = str(s).strip()
    for fmt in ("%Y-%m-%d %H:%M:%S %z", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d",
                "%m/%d/%Y", "%d/%m/%Y", "%d-%m-%Y"):
        try:
            return datetime.strptime(s[:len(fmt.replace('%', '').replace('-','').replace('/', '').replace(' ',''))
                                       + len([c for c in fmt if c == '%']) * 2], fmt).date()
        except Exception:
            pass
    # Try pandas
    try:
        return pd.to_datetime(s, dayfirst=True, errors='raise').date()
    except Exception as e:
        logging.debug("Errore parsing data '%s': %s", s, e)
        return None


def get_week_dates(any_date: date) -> tuple:
    """Returns (saturday_start, friday_end) for the week of `any_date`."""
    days_since_saturday = (any_date.weekday() - 5) % 7
    week_start = any_date - timedelta(days=days_since_saturday)
    week_end   = week_start + timedelta(days=6)
    return week_start, week_end


def _week_label(week_start: date, week_end: date) -> str:
    """Es: '14-20Mar' """
    months_it = {1:'Jan',2:'Feb',3:'Mar',4:'Apr',5:'May',6:'Jun',
                 7:'Jul',8:'Aug',9:'Sep',10:'Oct',11:'Nov',12:'Dec'}
    m = months_it.get(week_end.month, week_end.strftime('%b'))
    return f"{week_start.day:02d}-{week_end.day:02d}{m}"


def _week_days(week_start: date, week_end: date):
    """List of dates from week_start to week_end."""
    days = []
    d = week_start
    while d <= week_end:
        days.append(d)
        d += timedelta(days=1)
    return days


# ── SP CSV parsing ─────────────────────────────────────────────────────────────

def _parse_sp_csv(csv_path: str) -> pd.DataFrame:
    """
    Reads the Shopify Payments CSV.
    Expected columns (or similar): Transaction Date, Type, Order,
      Payment Method Name, Card Brand, Amount, Fee, Net,
      Presentment Amount, Presentment Currency
    """
    df = pd.read_csv(csv_path, dtype=str)
    df.columns = [_norm_col(c) for c in df.columns]

    # Map alternative columns
    col_map = {
        "transaction_date": ["transaction_date", "date", "payout_date"],
        "type":             ["type", "transaction_type"],
        "order":            ["order", "order_number", "order_id"],
        "method":           ["payment_method_name", "payment_method", "method"],
        "card_brand":       ["card_brand", "brand"],
        "amount":           ["amount", "gross_amount", "gross"],
        "fee":              ["fee", "fees"],
        "net":              ["net", "net_amount"],
        "pres_amount":      ["presentment_amount"],
        "pres_currency":    ["presentment_currency", "currency"],
    }
    for canonical, options in col_map.items():
        for opt in options:
            if opt in df.columns and canonical not in df.columns:
                df[canonical] = df[opt]
                break
        if canonical not in df.columns:
            df[canonical] = ""

    # Convert numeric fields
    for col in ("amount", "fee", "net", "pres_amount"):
        df[col] = pd.to_numeric(df[col].str.replace(",", ".", regex=False), errors="coerce").fillna(0)

    # Convert dates
    df["_date"] = df["transaction_date"].apply(_parse_date_flex)

    # Clean up type
    df["type"] = df["type"].str.strip().str.lower().fillna("")

    return df


def _build_sp_daily_summary(df: pd.DataFrame, week_start: date, week_end: date) -> list:
    """Groups by day: payments, refunds, gross, fee, net."""
    results = []
    for d in _week_days(week_start, week_end):
        day_df = df[df["_date"] == d]
        charges   = day_df[day_df["type"].isin(["charge", "payment", "sale", ""])]
        refunds   = day_df[day_df["type"].isin(["refund", "return", "dispute", "chargeback", "adjustment"])]

        n_pmt   = len(charges)
        gross   = charges["amount"].sum()
        fee     = abs(charges["fee"].sum())
        net_pmt = gross - fee

        ref_amt = abs(refunds["amount"].sum())
        netto   = net_pmt - ref_amt

        results.append({
            "date": d, "n_payments": n_pmt, "gross": gross, "fee": fee,
            "fee_pct": fee / gross if gross > 0 else 0,
            "refunds": ref_amt, "net_payments": net_pmt, "netto_totale": netto,
        })
    return results


# ── PP CSV parsing ─────────────────────────────────────────────────────────────

def _parse_pp_csv(csv_path: str, shop_id: str = PAYPAL_SHOP_ID) -> pd.DataFrame:
    """
    Reads the PayPal CSV and filters by shop_id (Custom Number).
    Excludes non-relevant types (Reserve Hold, etc.).
    """
    df = pd.read_csv(csv_path, dtype=str)
    df.columns = [_norm_col(c) for c in df.columns]

    col_map = {
        "date":      ["date", "transaction_date"],
        "type":      ["type", "transaction_type", "activity_type"],
        "currency":  ["currency", "transaction_currency"],
        "gross":     ["gross", "amount", "gross_amount"],
        "fee":       ["fee", "fee_amount"],
        "net":       ["net", "net_amount"],
        "custom_id": ["custom_number", "custom", "invoice_number", "reference_txn_id"],
        "txn_id":    ["transaction_id", "txn_id", "id"],
        "name":      ["name", "buyer_name", "from_email_address"],
        "status":    ["status", "transaction_status"],
    }
    for canonical, options in col_map.items():
        for opt in options:
            if opt in df.columns and canonical not in df.columns:
                df[canonical] = df[opt]
                break
        if canonical not in df.columns:
            df[canonical] = ""

    # Filter by shop_id
    df = df[df["custom_id"].str.strip().str.replace(".0", "", regex=False) == str(shop_id)].copy()

    # Exclude non-relevant types
    df = df[~df["type"].str.lower().str.strip().isin(PAYPAL_EXCLUDE_TYPES)].copy()

    # Convert numeric fields (PayPal sometimes uses comma as decimal separator)
    for col in ("gross", "fee", "net"):
        df[col] = (pd.to_numeric(
            df[col].str.replace(",", ".", regex=False).str.replace("'", "", regex=False),
            errors="coerce").fillna(0))

    # Convert dates
    df["_date"] = df["date"].apply(_parse_date_flex)

    df["type"] = df["type"].str.strip().str.lower().fillna("")
    df["currency"] = df["currency"].str.strip().str.upper().fillna("EUR")

    return df


def _build_pp_daily_summary(df: pd.DataFrame, week_start: date, week_end: date,
                             pp_reserve_pct: float = 0.15) -> list:
    results = []
    for d in _week_days(week_start, week_end):
        day_df = df[df["_date"] == d]
        pmts  = day_df[~day_df["type"].isin(["refund", "reversal", "dispute_loss",
                                              "chargeback", "charge", "correction"])]
        refs  = day_df[day_df["type"].isin(["refund", "reversal", "dispute_loss",
                                             "chargeback", "charge", "correction"])]

        gross   = pmts["gross"].sum()
        fee     = abs(pmts["fee"].sum())
        net_pmt = gross - fee
        ref_amt = abs(refs["gross"].sum())
        holds   = gross * pp_reserve_pct
        netto   = net_pmt - ref_amt

        results.append({
            "date": d, "n_payments": len(pmts), "gross": gross, "fee": fee,
            "fee_pct": fee / gross if gross > 0 else 0,
            "refunds": ref_amt, "holds": holds,
            "net_payments": net_pmt, "netto_totale": netto,
        })
    return results


# ── Excel builder utils ───────────────────────────────────────────────────────

def _title_row(ws, text: str, cols: int):
    c = ws.cell(1, 1, text)
    c.font = TITLE_FONT
    if cols > 1:
        ws.merge_cells(f"A1:{get_column_letter(cols)}1")
    ws.row_dimensions[1].height = 24


def _daily_summary_sheet(ws, daily: list, extra_col: bool = False,
                          title: str = "Daily Summary"):
    """Tab 1 for both files — Daily Summary."""
    ws.title = "📅 Daily Summary"
    if extra_col:
        headers = [("Date",14),("Day",12),("N Payments",12),("Gross €",14),
                   ("Fee €",12),("Fee %",9),("Refunds €",12),("Holds €",12),
                   ("Net Pmt €",14),("TOTAL NET €",16)]
    else:
        headers = [("Date",14),("Day",12),("N Payments",12),("Gross €",14),
                   ("Fee €",12),("Fee %",9),("Refunds €",12),
                   ("Net Pmt €",14),("TOTAL NET €",16)]

    n = len(headers)
    _title_row(ws, title, n)
    for c, (h, w) in enumerate(headers, 1):
        _h(ws, 2, c, h, w)
    _freeze(ws, 3, 1)

    totals = defaultdict(float)
    for r_idx, day in enumerate(daily, 3):
        d = day["date"]
        fill = ALT_FILL if r_idx % 2 == 0 else WHITE
        netto = day["netto_totale"]
        netto_fill = OK_FILL if netto >= 0 else ERR_FILL

        row = [d.strftime("%d/%m/%Y"), DAYS_IT[d.weekday()],
               day["n_payments"], day["gross"], day["fee"],
               day["fee_pct"], day["refunds"]]
        row_fmts = [None, None, FMT_NUM, FMT_EUR, FMT_EUR, FMT_PCT, FMT_EUR]

        if extra_col:
            row.append(day.get("holds", 0))
            row_fmts.append(FMT_EUR)

        row += [day["net_payments"], netto]
        row_fmts += [FMT_EUR, FMT_EUR]

        for c_idx, (v, fmt) in enumerate(zip(row, row_fmts), 1):
            f = netto_fill if c_idx == len(headers) else fill
            _c(ws, r_idx, c_idx, v, fmt, f, bold=(c_idx == len(headers)))

        for k in ("gross", "fee", "refunds", "net_payments", "netto_totale"):
            totals[k] += day.get(k, 0)
        totals["n_payments"] += day.get("n_payments", 0)
        if extra_col:
            totals["holds"] += day.get("holds", 0)

    # Totals row
    r = len(daily) + 3
    dark = PatternFill("solid", start_color="1F3864")
    wf = Font(name="Arial", bold=True, color="FFFFFF", size=10)
    tot_fee_pct = totals["fee"] / totals["gross"] if totals["gross"] > 0 else 0
    tot_row = ["WEEK TOTAL", "", int(totals["n_payments"]),
               totals["gross"], totals["fee"], tot_fee_pct, totals["refunds"]]
    tot_fmts = [None, None, FMT_NUM, FMT_EUR, FMT_EUR, FMT_PCT, FMT_EUR]
    if extra_col:
        tot_row.append(totals["holds"])
        tot_fmts.append(FMT_EUR)
    tot_row += [totals["net_payments"], totals["netto_totale"]]
    tot_fmts += [FMT_EUR, FMT_EUR]

    for c_idx, (v, fmt) in enumerate(zip(tot_row, tot_fmts), 1):
        cell = ws.cell(r, c_idx, v)
        cell.font = wf; cell.fill = dark; cell.border = BORDER
        if fmt: cell.number_format = fmt
        cell.alignment = Alignment(horizontal="right" if c_idx > 2 else "left")


# ── SP Excel tabs ─────────────────────────────────────────────────────────────

def _sp_payments_sheet(ws, df: pd.DataFrame):
    ws.title = "💳 Payments"
    headers = [("Date",14),("Order",12),("Method",16),("Card Brand",12),
               ("Amount €",14),("Fee €",11),("Net €",14),("Pres. Currency",10)]
    for c, (h, w) in enumerate(headers, 1):
        _h(ws, 1, c, h, w)
    _freeze(ws, 2, 1)

    charges = df[~df["type"].isin(["refund","return","dispute","chargeback","adjustment"])].copy()
    charges = charges.sort_values("_date", na_position="last")

    for r, (_, row) in enumerate(charges.iterrows(), 2):
        fill = ALT_FILL if r % 2 == 0 else WHITE
        vals = [
            row["_date"].strftime("%d/%m/%Y") if row["_date"] else "",
            str(row.get("order", "")).strip(),
            str(row.get("method", "")).strip(),
            str(row.get("card_brand", "")).strip(),
            float(row["amount"]),
            abs(float(row["fee"])),
            float(row["net"]),
            str(row.get("pres_currency", "EUR")).strip(),
        ]
        fmts = [None, None, None, None, FMT_EUR, FMT_EUR, FMT_EUR, None]
        for c, (v, fmt) in enumerate(zip(vals, fmts), 1):
            _c(ws, r, c, v, fmt, fill)


def _sp_refunds_sheet(ws, df: pd.DataFrame, chargeback_penalty: float = 15.0):
    ws.title = "↩ Refunds + Chargebacks"
    headers = [("Date",14),("Order",12),("Type",16),("Amount €",14),
               ("CB Penalty €",12),("Total Lost €",14)]
    for c, (h, w) in enumerate(headers, 1):
        _h(ws, 1, c, h, w)
    _freeze(ws, 2, 1)

    refs = df[df["type"].isin(["refund","return","dispute","chargeback","adjustment"])].copy()
    refs = refs.sort_values("_date", na_position="last")

    for r, (_, row) in enumerate(refs.iterrows(), 2):
        fill = ERR_FILL if r % 2 == 0 else PatternFill("solid", start_color="FFCCCC")
        is_cb = "chargeback" in str(row["type"])
        penalty = chargeback_penalty if is_cb else 0
        amount  = abs(float(row["amount"]))
        total   = amount + penalty
        vals = [
            row["_date"].strftime("%d/%m/%Y") if row["_date"] else "",
            str(row.get("order", "")).strip(),
            str(row["type"]).title(),
            -amount, penalty if is_cb else "", total,
        ]
        fmts = [None, None, None, FMT_EUR, FMT_EUR if is_cb else None, FMT_EUR]
        for c, (v, fmt) in enumerate(zip(vals, fmts), 1):
            _c(ws, r, c, v, fmt, fill, bold=(c == 6))


def _sp_methods_sheet(ws, df: pd.DataFrame):
    ws.title = "🏷 Payment Methods"
    headers = [("Method",20),("N Transactions",14),("Gross €",14),
               ("Fee €",11),("Fee %",9),("Net €",14)]
    for c, (h, w) in enumerate(headers, 1):
        _h(ws, 1, c, h, w)

    charges = df[~df["type"].isin(["refund","return","dispute","chargeback","adjustment"])].copy()
    by_method = charges.groupby("method").agg(
        n=("amount","count"), gross=("amount","sum"),
        fee=("fee", lambda x: abs(x.sum())), net=("net","sum")
    ).reset_index().sort_values("gross", ascending=False)

    for r, (_, row) in enumerate(by_method.iterrows(), 2):
        fill = ALT_FILL if r % 2 == 0 else WHITE
        fee_pct = row["fee"] / row["gross"] if row["gross"] > 0 else 0
        vals = [str(row["method"]).strip(), int(row["n"]),
                row["gross"], row["fee"], fee_pct, row["net"]]
        fmts = [None, FMT_NUM, FMT_EUR, FMT_EUR, FMT_PCT, FMT_EUR]
        for c, (v, fmt) in enumerate(zip(vals, fmts), 1):
            _c(ws, r, c, v, fmt, fill)


def _sp_currencies_sheet(ws, df: pd.DataFrame):
    ws.title = "🌍 Currencies"
    headers = [("Currency",10),("N",8),("Pres. Amount",14),("EUR Amount",14),("% Total",10)]
    for c, (h, w) in enumerate(headers, 1):
        _h(ws, 1, c, h, w)

    charges = df[~df["type"].isin(["refund","return","dispute","chargeback","adjustment"])].copy()
    by_curr = charges.groupby("pres_currency").agg(
        n=("pres_amount","count"),
        pres_total=("pres_amount","sum"),
        eur_total=("amount","sum")
    ).reset_index().sort_values("eur_total", ascending=False)
    total_eur = by_curr["eur_total"].sum()

    for r, (_, row) in enumerate(by_curr.iterrows(), 2):
        fill = ALT_FILL if r % 2 == 0 else WHITE
        vals = [str(row["pres_currency"]).strip(), int(row["n"]),
                row["pres_total"], row["eur_total"],
                row["eur_total"] / total_eur if total_eur > 0 else 0]
        fmts = [None, FMT_NUM, FMT_EUR, FMT_EUR, FMT_PCT]
        for c, (v, fmt) in enumerate(zip(vals, fmts), 1):
            _c(ws, r, c, v, fmt, fill)


# ── PP Excel tabs ─────────────────────────────────────────────────────────────

def _pp_payments_sheet(ws, df: pd.DataFrame):
    ws.title = "💳 Payments"
    headers = [("Date",14),("Name",20),("Type",18),("Currency",8),
               ("Gross",12),("Fee",11),("Net",12),("Net EUR",13)]
    for c, (h, w) in enumerate(headers, 1):
        _h(ws, 1, c, h, w)
    _freeze(ws, 2, 1)

    pmts = df[~df["type"].isin(["refund","reversal","dispute_loss",
                                  "chargeback","charge","correction"])].copy()
    pmts = pmts.sort_values("_date", na_position="last")

    for r, (_, row) in enumerate(pmts.iterrows(), 2):
        fill = ALT_FILL if r % 2 == 0 else WHITE
        vals = [
            row["_date"].strftime("%d/%m/%Y") if row["_date"] else "",
            str(row.get("name", "")).strip()[:30],
            str(row["type"]).title(),
            str(row["currency"]).strip(),
            float(row["gross"]),
            abs(float(row["fee"])),
            float(row["net"]),
            float(row.get("_net_eur", row["net"])),  # EUR conversion if available
        ]
        fmts = [None, None, None, None, FMT_EUR, FMT_EUR, FMT_EUR, FMT_EUR]
        for c, (v, fmt) in enumerate(zip(vals, fmts), 1):
            _c(ws, r, c, v, fmt, fill)


def _pp_refunds_sheet(ws, df: pd.DataFrame, dispute_fee: float = 28.0):
    ws.title = "↩ Refunds + Disputes"
    headers = [("Date",14),("Type",18),("Currency",8),
               ("Amount",12),("Dispute Penalty €",15),("Total Lost €",14)]
    for c, (h, w) in enumerate(headers, 1):
        _h(ws, 1, c, h, w)
    _freeze(ws, 2, 1)

    refs = df[df["type"].isin(["refund","reversal","dispute_loss",
                                "chargeback","charge","correction"])].copy()
    refs = refs.sort_values("_date", na_position="last")

    for r, (_, row) in enumerate(refs.iterrows(), 2):
        fill = ERR_FILL if r % 2 == 0 else PatternFill("solid", start_color="FFCCCC")
        is_dispute = "dispute" in str(row["type"]) or "chargeback" in str(row["type"])
        penalty = dispute_fee if is_dispute else 0
        amount  = abs(float(row["gross"]))
        total   = amount + penalty
        vals = [
            row["_date"].strftime("%d/%m/%Y") if row["_date"] else "",
            str(row["type"]).title(),
            str(row["currency"]).strip(),
            -amount, penalty if is_dispute else "", total,
        ]
        fmts = [None, None, None, FMT_EUR, FMT_EUR if is_dispute else None, FMT_EUR]
        for c, (v, fmt) in enumerate(zip(vals, fmts), 1):
            _c(ws, r, c, v, fmt, fill, bold=(c == 6))


def _pp_currencies_sheet(ws, df: pd.DataFrame):
    ws.title = "🌍 Currencies"
    headers = [("Currency",10),("N",8),("Gross",12),("Fee",11),("Net",12),("Net EUR",13),("% Total",10)]
    for c, (h, w) in enumerate(headers, 1):
        _h(ws, 1, c, h, w)

    pmts = df[~df["type"].isin(["refund","reversal","dispute_loss",
                                  "chargeback","charge","correction"])].copy()
    by_curr = pmts.groupby("currency").agg(
        n=("gross","count"),
        gross_tot=("gross","sum"),
        fee_tot=("fee", lambda x: abs(x.sum())),
        net_tot=("net","sum")
    ).reset_index().sort_values("gross_tot", ascending=False)

    # Estimate net EUR (if same currency is not EUR, use gross as proxy)
    total_net = by_curr["net_tot"].sum()

    for r, (_, row) in enumerate(by_curr.iterrows(), 2):
        fill = ALT_FILL if r % 2 == 0 else WHITE
        net_eur = row.get("_net_eur", row["net_tot"])
        vals = [str(row["currency"]).strip(), int(row["n"]),
                row["gross_tot"], abs(row["fee_tot"]), row["net_tot"],
                net_eur, row["net_tot"] / total_net if total_net > 0 else 0]
        fmts = [None, FMT_NUM, FMT_EUR, FMT_EUR, FMT_EUR, FMT_EUR, FMT_PCT]
        for c, (v, fmt) in enumerate(zip(vals, fmts), 1):
            _c(ws, r, c, v, fmt, fill)


# ── Main generators ──────────────────────────────────────────────────────

def generate_sp_weekly_report(
    sp_csv_path: str,
    config: dict,
    week_start: date,
    week_end: date,
    output_path: str,
) -> str:
    """
    Generates the Shopify Payments weekly report.
    """
    label = _week_label(week_start, week_end)
    fin = config.get("finance", {})
    cb_penalty = fin.get("chargeback_penalty_sp", 15.0)

    df = _parse_sp_csv(sp_csv_path)
    # Filter the week
    df = df[(df["_date"] >= week_start) & (df["_date"] <= week_end)].copy()

    daily = _build_sp_daily_summary(df, week_start, week_end)

    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    ws1 = wb.create_sheet()
    _daily_summary_sheet(ws1, daily, extra_col=False,
                         title=f"Shopify Payments — {label}")

    ws2 = wb.create_sheet()
    _sp_payments_sheet(ws2, df)

    ws3 = wb.create_sheet()
    _sp_refunds_sheet(ws3, df, cb_penalty)

    ws4 = wb.create_sheet()
    _sp_methods_sheet(ws4, df)

    ws5 = wb.create_sheet()
    _sp_currencies_sheet(ws5, df)

    wb.save(output_path)
    print(f"[Weekly] ✅ SP report saved: {output_path}")
    return output_path


def generate_pp_weekly_report(
    pp_csv_path: str,
    orders: list,
    config: dict,
    week_start: date,
    week_end: date,
    output_path: str,
) -> str:
    """
    Generates the PayPal weekly report.
    Uses `orders` (Shopify list) to map EUR values of PayPal orders.
    """
    label = _week_label(week_start, week_end)
    fin = config.get("finance", {})
    shop_id = str(fin.get("paypal_shop_id", PAYPAL_SHOP_ID))
    pp_reserve = fin.get("paypal_reserve_pct", 0.15)
    dispute_fee = fin.get("dispute_fee_paypal", 28.0)

    # Build order EUR lookup: order_name → eur_total
    order_eur = {}
    for o in orders:
        name = str(o.get("name", "")).replace("#", "").strip()
        order_eur[name] = float(o.get("_gross_revenue", o.get("total_price", 0)))

    df = _parse_pp_csv(pp_csv_path, shop_id)
    df = df[(df["_date"] >= week_start) & (df["_date"] <= week_end)].copy()

    daily = _build_pp_daily_summary(df, week_start, week_end, pp_reserve)

    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    ws1 = wb.create_sheet()
    _daily_summary_sheet(ws1, daily, extra_col=True,
                         title=f"PayPal — {label}")

    ws2 = wb.create_sheet()
    _pp_payments_sheet(ws2, df)

    ws3 = wb.create_sheet()
    _pp_refunds_sheet(ws3, df, dispute_fee)

    ws4 = wb.create_sheet()
    _pp_currencies_sheet(ws4, df)

    wb.save(output_path)
    print(f"[Weekly] ✅ PP report saved: {output_path}")
    return output_path


def generate_weekly_reports(
    sp_csv_path: Optional[str],
    pp_csv_path: Optional[str],
    orders: list,
    config: dict,
    week_start: date,
    week_end: date,
    output_dir: str,
) -> tuple:
    """
    Generates both weekly reports (SP + PP).
    Returns (sp_path, pp_path) — None if CSV not provided.
    """
    label = _week_label(week_start, week_end)
    company = (config.get("report", {}) or {}).get("company_name", "Company")
    sp_path = pp_path = None

    if sp_csv_path and os.path.exists(sp_csv_path):
        sp_path = os.path.join(output_dir, f"ShopifyPayments_{company}_{label}.xlsx")
        try:
            generate_sp_weekly_report(sp_csv_path, config, week_start, week_end, sp_path)
        except Exception as e:
            print(f"[Weekly] ⚠️ SP report error: {e}")
            sp_path = None
    else:
        print("[Weekly] ℹ️  Shopify Payments CSV not provided — skipping SP report.")

    if pp_csv_path and os.path.exists(pp_csv_path):
        pp_path = os.path.join(output_dir, f"PayPal_{company}_{label}.xlsx")
        try:
            generate_pp_weekly_report(pp_csv_path, orders, config, week_start, week_end, pp_path)
        except Exception as e:
            print(f"[Weekly] ⚠️ PP report error: {e}")
            pp_path = None
    else:
        print("[Weekly] ℹ️  PayPal CSV not provided — skipping PP report.")

    return sp_path, pp_path
