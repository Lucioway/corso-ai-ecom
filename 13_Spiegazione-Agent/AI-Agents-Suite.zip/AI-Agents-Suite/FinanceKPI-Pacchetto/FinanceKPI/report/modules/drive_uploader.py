"""
Google Drive Uploader — Finance Agent

Folder structure:
  📁 <Finance root>/
    📁 Giornalieri/            ← daily reports (flat, no subfolders)
    📁 Settimanali/            ← weekly reports SP + PP
    📁 Fornitori/              ← supplier CSV and price lists

Naming:
  Daily: <prefix>_COGS_DD_MM_YYYY.xlsx + Analisi_DD_MM_YYYY.html
  Weekly: ShopifyPayments_<company>_DD-DDMon.xlsx
          PayPal_<company>_DD-DDMon.xlsx
"""
import os
import pickle
from datetime import date
from pathlib import Path
from typing import Optional

try:
    from google.auth.transport.requests import Request
    from google.oauth2.credentials import Credentials
    from google_auth_oauthlib.flow import InstalledAppFlow
    from googleapiclient.discovery import build
    from googleapiclient.http import MediaFileUpload
    _DRIVE_AVAILABLE = True
except ImportError:
    _DRIVE_AVAILABLE = False


SCOPES    = ["https://www.googleapis.com/auth/drive"]
MIME_XLSX = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
MIME_HTML = "text/html"
MIME_CSV  = "text/csv"
MIME_FOLDER = "application/vnd.google-apps.folder"

TOKEN_FILE = Path(__file__).parent.parent / "token.pickle"


def _day_label(d: date) -> str:
    """DD_MM_YYYY for daily naming."""
    return d.strftime("%d_%m_%Y")


class DriveUploader:
    def __init__(self, config: dict):
        self.config = config or {}
        cfg = self.config.get("google_drive", {})
        self.enabled = bool(cfg.get("enabled", False))
        self.file_prefix = (self.config.get("report", {}) or {}).get("file_prefix", "Report_COGS")
        self.oauth_credentials  = cfg.get("oauth_credentials_file", "oauth_credentials.json")
        self.root_folder_id     = cfg.get("root_folder_id", "")
        self.daily_folder_name  = cfg.get("daily_folder_name",   "Giornalieri")
        self.weekly_folder_name = cfg.get("weekly_folder_name",  "Settimanali")
        self.supplier_folder_name = cfg.get("supplier_folder_name", "Fornitori")
        self.quotes_check_folder_name = cfg.get("quotes_check_folder_name", "Quotes Check")
        self._cogs_folder_id    = cfg.get("csv_cogs_folder_id", "")
        self._service = None
        self._folder_cache: dict = {}

    # ── Service ───────────────────────────────────────────────────────────────

    def _get_service(self):
        if not _DRIVE_AVAILABLE:
            raise ImportError(
                "google-auth / google-api-python-client not installed. "
                "Run: pip install google-auth google-auth-oauthlib google-api-python-client"
            )
        if self._service is None:
            creds = None
            if TOKEN_FILE.exists():
                with open(TOKEN_FILE, "rb") as f:
                    creds = pickle.load(f)
            if not creds or not creds.valid:
                if creds and creds.expired and creds.refresh_token:
                    creds.refresh(Request())
                else:
                    flow = InstalledAppFlow.from_client_secrets_file(
                        self.oauth_credentials, SCOPES
                    )
                    creds = flow.run_local_server(port=0)
                with open(TOKEN_FILE, "wb") as f:
                    pickle.dump(creds, f)
            self._service = build("drive", "v3", credentials=creds)
        return self._service

    # ── Folder management ────────────────────────────────────────────────────

    def _find_or_create_folder(self, name: str, parent_id: str) -> str:
        key = f"{parent_id}/{name}"
        if key in self._folder_cache:
            return self._folder_cache[key]

        service = self._get_service()
        q = (f"name='{name}' and '{parent_id}' in parents "
             f"and mimeType='{MIME_FOLDER}' and trashed=false")
        res = service.files().list(q=q, fields="files(id)").execute()
        files = res.get("files", [])

        if files:
            fid = files[0]["id"]
        else:
            meta = {"name": name, "mimeType": MIME_FOLDER, "parents": [parent_id]}
            fid = service.files().create(body=meta, fields="id").execute()["id"]

        self._folder_cache[key] = fid
        return fid

    def _get_daily_folder(self) -> str:
        return self._find_or_create_folder(self.daily_folder_name, self.root_folder_id)

    def _get_weekly_folder(self) -> str:
        return self._find_or_create_folder(self.weekly_folder_name, self.root_folder_id)

    def _get_supplier_folder(self) -> str:
        return self._find_or_create_folder(self.supplier_folder_name, self.root_folder_id)

    def _get_quotes_check_folder(self) -> str:
        return self._find_or_create_folder(self.quotes_check_folder_name, self.root_folder_id)

    # ── File upload ───────────────────────────────────────────────────────────

    def _upload_file(self, local_path: str, drive_name: str,
                     folder_id: str, mime: str) -> dict:
        """Upload file to Drive. Overwrites if it already exists.
        Returns dict with 'id' and 'webViewLink'."""
        service = self._get_service()
        q = f"name='{drive_name}' and '{folder_id}' in parents and trashed=false"
        existing = service.files().list(q=q, fields="files(id)").execute().get("files", [])

        media = MediaFileUpload(local_path, mimetype=mime, resumable=True)
        if existing:
            fid = existing[0]["id"]
            service.files().update(fileId=fid, media_body=media).execute()
        else:
            meta = {"name": drive_name, "parents": [folder_id]}
            fid = service.files().create(
                body=meta, media_body=media, fields="id"
            ).execute()["id"]

        # Fetch the full webViewLink
        file_meta = service.files().get(fileId=fid, fields="id,webViewLink").execute()
        return file_meta

    # ── Daily upload ──────────────────────────────────────────────────────────

    def upload_daily_report(
        self,
        target_date: date,
        excel_path: Optional[str] = None,
        analysis_path: Optional[str] = None,
    ) -> dict:
        """
        Upload daily files to the Giornalieri/ folder.
        File name: <prefix>_COGS_DD_MM_YYYY.xlsx  +  Analisi_DD_MM_YYYY.html
        """
        if not self.enabled:
            print("[Drive] ℹ️  Drive upload disabled (google_drive.enabled=false) — skipping daily upload.")
            return {}
        label  = _day_label(target_date)
        folder = self._get_daily_folder()
        uploaded = {}

        if excel_path and os.path.exists(excel_path):
            drive_name = f"{self.file_prefix}_{label}.xlsx"
            file_meta = self._upload_file(excel_path, drive_name, folder, MIME_XLSX)
            uploaded["excel"] = file_meta["id"]
            uploaded["excel_url"] = file_meta.get("webViewLink", "")
            print(f"[Drive] ✅ Uploaded daily report: {drive_name}")

        if analysis_path and os.path.exists(analysis_path):
            drive_name = f"Analisi_{label}.html"
            file_meta = self._upload_file(analysis_path, drive_name, folder, MIME_HTML)
            uploaded["analysis"] = file_meta["id"]
            uploaded["analysis_url"] = file_meta.get("webViewLink", "")
            print(f"[Drive] ✅ Uploaded analysis: {drive_name}")

        return uploaded

    # ── Quotes Check upload ──────────────────────────────────────────────────

    def upload_quotes_check_report(self, target_date: date, excel_path: str) -> dict:
        """Upload Quotes Check report to the Quotes Check/ folder."""
        if not self.enabled:
            print("[Drive] ℹ️  Drive upload disabled — skipping quotes check upload.")
            return {}
        label = _day_label(target_date)
        folder = self._get_quotes_check_folder()
        uploaded = {}
        if excel_path and os.path.exists(excel_path):
            drive_name = f"QuotesCheck_{label}.xlsx"
            file_meta = self._upload_file(excel_path, drive_name, folder, MIME_XLSX)
            uploaded["quotes_check"] = file_meta["id"]
            uploaded["quotes_check_url"] = file_meta.get("webViewLink", "")
            print(f"[Drive] ✅ Uploaded quotes check: {drive_name}")
        return uploaded

    # ── Weekly upload ─────────────────────────────────────────────────────────

    def upload_weekly_reports(
        self,
        week_start: date,
        week_end: date,
        sp_excel_path: Optional[str] = None,
        pp_excel_path: Optional[str] = None,
    ) -> dict:
        """
        Upload weekly SP + PP reports to the Settimanali/ folder.
        File names are read from the local path (already correctly formatted).
        """
        if not self.enabled:
            print("[Drive] ℹ️  Drive upload disabled — skipping weekly upload.")
            return {}
        folder = self._get_weekly_folder()
        uploaded = {}

        for path, key, label in [
            (sp_excel_path, "sp_excel", "SP"),
            (pp_excel_path, "pp_excel", "PP"),
        ]:
            if path and os.path.exists(path):
                drive_name = os.path.basename(path)
                file_meta = self._upload_file(path, drive_name, folder, MIME_XLSX)
                uploaded[key] = file_meta["id"]
                uploaded[f"{key}_url"] = file_meta.get("webViewLink", "")
                print(f"[Drive] ✅ Uploaded weekly {label}: {drive_name}")

        return uploaded

    # ── Supplier download (from Drive) ─────────────────────────────────────────

    def download_supplier_csv(self, target_date: date, output_dir: str,
                              folder_name: str = "CSV Cogs") -> Optional[str]:
        """
        Download the supplier CSV from the Drive 'CSV Cogs' folder.
        Searches for files named DD.MM.csv, orders_YYYYMMDD_all.csv, etc.
        Returns the local path of the downloaded file, or None.
        """
        if not self.enabled:
            print("[Drive] ℹ️  Drive disabled — skipping supplier CSV download.")
            return None
        from datetime import timedelta
        service = self._get_service()

        # Use direct folder ID from config if available, otherwise search by name
        if self._cogs_folder_id:
            csv_folder_id = self._cogs_folder_id
        else:
            # Find the CSV Cogs folder by name inside root
            q = (f"name='{folder_name}' and '{self.root_folder_id}' in parents "
                 f"and mimeType='{MIME_FOLDER}' and trashed=false")
            res = service.files().list(q=q, fields="files(id)").execute()
            folders = res.get("files", [])
            if not folders:
                return None
            csv_folder_id = folders[0]["id"]

        import io
        from googleapiclient.http import MediaIoBaseDownload

        MIME_SHEETS = "application/vnd.google-apps.spreadsheet"

        dd_mm      = target_date.strftime("%d.%m")
        dd_mm_yyyy = target_date.strftime("%d.%m.%Y")
        next_day   = target_date + timedelta(days=1)
        dd_mm_next = next_day.strftime("%d.%m")
        d0 = target_date.strftime("%Y%m%d")
        d1 = next_day.strftime("%Y%m%d")

        def _download_file(file_id: str, fname: str, mime: str) -> str:
            """Download a Drive file (CSV or Google Sheet exported as CSV)."""
            os.makedirs(output_dir, exist_ok=True)
            local_name = fname if fname.endswith(".csv") else fname + ".csv"
            local_path = os.path.join(output_dir, local_name)
            if mime == MIME_SHEETS:
                # Export Google Sheet as CSV (first sheet)
                request = service.files().export_media(
                    fileId=file_id,
                    mimeType="text/csv"
                )
            else:
                request = service.files().get_media(fileId=file_id)
            fh = io.BytesIO()
            downloader = MediaIoBaseDownload(fh, request)
            done = False
            while not done:
                _, done = downloader.next_chunk()
            with open(local_path, "wb") as f_out:
                f_out.write(fh.getvalue())
            return local_path

        # 1. Search by exact name (CSV and Google Sheets)
        search_names = [
            f"cogs {dd_mm_yyyy}",
            f"cogs {dd_mm}",
            f"{dd_mm}.csv",
            f"{dd_mm_next}.csv",
            f"orders_{d1}_all.csv",
            f"orders_{d0}_all.csv",
        ]
        for name in search_names:
            q = (f"name='{name}' and '{csv_folder_id}' in parents and trashed=false")
            res = service.files().list(q=q, fields="files(id, name, mimeType)").execute()
            files = res.get("files", [])
            if files:
                fid   = files[0]["id"]
                fname = files[0]["name"]
                mime  = files[0]["mimeType"]
                local_path = _download_file(fid, fname, mime)
                print(f"[Drive] ✅ Supplier COGS downloaded: {fname}")
                return local_path

        # 2. Fallback: any file (CSV or Sheet) with the date in the name
        q = (f"'{csv_folder_id}' in parents and trashed=false")
        res = service.files().list(
            q=q, fields="files(id, name, mimeType)", orderBy="createdTime desc"
        ).execute()
        date_tokens = [dd_mm, dd_mm_yyyy, d0, d1]
        for f in res.get("files", []):
            if any(tok in f["name"] for tok in date_tokens):
                local_path = _download_file(f["id"], f["name"], f["mimeType"])
                print(f"[Drive] ✅ Supplier COGS downloaded: {f['name']}")
                return local_path

        return None

    # ── Supplier upload ───────────────────────────────────────────────────────

    def upload_supplier_file(self, local_path: str, drive_name: str = None) -> str:
        """
        Upload a supplier file (CSV/XLSX) to the Fornitori/ folder.
        """
        if not self.enabled:
            print("[Drive] ℹ️  Drive upload disabled — skipping supplier file upload.")
            return None
        if not os.path.exists(local_path):
            raise FileNotFoundError(f"Supplier file not found: {local_path}")

        folder = self._get_supplier_folder()
        fname  = drive_name or os.path.basename(local_path)
        ext    = os.path.splitext(fname)[1].lower()
        mime   = MIME_XLSX if ext in (".xlsx", ".xls") else MIME_CSV

        fid = self._upload_file(local_path, fname, folder, mime)
        print(f"[Drive] ✅ Uploaded supplier file: {fname}")
        return fid

    def upload_cogs_csv(self, target_date, local_path: str) -> str:
        """Upload COGS CSV to the CSV Cogs folder on Drive."""
        if not self.enabled:
            print("[Drive] ℹ️  Drive upload disabled — skipping COGS CSV upload.")
            return None
        if not local_path or not os.path.exists(local_path):
            return None
        folder_id = self._cogs_folder_id
        if not folder_id:
            return None
        fname = os.path.basename(local_path)
        file_meta = self._upload_file(local_path, fname, folder_id, MIME_CSV)
        print(f"[Drive] ✅ Uploaded COGS CSV: {fname}")
        return file_meta["id"]

    # ── Backward compat alias (for existing code) ─────────────────────────────

    def upload_weekly_report(
        self,
        week_start: date,
        week_end: date,
        excel_path: Optional[str] = None,
        analysis_path: Optional[str] = None,
    ) -> dict:
        """Legacy alias — use upload_weekly_reports() for SP+PP."""
        return self.upload_weekly_reports(week_start, week_end,
                                          sp_excel_path=excel_path)
