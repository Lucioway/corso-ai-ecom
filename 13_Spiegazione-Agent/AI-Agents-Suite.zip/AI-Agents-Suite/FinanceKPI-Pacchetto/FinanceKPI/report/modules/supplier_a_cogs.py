"""Shim → canonical implementation lives in core/supplier_a_cogs.py.
Re-exports public names plus the private helpers consumed by web/supplier_a_cogs_adapter.
"""
import sys, pathlib
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[2]))
from core.supplier_a_cogs import *  # noqa: F401,F403
from core.supplier_a_cogs import (  # noqa: F401
    _order_cogs_usd, _pick_cost_ladder, _commodity_cost_usd,
)
