"""
Accounting Weekly Report — Finance Agent

Contabilità settimanale unificata Sabato→Venerdì.
Traccia al centesimo ogni EUR entrato e uscito su tutti i conti.

Input:
  - Shopify Payments CSV (Admin → Finances → Payouts → Export transactions)
  - PayPal CSV (PayPal Business → Reports → Activity Download)

Output:
  Contabilità_Settimanale_DD-DD_Mon_YYYY.xlsx
  Tabs:
    📊 Contabilità       → 1 riga/giorno: Entrate, Uscite, Netto per conto
    💳 Shopify Payments  → tutte le transazioni SP (dettaglio)
    🅿️  PayPal            → tutte le transazioni PP (dettaglio)
    💸 Costi Fissi       → costi fissi/variabili settimana (da compilare)
    💰 Saldo             → riepilogo e saldo finale settimana
"""
import os
from datetime import date
from collections import defaultdict
from typing import Optional

import pandas as pd
import openpyxl
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.utils import get_column_letter

from .weekly_report import (
    _parse_sp_csv, _parse_pp_csv,
    _week_label, _week_days,
)
from .report_generator import (
    FMT_EUR, FMT_PCT, FMT_NUM,
    HDR_FILL, ALT_FILL, OK_FILL, WARN_FILL, ERR_FILL, WHITE,
    TITLE_FONT, BORDER,
)


# ── Style constants ───────────────────────────────────────────────────────────

DAYS_IT = {
    0: "Lunedì", 1: "Martedì", 2: "Mercoledì", 3: "Giovedì",
    4: "Venerdì", 5: "Sabato", 6: "Domenica",
}

_F  = lambda color, bold=False, size=10, fg="000000": Font(
    name="Arial", bold=bold, size=size, color=fg)
_P  = lambda color: PatternFill("solid", start_color=color)

DARK_BLUE   = _P("1F3864")
MID_BLUE    = _P("2E75B6")
LIGHT_BLUE  = _P("D6E4F0")
PP_BLUE     = _P("003087")
PP_MID      = _P("009CDE")
GREEN_FILL  = _P("E2EFDA")
RED_FILL    = _P("FFDDD6")
YELLOW_FILL = _P("FFF3CC")
ORANGE_FILL = _P("FCE4D6")
GREY_FILL   = _P("F2F2F2")
GREY2       = _P("D9D9D9")
COSTS_RED   = _P("C00000")

WHITE_F  = _F("FFFFFF", bold=True)
DARK_F   = _F("1F3864", bold=True)
BODY_F   = _F("000000")
BOLD_F   = _F("000000", bold=True)

THIN = Side(style="thin",   color="CCCCCC")
MED  = Side(style="medium", color="AAAAAA")
CELL_BRD = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
SECT_BRD = Border(left=MED,  right=MED,  top=MED,  bottom=MED)


def _cell(ws, row, col, value, fmt=None, fill=None, font=None,
          bold=False, align="right"):
    c = ws.cell(row, col, value)
    if fmt:   c.number_format = fmt
    if fill:  c.fill   = fill
    c.font      = font or (BOLD_F if bold else BODY_F)
    c.alignment = Alignment(horizontal=align, vertical="center")
    c.border    = CELL_BRD
    return c


def _hdr(ws, row, col, text, width=14, fill=None):
    c = ws.cell(row, col, text)
    c.font      = WHITE_F
    c.fill      = fill or HDR_FILL
    c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    c.border    = CELL_BRD
    ws.column_dimensions[get_column_letter(col)].width = width
    return c


def _sect(ws, row, c1, c2, text, fill=None):
    """Merged section-header row."""
    ws.merge_cells(start_row=row, start_column=c1, end_row=row, end_column=c2)
    c = ws.cell(row, c1, text)
    c.font      = WHITE_F
    c.fill      = fill or MID_BLUE
    c.alignment = Alignment(horizontal="center", vertical="center")
    c.border    = SECT_BRD


def _title(ws, text, ncols, fill=None):
    ws.merge_cells(f"A1:{get_column_letter(ncols)}1")
    c = ws.cell(1, 1, text)
    c.font      = Font(name="Arial", bold=True, size=13, color="FFFFFF")
    c.fill      = fill or DARK_BLUE
    c.alignment = Alignment(horizontal="center", vertical="center")
    ws.row_dimensions[1].height = 26


# ── Daily accounting builder ──────────────────────────────────────────────────

def _build_daily_accounting(
    sp_df: pd.DataFrame,
    pp_df: pd.DataFrame,
    week_start: date,
    week_end: date,
    pp_reserve_pct: float = 0.15,
    cb_penalty: float    = 15.0,
    dispute_fee: float   = 28.0,
) -> list:
    """
    Builds one accounting row per day combining Shopify Payments + PayPal.
    All amounts in EUR, precise to the cent.
    """
    results = []
    for d in _week_days(week_start, week_end):

        # ── Shopify Payments ─────────────────────────────────────────────
        sp_d = sp_df[sp_df["_date"] == d] if not sp_df.empty else sp_df
        sp_charges = sp_d[sp_d["type"].isin(["charge", "payment", "sale", ""])]
        sp_refunds  = sp_d[sp_d["type"].isin(["refund", "return", "adjustment"])]
        sp_cb       = sp_d[sp_d["type"].isin(["chargeback", "dispute"])]

        sp_gross   = float(sp_charges["amount"].sum())
        sp_fee     = abs(float(sp_charges["fee"].sum()))
        sp_ref_amt = abs(float(sp_refunds["amount"].sum()))
        sp_cb_amt  = abs(float(sp_cb["amount"].sum())) + len(sp_cb) * cb_penalty
        sp_net     = sp_gross - sp_fee - sp_ref_amt - sp_cb_amt

        # ── PayPal ───────────────────────────────────────────────────────
        pp_d    = pp_df[pp_df["_date"] == d] if not pp_df.empty else pp_df
        pp_pmts = pp_d[~pp_d["type"].isin([
            "refund","reversal","dispute_loss","chargeback","charge","correction"])]
        pp_refs = pp_d[pp_d["type"].isin([
            "refund","reversal","dispute_loss","chargeback","charge","correction"])]
        pp_disp = pp_refs[pp_refs["type"].isin(["dispute_loss","chargeback"])]
        pp_ronly= pp_refs[~pp_refs["type"].isin(["dispute_loss","chargeback"])]

        pp_gross    = float(pp_pmts["gross"].sum())
        pp_fee      = abs(float(pp_pmts["fee"].sum()))
        pp_disp_amt = abs(float(pp_disp["gross"].sum())) + len(pp_disp) * dispute_fee
        pp_ref_amt  = abs(float(pp_ronly["gross"].sum()))
        pp_hold     = pp_gross * pp_reserve_pct
        pp_net      = pp_gross - pp_fee - pp_ref_amt - pp_disp_amt

        total_in  = sp_gross + pp_gross
        total_out = sp_fee + sp_ref_amt + sp_cb_amt + pp_fee + pp_ref_amt + pp_disp_amt

        results.append({
            "date":       d,
            "sp_n":       len(sp_charges),
            "sp_gross":   round(sp_gross,   2),
            "sp_fee":     round(sp_fee,     2),
            "sp_refund":  round(sp_ref_amt, 2),
            "sp_cb":      round(sp_cb_amt,  2),
            "sp_net":     round(sp_net,     2),
            "pp_n":       len(pp_pmts),
            "pp_gross":   round(pp_gross,   2),
            "pp_fee":     round(pp_fee,     2),
            "pp_refund":  round(pp_ref_amt, 2),
            "pp_dispute": round(pp_disp_amt,2),
            "pp_hold":    round(pp_hold,    2),
            "pp_net":     round(pp_net,     2),
            "total_in":   round(total_in,   2),
            "total_out":  round(total_out,  2),
            "net_cassa":  round(sp_net + pp_net, 2),
        })
    return results


# ── Tab 1: Contabilità Settimanale ────────────────────────────────────────────

def _tab_contabilita(ws, daily: list, label: str):
    ws.title = "📊 Contabilità"
    NCOLS = 17

    _title(ws, f"CONTABILITÀ SETTIMANALE — {label}", NCOLS)

    # Row 2: section headers
    _sect(ws, 2, 1,  2, "PERIODO",           fill=_P("333333"))
    _sect(ws, 2, 3,  8, "SHOPIFY PAYMENTS",  fill=_P("1F4E79"))
    _sect(ws, 2, 9,  14,"PAYPAL",            fill=_P("003087"))
    _sect(ws, 2, 15, 17,"TOTALI",            fill=_P("1F3864"))
    ws.row_dimensions[2].height = 18

    # Row 3: column headers
    COLS = [
        # meta
        ("Data",             12, None,    _P("333333")),
        ("Giorno",           12, None,    _P("333333")),
        # SP (cols 3–8)
        ("N Pgmt",            8, FMT_NUM, _P("1F4E79")),
        ("SP Lordo +",       14, FMT_EUR, _P("1F4E79")),
        ("SP Fee –",         12, FMT_EUR, _P("1F4E79")),
        ("SP Refund –",      12, FMT_EUR, _P("1F4E79")),
        ("SP Chargeback –",  13, FMT_EUR, _P("1F4E79")),
        ("Netto SP",         14, FMT_EUR, _P("1F4E79")),
        # PP (cols 9–14)
        ("N Pgmt",            8, FMT_NUM, _P("003087")),
        ("PP Lordo +",       13, FMT_EUR, _P("003087")),
        ("PP Fee –",         11, FMT_EUR, _P("003087")),
        ("PP Refund –",      12, FMT_EUR, _P("003087")),
        ("PP Dispute –",     12, FMT_EUR, _P("003087")),
        ("Netto PP",         13, FMT_EUR, _P("003087")),
        # totals (cols 15–17)
        ("Totale Entrato",   15, FMT_EUR, _P("1F3864")),
        ("Totale Uscite",    14, FMT_EUR, _P("1F3864")),
        ("NETTO CASSA",      14, FMT_EUR, _P("1F3864")),
    ]
    for i, (hdr, width, _, fill) in enumerate(COLS, 1):
        c = ws.cell(3, i, hdr)
        c.font      = WHITE_F
        c.fill      = fill
        c.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        c.border    = CELL_BRD
        ws.column_dimensions[get_column_letter(i)].width = width
    ws.row_dimensions[3].height = 32

    # Freeze header rows
    ws.freeze_panes = ws.cell(4, 3)

    totals = defaultdict(float)
    keys = ["sp_n","sp_gross","sp_fee","sp_refund","sp_cb","sp_net",
            "pp_n","pp_gross","pp_fee","pp_refund","pp_dispute","pp_net",
            "total_in","total_out","net_cassa"]

    for r, day in enumerate(daily, 4):
        d      = day["date"]
        base   = ALT_FILL if r % 2 == 0 else WHITE

        # Date / Day
        _cell(ws, r, 1, d.strftime("%d/%m/%Y"), fill=base, bold=True, align="center")
        _cell(ws, r, 2, DAYS_IT[d.weekday()],   fill=base, bold=True, align="left")

        # SP (3–8)
        sp_vals = [day["sp_n"],     day["sp_gross"],  day["sp_fee"],
                   day["sp_refund"],day["sp_cb"],      day["sp_net"]]
        sp_fmts = [FMT_NUM, FMT_EUR, FMT_EUR, FMT_EUR, FMT_EUR, FMT_EUR]
        for i, (v, fmt) in enumerate(zip(sp_vals, sp_fmts)):
            col  = 3 + i
            fill = (GREEN_FILL if v >= 0 else RED_FILL) if col == 8 else base
            _cell(ws, r, col, v, fmt, fill, bold=(col == 8))

        # PP (9–14)
        pp_vals = [day["pp_n"],     day["pp_gross"],  day["pp_fee"],
                   day["pp_refund"],day["pp_dispute"], day["pp_net"]]
        pp_fmts = [FMT_NUM, FMT_EUR, FMT_EUR, FMT_EUR, FMT_EUR, FMT_EUR]
        for i, (v, fmt) in enumerate(zip(pp_vals, pp_fmts)):
            col  = 9 + i
            fill = (GREEN_FILL if v >= 0 else RED_FILL) if col == 14 else base
            _cell(ws, r, col, v, fmt, fill, bold=(col == 14))

        # Totali (15–17)
        _cell(ws, r, 15, day["total_in"],            FMT_EUR, LIGHT_BLUE,  bold=True)
        _cell(ws, r, 16, -day["total_out"],           FMT_EUR, ORANGE_FILL, bold=True)
        net   = day["net_cassa"]
        nfill = GREEN_FILL if net >= 0 else RED_FILL
        c = ws.cell(r, 17, net)
        c.number_format = FMT_EUR
        c.fill      = nfill
        c.font      = Font(name="Arial", bold=True, size=11)
        c.alignment = Alignment(horizontal="right", vertical="center")
        c.border    = CELL_BRD

        ws.row_dimensions[r].height = 20

        for k in keys:
            totals[k] += day.get(k, 0)

    # Totals row
    r_tot = len(daily) + 4
    ws.merge_cells(start_row=r_tot, start_column=1, end_row=r_tot, end_column=2)
    _cell(ws, r_tot, 1, "TOTALE SETTIMANA", fill=DARK_BLUE,
          font=WHITE_F, align="center")

    tot_vals = [
        int(totals["sp_n"]), totals["sp_gross"],  totals["sp_fee"],
        totals["sp_refund"], totals["sp_cb"],      totals["sp_net"],
        int(totals["pp_n"]), totals["pp_gross"],  totals["pp_fee"],
        totals["pp_refund"], totals["pp_dispute"], totals["pp_net"],
        totals["total_in"],  -totals["total_out"], totals["net_cassa"],
    ]
    tot_fmts = [FMT_NUM,FMT_EUR,FMT_EUR,FMT_EUR,FMT_EUR,FMT_EUR,
                FMT_NUM,FMT_EUR,FMT_EUR,FMT_EUR,FMT_EUR,FMT_EUR,
                FMT_EUR,FMT_EUR,FMT_EUR]
    for i, (v, fmt) in enumerate(zip(tot_vals, tot_fmts), 3):
        is_net = i in [8, 14, 15, 16, 17]
        _cell(ws, r_tot, i, v, fmt, DARK_BLUE,
              font=Font(name="Arial", bold=True, size=11 if is_net else 10, color="FFFFFF"))
    ws.row_dimensions[r_tot].height = 24

    # PP Hold info section
    r_sep  = r_tot + 2
    r_hold = r_tot + 3
    ws.merge_cells(f"A{r_sep}:{get_column_letter(NCOLS)}{r_sep}")
    ws.row_dimensions[r_sep].height = 4

    ws.merge_cells(f"A{r_hold}:{get_column_letter(NCOLS)}{r_hold}")
    c = ws.cell(r_hold, 1,
        "📌  PP HOLD (15% bloccato da PayPal — non è un costo, verrà sbloccato dopo 30 giorni)")
    c.font = Font(name="Arial", bold=True, size=9, color="7F6000")
    c.fill = YELLOW_FILL
    c.alignment = Alignment(horizontal="left", vertical="center")
    ws.row_dimensions[r_hold].height = 16

    for r, day in enumerate(daily, r_hold + 1):
        d = day["date"]
        _cell(ws, r, 1, d.strftime("%d/%m/%Y"),  fill=YELLOW_FILL,
              font=Font(name="Arial", size=9), align="center")
        _cell(ws, r, 2, DAYS_IT[d.weekday()],    fill=YELLOW_FILL,
              font=Font(name="Arial", size=9), align="left")
        _cell(ws, r, 3, day["pp_hold"], FMT_EUR, fill=YELLOW_FILL,
              font=Font(name="Arial", size=9))
        for col in range(4, NCOLS + 1):
            ws.cell(r, col).fill   = YELLOW_FILL
            ws.cell(r, col).border = CELL_BRD
        ws.row_dimensions[r].height = 15


# ── Tab 2: Shopify Payments Detail ────────────────────────────────────────────

def _tab_sp_detail(ws, sp_df: pd.DataFrame):
    ws.title = "💳 Shopify Payments"
    headers = [
        ("Data",        14), ("Ordine",   12), ("Tipo",       16),
        ("Metodo",      18), ("Carta",    12), ("Lordo €",    14),
        ("Fee €",       11), ("Netto €",  14), ("Val. Cliente",10),
    ]
    for i, (h, w) in enumerate(headers, 1):
        _hdr(ws, 1, i, h, w)
    ws.row_dimensions[1].height = 20
    ws.freeze_panes = ws.cell(2, 1)

    df = sp_df.sort_values("_date", na_position="last")
    for r, (_, row) in enumerate(df.iterrows(), 2):
        t    = str(row.get("type","")).strip().lower()
        fill = (RED_FILL    if t in ["chargeback","dispute"] else
                ORANGE_FILL if t in ["refund","return","adjustment"] else
                (ALT_FILL if r % 2 == 0 else WHITE))
        vals = [
            row["_date"].strftime("%d/%m/%Y") if row["_date"] else "",
            str(row.get("order","")).strip(),
            str(row.get("type","")).strip().title(),
            str(row.get("method","")).strip(),
            str(row.get("card_brand","")).strip(),
            float(row.get("amount", 0)),
            abs(float(row.get("fee", 0))),
            float(row.get("net", 0)),
            str(row.get("pres_currency","EUR")).strip(),
        ]
        fmts = [None,None,None,None,None,FMT_EUR,FMT_EUR,FMT_EUR,None]
        for c, (v, fmt) in enumerate(zip(vals, fmts), 1):
            _cell(ws, r, c, v, fmt, fill,
                  align="left" if c in [2,3,4,5,9] else "right")
        ws.row_dimensions[r].height = 16


# ── Tab 3: PayPal Detail ──────────────────────────────────────────────────────

def _tab_pp_detail(ws, pp_df: pd.DataFrame, dispute_fee: float = 28.0):
    ws.title = "🅿️ PayPal"
    headers = [
        ("Data",        14), ("Nome / Email", 22), ("Tipo",       18),
        ("Valuta",       8), ("Lordo",        13), ("Fee",        11),
        ("Netto",       12), ("Note",         22),
    ]
    for i, (h, w) in enumerate(headers, 1):
        _hdr(ws, 1, i, h, w, fill=PP_BLUE)
    ws.row_dimensions[1].height = 20
    ws.freeze_panes = ws.cell(2, 1)

    df = pp_df.sort_values("_date", na_position="last")
    for r, (_, row) in enumerate(df.iterrows(), 2):
        t    = str(row.get("type","")).strip().lower()
        fill = (RED_FILL    if t in ["dispute_loss","chargeback"] else
                ORANGE_FILL if t in ["refund","reversal","correction"] else
                (ALT_FILL if r % 2 == 0 else WHITE))
        is_disp = t in ["dispute_loss","chargeback"]
        note    = f"Penalità dispute: €{dispute_fee:.2f}" if is_disp else ""
        vals = [
            row["_date"].strftime("%d/%m/%Y") if row["_date"] else "",
            str(row.get("name","")).strip()[:35],
            str(row.get("type","")).strip().title(),
            str(row.get("currency","EUR")).strip(),
            float(row.get("gross", 0)),
            abs(float(row.get("fee", 0))),
            float(row.get("net", 0)),
            note,
        ]
        fmts = [None,None,None,None,FMT_EUR,FMT_EUR,FMT_EUR,None]
        for c, (v, fmt) in enumerate(zip(vals, fmts), 1):
            _cell(ws, r, c, v, fmt, fill,
                  align="left" if c in [2,3,4,8] else "right")
        ws.row_dimensions[r].height = 16


# ── Tab 4: Costi Fissi ────────────────────────────────────────────────────────

def _tab_costi(ws, week_start: date, week_end: date):
    ws.title = "💸 Costi Fissi"
    label = f"{week_start.strftime('%d/%m')}–{week_end.strftime('%d/%m/%Y')}"

    _title(ws, f"COSTI FISSI & VARIABILI — {label}", 5, fill=COSTS_RED)

    headers = [
        ("Categoria",  22), ("Descrizione",         30),
        ("Importo €",  14), ("Frequenza",            14),
        ("Note",       28),
    ]
    for i, (h, w) in enumerate(headers, 1):
        _hdr(ws, 2, i, h, w, fill=COSTS_RED)
    ws.row_dimensions[2].height = 20
    ws.freeze_panes = ws.cell(3, 1)

    FIXED_ROWS = [
        ("Shopify",      "Shopify Subscription (piano mensile)",  None, "Mensile", "÷4 per settimana"),
        ("Shopify",      "Shopify Bill (app, ADV credit, ecc.)", None, "Mensile", "÷4 per settimana"),
        ("App",          "Klaviyo",                               None, "Mensile", "÷4 per settimana"),
        ("App",          "Triple Whale",                          None, "Mensile", "÷4 per settimana"),
        ("App",          "Altre app",                             None, "Mensile", ""),
        ("Costo Extra",  "",                                      None, "",        ""),
        ("Costo Extra",  "",                                      None, "",        ""),
        ("Costo Extra",  "",                                      None, "",        ""),
        ("Costo Extra",  "",                                      None, "",        ""),
        ("Costo Extra",  "",                                      None, "",        ""),
    ]

    for r, (cat, desc, amt, freq, note) in enumerate(FIXED_ROWS, 3):
        fill = GREY_FILL if r % 2 == 0 else WHITE
        _cell(ws, r, 1, cat,  fill=fill, align="left")
        _cell(ws, r, 2, desc, fill=fill, align="left")
        _cell(ws, r, 3, amt,  FMT_EUR, fill=fill)
        _cell(ws, r, 4, freq, fill=fill, align="left")
        _cell(ws, r, 5, note, fill=fill, align="left",
              font=Font(name="Arial", size=9, italic=True, color="666666"))
        ws.row_dimensions[r].height = 18

    r_tot = len(FIXED_ROWS) + 3
    ws.merge_cells(f"A{r_tot}:B{r_tot}")
    _cell(ws, r_tot, 1, "TOTALE COSTI SETTIMANA", fill=COSTS_RED, font=WHITE_F, align="left")
    c = ws.cell(r_tot, 3, f"=SUM(C3:C{r_tot-1})")
    c.number_format = FMT_EUR
    c.fill   = COSTS_RED
    c.font   = Font(name="Arial", bold=True, size=11, color="FFFFFF")
    c.border = CELL_BRD
    c.alignment = Alignment(horizontal="right", vertical="center")
    for col in [4, 5]:
        ws.cell(r_tot, col).fill   = COSTS_RED
        ws.cell(r_tot, col).border = CELL_BRD
    ws.row_dimensions[r_tot].height = 22

    # Note
    r_note = r_tot + 2
    ws.merge_cells(f"A{r_note}:E{r_note}")
    c = ws.cell(r_note, 1,
        "📌  Compila la colonna Importo €. I costi mensili vanno divisi per 4 per il costo settimanale. "
        "Il Netto Cassa nel tab Contabilità non include ancora questi costi.")
    c.font      = Font(name="Arial", size=9, italic=True, color="C00000")
    c.alignment = Alignment(wrap_text=True, horizontal="left", vertical="top")
    ws.row_dimensions[r_note].height = 30


# ── Tab 5: Saldo ──────────────────────────────────────────────────────────────

def _tab_saldo(ws, daily: list, label: str):
    ws.title = "💰 Saldo"
    _title(ws, f"SALDO SETTIMANA — {label}", 3)
    ws.column_dimensions["A"].width = 34
    ws.column_dimensions["B"].width = 18
    ws.column_dimensions["C"].width = 22

    t = defaultdict(float)
    for day in daily:
        for k in ["sp_gross","sp_fee","sp_refund","sp_cb","sp_net",
                  "pp_gross","pp_fee","pp_refund","pp_dispute","pp_hold","pp_net",
                  "total_in","total_out","net_cassa"]:
            t[k] += day.get(k, 0)

    def row_kpi(r, label, value, fmt=FMT_EUR, fill=WHITE, bold=False, note=""):
        _cell(ws, r, 1, label, fill=fill, bold=bold, align="left")
        _cell(ws, r, 2, value, fmt,       fill=fill, bold=bold)
        c = ws.cell(r, 3, note)
        c.font      = Font(name="Arial", size=9, italic=True, color="777777")
        c.fill      = fill
        c.border    = CELL_BRD
        c.alignment = Alignment(horizontal="left")
        ws.row_dimensions[r].height = 18

    def sep(r, text, fill=_P("444444")):
        ws.merge_cells(f"A{r}:C{r}")
        c = ws.cell(r, 1, f"  {text}")
        c.font      = WHITE_F
        c.fill      = fill
        c.alignment = Alignment(horizontal="left", vertical="center")
        ws.row_dimensions[r].height = 16

    r = 2
    sep(r, "SHOPIFY PAYMENTS"); r += 1
    row_kpi(r, "Lordo ricevuto",          t["sp_gross"],     note="Tutti i pagamenti incassati"); r += 1
    row_kpi(r, "Fee gateway",            -t["sp_fee"],       note="Commissioni Shopify Payments"); r += 1
    row_kpi(r, "Refund pagati",          -t["sp_refund"],    note="Rimborsi clienti"); r += 1
    row_kpi(r, "Chargeback (+ penalità)",-t["sp_cb"],        note="€15 penalità per chargeback"); r += 1
    sf = GREEN_FILL if t["sp_net"] >= 0 else RED_FILL
    row_kpi(r, "NETTO SP",               t["sp_net"],        fill=sf, bold=True); r += 1

    r += 1
    sep(r, "PAYPAL", fill=PP_BLUE); r += 1
    row_kpi(r, "Lordo ricevuto",          t["pp_gross"],     note="Tutti i pagamenti incassati"); r += 1
    row_kpi(r, "Fee PayPal",             -t["pp_fee"],       note="Commissioni PayPal"); r += 1
    row_kpi(r, "Refund pagati",          -t["pp_refund"],    note="Rimborsi clienti"); r += 1
    row_kpi(r, "Dispute (+ penalità)",   -t["pp_dispute"],   note="€28 penalità per dispute"); r += 1
    pf = GREEN_FILL if t["pp_net"] >= 0 else RED_FILL
    row_kpi(r, "NETTO PP",               t["pp_net"],        fill=pf, bold=True); r += 1
    row_kpi(r, "PP Hold 15% (bloccato)", t["pp_hold"],       fill=YELLOW_FILL,
            note="Non è un costo — sbloccato ~30gg"); r += 1

    r += 1
    sep(r, "TOTALI SETTIMANA"); r += 1
    row_kpi(r, "Totale Entrato",          t["total_in"],     fill=LIGHT_BLUE, bold=True); r += 1
    row_kpi(r, "Totale Uscite",          -t["total_out"],    fill=ORANGE_FILL, bold=True); r += 1

    # Final NET row — big
    for col in range(1, 4):
        ws.cell(r, col).fill   = DARK_BLUE
        ws.cell(r, col).border = CELL_BRD
    c1 = ws.cell(r, 1, "NETTO CASSA SETTIMANA")
    c1.font      = Font(name="Arial", bold=True, size=13, color="FFFFFF")
    c1.fill      = DARK_BLUE
    c1.alignment = Alignment(horizontal="left", vertical="center")
    c2 = ws.cell(r, 2, t["net_cassa"])
    c2.number_format = FMT_EUR
    c2.font      = Font(name="Arial", bold=True, size=13, color="FFFFFF")
    c2.fill      = DARK_BLUE
    c2.alignment = Alignment(horizontal="right", vertical="center")
    ws.row_dimensions[r].height = 28

    r += 2
    ws.merge_cells(f"A{r}:C{r}")
    c = ws.cell(r, 1,
        "📌  Il Netto Cassa NON include ancora i Costi Fissi. "
        "Compilare il tab 💸 Costi Fissi e sottrarre il totale manualmente.")
    c.font      = Font(name="Arial", size=9, italic=True, color="888888")
    c.alignment = Alignment(wrap_text=True, horizontal="left")
    ws.row_dimensions[r].height = 28


# ── Main entry point ──────────────────────────────────────────────────────────

def generate_accounting_report(
    sp_csv_path: Optional[str],
    pp_csv_path: Optional[str],
    config: dict,
    week_start: date,
    week_end: date,
    output_path: str,
) -> str:
    """
    Generates the unified weekly accounting Excel.
    Returns the output file path.
    """
    label       = f"{week_start.strftime('%d/%m')}–{week_end.strftime('%d/%m/%Y')}"
    fin         = config.get("finance", {})
    pp_reserve  = fin.get("paypal_reserve_pct",   0.15)
    cb_penalty  = fin.get("chargeback_penalty_sp", 15.0)
    dispute_fee = fin.get("dispute_fee_paypal",    28.0)
    shop_id     = str(fin.get("paypal_shop_id",    "90660110676"))

    _EMPTY_SP = pd.DataFrame(columns=["_date","type","amount","fee","net",
                                       "order","method","card_brand",
                                       "pres_currency","pres_amount"])
    _EMPTY_PP = pd.DataFrame(columns=["_date","type","gross","fee","net",
                                       "currency","name","txn_id","status"])

    # Parse Shopify Payments CSV
    if sp_csv_path and os.path.exists(sp_csv_path):
        sp_df = _parse_sp_csv(sp_csv_path)
        sp_df = sp_df[(sp_df["_date"] >= week_start) &
                      (sp_df["_date"] <= week_end)].copy()
        print(f"[Accounting] ✅ SP CSV: {len(sp_df)} righe")
    else:
        sp_df = _EMPTY_SP.copy()
        print("[Accounting] ℹ️  SP CSV non fornito — colonne SP a zero")

    # Parse PayPal CSV
    if pp_csv_path and os.path.exists(pp_csv_path):
        pp_df = _parse_pp_csv(pp_csv_path, shop_id)
        pp_df = pp_df[(pp_df["_date"] >= week_start) &
                      (pp_df["_date"] <= week_end)].copy()
        print(f"[Accounting] ✅ PP CSV: {len(pp_df)} righe")
    else:
        pp_df = _EMPTY_PP.copy()
        print("[Accounting] ℹ️  PP CSV non fornito — colonne PP a zero")

    # Build daily rows
    daily = _build_daily_accounting(
        sp_df, pp_df, week_start, week_end,
        pp_reserve_pct=pp_reserve,
        cb_penalty=cb_penalty,
        dispute_fee=dispute_fee,
    )

    # Build Excel
    wb = openpyxl.Workbook()
    wb.remove(wb.active)

    _tab_contabilita(wb.create_sheet(), daily, label)
    _tab_sp_detail(wb.create_sheet(), sp_df)
    _tab_pp_detail(wb.create_sheet(), pp_df, dispute_fee)
    _tab_costi(wb.create_sheet(), week_start, week_end)
    _tab_saldo(wb.create_sheet(), daily, label)

    wb.save(output_path)
    print(f"[Accounting] ✅ Salvato: {output_path}")
    return output_path
