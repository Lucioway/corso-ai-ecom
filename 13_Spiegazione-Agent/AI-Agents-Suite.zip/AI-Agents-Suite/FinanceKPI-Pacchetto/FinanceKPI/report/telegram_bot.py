#!/usr/bin/env python3
"""
Finance Bot — Bot Telegram DEDICATO al Finance Agent.

Bot separato da BrainAgent per evitare conflitti di polling.
Richiede un token dedicato (FINANCE_BOT_TOKEN) creato via @BotFather.

Comandi:
  /runnow [YYYY-MM-DD]   — Avvia report subito (anche prima delle 16)
  /dailyfinance [date]    — Alias di /runnow
  /status                 — Stato del bot e ultimo run
  /lastlog                — Ultime 30 righe del log dell'ultimo report
  /help                   — Lista comandi

Schedule automatico: ogni giorno alle 16:00 (Europe/Rome)

Avvio:
  python telegram_bot.py
"""

import json
import logging
import os
import subprocess
import sys
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).parent / ".env")
except ImportError:
    pass

import pytz
import requests

# ── Config ────────────────────────────────────────────────────────────────────

AGENT_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_PATH = os.path.join(AGENT_DIR, "config.json")
LOG_DIR = os.path.join(AGENT_DIR, "logs")

# Trova il Python giusto in base alla piattaforma
# Priorità: env var FINANCE_VENV_PYTHON > venv locale > Python di sistema
_env_python = os.environ.get("FINANCE_VENV_PYTHON", "")
if _env_python and os.path.isfile(_env_python):
    VENV_PYTHON = _env_python
elif sys.platform == "win32":
    _venv_win = os.path.join(AGENT_DIR, "venv", "Scripts", "python.exe")
    VENV_PYTHON = _venv_win if os.path.isfile(_venv_win) else sys.executable
else:
    # Linux: cerca venv nella home (stile agent-venvs) o nella cartella progetto
    _venv_home = os.path.expanduser("~/.agent-venvs/FinanceAgent/bin/python")
    _venv_local = os.path.join(AGENT_DIR, "venv", "bin", "python3")
    if os.path.isfile(_venv_home):
        VENV_PYTHON = _venv_home
    elif os.path.isfile(_venv_local):
        VENV_PYTHON = _venv_local
    else:
        VENV_PYTHON = sys.executable
TIMEZONE = pytz.timezone("Europe/Rome")
SCHEDULED_HOUR = 7
SCHEDULED_MINUTE = 0

with open(CONFIG_PATH, "r", encoding="utf-8") as f:
    _config = json.load(f)

# Token DEDICATO per il Finance Bot (separato da BrainAgent)
TG_TOKEN = os.environ.get("FINANCE_BOT_TOKEN", "")
if not TG_TOKEN:
    # Fallback al token condiviso (backward compat)
    TG_TOKEN = os.environ.get("TELEGRAM_BOT_TOKEN", "")
    if TG_TOKEN:
        logging.warning(
            "FINANCE_BOT_TOKEN non trovato — uso TELEGRAM_BOT_TOKEN condiviso. "
            "Crea un bot dedicato con @BotFather e imposta FINANCE_BOT_TOKEN nel .env"
        )

TG_CHAT_ID = os.environ.get("TELEGRAM_CHAT_ID", "")

# Chat IDs autorizzati (supporta più utenti)
AUTHORIZED_CHATS = set()
if TG_CHAT_ID:
    AUTHORIZED_CHATS.add(TG_CHAT_ID)
for cid in os.environ.get("FINANCE_CHAT_IDS", "").split(","):
    cid = cid.strip()
    if cid:
        AUTHORIZED_CHATS.add(cid)

TG_API = f"https://api.telegram.org/bot{TG_TOKEN}"

os.makedirs(LOG_DIR, exist_ok=True)

# ── State ─────────────────────────────────────────────────────────────────────

_running = False
_last_run = None
_last_run_date = None  # data dell'ultimo report processato
_offset = 0

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
)
logger = logging.getLogger("finance-bot")


def _log(msg: str):
    ts = datetime.now(TIMEZONE).strftime("%Y-%m-%d %H:%M:%S")
    line = f"[{ts}] {msg}"
    print(line, flush=True)
    log_file = os.path.join(LOG_DIR, f"bot_{datetime.now(TIMEZONE).strftime('%Y-%m-%d')}.log")
    try:
        with open(log_file, "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass


def send_tg(text: str, chat_id: str = None):
    """Send a message to a Telegram chat (default: primary chat)."""
    target = chat_id or TG_CHAT_ID
    if not TG_TOKEN or not target:
        return
    try:
        requests.post(
            f"{TG_API}/sendMessage",
            data={
                "chat_id": target,
                "text": text,
                "parse_mode": "Markdown",
                "disable_web_page_preview": "true",
            },
            timeout=10,
        )
    except Exception as e:
        _log(f"Telegram send error: {e}")


# ── Agent runner ──────────────────────────────────────────────────────────────

def run_agent(date_str: str = None, triggered_by: str = "scheduler"):
    """Run main.py and return True on success."""
    global _running, _last_run, _last_run_date

    if _running:
        send_tg("⏳ *Report già in corso...* Attendi il completamento.")
        return False

    _running = True
    target = date_str or (datetime.now(TIMEZONE) - timedelta(days=1)).strftime("%Y-%m-%d")
    _log(f"Starting agent for {target} (triggered by {triggered_by})")
    send_tg(f"🚀 *Avvio Finance Agent* per il {target}...\n_(triggered by {triggered_by})_")

    cmd = [VENV_PYTHON, os.path.join(AGENT_DIR, "main.py"), "--date", target]
    log_file = os.path.join(LOG_DIR, f"agent_{target}.log")

    # PYTHONIOENCODING per evitare errori emoji su Windows cp1252
    env = os.environ.copy()
    env["PYTHONIOENCODING"] = "utf-8"

    try:
        result = subprocess.run(
            cmd,
            cwd=AGENT_DIR,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=600,  # 10 min max
            env=env,
        )
        # Save full output to log
        with open(log_file, "w", encoding="utf-8") as f:
            f.write(result.stdout)
            if result.stderr:
                f.write("\n--- STDERR ---\n")
                f.write(result.stderr)

        if result.returncode == 0:
            _last_run = datetime.now(TIMEZONE)
            _last_run_date = target
            _log(f"Agent completed successfully for {target}")
        else:
            _log(f"Agent failed (exit {result.returncode}) for {target}")
            send_tg(f"❌ *Agent fallito* (exit {result.returncode})\nControlla log: {log_file}")

    except subprocess.TimeoutExpired:
        _log(f"Agent timed out for {target}")
        send_tg("❌ *Agent timeout* (>10 min)")
    except Exception as e:
        _log(f"Agent error: {e}")
        send_tg(f"❌ *Agent error:* {e}")
    finally:
        _running = False

    return True


# ── Telegram command handlers ────────────────────────────────────────────────

def handle_runnow(parts, chat_id):
    """Handle /runnow and /dailyfinance commands."""
    cmd_name = parts[0]
    date_arg = parts[1] if len(parts) > 1 else None

    # Validate date format if provided
    if date_arg:
        try:
            datetime.strptime(date_arg, "%Y-%m-%d")
        except ValueError:
            send_tg(f"❌ Formato data non valido: `{date_arg}`\nUsa: `{cmd_name} YYYY-MM-DD`", chat_id)
            return

    now_rome = datetime.now(TIMEZONE)
    if now_rome.hour < SCHEDULED_HOUR:
        send_tg(
            f"⏰ *Avvio anticipato* (sono le {now_rome.strftime('%H:%M')}, "
            f"prima delle {SCHEDULED_HOUR:02d}:00)\n"
            f"Il report verrà generato ora.",
            chat_id,
        )

    threading.Thread(
        target=run_agent,
        args=(date_arg, f"Telegram {cmd_name}"),
        daemon=True,
    ).start()


def handle_status(chat_id: str):
    """Handle /status command."""
    now = datetime.now(TIMEZONE).strftime("%d/%m/%Y %H:%M")
    last = _last_run.strftime("%d/%m/%Y %H:%M") if _last_run else "mai"
    last_date = _last_run_date or "—"
    status = "🔄 In esecuzione..." if _running else "✅ Idle"

    send_tg(
        f"📡 *Finance Bot*\n"
        f"Stato: {status}\n"
        f"Ultimo run: {last} (data: {last_date})\n"
        f"Prossimo scheduled: ogni giorno alle {SCHEDULED_HOUR:02d}:{SCHEDULED_MINUTE:02d}\n"
        f"Ora: {now}",
        chat_id,
    )


def handle_lastlog(chat_id: str):
    """Handle /lastlog — mostra ultime righe del log dell'ultimo agent run."""
    # Trova il log più recente
    try:
        log_files = sorted(
            [f for f in os.listdir(LOG_DIR) if f.startswith("agent_") and f.endswith(".log")],
            reverse=True,
        )
    except Exception:
        log_files = []

    if not log_files:
        send_tg("ℹ️ Nessun log agent trovato.", chat_id)
        return

    log_path = os.path.join(LOG_DIR, log_files[0])
    try:
        with open(log_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        tail = lines[-30:] if len(lines) > 30 else lines
        text = f"📄 *Log:* `{log_files[0]}`\n```\n{''.join(tail)}```"
        # Telegram max message length is 4096
        if len(text) > 4000:
            text = text[:3990] + "...```"
        send_tg(text, chat_id)
    except Exception as e:
        send_tg(f"❌ Errore lettura log: {e}", chat_id)


def handle_help(chat_id: str):
    """Handle /help command."""
    send_tg(
        "💰 *Finance Bot*\n\n"
        "*Comandi:*\n"
        "/runnow — Avvia report subito (anche prima delle 16)\n"
        "/runnow 2026-04-07 — Report per data specifica\n"
        "/dailyfinance — Alias di /runnow\n"
        "/status — Stato del bot e ultimo run\n"
        "/lastlog — Ultime righe del log agent\n"
        "/help — Questo messaggio\n\n"
        f"⏰ *Schedule:* ogni giorno alle {SCHEDULED_HOUR:02d}:{SCHEDULED_MINUTE:02d}",
        chat_id,
    )


# ── Telegram polling ─────────────────────────────────────────────────────────

def poll_telegram():
    """Poll for new Telegram messages and handle commands."""
    global _offset

    try:
        resp = requests.get(
            f"{TG_API}/getUpdates",
            params={"offset": _offset, "timeout": 30},
            timeout=35,
        )
        data = resp.json()
    except Exception as e:
        logger.debug("Polling error: %s", e)
        return

    if not data.get("ok"):
        return

    for update in data.get("result", []):
        _offset = update["update_id"] + 1
        msg = update.get("message", {})
        text = msg.get("text", "").strip()
        chat_id = str(msg.get("chat", {}).get("id", ""))

        # Solo chat autorizzate
        if chat_id not in AUTHORIZED_CHATS:
            continue

        if not text.startswith("/"):
            continue

        parts = text.split()
        cmd = parts[0].lower()

        # Rimuovi @bot_username se presente (es. /runnow@your_finance_bot)
        if "@" in cmd:
            cmd = cmd.split("@")[0]

        if cmd in ("/runnow", "/dailyfinance"):
            handle_runnow(parts, chat_id)
        elif cmd == "/status":
            handle_status(chat_id)
        elif cmd == "/lastlog":
            handle_lastlog(chat_id)
        elif cmd in ("/help", "/start"):
            handle_help(chat_id)


# ── Daily scheduler ──────────────────────────────────────────────────────────

_today_done = False


def check_schedule():
    """Check if it's time for the daily scheduled run."""
    global _today_done

    now = datetime.now(TIMEZONE)

    # Reset flag at midnight
    if now.hour == 0 and now.minute < 2:
        _today_done = False

    # Run at scheduled time
    if now.hour == SCHEDULED_HOUR and now.minute == SCHEDULED_MINUTE and not _today_done:
        _today_done = True
        threading.Thread(
            target=run_agent,
            args=(None, f"scheduler {SCHEDULED_HOUR:02d}:{SCHEDULED_MINUTE:02d}"),
            daemon=True,
        ).start()


# ── Main ─────────────────────────────────────────────────────────────────────

def main():
    if not TG_TOKEN:
        print("❌ FINANCE_BOT_TOKEN (o TELEGRAM_BOT_TOKEN) non configurato nel .env")
        print("   Crea un bot dedicato con @BotFather e aggiungi il token al .env:")
        print("   FINANCE_BOT_TOKEN=123456:ABC...")
        sys.exit(1)

    _log(f"Finance Bot started — scheduled daily at {SCHEDULED_HOUR:02d}:{SCHEDULED_MINUTE:02d} Europe/Rome")
    _log(f"Authorized chats: {AUTHORIZED_CHATS}")

    send_tg(
        f"💰 *Finance Bot avviato!*\n"
        f"⏰ Report automatico: ogni giorno alle {SCHEDULED_HOUR:02d}:{SCHEDULED_MINUTE:02d}\n\n"
        f"📲 /runnow — avvia subito (anche prima delle 16)\n"
        f"📲 /status — stato bot\n"
        f"📲 /help — tutti i comandi"
    )

    while True:
        try:
            poll_telegram()
            # check_schedule() disabilitato — unico trigger automatico è Windows Task Scheduler alle 00:01
        except KeyboardInterrupt:
            _log("Bot stopped by user")
            send_tg("🛑 *Finance Bot fermato.*")
            break
        except Exception as e:
            _log(f"Main loop error: {e}")
            time.sleep(5)


if __name__ == "__main__":
    main()
