#!/bin/bash
# Synology NAS legacy launcher. TODO: aggiornare path + tokens.
AGENT_DIR="${AGENT_DIR:-/volume1/Agents/FinanceDaily}"
cd "$AGENT_DIR"
export FINANCE_BOT_TOKEN=""
export TELEGRAM_BOT_TOKEN=""
export TELEGRAM_CHAT_ID=""
export FINANCE_VENV_PYTHON="$AGENT_DIR/venv/bin/python3"
export PYTHONIOENCODING=utf-8

# Kill eventuale istanza precedente
pkill -f "telegram_bot.py" 2>/dev/null
sleep 1

# Avvia
exec /volume1/Agents/finance_bot_venv/bin/python3 telegram_bot.py >> /tmp/finance_bot.log 2>&1
