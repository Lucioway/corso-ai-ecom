"""
Supplier A → Drive product cost catalog sync.

Builds an always-updated XLSX of every product variant × country combination,
with unit cost (USD) per MOQ tier + avg shipping cost per country observed
from order history.

Output:
    Drive: <root>/Catalogo_Costi/SupplierA_Product_Costs_<YYYY-MM-DD>.xlsx
    Local: ./COGS_Catalog.xlsx

Run:
    python scripts/supplier_a_catalog_sync.py [--country IT] [--no-upload]
"""
from __future__ import annotations

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

# Make project root importable
sys.path.insert(0, str(Path(__file__).parent.parent))

import openpyxl
from openpyxl.styles import Alignment, Font, PatternFill

from modules.supplier_a_cogs import SupplierACogsClient


def write_xlsx(rows: list[dict], out_path: Path, country: str):
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = f"Costi Supplier A {country}"

    headers = [
        "Nome Prodotto (Supplier A)",
        "Nome Prodotto (Sito)",
        "Quantità",
        "Costo Merce (USD)",
        "Costo Spedizione (USD)",
        "Paese",
    ]
    header_fill = PatternFill("solid", fgColor="1F3864")
    header_font = Font(name="Arial", bold=True, size=10, color="FFFFFF")
    center = Alignment(horizontal="center", vertical="center")

    for col, h in enumerate(headers, 1):
        c = ws.cell(1, col, h)
        c.fill = header_fill; c.font = header_font; c.alignment = center

    for r_idx, row in enumerate(rows, 2):
        vals = [
            row["product_name_supplier_a"],
            row["product_name_site"],
            row["quantity"],
            row["cost_usd"],
            row["shipping_usd"],
            row["country"],
        ]
        for col, v in enumerate(vals, 1):
            ws.cell(r_idx, col, v)

    widths = [60, 32, 10, 18, 22, 10]
    for col, w in enumerate(widths, 1):
        ws.column_dimensions[openpyxl.utils.get_column_letter(col)].width = w

    # Freeze header
    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    # Footer note
    note_row = len(rows) + 3
    note = ws.cell(note_row, 1,
                   f"Generated {datetime.now():%Y-%m-%d %H:%M} from Supplier A Dropshipping. "
                   "Shipping avg derived from historical orders to this country. "
                   "Expand by re-running with --country <CC>.")
    note.font = Font(italic=True, size=9, color="666666")
    ws.merge_cells(start_row=note_row, end_row=note_row, start_column=1, end_column=len(headers))

    wb.save(out_path)


def upload_to_drive(local_path: Path, config: dict, subfolder: str = "Catalogo_Costi"):
    from modules.drive_uploader import DriveUploader, MIME_XLSX
    uploader = DriveUploader(config)
    folder_id = uploader._find_or_create_folder(subfolder, uploader.root_folder_id)
    file_meta = uploader._upload_file(
        str(local_path), local_path.name, folder_id, MIME_XLSX
    )
    return file_meta.get("webViewLink", "")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--country", default="IT", help="Target country code (default IT)")
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--no-upload", action="store_true", help="Skip Drive upload")
    parser.add_argument("--out", default="COGS_Catalog.xlsx")
    args = parser.parse_args()

    cfg = json.loads(Path(args.config).read_text())
    cfg.setdefault("supplier_a", cfg.get("supplier_b", {})).setdefault("enabled", True)

    print(f"📦 Supplier A Catalog Sync — country={args.country}")
    client = SupplierACogsClient(cfg)
    client.refresh_orders(use_cache_hours=cfg.get("supplier_a", {}).get("cache_hours", 0.5))
    rows = client.build_catalog_rows(target_country=args.country)
    print(f"   Built {len(rows)} catalog rows ({len(set(r['product_name_site'] for r in rows))} unique products)")

    out_path = Path(args.out)
    write_xlsx(rows, out_path, args.country)
    print(f"   ✅ Wrote {out_path}")

    if not args.no_upload:
        try:
            link = upload_to_drive(out_path, cfg)
            print(f"   ☁️ Uploaded to Drive: {link}")
        except Exception as e:
            print(f"   ⚠️ Drive upload failed: {e}")


if __name__ == "__main__":
    main()
