#!/usr/bin/env python3
"""
Finance Agent (Orchestratore principale)

Uso:
  python main.py                              # Processa ieri
  python main.py --date 2026-03-21            # Data specifica
  python main.py --supplier-csv fornitore.csv # CSV giornaliero fornitore
  python main.py --week                       # Genera anche i report settimanali
  python main.py --week-only --sp-csv sp.csv --pp-csv pp.csv
  python main.py --date 2026-03-21 --week --supplier-csv fornitore.csv

Output:
  <prefix>_COGS_DD_MM_YYYY.xlsx   (6 tab: Analisi, Ordini, Prodotti, Paesi, Meta...)
  Analisi_DD_MM_YYYY.html         (documento analisi)
  ShopifyPayments_<company>_DD-DDMon.xlsx  (se --sp-csv fornito)
  PayPal_<company>_DD-DDMon.xlsx           (se --pp-csv fornito)
"""
import argparse
import json
import os
import sys
import tempfile
from datetime import date, datetime, timedelta
from pathlib import Path

try:
    from dotenv import load_dotenv
    load_dotenv(Path(__file__).parent / ".env")
except ImportError:
    pass  # dotenv non installato — le env vars devono essere settate manualmente

sys.path.insert(0, str(Path(__file__).parent))
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))  # per trovare shared/

from shared.logging_config import setup_logger
logger = setup_logger("finance-agent")

from modules.shopify_client      import ShopifyClient, enrich_orders
from modules.ads_client          import TripleWhaleClient, get_meta_spend, get_tiktok_spend, get_google_spend
from modules.exchange_rates      import ExchangeRateClient
from modules.cogs_reader         import COGSReader
from modules.report_generator    import generate_daily_report, convert_orders_to_currency, compute_subscription_kpis
from modules.weekly_report       import get_week_dates, generate_weekly_reports
from modules.drive_uploader      import DriveUploader
from modules.supplier_downloader  import SupplierDownloader
import requests as _requests


# ── Config ─────────────────────────────────────────────────────────────────────

def load_config(config_path: str = "config.json") -> dict:
    with open(config_path, "r", encoding="utf-8") as f:
        return json.load(f)


def _find_supplier_csv(config: dict, target_date: date) -> str:
    """
    Cerca il CSV fornitore nella cartella 'CSV Fornitore'.

    Convenzione naming fornitore (D+1):
      Il fornitore esporta il CSV il giorno DOPO gli ordini.
      Esempio: ordini del 20/03 → file orders_20260321_all.csv (export del 21/03)

    Cerca prima il file D+1 (convenzione fornitore), poi D+0 come fallback.
    """
    folder = config.get("cogs", {}).get("supplier_csv_folder", "")
    if not folder:
        return None
    folder = os.path.expanduser(folder)
    if not os.path.isdir(folder):
        return None

    # Il fornitore esporta il CSV il giorno DOPO → cerca D+1
    next_day = target_date + timedelta(days=1)
    d1 = next_day.strftime("%Y%m%d")  # es. 20260321 per ordini del 20/03
    d0 = target_date.strftime("%Y%m%d")

    # Naming: orders_YYYYMMDD_all.csv (D+1), DD.MM.csv (D+0), ecc.
    dd_mm = target_date.strftime("%d.%m")       # es. 20.03
    dd_mm_next = next_day.strftime("%d.%m")      # es. 21.03

    candidates = [
        f"orders_{d1}_all.csv",
        f"orders_{d1}.csv",
        f"orders_{d0}_all.csv",
        f"orders_{d0}.csv",
        f"cogs_{d1}.csv",
        f"cogs_{d0}.csv",
        f"{dd_mm}.csv",           # 20.03.csv
        f"{dd_mm_next}.csv",      # 21.03.csv
    ]

    # Cerca anche file con naming generico: orders_*_YYYYMMDD_all.csv
    for name in candidates:
        path = os.path.join(folder, name)
        if os.path.exists(path):
            return path

    # Cerca pattern generico con la data nel nome
    import glob
    for pattern in [f"*{d1}*", f"*{d0}*", f"*{dd_mm}*"]:
        matches = glob.glob(os.path.join(folder, pattern))
        csv_matches = [m for m in matches if m.endswith(".csv")]
        if csv_matches:
            return csv_matches[0]

    return None


def _day_label(d: date) -> str:
    """DD_MM_YYYY — file naming label."""
    return d.strftime("%d_%m_%Y")


# ── Runner giornaliero ─────────────────────────────────────────────────────────

def run_daily(
    target_date: date,
    config: dict,
    tmp_dir: str,
    supplier_csv: str = None,
    revenue_override: float = None,
) -> dict:
    """
    Esegue il processo giornaliero completo.
    Ritorna il dict KPI (usato da run_weekly se necessario).
    """
    company = config.get("report", {}).get("company_name", "Finance Agent")
    print(f"\n{'='*62}")
    print(f"  📅 {company.upper()} FINANCE AGENT — {target_date.strftime('%d/%m/%Y')}")
    print(f"{'='*62}")

    shopify = ShopifyClient(config)
    fx      = ExchangeRateClient(config)
    cogs    = COGSReader(config)

    # ADV client: Triple Whale
    ads_client = TripleWhaleClient(config)

    # 1. CSV fornitore — cerca nell'ordine:
    #    a) argomento esplicito --supplier-csv
    #    b) API fornitore (download diretto)
    #    c) Google Drive cartella "CSV Cogs"
    #    d) cartella locale CSV Fornitore
    #    e) fallback matrice config
    if not supplier_csv:
        # Prova da API fornitore
        try:
            supplier = SupplierDownloader(config)
            if supplier.enabled:
                supplier_csv = supplier.download_cogs_csv(target_date, tmp_dir)
                # Upload to Google Drive for archiving
                try:
                    uploader = DriveUploader(config)
                    uploader.upload_cogs_csv(target_date, supplier_csv)
                except Exception as e:
                    print(f"[1/5] ⚠️  Drive upload: {e}")
        except Exception as e:
            print(f"[1/5] ⚠️  API fornitore: {e}")

    if not supplier_csv:
        # Prova da Google Drive
        try:
            uploader = DriveUploader(config)
            csv_folder = config.get("google_drive", {}).get("csv_cogs_folder_name", "CSV Cogs")
            supplier_csv = uploader.download_supplier_csv(target_date, tmp_dir, csv_folder)
        except Exception as e:
            print(f"[1/5] ⚠️  Drive CSV: {e}")

    if not supplier_csv:
        supplier_csv = _find_supplier_csv(config, target_date)

    if supplier_csv and os.path.exists(supplier_csv):
        cogs.load_supplier_csv_from_path(supplier_csv)
        print(f"[1/5] 📂 Supplier CSV: {os.path.basename(supplier_csv)}")
    else:
        print(f"[1/5] ℹ️  No supplier CSV — using config matrix.")

    # 2. Fetch Shopify orders
    print(f"\n[2/5] 🛒 Fetching Shopify orders...")
    orders = shopify.get_orders_for_date(target_date)
    print(f"      Found {len(orders)} orders")
    orders = enrich_orders(shopify, orders)
    print(f"      Enriched with transactions and refunds")

    # 3b. Enrich orders with REAL payout data (Stripe balance transactions)
    #     This gives us the actual currency the shop receives in its bank account
    #     (USD or EUR depending on Stripe's payout configuration)
    try:
        order_ids = [o.get("id") for o in orders if o.get("id")]
        payout_map = shopify.get_payout_data_for_orders(order_ids)
        matched = 0
        cur_count = {}
        for o in orders:
            pdata = payout_map.get(int(o.get("id", 0)))
            if pdata:
                o["_payout_currency"] = pdata["currency"]
                o["_payout_gross"]    = pdata["gross"]
                o["_payout_fee"]      = pdata["fee"]
                o["_payout_net"]      = pdata["net"]
                cur_count[pdata["currency"]] = cur_count.get(pdata["currency"], 0) + 1
                matched += 1
            else:
                o["_payout_currency"] = None
        cur_str = ", ".join(f"{c}:{n}" for c, n in cur_count.items()) or "—"
        print(f"      💱 Payout data: {matched}/{len(orders)} matched ({cur_str})")

        # Compute FX rate EUR→USD from real payouts (USD txs only)
        usd_txs = [o for o in orders if o.get("_payout_currency") == "USD"]
        if usd_txs:
            tot_eur = sum(float(o.get("_gross_revenue", o.get("total_price", 0)) or 0) for o in usd_txs)
            tot_usd = sum(o["_payout_gross"] for o in usd_txs)
            fx_rate = (tot_usd / tot_eur) if tot_eur > 0 else 1.0
            print(f"      💱 Implied FX rate EUR→USD: {fx_rate:.4f}")
        else:
            fx_rate = None
        config["_fx_eur_usd"] = fx_rate
    except Exception as e:
        print(f"      ⚠️  Payout enrichment error: {e}")
        config["_fx_eur_usd"] = None

    # 3. Daily COGS
    print(f"\n[3/5] 💰 Calculating COGS...")
    cogs_daily = cogs.calculate_daily_cogs(orders)
    src = cogs_daily.get("source_breakdown", {})
    print(f"      Total COGS: €{cogs_daily['total_cogs']:.2f} "
          f"({cogs_daily.get('cogs_pct', 0)*100:.1f}%)")
    if src:
        src_str = ", ".join(f"{k}:{v}" for k, v in src.items())
        print(f"      Source: {src_str}")

    # 4. ADV data (Triple Whale)
    adv_source = "Triple Whale"
    print(f"\n[4/5] 📣 Fetching ADV data from {adv_source}...")
    tw_data = ads_client.get_daily_data(target_date)
    rep_cfg = config.get("report", {})
    cur_sym = rep_cfg.get("currency_symbol", "€")

    total_adv    = tw_data.get("spend_eur", 0)
    meta_spend   = get_meta_spend(tw_data)
    tiktok_spend = get_tiktok_spend(tw_data)
    google_spend = get_google_spend(tw_data)
    roas_attr    = tw_data.get("roas_attributed", 0)
    roas_blend   = tw_data.get("roas_blended", 0)
    print(f"      Total ADV (raw EUR):  €{total_adv:.2f}")
    print(f"      Meta: €{meta_spend:.2f}  |  TikTok: €{tiktok_spend:.2f}"
          + (f"  |  Google: €{google_spend:.2f}" if google_spend > 0 else ""))
    print(f"      ROAS Attr: {roas_attr:.2f}x  |  ROAS Blend: {roas_blend:.2f}x")

    # 5b. Returns processed today (from any order, for Shopify Total Sales)
    print(f"\n  📊 Fetching returns processed on {target_date.strftime('%d/%m')}...")
    daily_returns = {}
    try:
        daily_returns = shopify.get_daily_returns_graphql(target_date)
        n_ret = daily_returns.get("refund_count", 0)
        tot_ret = daily_returns.get("total_refunded", 0)
        if n_ret > 0:
            print(f"      {n_ret} returns for €{tot_ret:.2f}")
        else:
            print(f"      No returns processed")
    except Exception as e:
        print(f"      ⚠️  Error fetching returns: {e}")

    # 5c. Fetch exact Total Sales from Shopify Analytics (ShopifyQL)
    if not revenue_override:
        print(f"\n  📊 Fetching Total Sales from Shopify Analytics...")
        try:
            analytics_total = shopify.get_total_sales_analytics(target_date)
            if analytics_total is not None and analytics_total > 0:
                revenue_override = analytics_total
                print(f"      ✅ Total Sales (Analytics): €{analytics_total:,.2f}")
            else:
                print(f"      ⚠️  Analytics returned no data — using order sum")
        except Exception as e:
            print(f"      ⚠️  Analytics error: {e} — using order sum")

    # 5d. Currency conversion EUR → USD (after all EUR data has been fetched)
    target_cur = rep_cfg.get("currency", "EUR")
    if target_cur == "USD":
        fx_rate = config.get("_fx_eur_usd") or rep_cfg.get("fx_fallback_eur_usd", 1.0)
        convert_orders_to_currency(orders, tw_data, cogs_daily, config, fx_rate)
        # Prefer SUM of real Stripe _payout_gross when every order has a USD payout
        # match (centesimo preciso, no FX rounding on revenue side).
        usd_matched = [o for o in orders if o.get("_payout_currency") == "USD" and o.get("_payout_gross")]
        if orders and len(usd_matched) == len(orders):
            sum_payout_gross = round(sum(float(o["_payout_gross"]) for o in usd_matched), 2)
            revenue_override = sum_payout_gross
            print(f"      💵 Using sum(_payout_gross) as Total Sales: ${sum_payout_gross:,.2f}")
        elif revenue_override:
            revenue_override = round(revenue_override * fx_rate, 2)
        # Re-read converted ADV values
        total_adv    = tw_data.get("spend_eur", 0)
        meta_spend   = get_meta_spend(tw_data)
        tiktok_spend = get_tiktok_spend(tw_data)
        google_spend = get_google_spend(tw_data)
        print(f"\n  💱 Converted to {target_cur} @ FX {fx_rate:.4f}")
        print(f"      Total ADV: {cur_sym}{total_adv:.2f}  |  Total Sales: {cur_sym}{revenue_override or 0:,.2f}")

    # 5e. Fetch Supplier COGS catalog (last 30 days) for the catalog tab
    supplier_catalog_orders = []
    try:
        supplier_cat = SupplierDownloader(config)
        if supplier_cat.enabled:
            from datetime import timedelta as _td
            cat_start = target_date - _td(days=30)
            print(f"\n  📚 Fetching Supplier COGS catalog ({cat_start} → {target_date})...")
            supplier_catalog_orders = supplier_cat.fetch_orders_range(cat_start, target_date)
            print(f"      ✅ {len(supplier_catalog_orders)} historical orders for catalog")
    except Exception as e:
        print(f"      ⚠️  Catalog fetch error: {e}")

    # 5. Generate report — single Excel file
    print(f"\n[5/5] 📊 Generating Excel report...")
    config["_today_total_adv"] = total_adv  # used by Subscription Analytics for CAC
    label      = _day_label(target_date)
    prefix     = (config.get("report", {}) or {}).get("file_prefix", "Report_COGS")
    excel_path = os.path.join(tmp_dir, f"{prefix}_{label}.xlsx")

    kpis = generate_daily_report(
        orders, tw_data, cogs_daily, config, target_date, excel_path,
        daily_returns=daily_returns, revenue_override=revenue_override,
        supplier_catalog_orders=supplier_catalog_orders,
    )

    # Enrich KPI with Triple Whale data
    kpis["date"]            = target_date
    kpis["total_adv"]       = total_adv
    kpis["meta_adv"]        = meta_spend
    kpis["tiktok_adv"]      = tiktok_spend
    kpis["google_adv"]      = google_spend
    kpis["purchase_value"]  = tw_data.get("purchase_value", 0)
    kpis["roas_attributed"] = roas_attr
    kpis["roas_blended"]    = roas_blend
    kpis["meta_roas"]       = tw_data.get("channels", {}).get("meta",   {}).get("roas", 0)
    kpis["tiktok_roas"]     = tw_data.get("channels", {}).get("tiktok", {}).get("roas", 0)
    kpis["tw_sessions"]     = tw_data.get("sessions", 0)

    # PayPal reserve hold (cash flow, not P&L)
    pp_gross = kpis.get("gross", 0) * config.get("finance", {}).get("paypal_share", 0.16)
    kpis["paypal_reserve_hold"] = round(
        pp_gross * config.get("finance", {}).get("paypal_reserve_pct", 0.15), 2
    )

    # ── Pubblica KPI su shared per Marketing_KB e orchestrator ──
    try:
        from shared.bridges import publish_finance_kpis
        publish_finance_kpis(
            date=target_date.isoformat() if hasattr(target_date, 'isoformat') else str(target_date),
            kpis={k: v for k, v in kpis.items() if k != "date"},
        )
    except Exception as _bridge_err:
        print(f"  [info] Bridge shared non disponibile: {_bridge_err}")

    print(f"      ✅ {os.path.basename(excel_path)}")

    # Upload to Google Drive
    print(f"\n  ☁️  Uploading to Google Drive...")
    drive_file_id = None
    drive_file_url = None
    try:
        uploader = DriveUploader(config)
        uploaded = uploader.upload_daily_report(target_date, excel_path, None)
        drive_file_id = uploaded.get("excel")
        drive_file_url = uploaded.get("excel_url")
        print(f"      ✅ Upload complete!")
    except Exception as e:
        print(f"      ⚠️  Drive error: {e}")
        print(f"      Local files in: {tmp_dir}")

    # Telegram recap
    tg_cfg_guard   = config.get("telegram", {})
    tg_token_guard = (
        tg_cfg_guard.get("token", "") or tg_cfg_guard.get("bot_token", "")
        or os.environ.get("FINANCE_BOT_TOKEN", "") or os.environ.get("TELEGRAM_BOT_TOKEN", "")
    )
    tg_chat_guard = tg_cfg_guard.get("chat_id", "") or os.environ.get("TELEGRAM_CHAT_ID", "")
    _tg_enabled = tg_cfg_guard.get("enabled", False) and tg_token_guard and tg_chat_guard
    if not _tg_enabled:
        print("  ℹ️  Telegram disabled or not configured — skipping recap.")
    try:
      if _tg_enabled:
        order_names = sorted([o.get("name", "") for o in orders if o.get("name")])
        first_order = order_names[0] if order_names else "?"
        last_order  = order_names[-1] if order_names else "?"
        net      = kpis.get("net", 0)
        net_pct  = kpis.get("net_margin_pct", 0) * 100
        icon     = "✅" if net >= 0 else "🔴"
        cogs_ok  = ""
        drive_link = drive_file_url or (f"https://drive.google.com/file/d/{drive_file_id}/view" if drive_file_id else "N/A")

        gross_val   = kpis.get("gross", 0)
        n_ord       = kpis.get("n_orders", 0)
        aov         = kpis.get("aov", 0)
        uv          = kpis.get("uv", 0)
        gm_pct      = kpis.get("gross_margin_pct", 0) * 100
        adv_pct     = (total_adv / gross_val * 100) if gross_val > 0 else 0

        # Subscription KPIs
        sub_k = compute_subscription_kpis(orders, config)
        sub_section = ""
        if sub_k["n_sub"] > 0:
            sub_section = (
                f"{'─' * 30}\n"
                f"📦 *Subscriptions*\n"
                f"   Total: {sub_k['n_sub']} ({sub_k['sub_pct']*100:.0f}% of orders)\n"
                f"   🆕 New: {sub_k['n_first']} | 🔁 Recurring: {sub_k['n_recur']}"
                + (f" | ❌ Cancelled: {sub_k['n_cancelled']}" if sub_k['n_cancelled'] else "") + "\n"
            )

        msg = (
            f"📊 *{company} Finance — {target_date.strftime('%d/%m/%Y')}*\n"
            f"Ordini: {first_order} → {last_order}\n\n"
            f"🛒 Ordini: {n_ord}\n"
            f"💰 Total Sales: {cur_sym}{gross_val:,.2f}\n"
            f"🎯 AOV: {cur_sym}{aov:,.2f}\n"
            f"📦 COGS: {cur_sym}{cogs_daily['total_cogs']:,.2f} ({cogs_daily.get('cogs_pct',0)*100:.1f}%)\n"
            f"📈 Gross Margin: {gm_pct:.1f}%\n"
            f"📣 ADV: {cur_sym}{total_adv:,.2f} ({adv_pct:.1f}%)\n"
            f"   Meta: {cur_sym}{meta_spend:,.2f} | TikTok: {cur_sym}{tiktok_spend:,.2f}"
            + (f" | Google: {cur_sym}{google_spend:,.2f}" if google_spend > 0 else "")
            + "\n"
            f"🏦 Fees: {cur_sym}{kpis.get('fees', 0):,.2f}\n"
            f"{'─' * 30}\n"
            f"{icon} *NET: {cur_sym}{net:,.2f} ({net_pct:.1f}%)*\n"
            f"💵 NET ({kpis.get('alt_currency','USD')}): {('$' if kpis.get('alt_currency')=='USD' else '€')}{kpis.get('net_alt', 0):,.2f}  (fx {kpis.get('fx_eur_usd', 0):.4f})\n"
            f"💵 Net/Ordine: {cur_sym}{uv:,.2f}\n"
            f"📊 ROAS: {roas_attr:.2f}x | BE ROAS: {kpis.get('be_roas', 0):.2f}x\n"
            f"{sub_section}\n"
            f"📎 Report completo:\n{drive_link}"
        )

        tg_cfg     = config.get("telegram", {})
        tg_token   = tg_cfg.get("bot_token", "") or os.environ.get("FINANCE_BOT_TOKEN", "") or os.environ.get("TELEGRAM_BOT_TOKEN", "")
        tg_chat_id = tg_cfg.get("chat_id", "") or os.environ.get("TELEGRAM_CHAT_ID", "")
        resp = _requests.post(
            f"https://api.telegram.org/bot{tg_token}/sendMessage",
            data={"chat_id": tg_chat_id, "text": msg, "parse_mode": "Markdown",
                  "disable_web_page_preview": "true"},
            timeout=10,
        )
        if resp.json().get("ok"):
            print(f"  📱 Telegram recap inviato! ✅")
        else:
            print(f"  📱 Telegram error: {resp.text}")
    except Exception as e:
        print(f"  ⚠️  Telegram error: {e}")

    # ── Console summary ────────────────────────────────────────────────────
    net     = kpis.get("net", 0)
    net_pct = kpis.get("net_margin_pct", 0) * 100
    uv      = kpis.get("uv", 0)
    be_roas = kpis.get("be_roas", 0)
    icon    = "✅" if net >= 0 else "🔴"

    print(f"\n{'='*62}")
    print(f"  💰 SUMMARY {target_date.strftime('%d/%m/%Y')} ({target_cur})")
    print(f"{'='*62}")
    print(f"  Orders:              {kpis.get('n_orders', 0)}")
    print(f"  Gross Orders:        {cur_sym}{kpis.get('shopify_order_revenue', 0):>12,.2f}")
    if kpis.get('daily_returns', 0) > 0:
        print(f"  Returns processed:  -{cur_sym}{kpis.get('daily_returns', 0):>12,.2f}")
    print(f"  Total Sales:         {cur_sym}{kpis.get('gross', 0):>12,.2f}")
    print(f"  Total COGS:          {cur_sym}{cogs_daily['total_cogs']:>12,.2f}  ({cogs_daily.get('cogs_pct',0)*100:.1f}%)")
    print(f"  ADV ({adv_source}):     {cur_sym}{total_adv:>12,.2f}")
    print(f"    ↳ Meta:            {cur_sym}{meta_spend:>12,.2f}")
    print(f"    ↳ TikTok:          {cur_sym}{tiktok_spend:>12,.2f}")
    if google_spend > 0:
        print(f"    ↳ Google:          {cur_sym}{google_spend:>12,.2f}")
    print(f"  Gateway Fees:        {cur_sym}{kpis.get('fees', 0):>12,.2f}")
    if kpis.get('refunds', 0) > 0:
        print(f"  Returns (in Total Sales):{cur_sym}{kpis.get('refunds', 0):>12,.2f}")
    print(f"  {'─'*44}")
    print(f"  EXACT NET:           {cur_sym}{net:>12,.2f}  ({net_pct:.1f}%) {icon}")
    _alt_cur = kpis.get('alt_currency', 'USD')
    _alt_sym = '$' if _alt_cur == 'USD' else '€'
    print(f"  EXACT NET ({_alt_cur}):     {_alt_sym}{kpis.get('net_alt', 0):>12,.2f}  (fx {kpis.get('fx_eur_usd', 0):.4f})")
    print(f"  Net per Order:       {cur_sym}{uv:>12,.2f}")
    print(f"  Net per Order ({_alt_cur}): {_alt_sym}{kpis.get('uv_alt', 0):>12,.2f}")
    print(f"  ROAS Attributed:     {roas_attr:>14.2f}x")
    print(f"  ROAS Blended:        {roas_blend:>14.2f}x")
    print(f"  BE ROAS:             {be_roas:>14.2f}x")
    print(f"{'='*62}\n")

    return kpis


# ── Runner settimanale ─────────────────────────────────────────────────────────

def run_weekly(
    week_start: date,
    week_end: date,
    config: dict,
    tmp_dir: str,
    sp_csv: str = None,
    pp_csv: str = None,
    orders: list = None,
):
    """
    Generates weekly SP + PayPal reports from CSV exports.
    """
    print(f"\n{'='*62}")
    print(f"  📅 WEEKLY REPORT — Sat {week_start.strftime('%d/%m')} → Fri {week_end.strftime('%d/%m/%Y')}")
    print(f"{'='*62}")

    if not sp_csv and not pp_csv:
        print("\n  ℹ️  No weekly CSV provided.")
        print("     Use --sp-csv <file.csv> for Shopify Payments")
        print("     Use --pp-csv <file.csv> for PayPal")
        return

    if orders is None:
        # Fetch week orders for EUR PayPal conversion
        shopify = ShopifyClient(config)
        print(f"\n[1/3] 🛒 Fetching week orders (for PP currency conversion)...")
        orders = shopify.get_orders_range(week_start, week_end)
        orders = enrich_orders(shopify, orders)
        print(f"      Found {len(orders)} orders")

    print(f"\n[2/3] 📊 Generating weekly reports...")
    sp_path, pp_path = generate_weekly_reports(
        sp_csv, pp_csv, orders, config, week_start, week_end, tmp_dir
    )

    print(f"\n[3/3] ☁️  Uploading to Google Drive...")
    try:
        uploader = DriveUploader(config)
        uploader.upload_weekly_reports(week_start, week_end, sp_path, pp_path)
        print(f"      ✅ Upload complete!")
    except Exception as e:
        print(f"      ⚠️  Drive error: {e}")

    if sp_path:
        print(f"\n  ✅ SP: {os.path.basename(sp_path)}")
    if pp_path:
        print(f"  ✅ PP: {os.path.basename(pp_path)}")
    print(f"{'='*62}\n")


# ── Entry point ────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Finance Agent — Report Shopify + Triple Whale ADV",
        formatter_class=argparse.RawTextHelpFormatter
    )
    parser.add_argument("--date",          type=str,
                        help="Date to process (YYYY-MM-DD). Default: yesterday")
    parser.add_argument("--supplier-csv",  type=str, dest="supplier_csv",
                        help="Path to daily supplier CSV (fornitore)")
    parser.add_argument("--week",          action="store_true",
                        help="Also generate weekly SP + PP reports")
    parser.add_argument("--week-only",     action="store_true",
                        help="Weekly reports only (no daily)")
    parser.add_argument("--sp-csv",        type=str, dest="sp_csv",
                        help="Shopify Payments CSV export (for weekly report)")
    parser.add_argument("--pp-csv",        type=str, dest="pp_csv",
                        help="PayPal CSV export (for weekly report)")
    parser.add_argument("--revenue",       type=float, dest="revenue_override",
                        help="Revenue override: exact Total Sales from Shopify dashboard (€)")
    parser.add_argument("--config",        type=str, default="config.json",
                        help="Path to config file (default: config.json)")
    args = parser.parse_args()

    # ── Carica config ──────────────────────────────────────────────────────────
    config_path = args.config
    if not os.path.exists(config_path):
        print(f"❌ Config file not found: {config_path}")
        print("   Make sure you are in the FinanceAgent/ folder and config.json exists.")
        sys.exit(1)

    config = load_config(config_path)
    config_dir = os.path.dirname(os.path.abspath(config_path))
    os.chdir(config_dir)

    # Validate Triple Whale key
    tw_key = config.get("triple_whale", {}).get("api_key", "")
    if tw_key in ("", "TW_API_KEY"):
        print("⚠️  Triple Whale API key not configured — ADV data will not be available.\n")

    # ── Data target ────────────────────────────────────────────────────────────
    target_date = (
        datetime.strptime(args.date, "%Y-%m-%d").date()
        if args.date
        else date.today() - timedelta(days=1)
    )

    # Cartella temporanea per generare i file prima dell'upload su Drive
    tmp_dir = tempfile.mkdtemp(prefix="finance_report_")

    week_start, week_end = get_week_dates(target_date)

    # ── Supplier CSV: explicit argument (Supplier/Drive fallback inside run_daily) ──
    supplier_csv = args.supplier_csv

    # ── Run daily ──────────────────────────────────────────────────────────────
    daily_orders = None
    if not args.week_only:
        kpis = run_daily(
            target_date, config, tmp_dir,
            supplier_csv=supplier_csv,
            revenue_override=args.revenue_override,
        )
        daily_orders = None  # ordini già processati internamente

    # ── Run weekly ─────────────────────────────────────────────────────────────
    # Automatico ogni venerdì (giorno fine settimana), oppure con --week / --week-only
    is_friday = (target_date.weekday() == 4)
    if args.week or args.week_only or (is_friday and (args.sp_csv or args.pp_csv)):
        run_weekly(
            week_start, week_end, config, tmp_dir,
            sp_csv=args.sp_csv,
            pp_csv=args.pp_csv,
        )

    # Pulizia cartella temporanea (i file sono già su Drive)
    import shutil
    try:
        shutil.rmtree(tmp_dir)
        print(f"  ☁️  Report caricati su Google Drive. Cartella temp rimossa.")
    except Exception as e:
        print(f"  ⚠️  Temp dir non rimossa: {tmp_dir} — {e}")


if __name__ == "__main__":
    main()
