#!/bin/bash
# Synology NAS launcher. Aggiornare path + tokens prima del deploy NAS.
AGENT_DIR="${AGENT_DIR:-/volume1/Agents/FinanceDaily}"
cd "$AGENT_DIR"
rm -f .telegram_bot.lock
# TODO: creare bot Telegram dedicato e sostituire i token (sotto sono placeholder).
export FINANCE_BOT_TOKEN=""
export TELEGRAM_BOT_TOKEN=""
export TELEGRAM_CHAT_ID=""
export FINANCE_VENV_PYTHON="$AGENT_DIR/venv/bin/python3"
export PYTHONIOENCODING=utf-8
setsid "$AGENT_DIR/venv/bin/python3" telegram_bot.py >> logs/bot_nohup.log 2>&1 < /dev/null &
echo "PID: $!"
sleep 2
ps -p $! > /dev/null 2>&1 && echo "BOT_RUNNING" || echo "BOT_FAILED"
