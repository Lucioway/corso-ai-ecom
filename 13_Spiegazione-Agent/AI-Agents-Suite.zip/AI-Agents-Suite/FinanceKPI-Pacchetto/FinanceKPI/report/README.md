# Finance Daily Report

Genera report finanziari giornalieri e settimanali per il tuo store Shopify, combinando dati Shopify (ordini, transazioni, resi), Triple Whale (ADV Meta/TikTok/Google), COGS da fornitore e tassi di cambio. Output: Excel multi-tab caricato su Google Drive con notifica Telegram.

## TODO prima del primo run
- [ ] Compilare `google_drive.root_folder_id` (cartella Drive di destinazione)
- [ ] Creare un bot Telegram dedicato + chat_id → `config.json` `telegram.*`
- [ ] Inserire `google_service_account.json` + `oauth_credentials.json` (Drive)
- [ ] `python -m venv venv && source venv/bin/activate && pip install -r requirements.txt`
- [ ] Se serve PayPal: settare `finance.paypal_shop_id` se condivide account
- [ ] Configurare la matrice COGS in `config.json` (`cogs.matrix`)

## Setup

1. Crea virtual environment e installa dipendenze:
   ```bash
   python -m venv .venv
   .venv\Scripts\activate  # Windows
   pip install -r requirements.txt
   ```

2. Configura credenziali:
   ```bash
   cp config.example.json config.json
   # Compila shopify, triple_whale, google_drive, supplier in config.json
   ```

3. Scarica `google_service_account.json` da Google Cloud Console e mettilo nella cartella.

## Uso

```bash
python main.py                                # Report di ieri
python main.py --date 2026-03-21              # Report per data specifica
python main.py --supplier-csv fornitore.csv   # CSV fornitore esplicito
python main.py --week                         # Giornaliero + report settimanale
python main.py --week-only --sp-csv sp.csv    # Solo report settimanale Shopify Payments
python main.py --revenue 12500.00             # Override Total Sales manuale
```

## Configurazione (config.json)

| Sezione | Descrizione | Obbligatoria |
|---------|-------------|:------------:|
| `shopify` | shop_url, api_key, api_password | Si |
| `triple_whale` | api_key, shop_url | Si |
| `google_drive` | credentials_file, root_folder_id | Si |
| `cogs` | Matrice COGS, supplier_csv_folder | Si |
| `supplier` | Credenziali Supplier per download CSV automatico | No |
| `email_watcher` | Gmail per download CSV fornitore da email | No |

Variabili d'ambiente (opzionali, per Telegram): `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`.

## Struttura

```
report/
├── main.py                  # Entry point CLI
├── config.json              # Configurazione completa
├── config.example.json      # Template configurazione
├── modules/
│   ├── shopify_client.py    # API Shopify (ordini, resi, analytics)
│   ├── ads_client.py        # Triple Whale (ADV multi-canale)
│   ├── cogs_reader.py       # Calcolo COGS da CSV o matrice
│   ├── report_generator.py  # Genera Excel giornaliero
│   ├── weekly_report.py     # Report settimanale SP/PayPal
│   ├── drive_uploader.py    # Upload Google Drive
│   ├── exchange_rates.py    # Tassi di cambio EUR
│   ├── supplier_downloader.py # Download CSV da Supplier
│   ├── email_watcher.py     # Download CSV da Gmail
│   └── quotes_checker.py    # Verifica prezzi fornitore
└── Quotes/                  # File listino fornitore
```
