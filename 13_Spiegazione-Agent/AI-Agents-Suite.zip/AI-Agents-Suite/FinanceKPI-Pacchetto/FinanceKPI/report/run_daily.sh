#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  Finance Daily — Script di avvio giornaliero
#  Gira automaticamente ogni mattina alle 07:00
# ─────────────────────────────────────────────────────────────

AGENT_DIR="${AGENT_DIR:-$(cd "$(dirname "$0")" && pwd)}"
LOG_DIR="$AGENT_DIR/logs"
LOG_FILE="$LOG_DIR/agent_$(date +%Y-%m-%d).log"
INPUT_FILE="$AGENT_DIR/daily_input.json"

mkdir -p "$LOG_DIR"

echo "========================================" >> "$LOG_FILE"
echo "  Finance Daily" >> "$LOG_FILE"
echo "  $(date '+%d/%m/%Y %H:%M:%S')" >> "$LOG_FILE"
echo "========================================" >> "$LOG_FILE"

# Leggi daily_input.json
SUPPLIER_CSV=$(python3 -c "import json; d=json.load(open('$INPUT_FILE')); print(d.get('supplier_csv', ''))" 2>/dev/null || echo "")

echo "Supplier CSV:  $SUPPLIER_CSV" >> "$LOG_FILE"
echo "" >> "$LOG_FILE"

cd "$AGENT_DIR"

# Costruisci il comando
CMD="python3 main.py"
if [ -n "$SUPPLIER_CSV" ] && [ -f "$SUPPLIER_CSV" ]; then
    CMD="$CMD --supplier-csv $SUPPLIER_CSV"
fi

# Esegui e logga
eval "$CMD" >> "$LOG_FILE" 2>&1

echo "" >> "$LOG_FILE"
echo "Completato: $(date '+%H:%M:%S')" >> "$LOG_FILE"

# Reset daily_input.json per il giorno dopo
python3 -c "
import json
with open('$INPUT_FILE', 'r') as f:
    d = json.load(f)
d['supplier_csv'] = ''
with open('$INPUT_FILE', 'w') as f:
    json.dump(d, f, indent=2)
" 2>/dev/null
