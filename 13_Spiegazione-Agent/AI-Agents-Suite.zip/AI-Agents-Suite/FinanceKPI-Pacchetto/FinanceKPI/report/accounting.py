#!/usr/bin/env python3
"""
Accounting Agent — Contabilità Settimanale Sab→Ven

Genera un Excel unificato con tutto il cash flow della settimana:
  - Entrate/uscite Shopify Payments al centesimo
  - Entrate/uscite PayPal al centesimo
  - 1 riga per giorno (Sabato→Venerdì)
  - Sezione costi fissi da compilare

Uso:
  python3 accounting.py --sp-csv shopify_payments.csv --pp-csv paypal.csv
  python3 accounting.py --date 2026-03-21 --sp-csv sp.csv --pp-csv pp.csv
  python3 accounting.py --sp-csv sp.csv              # PayPal opzionale
  python3 accounting.py --pp-csv pp.csv              # SP opzionale
"""
import argparse
import json
import os
import sys
from datetime import date, datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from modules.weekly_report import get_week_dates, _week_label
from modules.accounting_weekly import generate_accounting_report
from modules.drive_uploader import DriveUploader


def load_config(path: str = "config.json") -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def main():
    parser = argparse.ArgumentParser(
        description="Accounting Agent — Contabilità Settimanale",
        formatter_class=argparse.RawTextHelpFormatter,
    )
    parser.add_argument(
        "--date",     type=str,
        help="Qualsiasi data della settimana (YYYY-MM-DD). Default: settimana corrente")
    parser.add_argument(
        "--sp-csv",   type=str, dest="sp_csv",
        help="CSV Shopify Payments  (Admin → Finances → Payouts → Export)")
    parser.add_argument(
        "--pp-csv",   type=str, dest="pp_csv",
        help="CSV PayPal            (PayPal Business → Reports → Activity Download)")
    parser.add_argument(
        "--no-drive", action="store_true",
        help="Non caricare su Google Drive")
    parser.add_argument(
        "--config",   type=str, default="config.json",
        help="Percorso config file (default: config.json)")
    args = parser.parse_args()

    # Config
    config     = load_config(args.config)
    config_dir = os.path.dirname(os.path.abspath(args.config))
    os.chdir(config_dir)

    # Week dates
    ref_date   = (datetime.strptime(args.date, "%Y-%m-%d").date()
                  if args.date else date.today())
    week_start, week_end = get_week_dates(ref_date)
    label      = _week_label(week_start, week_end)

    print(f"\n{'='*62}")
    print(f"  📒 ACCOUNTING AGENT")
    print(f"  Settimana: Sab {week_start.strftime('%d/%m')} → "
          f"Ven {week_end.strftime('%d/%m/%Y')}")
    if not args.sp_csv and not args.pp_csv:
        print("\n  ⚠️  Nessun CSV fornito. Specifica almeno uno tra:")
        print("     --sp-csv <file>   Shopify Payments CSV")
        print("     --pp-csv <file>   PayPal CSV")
        print(f"{'='*62}\n")
        sys.exit(1)
    print(f"{'='*62}")

    # Output path
    local_out = os.path.expanduser(
        config.get("local_output_dir", "~/Desktop/Finance Reports"))
    os.makedirs(local_out, exist_ok=True)

    filename  = f"Contabilità_Settimanale_{label}.xlsx"
    out_path  = os.path.join(local_out, filename)

    # Generate
    generate_accounting_report(
        sp_csv_path=args.sp_csv,
        pp_csv_path=args.pp_csv,
        config=config,
        week_start=week_start,
        week_end=week_end,
        output_path=out_path,
    )

    # Upload to Drive
    if not args.no_drive:
        print(f"\n  ☁️  Caricamento su Google Drive...")
        try:
            uploader    = DriveUploader(config)
            weekly_name = config.get("google_drive", {}).get(
                "weekly_folder_name", "Settimanali")
            folder_id   = uploader._find_or_create_folder(
                weekly_name, config["google_drive"]["root_folder_id"])
            uploader._upload_file(
                out_path, filename, folder_id,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
            print(f"  [Drive] ✅ Caricato: {filename}")
        except Exception as e:
            print(f"  [Drive] ⚠️  {e}")

    print(f"\n  ✅ Report: {out_path}")
    print(f"{'='*62}\n")


if __name__ == "__main__":
    main()
