#!/bin/bash
# Auto-start script for Finance Bot on Synology NAS

AGENT_DIR="${AGENT_DIR:-/volume1/Agents/FinanceDaily}"
VENV_PYTHON="$AGENT_DIR/venv/bin/python3"
LOG_FILE="$AGENT_DIR/logs/finance_bot.log"

# Setup SSH key if not already done
mkdir -p ~/.ssh
chmod 700 ~/.ssh
if [ -f "$AGENT_DIR/id_ed25519.pub" ]; then
    grep -qf "$AGENT_DIR/id_ed25519.pub" ~/.ssh/authorized_keys 2>/dev/null || cat "$AGENT_DIR/id_ed25519.pub" >> ~/.ssh/authorized_keys
    chmod 600 ~/.ssh/authorized_keys
fi

# Load environment
export PYTHONIOENCODING=utf-8
cd "$AGENT_DIR"
set -a
source "$AGENT_DIR/.env"
set +a

# Kill any existing instance
pkill -f "telegram_bot.py" 2>/dev/null
sleep 1

# Check venv python
if [ ! -f "$VENV_PYTHON" ]; then
    echo "$(date): venv python not found at $VENV_PYTHON" >> "$LOG_FILE"
    # Try system python
    VENV_PYTHON=$(which python3)
fi

# Start bot
mkdir -p "$AGENT_DIR/logs"
echo "$(date): Starting Finance Bot..." >> "$LOG_FILE"
nohup "$VENV_PYTHON" "$AGENT_DIR/telegram_bot.py" >> "$LOG_FILE" 2>&1 &
echo "$(date): Finance Bot started with PID $!" >> "$LOG_FILE"