# Finance Agent — Guida al Setup

## 1. Installa le dipendenze

```bash
cd FinanceAgent
pip install -r requirements.txt
```

---

## 2. Configura le credenziali API

Apri `config.json` e compila tutti i campi:

### Shopify
- Vai su: Shopify Admin → Impostazioni → App e canali di vendita → Sviluppa app
- Crea una nuova app privata con permessi: `read_orders`, `read_products`, `read_customers`
- Copia `API access token` → incolla in `shopify.api_password`
- `shop_url`: es. `tuo-negozio.myshopify.com`

### Triple Whale (fonte dati ADV unificata — sostituisce Meta + TikTok separati)

Triple Whale aggrega automaticamente la spesa e i dati di attribution da **tutti i canali ADV connessi** (Meta, TikTok, Google, ecc.) con una singola API key. Non devi configurare Meta e TikTok separatamente.

**Vantaggi rispetto alle API singole:**
- ROAS Attributed (pixel-based, post-iOS14 accuracy) + ROAS Blended in un'unica chiamata
- Deduplicazione cross-channel automatica
- Breakdown per canale (Meta, TikTok, Google, altri)
- Una sola credenziale da gestire

**Come ottenere la API key:**
1. Vai su [Triple Whale](https://app.triplewhale.com) → **Settings** → **Integrations** → **API**
2. Clicca **Create API Key**
3. Seleziona gli scope: `Summary Page: Read` e `Pixel Attribution: Read`
4. Copia la key → incolla in `triple_whale.api_key`
5. `shop_url`: deve essere identico allo Shopify shop URL collegato a Triple Whale (es. `tuo-negozio.myshopify.com`)

> ⚠️ Assicurati che Meta Ads e TikTok Ads siano già connessi a Triple Whale dalla dashboard TW prima di usare l'agent.

### Google Drive (Service Account)
1. Vai su [Google Cloud Console](https://console.cloud.google.com)
2. Crea un progetto → Abilita **Google Drive API**
3. IAM → Crea service account → Scarica JSON → rinomina `google_service_account.json`
4. Metti il file `google_service_account.json` nella cartella `FinanceAgent/`
5. Crea una cartella su Google Drive → tasto destro → "Condividi" → inserisci l'email del service account
6. Copia l'ID della cartella dall'URL → incolla in `google_drive.root_folder_id`

---

## 3. Aggiungi il file prezzi fornitore

Crea/copia il file `fornitori_prezzi.xlsx` nella cartella `FinanceAgent/`.

Il file deve avere queste colonne:
| SKU | Prodotto | Costo_EUR |
|-----|----------|-----------|
| SKU001 | Nome Prodotto | 12.50 |

> I nomi colonne sono configurabili in `config.json` → sezione `cogs`.

---

## 4. Uso manuale

```bash
# Report di ieri (default)
python main.py

# Report di una data specifica
python main.py --date 2025-03-21

# Report giornaliero + settimanale
python main.py --week

# Solo report settimanale
python main.py --week-only

# Data specifica + settimanale
python main.py --date 2025-03-21 --week
```

---

## 5. Automazione

Il task `finance-agent-daily` è già configurato e girerà automaticamente **ogni giorno alle 7:00**.

Il report settimanale (Sabato→Venerdì) viene generato **ogni venerdì mattina** in automatico.

Per avviarlo manualmente: sezione **Scheduled** nella sidebar di Claude.

---

## Output generato

Per ogni giorno:
- `Report_Giornaliero_YYYY-MM-DD.xlsx` (6 fogli)
  - 💰 P&L Summary
  - 📦 Ordini (dettaglio per ordine con lordo, fee, COGS, netto, valuta originale/EUR)
  - 💳 Transazioni
  - 📊 Breakdown Prodotto
  - 🌍 Breakdown Paese
  - 🔍 Confronto Fornitore vs Ordini
- `Analisi_YYYY-MM-DD.html` (documento analisi con KPI, punti critici/favorevoli, trend)

Per ogni settimana (Sab→Ven):
- `Report_Settimanale_W{nn}_{YYYY}.xlsx`
- `Analisi_Settimanale_W{nn}_{YYYY}.html`

Struttura Google Drive:
```
📁 [Root Folder]
├── 📁 Report Giornalieri/
│   └── 📁 2025-03/
│       └── 📁 2025-03-21/
│           ├── Report_Giornaliero_2025-03-21.xlsx
│           └── Analisi_2025-03-21.html
└── 📁 Report Settimanali/
    └── 📁 2025-W12 (Sab 15 Mar → Ven 21 Mar)/
        ├── Report_Settimanale_W12_2025.xlsx
        └── Analisi_Settimanale_W12_2025.html
```
