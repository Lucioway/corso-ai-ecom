#!/bin/bash
# ─────────────────────────────────────────────────────────────
#  Finance Daily — Installazione Mac
#  Esegui UNA VOLTA dal terminale:
#    cd <repo>/report
#    bash install_mac.sh
#  (Imposta AGENT_DIR sul path del tuo report/ runtime.)
# ─────────────────────────────────────────────────────────────

AGENT_DIR="${AGENT_DIR:-$(cd "$(dirname "$0")" && pwd)}"
PLIST_NAME="com.financekpi.financedaily"
PLIST_PATH="$HOME/Library/LaunchAgents/$PLIST_NAME.plist"

echo "🚀 Finance Daily — Installazione"
echo ""

# 1. Installa dipendenze Python
echo "📦 Installazione librerie Python..."
pip3 install requests openpyxl pandas google-auth google-api-python-client --quiet
echo "   ✅ Librerie installate"

# 2. Permessi script
chmod +x "$AGENT_DIR/run_daily.sh"
echo "   ✅ Permessi script impostati"

# 3. Crea cartella logs
mkdir -p "$AGENT_DIR/logs"
echo "   ✅ Cartella logs creata"

# 4. Crea launchd plist (schedule automatico 07:00)
cat > "$PLIST_PATH" << EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
  "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>$PLIST_NAME</string>

    <key>ProgramArguments</key>
    <array>
        <string>/bin/bash</string>
        <string>$AGENT_DIR/run_daily.sh</string>
    </array>

    <key>StartCalendarInterval</key>
    <dict>
        <key>Hour</key>
        <integer>7</integer>
        <key>Minute</key>
        <integer>0</integer>
    </dict>

    <key>WorkingDirectory</key>
    <string>$AGENT_DIR</string>

    <key>StandardOutPath</key>
    <string>$AGENT_DIR/logs/launchd_out.log</string>

    <key>StandardErrorPath</key>
    <string>$AGENT_DIR/logs/launchd_err.log</string>

    <key>RunAtLoad</key>
    <false/>
</dict>
</plist>
EOF

echo "   ✅ Schedule 07:00 configurato"

# 5. Carica il job
launchctl unload "$PLIST_PATH" 2>/dev/null
launchctl load "$PLIST_PATH"
echo "   ✅ Job attivato"

echo ""
echo "════════════════════════════════════════"
echo "  ✅ Installazione completata!"
echo ""
echo "  L'agent partirà automaticamente"
echo "  ogni mattina alle 07:00."
echo ""
echo "  Per un test manuale adesso:"
echo "  → bash run_daily.sh"
echo "════════════════════════════════════════"
