#!/usr/bin/env python3
"""
FINANCE-KPI — unified command engine.

One entry point for the daily P&L batch (report/) and the live dashboard (web/),
both sharing core/.  Used directly by launchd / Render and wrapped by the
/finance-kpi skill.

Usage:
  finance-kpi report [--date YYYY-MM-DD] [--week] [extra main.py args...]
  finance-kpi report-range --from YYYY-MM-DD --to YYYY-MM-DD
  finance-kpi dashboard [--port 8789]
  finance-kpi status
"""
from __future__ import annotations

import argparse
import subprocess
import sys
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent
REPORT_DIR = ROOT / "report"
WEB_DIR = ROOT / "web"
PYTHON = sys.executable


def _run(cmd: list[str], cwd: Path) -> int:
    print(f"$ {' '.join(cmd)}  (cwd={cwd.name})")
    return subprocess.call(cmd, cwd=str(cwd))


def cmd_report(args: argparse.Namespace, extra: list[str]) -> int:
    cmd = [PYTHON, "main.py"]
    if args.date:
        cmd += ["--date", args.date]
    if args.week:
        cmd += ["--week"]
    cmd += extra
    return _run(cmd, REPORT_DIR)


def cmd_report_range(args: argparse.Namespace, extra: list[str]) -> int:
    start = date.fromisoformat(args.from_)
    end = date.fromisoformat(args.to)
    if end < start:
        print("--to must be >= --from")
        return 2
    rc = 0
    d = start
    while d <= end:
        print(f"\n===== {d.isoformat()} =====")
        r = _run([PYTHON, "main.py", "--date", d.isoformat()] + extra, REPORT_DIR)
        rc = rc or r
        d += timedelta(days=1)
    return rc


def cmd_dashboard(args: argparse.Namespace, extra: list[str]) -> int:
    import os
    env_port = str(args.port)
    print(f"Starting dashboard on http://127.0.0.1:{env_port}")
    os.environ.setdefault("HOST", "127.0.0.1")
    os.environ["PORT"] = env_port
    return _run([PYTHON, "server.py"], WEB_DIR)


def cmd_status(args: argparse.Namespace, extra: list[str]) -> int:
    """Health check: Shopify auth, Supplier A, Drive creds presence."""
    import json
    sys.path.insert(0, str(ROOT))
    sys.path.insert(0, str(REPORT_DIR))
    cfg_path = REPORT_DIR / "config.notg.json"
    cfg = json.load(open(cfg_path)) if cfg_path.is_file() else {}
    ok = True

    # Shopify
    try:
        from core.shopify_client import ShopifyClient
        sc = ShopifyClient(cfg)
        tok = sc.api_password
        print(f"  Shopify auth : OK (token {tok[:8]}…)")
    except Exception as e:
        ok = False
        print(f"  Shopify auth : FAIL — {e}")

    # Drive creds
    sa = REPORT_DIR / cfg.get("google_drive", {}).get("credentials_file", "google_service_account.json")
    print(f"  Drive creds  : {'OK' if sa.is_file() else 'MISSING ' + str(sa)}")

    # Supplier A config
    supplier_a = cfg.get("supplier_a", {})
    print(f"  Supplier A config    : {'enabled' if supplier_a.get('enabled') else 'disabled'} ({supplier_a.get('email','-')})")

    print("STATUS:", "OK" if ok else "DEGRADED")
    return 0 if ok else 1


def cmd_subs(args: argparse.Namespace, extra: list[str]) -> int:
    """Scrape Shopify Subscriptions contracts via the authenticated browser."""
    import json as _json
    from collections import Counter
    sys.path.insert(0, str(ROOT))
    from core.subscriptions_scraper import ensure_session, fetch_contracts

    store = args.store
    if not store:
        cfg_path = REPORT_DIR / "config.json"
        if cfg_path.is_file():
            cfg = _json.load(open(cfg_path))
            shop_url = cfg.get("shopify", {}).get("shop_url", "")
            # shop_url is typically "my-store-1234.myshopify.com" — extract the subdomain slug
            store = shop_url.replace("https://", "").replace("http://", "").split(".")[0]
        if not store:
            print("Error: --store is required (or set shopify.shop_url in config.json).")
            print("  Example: finance-kpi subs --store my-store-1234")
            return 2

    if not ensure_session(store, force_login=args.login):
        print("✗ No admin session. Run with --login once to authenticate.")
        return 1
    rows = fetch_contracts(store)
    counts = Counter(r["status"] for r in rows)
    out = ROOT / "report" / "cache" / "subscriptions.json"
    out.parent.mkdir(parents=True, exist_ok=True)
    _json.dump(rows, open(out, "w"), ensure_ascii=False, indent=1)
    print(f"Subscription contracts: {len(rows)}")
    for k, v in counts.most_common():
        print(f"  {k:10s} {v}")
    print(f"saved → {out}")
    return 0


def cmd_cogs_matrix(args: argparse.Namespace, extra: list[str]) -> int:
    """Compute the bundle COGS matrix (primary×accessory → avg total USD) from REAL
    fulfilled Supplier A orders and write it to config cogs.matrix. The dashboard uses
    this to ESTIMATE COGS for recent days that aren't fulfilled yet (precise days
    keep using the exact xlsx)."""
    import json as _json
    from collections import defaultdict
    sys.path.insert(0, str(ROOT))
    from core.supplier_a_cogs import SupplierACogsClient, _order_cogs_usd

    cfg_path = REPORT_DIR / "config.json"
    cfg = _json.load(open(cfg_path))
    supplier_a = SupplierACogsClient(cfg, cache_dir=str(REPORT_DIR / "cache" / "supplier_a"))
    supplier_a.refresh_orders(states=[1, 2, 3, 4], use_cache_hours=args.cache_hours)

    # Product/accessory matching keywords come from config (cogs.title_hints).
    # "primary" = the primary product, "accessory" = the secondary item/accessory.
    # Set these to lowercase substrings that appear in your supplier productName.
    hints = cfg.get("cogs", {}).get("title_hints", {})
    primary_kw = [w for w in (hints.get("primary") or "product").lower().split() if w]
    accessory_kw = [w for w in (hints.get("accessory") or "accessory").lower().split() if w]

    agg = defaultdict(lambda: {"n": 0, "tot": 0.0, "prod": 0.0, "ship": 0.0})
    for o in supplier_a._by_platform_id.values():
        if (o.get("state") or {}).get("value") != 4:
            continue
        primary = accessory = 0
        for c in o.get("commodities", []) or []:
            nm = (c.get("productName") or "").lower(); q = int(c.get("quantity", 1) or 1)
            if any(w in nm for w in primary_kw):
                primary += q
            elif any(w in nm for w in accessory_kw):
                accessory += q
        if primary == 0 and accessory == 0:
            continue
        r = _order_cogs_usd(o)
        if r["shipping_source"] != "fulfilled_settled":
            continue
        k = (primary, accessory)
        agg[k]["n"] += 1
        agg[k]["tot"] += r["total_cogs_usd"]
        agg[k]["prod"] += r["product_cost_usd"]
        agg[k]["ship"] += r["shipping_cost_usd"]

    matrix = {}
    detail = {}
    for (c, b), d in agg.items():
        if d["n"] >= args.min_n:
            n = d["n"]
            matrix[f"{c}_{b}"] = round(d["tot"] / n, 2)
            detail[f"{c}_{b}"] = {
                "primaries": c, "accessories": b, "n": n,
                "product_usd": round(d["prod"] / n, 2),
                "shipping_usd": round(d["ship"] / n, 2),
                "total_usd": round(d["tot"] / n, 2),
            }

    cfg.setdefault("cogs", {})["matrix"] = matrix
    cfg["cogs"]["matrix_detail"] = detail
    cfg["cogs"].setdefault("title_hints", {"primary": "product", "accessory": "accessory"})
    cfg["cogs"]["_matrix_source"] = "fulfilled_settled_avg (cli cogs-matrix)"
    _json.dump(cfg, open(cfg_path, "w"), indent=2, ensure_ascii=False)
    print(f"Bundle COGS matrix (USD, from fulfilled, min_n={args.min_n}):")
    print(f"  {'combo':6s} {'n':>4s} {'prod$':>7s} {'ship$':>7s} {'tot$':>7s}")
    for k in sorted(detail, key=lambda x: tuple(int(i) for i in x.split("_"))):
        d = detail[k]
        print(f"  {k:6s} {d['n']:>4d} {d['product_usd']:>7.2f} {d['shipping_usd']:>7.2f} {d['total_usd']:>7.2f}")
    print(f"written → {cfg_path}")
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="finance-kpi", description="FinanceKPI unified engine")
    sub = p.add_subparsers(dest="command", required=True)

    pr = sub.add_parser("report", help="Generate daily report")
    pr.add_argument("--date", help="YYYY-MM-DD (default: today)")
    pr.add_argument("--week", action="store_true", help="also weekly reports")
    pr.set_defaults(func=cmd_report)

    prr = sub.add_parser("report-range", help="Generate reports for a date range")
    prr.add_argument("--from", dest="from_", required=True, help="YYYY-MM-DD")
    prr.add_argument("--to", required=True, help="YYYY-MM-DD")
    prr.set_defaults(func=cmd_report_range)

    pd = sub.add_parser("dashboard", help="Start live dashboard locally")
    pd.add_argument("--port", type=int, default=8789)
    pd.set_defaults(func=cmd_dashboard)

    ps = sub.add_parser("status", help="Auth/config health check")
    ps.set_defaults(func=cmd_status)

    psub = sub.add_parser("subs", help="Scrape subscription contracts (active/paused/cancelled)")
    psub.add_argument(
        "--store",
        default=None,
        help="Shopify admin store slug (e.g. my-store-1234). "
             "Defaults to the subdomain derived from shopify.shop_url in config.json.",
    )
    psub.add_argument("--login", action="store_true", help="force one-time visible login")
    psub.set_defaults(func=cmd_subs)

    pcm = sub.add_parser("cogs-matrix", help="Rebuild bundle COGS estimate matrix from fulfilled orders")
    pcm.add_argument("--min-n", dest="min_n", type=int, default=3, help="min fulfilled orders per combo")
    pcm.add_argument("--cache-hours", dest="cache_hours", type=float, default=0.5)
    pcm.set_defaults(func=cmd_cogs_matrix)

    return p


def main(argv: list[str] | None = None) -> int:
    parser = build_parser()
    args, extra = parser.parse_known_args(argv)
    return args.func(args, extra)


if __name__ == "__main__":
    raise SystemExit(main())
