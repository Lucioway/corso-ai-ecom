# Deploying FinanceKPI on Render

The live dashboard is a single Python web service. These steps deploy it on
[Render](https://render.com) with a persistent disk so its order/fee/refund
caches survive restarts. The repo ships a `web/render.yaml` that pre-fills most
of this — Render auto-detects it.

---

## 1. Create the web service

1. Push this repo to a Git provider Render can read (GitHub/GitLab).
2. In the Render dashboard: **New + → Web Service**, then connect the repo.
3. Set **Root Directory** to `web`.
4. Verify the auto-detected settings from `render.yaml`:

   | Field | Value |
   |---|---|
   | Runtime | Python 3 |
   | Build Command | `pip install -r requirements.txt` |
   | Start Command | `python server.py` |
   | Health Check Path | `/healthz` |
   | Instance Type | Starter (supports a persistent disk) |

The service binds to the `PORT` Render assigns automatically, on `HOST=0.0.0.0`.

---

## 2. Add the persistent disk

Under **Advanced → Add Disk** (already declared in `render.yaml`):

| Field | Value |
|---|---|
| Name | `app-data` |
| Mount Path | `/data` |
| Size | `1` GB |

This persists the cached orders, fees, and refunds across deploys. Wipe it by
clearing the disk in the Render UI.

---

## 3. Environment variables

Non-secret values are baked into `render.yaml` (`PYTHON_VERSION`, `HOST`,
`DATA_DIR=/data`, `SHOPIFY_API_VERSION`). Add the **secrets** manually in the
Render dashboard (each is `sync: false`):

| Key | What it is |
|---|---|
| `DASHBOARD_USER` | Username for the dashboard login |
| `DASHBOARD_PASS` | Password for the dashboard login |
| `DASHBOARD_SESSION_SECRET` | Random string; generate with `python3 -c "import secrets;print(secrets.token_hex(24))"` |
| `SHOPIFY_SHOP_URL` | e.g. `my-store-1234.myshopify.com` |
| `SHOPIFY_API_PASSWORD` | Shopify Admin API token (`shpat_...`) |
| `SHOPIFY_API_KEY` | Only if you use client-credentials token refresh |
| `SHOPIFY_API_SECRET` | Only if you use client-credentials token refresh |
| `TRIPLE_WHALE_API_KEY` | Optional — only if Triple Whale is enabled |
| `GOOGLE_SERVICE_ACCOUNT_JSON` | Optional — only if Drive upload is enabled |

### Config source on the cloud

On Render the service reads its config from **environment variables** (see
`core/config.py` → `load_from_env()`), so you do **not** need to upload a
`config.json`. Set the `SHOPIFY_*` vars above and the dashboard assembles the
same config it would from a file.

If you prefer to ship a file instead, commit a `config.json` (do not commit
secrets) or mount one and point `APP_CONFIG_JSON` at its path; the file wins
over env vars when present.

---

## 4. Deploy and verify

1. Click **Create Web Service**. Render clones, runs the build, then
   `python server.py`.
2. Render hits `/healthz` for the health check — expect an `ok` response.
3. Open the service URL. You'll be prompted for the dashboard login
   (`DASHBOARD_USER` / `DASHBOARD_PASS`). KPI cards populate within a minute or
   two of the first request while the order cache warms up.

`autoDeploy` is on, so each push to the connected branch redeploys.

---

## Local dev still works

After deploying, local development is unchanged — run `./setup.sh` to generate a
local `config.json` + `.env`, then `python cli.py dashboard --port 8890`.
