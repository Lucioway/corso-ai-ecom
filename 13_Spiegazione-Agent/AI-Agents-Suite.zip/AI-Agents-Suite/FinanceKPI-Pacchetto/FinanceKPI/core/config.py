"""
FINANCE KPI — unified config loader.

Single source of truth for assembling the config dict consumed by core modules
(shopify_client, supplier_a_cogs, ads_client) and the report/web runtimes.

Two assemblers, one schema:
  - load_from_file(path)  → local batch runtime (report/), reads JSON
  - load_from_env()       → cloud runtime (web/ on Render), reads env vars

`load()` auto-detects: if APP_CONFIG_JSON points to a readable file (or the
default config.json exists) it uses the file; otherwise it falls back to env.
(A legacy env-var alias is honored as a backward-compat fallback.)
Core modules never assume a source — they just receive the resulting dict.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional


def load_from_file(path: str) -> dict:
    """Assemble config dict from a JSON file (local batch runtime)."""
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def load_from_env() -> dict:
    """Assemble config dict from environment variables (Render web runtime).

    Mirrors the schema produced by the JSON files so core modules behave
    identically regardless of source.
    """
    cfg: dict = {
        "shopify": {
            "shop_url": os.environ.get("SHOPIFY_SHOP_URL", "").strip(),
            "api_key": os.environ.get("SHOPIFY_API_KEY", "").strip(),
            "api_secret": os.environ.get("SHOPIFY_API_SECRET", "").strip(),
            "api_password": os.environ.get("SHOPIFY_API_PASSWORD", "").strip(),
            "api_version": os.environ.get("SHOPIFY_API_VERSION", "2025-01"),
        },
        "triple_whale": {
            "enabled": bool(os.environ.get("TRIPLE_WHALE_API_KEY", "").strip()),
            "api_key": os.environ.get("TRIPLE_WHALE_API_KEY", "").strip(),
            "shop_url": os.environ.get("SHOPIFY_SHOP_URL", "").strip(),
            "currency": os.environ.get("REPORT_CURRENCY", "EUR"),
        },
        "supplier_a": {
            "enabled": bool(os.environ.get("SUPPLIER_A_EMAIL", "").strip()),
            "email": os.environ.get("SUPPLIER_A_EMAIL", "").strip(),
            "password": os.environ.get("SUPPLIER_A_PASSWORD", "").strip(),
            "base_url": os.environ.get("SUPPLIER_A_BASE_URL", "https://system.supplier-a.example.com"),
            "states_to_fetch": [
                int(s) for s in os.environ.get("SUPPLIER_A_STATES", "1,2,3").split(",") if s.strip()
            ],
            "cache_hours": float(os.environ.get("SUPPLIER_A_CACHE_HOURS", "0.5")),
        },
    }
    return cfg


def load(path: Optional[str] = None) -> dict:
    """Auto-detect source. File wins when present; otherwise env.

    Priority:
      1. explicit `path` argument
      2. $APP_CONFIG_JSON
      3. ./config.json next to the caller's cwd
      4. environment variables
    """
    candidate = (
        path
        or os.environ.get("APP_CONFIG_JSON", "").strip()
    )
    if candidate and Path(candidate).is_file():
        return load_from_file(candidate)
    default = Path("config.json")
    if default.is_file():
        return load_from_file(str(default))
    return load_from_env()
