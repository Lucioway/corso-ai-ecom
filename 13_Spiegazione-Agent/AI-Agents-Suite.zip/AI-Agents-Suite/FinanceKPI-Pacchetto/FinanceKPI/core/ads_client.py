"""
Triple Whale Client - Retrieves unified ADV metrics from Triple Whale.

Triple Whale is the single source of truth for all ADV channels (Meta, TikTok, Google, etc.).
Advantages over individual APIs:
  - Unified and deduplicated cross-channel attribution
  - Blended ROAS and Attributed ROAS in a single call
  - Spend per channel (Facebook, TikTok, Google, etc.)
  - Pixel data for accurate attribution (post-iOS14)
  - A single API key to manage instead of 2+ integrations

Endpoints used:
  - POST /api/v2/summary-page/get-data     → aggregate + per-channel metrics
  - POST /api/v2/attribution/get-orders-with-journeys-v2  → customer journey (optional)

Documentation: https://github.com/Triple-Whale/triple-whale-public-apis
"""
import requests
from datetime import date, timedelta
from typing import Optional


BASE_URL = "https://api.triplewhale.com/api/v2"

# ADV channel names returned by Triple Whale (may vary per account)
CHANNEL_FACEBOOK = "facebook"
CHANNEL_TIKTOK   = "tiktok"
CHANNEL_GOOGLE   = "google"
CHANNEL_SNAPCHAT = "snapchat"
CHANNEL_PINTEREST= "pinterest"


class TripleWhaleClient:
    """
    Client for Triple Whale API.
    Retrieves ADV spend data, ROAS, and attribution from all connected channels.
    """

    def __init__(self, config: dict):
        cfg = config.get("triple_whale", {})
        self.enabled    = bool(cfg.get("enabled", False))
        self.api_key    = cfg.get("api_key", "")
        self.shop_url   = cfg.get("shop_url", config.get("shopify", {}).get("shop_url", ""))
        self.currency   = cfg.get("currency", "EUR")
        self._headers = {
            "x-api-key": self.api_key,
            "Content-Type": "application/json",
        }

    # ── Summary Page (aggregate metrics) ──────────────────────────────────────
    def _fetch_summary(self, start_date: date, end_date: date) -> dict:
        """
        Calls the Triple Whale Summary Page endpoint.
        Returns the raw JSON response.
        """
        if not self.enabled or not self.api_key:
            # Integration disabled or no key — return empty so ADV reports as zero.
            print("[TripleWhale] ℹ️ Triple Whale disabled or no API key — ADV spend = 0.")
            return {}
        url = f"{BASE_URL}/summary-page/get-data"
        body = {
            "shopDomain": self.shop_url,
            "period": {
                "start": start_date.strftime("%Y-%m-%d"),
                "end":   end_date.strftime("%Y-%m-%d"),
            },
            "todayHour": 23,
            "currency":   self.currency,
        }
        try:
            resp = requests.post(url, json=body, headers=self._headers, timeout=30)
            resp.raise_for_status()
            return resp.json()
        except requests.HTTPError as e:
            print(f"[TripleWhale] ⚠️ HTTP Error {e.response.status_code}: {e.response.text[:200]}")
            return {}
        except Exception as e:
            print(f"[TripleWhale] ⚠️ API call error: {e}")
            return {}

    # ── Parsing metrics from response ────────────────────────────────────────
    @staticmethod
    def _metrics_to_dict(raw: dict) -> dict:
        """
        Triple Whale v2 returns 'metrics' as a LIST of objects:
          [{"metricId": "fb_ads_spend", "values": {"current": 1000.00}}, ...]
        This method converts the list into a dict {metricId: float_value}
        for direct key-based access.
        Also supports the legacy format where 'metrics' is already a dict.
        """
        raw_metrics = raw.get("metrics", raw)
        if isinstance(raw_metrics, list):
            result = {}
            for item in raw_metrics:
                if isinstance(item, dict):
                    mid = item.get("metricId", "")
                    vals = item.get("values", {})
                    if isinstance(vals, dict):
                        val = vals.get("current", vals.get("value", 0))
                    else:
                        val = vals
                    try:
                        result[mid] = float(val) if val is not None else 0.0
                    except (TypeError, ValueError):
                        result[mid] = 0.0
            return result
        elif isinstance(raw_metrics, dict):
            return raw_metrics
        return {}

    @staticmethod
    def _safe_float(data: dict, *keys) -> float:
        """Navigates a nested dict with multiple keys and returns a safe float."""
        for key in keys:
            if isinstance(data, dict):
                data = data.get(key, {})
            else:
                return 0.0
        try:
            return float(data) if data else 0.0
        except (TypeError, ValueError):
            return 0.0

    def _parse_channel_spend(self, metrics: dict) -> dict:
        """
        Extracts per-channel spend from the already-converted metrics dict.
        Uses the official Triple Whale v2 metricIds:
          fb_ads_spend, tiktok_spend, googleAdsSpend, snapchatSpend, pinterestSpend
        """
        channels = {}

        # Main channels with TW v2 metricIds
        channel_map = {
            "facebook":  ["fb_ads_spend", "facebookSpend", "metaSpend"],
            "tiktok":    ["tiktok_spend", "tiktokSpend"],
            "google":    ["ga_adCost", "googleAdsSpend", "googleSpend", "google_spend"],
            "snapchat":  ["snapchatSpend", "snapchat_spend"],
            "pinterest": ["pinterestSpend", "pinterest_spend"],
        }

        for ch_key, metric_ids in channel_map.items():
            for mid in metric_ids:
                val = metrics.get(mid, 0.0)
                if val > 0:
                    channels[ch_key] = val
                    break

        return channels

    def _parse_summary(self, raw: dict, start_date: date, end_date: date) -> dict:
        """
        Converts the raw Triple Whale response into the standard format
        used by the Finance Agent.
        Triple Whale v2 returns 'metrics' as a list of {metricId, values:{current}}.
        """
        if not raw:
            return self._empty_result(start_date, end_date)

        # Convert the metrics list into a dict {metricId: float}
        metrics = self._metrics_to_dict(raw)

        # Per-channel spend
        channels = self._parse_channel_spend(metrics)

        # Total spend: use blendedAds (all platforms) or sum of channels
        total_spend = (
            metrics.get("blendedAds", 0.0)
            or metrics.get("totalAdSpend", 0.0)
            or sum(channels.values())
        )

        # Spend for main channels
        meta_spend   = channels.get("facebook", channels.get("meta", 0.0))
        tiktok_spend = channels.get("tiktok", 0.0)
        google_spend = channels.get("google", 0.0)
        other_spend  = max(0.0, total_spend - meta_spend - tiktok_spend - google_spend)

        # Revenue
        revenue = (
            metrics.get("totalSales", 0.0)
            or metrics.get("revenue", 0.0)
            or metrics.get("totalRevenue", 0.0)
        )

        # ROAS: use official TW values
        roas_blended = (
            metrics.get("totalRoas", 0.0)
            or (revenue / total_spend if total_spend > 0 else 0.0)
        )
        roas_meta    = metrics.get("fb_ads_purchase_roas", 0.0)
        roas_tiktok  = metrics.get("tiktok_complete_payment_roas", 0.0)
        roas_attributed = roas_blended  # TW does not separate attrib/blended in the same way

        # Orders
        orders = int(metrics.get("totalOrders", 0) or 0)
        cpa    = total_spend / orders if orders > 0 else 0.0

        # Extra financial metrics
        net_profit    = metrics.get("totalNetProfit", 0.0)
        net_margin    = metrics.get("totalNetMargin", 0.0)
        gateway_costs = metrics.get("totalPaymentGatewayCosts", 0.0)
        total_refunds = metrics.get("totalRefunds", 0.0)
        aov           = metrics.get("shopifyAov", 0.0)

        # Pixel/click metrics (often not present in summary)
        impressions = int(metrics.get("impressions", 0) or 0)
        clicks      = int(metrics.get("clicks", 0) or 0)
        sessions    = int(metrics.get("sessions", 0) or 0)
        ncr         = metrics.get("newCustomerRate", 0.0)

        return {
            # Identification
            "source":     "Triple Whale",
            "start_date": start_date.strftime("%Y-%m-%d"),
            "end_date":   end_date.strftime("%Y-%m-%d"),

            # Aggregate spend
            "platform":      "Triple Whale (All Channels)",
            "spend_eur":      total_spend,
            "purchase_value": revenue,
            "purchases":      orders,

            # ROAS
            "roas":            roas_blended,
            "roas_attributed": roas_attributed,
            "roas_blended":    roas_blended,

            # CPA and clicks
            "cpa":         cpa,
            "impressions": impressions,
            "clicks":      clicks,
            "sessions":    sessions,
            "cpc":         total_spend / clicks if clicks > 0 else 0,
            "ctr":         clicks / impressions * 100 if impressions > 0 else 0,
            "ncr":         ncr,

            # Extra TW financial metrics
            "net_profit":    net_profit,
            "net_margin":    net_margin,
            "gateway_costs": gateway_costs,
            "total_refunds": total_refunds,
            "aov":           aov,

            # Per-channel breakdown
            "channels": {
                "meta":   {"platform": "Meta Ads (Facebook/Instagram)", "spend_eur": meta_spend,
                           "roas": roas_meta},
                "tiktok": {"platform": "TikTok Ads", "spend_eur": tiktok_spend,
                           "roas": roas_tiktok},
                "google": {"platform": "Google Ads", "spend_eur": google_spend,
                           "roas": 0},
                "other":  {"platform": "Other channels", "spend_eur": other_spend,
                           "roas": 0},
            },
        }

    def _empty_result(self, start_date: date, end_date: date) -> dict:
        return {
            "source": "Triple Whale",
            "start_date": start_date.strftime("%Y-%m-%d"),
            "end_date":   end_date.strftime("%Y-%m-%d"),
            "platform":   "Triple Whale (All Channels)",
            "spend_eur":  0.0, "purchase_value": 0.0, "purchases": 0,
            "roas": 0.0, "roas_attributed": 0.0, "roas_blended": 0.0,
            "cpa": 0.0, "impressions": 0, "clicks": 0, "sessions": 0,
            "cpc": 0.0, "ctr": 0.0, "ncr": 0.0,
            "channels": {
                "meta":   {"platform": "Meta Ads (Facebook/Instagram)", "spend_eur": 0.0, "roas": 0},
                "tiktok": {"platform": "TikTok Ads", "spend_eur": 0.0, "roas": 0},
                "google": {"platform": "Google Ads", "spend_eur": 0.0, "roas": 0},
                "other":  {"platform": "Other channels", "spend_eur": 0.0, "roas": 0},
            },
        }

    # ── Public API ───────────────────────────────────────────────────────────
    def get_daily_data(self, target_date: date) -> dict:
        """
        Retrieves all ADV metrics for a specific date.
        Replaces MetaAdsClient.get_daily_spend() + TikTokAdsClient.get_daily_spend().
        """
        raw = self._fetch_summary(target_date, target_date)
        result = self._parse_summary(raw, target_date, target_date)
        print(f"[TripleWhale] 📊 {target_date} — Total spend: €{result['spend_eur']:.2f} | "
              f"Revenue: €{result['purchase_value']:.2f} | ROAS: {result['roas']:.2f}x")
        return result

    def get_date_range_data(self, start_date: date, end_date: date) -> dict:
        """
        Retrieves ADV metrics for a date range (weekly report).
        Replaces MetaAdsClient.get_date_range_spend() + TikTokAdsClient.get_date_range_spend().
        """
        raw = self._fetch_summary(start_date, end_date)
        result = self._parse_summary(raw, start_date, end_date)
        days = (end_date - start_date).days + 1
        print(f"[TripleWhale] 📊 {start_date}→{end_date} ({days}d) — "
              f"Spend: €{result['spend_eur']:.2f} | Blended ROAS: {result['roas_blended']:.2f}x")
        return result

    # ── Backward compatibility: methods with legacy names ─────────────────────────────
    def get_daily_spend(self, target_date: date) -> dict:
        """Alias for backward compatibility with existing code."""
        return self.get_daily_data(target_date)

    def get_date_range_spend(self, start_date: date, end_date: date) -> dict:
        """Alias for backward compatibility with existing code."""
        return self.get_date_range_data(start_date, end_date)


# ── Helper functions for channel data access ─────────────────────────────────
def get_meta_spend(tw_data: dict) -> float:
    return tw_data.get("channels", {}).get("meta", {}).get("spend_eur", 0.0)


def get_tiktok_spend(tw_data: dict) -> float:
    return tw_data.get("channels", {}).get("tiktok", {}).get("spend_eur", 0.0)


def get_google_spend(tw_data: dict) -> float:
    return tw_data.get("channels", {}).get("google", {}).get("spend_eur", 0.0)


def get_channel_breakdown(tw_data: dict) -> list:
    """
    Returns a list of dicts for the ADV breakdown in the report.
    E.g.: [{"platform": "Meta Ads", "spend_eur": 42.5, "roas": 3.2}, ...]
    """
    channels = tw_data.get("channels", {})
    result = []
    for ch_key, ch_data in channels.items():
        spend = ch_data.get("spend_eur", 0.0)
        if spend > 0:
            result.append({
                "channel_key": ch_key,
                "platform": ch_data.get("platform", ch_key.title()),
                "spend_eur": spend,
                "roas": ch_data.get("roas", 0.0),
            })
    return sorted(result, key=lambda x: -x["spend_eur"])
