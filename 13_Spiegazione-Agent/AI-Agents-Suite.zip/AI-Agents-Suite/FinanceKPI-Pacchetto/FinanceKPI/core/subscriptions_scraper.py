"""
Shopify admin Subscriptions scraper (browser-based).

Why: native Shopify Subscriptions contracts are owned by the first-party
"Shopify Subscriptions" app and are invisible to any custom-app Admin API token
(subscriptionContracts → 0). The only authoritative source for cancellations is
the admin UI. We read it with an authenticated headless browser.

Pattern (mirrors core/supplier_a_cogs.py):
  - One-time visible login → storage_state saved to cache/shopify_admin_state.json
  - Subsequent runs reuse the session headless (real Chrome channel to pass Cloudflare)

Public API:
  ensure_session(store, headful=False) -> bool   # login if needed, save state
  fetch_contracts(store) -> list[dict]           # [{id,status,...}] (best-effort)
"""
from __future__ import annotations

import json
from pathlib import Path

CACHE = Path(__file__).resolve().parent.parent / "report" / "cache"
STATE_FILE = CACHE / "shopify_admin_state.json"
PROFILE_DIR = CACHE / "shopify_profile"          # persistent login profile
WINDOW_ARGS = ["--window-position=4000,4000", "--window-size=460,360"]


def _admin_home(store: str) -> str:
    return f"https://admin.shopify.com/store/{store}"


def _is_logged_in(url: str) -> bool:
    return url.startswith("https://admin.shopify.com/store/") and "accounts.shopify.com" not in url


def _logged_in_context(ctx) -> bool:
    """True if any open page is on the admin dashboard (not the login flow)."""
    try:
        for pg in ctx.pages:
            if _is_logged_in(pg.url):
                return True
    except Exception:
        pass
    return False


def ensure_session(store: str, timeout_login_s: int = 300, force_login: bool = False) -> bool:
    """Persistent-profile login. The profile keeps you logged in across runs, so
    the visible login is needed only the first time (or after expiry).

    headless reuse → if profile already logged in, returns True with no window.
    else opens a visible window; robust to login redirects (no crash on nav)."""
    import time
    from playwright.sync_api import sync_playwright

    PROFILE_DIR.mkdir(parents=True, exist_ok=True)

    # 1) Try the persistent profile headless
    if not force_login:
        with sync_playwright() as p:
            ctx = p.chromium.launch_persistent_context(
                str(PROFILE_DIR), headless=True, channel="chrome", args=WINDOW_ARGS)
            try:
                pg = ctx.pages[0] if ctx.pages else ctx.new_page()
                pg.goto(_admin_home(store), wait_until="domcontentloaded", timeout=60000)
                pg.wait_for_timeout(3000)
                ok = _is_logged_in(pg.url)
            except Exception:
                ok = False
            ctx.storage_state(path=str(STATE_FILE)) if ok else None
            ctx.close()
            if ok:
                return True

    # 2) Visible login in the persistent profile (login persists in the profile)
    #    Anti-automation flags so Google sign-in doesn't block ("browser not secure").
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(
            str(PROFILE_DIR), headless=False, channel="chrome",
            ignore_default_args=["--enable-automation"],
            args=["--disable-blink-features=AutomationControlled"])
        try:
            ctx.add_init_script(
                "Object.defineProperty(navigator,'webdriver',{get:()=>undefined});")
        except Exception:
            pass
        try:
            pg = ctx.pages[0] if ctx.pages else ctx.new_page()
            pg.goto(_admin_home(store), wait_until="domcontentloaded", timeout=60000)
        except Exception:
            pass
        print("\n>>> Log in to Shopify admin in the window (email + 2FA + select store).")
        print(">>> Keep the window open. Detecting when you reach the dashboard…")
        deadline = time.time() + timeout_login_s
        while time.time() < deadline:
            time.sleep(2)
            if _logged_in_context(ctx):
                time.sleep(2)
                try:
                    ctx.storage_state(path=str(STATE_FILE))
                except Exception:
                    pass
                ctx.close()
                print(f"✅ Session saved → profile + {STATE_FILE.name}")
                return True
        ctx.close()
        print("✗ Login timed out.")
        return False


CONTRACTS_URL = ("https://admin.shopify.com/store/{store}"
                 "/apps/subscriptions-remix/app/contracts")

_PARSE_JS = r"""
() => {
  const out = [];
  const rows = document.querySelectorAll('table tbody tr');
  rows.forEach(tr => {
    const cells = Array.from(tr.querySelectorAll('td,th')).map(c => c.innerText.trim());
    if (cells.length < 4) return;
    const txt = tr.innerText;
    let status = '';
    for (const s of ['Active','Paused','Canceled','Cancelled','Expired','Failed']) {
      if (txt.includes(s)) { status = s; break; }
    }
    out.push({ cells, status });
  });
  return out;
}
"""


def _app_frame(pg):
    for fr in pg.frames:
        if "shopifyapps.com" in fr.url and "subscriptions" in fr.url:
            return fr
    return None


def fetch_contracts(store: str, max_pages: int = 40) -> list[dict]:
    """Scrape the Subscriptions > Contracts admin page (all statuses, paginated).
    Returns [{contract, customer, product, price, frequency, status}].
    Runs headed but off-screen (Cloudflare blocks headless); reuses the persistent
    logged-in profile."""
    from playwright.sync_api import sync_playwright

    if not PROFILE_DIR.exists():
        raise RuntimeError("No saved session. Run ensure_session() first.")

    rows_out: list[dict] = []
    seen_ids: set[str] = set()
    with sync_playwright() as p:
        ctx = p.chromium.launch_persistent_context(
            str(PROFILE_DIR), headless=False, channel="chrome",
            ignore_default_args=["--enable-automation"],
            args=["--disable-blink-features=AutomationControlled",
                  "--window-position=5000,5000", "--window-size=500,400"])
        pg = ctx.pages[0] if ctx.pages else ctx.new_page()
        pg.set_default_timeout(25000)
        try:
            pg.goto(CONTRACTS_URL.format(store=store),
                    wait_until="domcontentloaded", timeout=45000)
        except Exception:
            pass
        pg.wait_for_timeout(9000)

        for _ in range(max_pages):
            fr = _app_frame(pg)
            if not fr:
                pg.wait_for_timeout(2000)
                fr = _app_frame(pg)
                if not fr:
                    break
            try:
                parsed = fr.evaluate(_PARSE_JS)
            except Exception:
                parsed = []
            new = 0
            for r in parsed:
                cells = r["cells"]
                cid = next((c for c in cells if c.isdigit() and len(c) >= 8), "")
                if not cid or cid in seen_ids:
                    continue
                seen_ids.add(cid)
                new += 1
                # cells: [select?, id, warning, customer, product, price, freq, status...]
                vals = [c for c in cells if c and c != "Select Contract"]
                rows_out.append({
                    "contract": cid,
                    "customer": next((c for c in vals if " " in c and not c.startswith("€")
                                      and not c[0].isdigit()), ""),
                    "product": next((c for c in vals if "rodott" in c
                                     or "roduct" in c), ""),
                    "price": next((c for c in vals if c.startswith("€")), ""),
                    "frequency": next((c for c in vals if "week" in c.lower()
                                       or "Every" in c), ""),
                    "status": r["status"],
                })
            # next page
            try:
                nxt = fr.get_by_role("button", name="Next").first
                if nxt.is_enabled():
                    nxt.click()
                    pg.wait_for_timeout(3500)
                else:
                    break
            except Exception:
                break
        ctx.close()
    return rows_out
