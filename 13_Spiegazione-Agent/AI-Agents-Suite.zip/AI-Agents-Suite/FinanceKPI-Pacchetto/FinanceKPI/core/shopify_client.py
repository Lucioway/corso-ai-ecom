"""
Shopify API Client - Extracts orders, transactions and refunds.
v2.0 — Real transaction data (fees, currency, exchange rate, payment method).
"""
import requests
from datetime import datetime, date
from typing import Optional
import time

try:
    from zoneinfo import ZoneInfo  # Python 3.9+
except ImportError:
    from backports.zoneinfo import ZoneInfo  # type: ignore

_ROME_TZ = ZoneInfo("Europe/Rome")


def _rome_day_window(target_date: date):
    """Return ISO timestamps for start/end of the given date in Europe/Rome (DST-aware)."""
    start_dt = datetime(target_date.year, target_date.month, target_date.day, 0, 0, 0, tzinfo=_ROME_TZ)
    end_dt   = datetime(target_date.year, target_date.month, target_date.day, 23, 59, 59, tzinfo=_ROME_TZ)
    return start_dt.isoformat(), end_dt.isoformat()


class ShopifyClient:
    def __init__(self, config: dict):
        cfg = config["shopify"]
        self.shop_url = cfg["shop_url"].rstrip("/")
        self.api_version = cfg.get("api_version", "2024-01")
        self.base_url = f"https://{self.shop_url}/admin/api/{self.api_version}"
        self._client_id = cfg.get("api_key", "")
        self._client_secret = cfg.get("api_secret", "")
        # New Shopify custom-app model: derive a fresh Admin API access token via
        # client_credentials grant. Falls back to a static api_password if present.
        if self._client_secret.startswith("shpss_"):
            self.api_password = self._fetch_access_token()
        else:
            self.api_password = cfg["api_password"]
        self.headers = {
            "X-Shopify-Access-Token": self.api_password,
            "Content-Type": "application/json",
        }

    def _fetch_access_token(self) -> str:
        """Exchange client_id + client_secret for a fresh Admin API access token
        (Shopify custom-app client_credentials grant)."""
        url = f"https://{self.shop_url}/admin/oauth/access_token"
        resp = requests.post(url, json={
            "client_id": self._client_id,
            "client_secret": self._client_secret,
            "grant_type": "client_credentials",
        })
        resp.raise_for_status()
        return resp.json()["access_token"]

    def _refresh_token(self) -> bool:
        """Re-derive the client_credentials token (short-lived) and update headers.
        Returns True if a refresh was possible."""
        if not (self._client_secret or "").startswith("shpss_"):
            return False
        self.api_password = self._fetch_access_token()
        self.headers["X-Shopify-Access-Token"] = self.api_password
        return True

    def _get(self, endpoint: str, params: dict = None) -> dict:
        import time
        url = f"{self.base_url}/{endpoint}"
        refreshed = False
        for attempt in range(6):
            response = requests.get(url, headers=self.headers, params=params)
            if response.status_code == 429:
                wait = float(response.headers.get("Retry-After", 2 ** attempt))
                time.sleep(max(wait, 1.0))
                continue
            if response.status_code == 401 and not refreshed and self._refresh_token():
                refreshed = True
                continue
            response.raise_for_status()
            return response.json()
        response.raise_for_status()
        return response.json()

    def _paginate(self, endpoint: str, key: str, params: dict = None) -> list:
        """Handles cursor-based pagination for Shopify."""
        results = []
        p = params.copy() if params else {}
        p["limit"] = 250
        url = f"{self.base_url}/{endpoint}"

        refreshed = False
        while url:
            response = requests.get(url, headers=self.headers, params=p)
            if response.status_code == 401 and not refreshed and self._refresh_token():
                refreshed = True
                continue
            response.raise_for_status()
            data = response.json()
            results.extend(data.get(key, []))

            link_header = response.headers.get("Link", "")
            next_url = None
            if 'rel="next"' in link_header:
                for part in link_header.split(","):
                    if 'rel="next"' in part:
                        next_url = part.strip().split(";")[0].strip("<>")
                        break
            url = next_url
            p = {}
            time.sleep(0.5)

        return results

    def get_balance_transactions(self, since_id: int = 0, limit: int = 250) -> list:
        """
        Fetch Shopify Payments balance transactions (charges, payouts, etc.).
        These contain the REAL payout currency and amount per order
        — i.e. how much USD/EUR the shop actually receives in its bank account.
        """
        try:
            params = {"limit": limit}
            if since_id:
                params["since_id"] = since_id
            data = self._get("shopify_payments/balance/transactions.json", params)
            return data.get("transactions", [])
        except Exception as e:
            print(f"[Shopify] ⚠️ balance transactions error: {e}")
            return []

    def get_payout_data_for_orders(self, order_ids: list) -> dict:
        """
        Returns a dict {order_id: {currency, gross, fee, net, processed_at}}
        with the actual Stripe payout currency and amounts for the given orders.
        Looks back through the most recent balance transactions until all
        requested orders are matched (or until pages are exhausted).
        """
        wanted = {int(oid) for oid in order_ids}
        result = {}
        # The balance/transactions endpoint returns most-recent first
        # and supports `since_id` for paging older. We page newest→oldest
        # by collecting all txs once (250) — for daily reports this is plenty.
        txs = self.get_balance_transactions(limit=250)
        for t in txs:
            if t.get("type") != "charge":
                continue
            oid = t.get("source_order_id")
            if oid is None:
                continue
            try:
                oid = int(oid)
            except (TypeError, ValueError):
                continue
            if oid in wanted and oid not in result:
                result[oid] = {
                    "currency":     t.get("currency"),
                    "gross":        float(t.get("amount", 0)),
                    "fee":          float(t.get("fee", 0)),
                    "net":          float(t.get("net", 0)),
                    "processed_at": t.get("processed_at"),
                }
        return result

    def get_orders_for_date(self, target_date: date) -> list:
        """Fetch all orders created on a specific date (Europe/Rome, DST-aware)."""
        start, end = _rome_day_window(target_date)
        params = {
            "created_at_min": start,
            "created_at_max": end,
            "status": "any",
            "financial_status": "any",
        }
        orders = self._paginate("orders.json", "orders", params)
        # Segna i draft order a €0 come rispedizioni (hanno COGS ma non revenue)
        # Una vera rispedizione ha prezzo=0 SENZA sconti applicati.
        # Gli ordini con coupon 100% hanno total_price=0 ma total_discounts>0 e vanno contati.
        for o in orders:
            o["_is_reshipment"] = (
                float(o.get("total_price", 0)) == 0
                and float(o.get("total_discounts", 0)) == 0
            )
        return orders

    def _graphql(self, query: str, variables: dict = None) -> dict:
        """Execute a GraphQL query on the Shopify Admin API."""
        url = f"https://{self.shop_url}/admin/api/{self.api_version}/graphql.json"
        payload = {"query": query}
        if variables:
            payload["variables"] = variables
        resp = requests.post(url, headers=self.headers, json=payload)
        if resp.status_code == 401 and self._refresh_token():
            resp = requests.post(url, headers=self.headers, json=payload)
        resp.raise_for_status()
        return resp.json()

    def get_fees_for_orders_graphql(self, order_ids: list) -> dict:
        """
        Fetch REAL gateway fees via GraphQL for a batch of orders.
        Returns dict {order_id: {"fee": float, "details": [...]}}

        GraphQL is the only way to get exact fees to the cent
        (REST API doesn't expose them in the transactions field).
        """
        results = {}
        # GraphQL supports max 250 nodes per query, process in batches of 50
        batch_size = 50
        for i in range(0, len(order_ids), batch_size):
            batch = order_ids[i:i + batch_size]
            # Build query with alias for each order
            fragments = []
            for idx, oid in enumerate(batch):
                gid = f"gid://shopify/Order/{oid}"
                fragments.append(f'''
                    o{idx}: node(id: "{gid}") {{
                        ... on Order {{
                            legacyResourceId
                            transactions(first: 5) {{
                                gateway
                                kind
                                status
                                amountSet {{
                                    shopMoney {{ amount currencyCode }}
                                }}
                                fees {{
                                    amount {{ amount currencyCode }}
                                    rate
                                    rateName
                                    type
                                }}
                            }}
                        }}
                    }}
                ''')

            query = "{ " + "\n".join(fragments) + " }"
            try:
                resp = self._graphql(query)
                data = resp.get("data", {})
                for key, node in data.items():
                    if not node:
                        continue
                    legacy_id = node.get("legacyResourceId")
                    if not legacy_id:
                        continue
                    oid = int(legacy_id)
                    # Find the main transaction (SALE/CAPTURE with SUCCESS)
                    for tx in node.get("transactions", []):
                        if tx["status"] == "SUCCESS" and tx["kind"] in ("SALE", "CAPTURE"):
                            fees = tx.get("fees") or []
                            tx_amount = float(
                                tx.get("amountSet", {}).get("shopMoney", {}).get("amount", 0)
                            )
                            # Use rate * tx_amount (the amounts in fees field are
                            # often aggregated per batch/payout, not per single order)
                            total_fee = round(
                                sum(float(f.get("rate", 0)) * tx_amount for f in fees), 2
                            )
                            results[oid] = {
                                "fee": total_fee,
                                "details": [
                                    {
                                        "name": f.get("rateName", ""),
                                        "amount": round(float(f.get("rate", 0)) * tx_amount, 2),
                                        "rate": float(f.get("rate", 0)),
                                        "type": f.get("type", ""),
                                    }
                                    for f in fees
                                ],
                            }
                            break
            except Exception as e:
                print(f"      ⚠️  GraphQL batch {i//batch_size + 1} error: {e}")
            time.sleep(0.5)

        return results

    def get_daily_returns_graphql(self, target_date: date) -> dict:
        """
        Find ALL refunds processed on a specific date (CET timezone),
        regardless of the original order date.
        Used to calculate the correct Shopify "Total Sales".

        Returns: {
            "total_refunded": float,   # Total EUR refunded on the day
            "refund_count": int,
            "details": [{"order_id": int, "amount": float, "created_at": str}, ...]
        }
        """
        from datetime import timedelta, datetime, timezone

        # CET = UTC+1 (before daylight saving time change in late March)
        # CEST = UTC+2 (after the change)
        # For simplicity we use UTC+1 (CET) — valid for most of the period
        cet_offset = timezone(timedelta(hours=1))
        day_start_cet = datetime(target_date.year, target_date.month, target_date.day,
                                  0, 0, 0, tzinfo=cet_offset)
        day_end_cet = datetime(target_date.year, target_date.month, target_date.day,
                                23, 59, 59, tzinfo=cet_offset)

        # Convert to UTC for GraphQL filter
        day_start_utc = day_start_cet.astimezone(timezone.utc)
        day_end_utc = day_end_cet.astimezone(timezone.utc)

        # Expand window by 2h to catch orders at timezone boundary
        search_start = (day_start_utc - timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M:%S")
        search_end = (day_end_utc + timedelta(hours=2)).strftime("%Y-%m-%dT%H:%M:%S")

        total_refunded = 0.0
        details = []
        cursor = None

        while True:
            after_clause = f', after: "{cursor}"' if cursor else ""
            query = f'''
            {{
                orders(
                    query: "updated_at:>='{search_start}' AND updated_at:<='{search_end}'"
                    first: 100
                    {after_clause}
                ) {{
                    edges {{
                        node {{
                            legacyResourceId
                            refunds {{
                                createdAt
                                totalRefundedSet {{
                                    shopMoney {{ amount currencyCode }}
                                }}
                            }}
                        }}
                        cursor
                    }}
                    pageInfo {{ hasNextPage }}
                }}
            }}
            '''

            resp = self._graphql(query)
            data = resp.get("data", {}).get("orders", {})
            edges = data.get("edges", [])

            for edge in edges:
                node = edge["node"]
                order_id = int(node.get("legacyResourceId", 0))
                for refund in node.get("refunds", []):
                    created_at = refund.get("createdAt", "")
                    # Convert createdAt (UTC with Z) to CET for comparison
                    try:
                        refund_utc = datetime.fromisoformat(created_at.replace("Z", "+00:00"))
                        refund_cet = refund_utc.astimezone(cet_offset)
                        if refund_cet.date() == target_date:
                            amount = float(
                                refund.get("totalRefundedSet", {})
                                      .get("shopMoney", {})
                                      .get("amount", 0)
                            )
                            if amount > 0:
                                total_refunded += amount
                                details.append({
                                    "order_id": order_id,
                                    "amount": amount,
                                    "created_at": created_at,
                                })
                    except (ValueError, TypeError):
                        pass

            if data.get("pageInfo", {}).get("hasNextPage") and edges:
                cursor = edges[-1]["cursor"]
            else:
                break
            time.sleep(0.5)

        return {
            "total_refunded": round(total_refunded, 2),
            "refund_count": len(details),
            "details": details,
        }

    def get_total_sales_analytics(self, target_date: date) -> Optional[float]:
        """
        Fetch the exact 'Total Sales' from Shopify Analytics via ShopifyQL.
        Requires the 'read_reports' scope on the app.
        Uses API version 2026-01 (ShopifyQL requires 2025-10+).
        Returns the Total Sales value in EUR, or None if unavailable.
        """
        date_str = target_date.strftime("%Y-%m-%d")
        shopify_ql = f"FROM sales SHOW total_sales SINCE {date_str} UNTIL {date_str}"
        query = '''
        {
            shopifyqlQuery(query: "%s") {
                tableData {
                    rows
                    columns { name dataType }
                }
                parseErrors
            }
        }
        ''' % shopify_ql

        try:
            # ShopifyQL requires API version 2025-10+
            url = f"https://{self.shop_url}/admin/api/2026-01/graphql.json"
            import json as _json
            resp = requests.post(url, headers=self.headers, json={"query": query})
            resp.raise_for_status()
            data = resp.json()

            # Check for GraphQL errors
            if "errors" in data:
                print(f"      ⚠️  ShopifyQL error: {data['errors'][0].get('message','')}")
                return None

            result = data.get("data", {}).get("shopifyqlQuery", {})

            # Check for parse errors
            errors = result.get("parseErrors", [])
            if errors:
                print(f"      ⚠️  ShopifyQL parse error: {errors}")
                return None

            rows = result.get("tableData", {}).get("rows", [])
            if rows and len(rows) > 0:
                row = rows[0]
                if isinstance(row, dict):
                    return round(float(row.get("total_sales", 0)), 2)
                elif isinstance(row, (list, str)):
                    val = row[0] if isinstance(row, list) else row
                    return round(float(val), 2)
            return None
        except Exception as e:
            print(f"      ⚠️  ShopifyQL analytics error: {e}")
            return None

    def get_transactions(self, order_id: int) -> list:
        """Fetch transactions for a specific order."""
        data = self._get(f"orders/{order_id}/transactions.json")
        return data.get("transactions", [])

    def get_refunds(self, order_id: int) -> list:
        """Fetch refunds for a specific order."""
        data = self._get(f"orders/{order_id}/refunds.json")
        return data.get("refunds", [])

    def get_orders_range(self, start_date: date, end_date: date) -> list:
        """Fetch all orders in a date range (Europe/Rome, DST-aware)."""
        start, _ = _rome_day_window(start_date)
        _, end   = _rome_day_window(end_date)
        params = {
            "created_at_min": start,
            "created_at_max": end,
            "status": "any",
            "financial_status": "any",
        }
        return self._paginate("orders.json", "orders", params)


# ── Metodo pagamento ───────────────────────────────────────────────────────────
def _detect_payment_method(transaction: dict) -> str:
    """
    Identifica il metodo di pagamento reale dalla transazione Shopify.
    Ritorna: 'Card (Visa)', 'PayPal', 'Apple Pay', 'Google Pay', 'Klarna', ecc.
    """
    gateway = (transaction.get("gateway") or "").lower()
    pd = transaction.get("payment_details") or {}
    pm_name = (pd.get("payment_method_name") or "").lower()
    wallet  = (pd.get("credit_card_wallet") or "").lower()
    cc_company = (pd.get("credit_card_company") or "").strip()

    # PayPal — può venire sia da gateway sia da payment_method_name
    if "paypal" in gateway or pm_name == "paypal":
        return "PayPal"

    # Klarna
    if "klarna" in gateway or "klarna" in pm_name or "klarna" in str(pd).lower():
        return "Klarna"

    # Bancontact / iDEAL / SOFORT
    if "bancontact" in gateway or "bancontact" in pm_name:
        return "Bancontact"
    if "ideal" in gateway or "ideal" in pm_name:
        return "iDEAL"
    if "sofort" in gateway or "sofort" in pm_name:
        return "SOFORT"

    # Wallet (Apple Pay, Google Pay) on top of Shopify Payments
    if wallet in ("apple_pay", "applepay"):
        return "Apple Pay"
    if wallet in ("google_pay", "googlepay"):
        return "Google Pay"

    # Shopify Payments (carta)
    if "shopify_payments" in gateway or gateway == "":
        if cc_company and cc_company.lower() != "unknown":
            return f"Card ({cc_company})"
        # If we have a payment_method_name like "visa", use it
        if pm_name and pm_name != "unknown":
            return f"Card ({pm_name.title()})"
        return "Card"

    # Fallback: usa il nome del gateway
    return gateway.replace("_", " ").title() if gateway else "Unknown"


def _extract_transaction_data(transactions: list) -> dict:
    """
    Estrae i dati finanziari reali dalla lista di transazioni di un ordine.

    Cerca la transazione 'sale' o 'capture' con status 'success' per ottenere:
    - Fee reale del gateway (campo 'fees' della transazione)
    - Importo nella valuta del cliente (presentment)
    - Importo in EUR (shop money)
    - Tasso di cambio
    - Metodo di pagamento effettivo

    Ritorna dict con tutti i dati della transazione principale.
    """
    result = {
        "gateway_fee": 0.0,           # Fee reale dal processore
        "gateway_fee_currency": "EUR", # Valuta della fee
        "payment_method": "Sconosciuto",
        "customer_amount": 0.0,        # Importo nella valuta del cliente
        "customer_currency": "EUR",    # Valuta del cliente
        "shop_amount": 0.0,            # Importo in EUR (shop currency)
        "shop_currency": "EUR",
        "exchange_rate": 1.0,          # Tasso di cambio applicato
        "transaction_id": None,
        "gateway_name": "",
    }

    # Trova la transazione principale: 'sale' o 'capture' con status 'success'
    main_tx = None
    for tx in transactions:
        kind = tx.get("kind", "")
        status = tx.get("status", "")
        if status == "success" and kind in ("sale", "capture"):
            main_tx = tx
            break

    if not main_tx:
        # Fallback: prendi la prima transazione success
        for tx in transactions:
            if tx.get("status") == "success":
                main_tx = tx
                break

    if not main_tx:
        return result

    result["transaction_id"] = main_tx.get("id")
    result["gateway_name"] = main_tx.get("gateway", "")
    result["payment_method"] = _detect_payment_method(main_tx)

    # ── Importo nella valuta del cliente ──
    # Shopify può avere amount in shop currency o presentment currency
    result["shop_amount"] = float(main_tx.get("amount", 0))
    result["shop_currency"] = main_tx.get("currency", "EUR")

    # Controlla receipt per dati PayPal (valuta originale)
    receipt = main_tx.get("receipt") or {}

    # Per PayPal: amount_money_set potrebbe avere dati in valuta originale
    # Per Shopify Payments: controlla exchange rate nel receipt

    # ── Exchange rate ──
    # Shopify mette l'exchange rate nel campo 'exchange_rate' o nel receipt
    # Nota: l'ordine ha 'total_price' sempre in shop currency (EUR per the shop)

    # ── Fee reali ──
    # Il campo 'fees' è disponibile nelle transazioni Shopify Payments (API 2024-01+)
    fees_list = main_tx.get("fees") or []
    total_fee = 0.0
    for fee_obj in fees_list:
        fee_amount = float(fee_obj.get("amount", 0))
        total_fee += fee_amount

    result["gateway_fee"] = total_fee

    # Se non ci sono fees nel campo 'fees', controlla receipt per PayPal
    if total_fee == 0 and "paypal" in result["payment_method"].lower():
        # PayPal Express Checkout: fee in seller_receivable_breakdown
        # Percorso: receipt → purchase_units[0] → payments → captures[0]
        #           → seller_receivable_breakdown → paypal_fee
        pp_fee_found = False
        try:
            purchase_units = receipt.get("purchase_units", [])
            if purchase_units and isinstance(purchase_units, list):
                captures = (purchase_units[0]
                            .get("payments", {})
                            .get("captures", []))
                if captures:
                    breakdown = captures[0].get("seller_receivable_breakdown", {})
                    paypal_fee_obj = breakdown.get("paypal_fee", {})
                    fee_val = float(paypal_fee_obj.get("value", 0))
                    fee_currency = paypal_fee_obj.get("currency_code", "EUR")
                    if fee_val > 0:
                        result["gateway_fee"] = fee_val
                        result["gateway_fee_currency"] = fee_currency
                        pp_fee_found = True
        except (ValueError, TypeError, IndexError, KeyError, AttributeError):
            pass

        # Fallback legacy: fee_amount / mc_fee (vecchio formato PayPal)
        if not pp_fee_found:
            paypal_fee = receipt.get("fee_amount") or receipt.get("mc_fee") or "0"
            try:
                result["gateway_fee"] = abs(float(paypal_fee))
                result["gateway_fee_currency"] = receipt.get("mc_currency", "EUR")
            except (ValueError, TypeError):
                pass

    return result


def enrich_orders(client: ShopifyClient, orders: list) -> list:
    """
    Adds transactions and refunds to each order.
    v2.0: extracts real transaction data (fees, currency, payment method).
    Returns list of enriched orders with calculated fields.
    """
    enriched = []
    total = len(orders)

    for i, order in enumerate(orders):
        oid = order["id"]

        # Progress every 50 orders
        if (i + 1) % 50 == 0 or i == 0:
            print(f"      Enriching order {i+1}/{total}...")

        # Fetch transactions and refunds
        order["_transactions"] = client.get_transactions(oid)
        order["_refunds"] = client.get_refunds(oid)

        # ── Base order data ──
        gross    = float(order.get("total_price", 0))
        tax      = float(order.get("total_tax", 0))
        discount = float(order.get("total_discounts", 0))
        shipping_shop = float(
            order.get("total_shipping_price_set", {})
                 .get("shop_money", {})
                 .get("amount", 0)
        )

        # ── Customer currency (presentment) ──
        presentment = order.get("total_price_set", {}).get("presentment_money", {})
        customer_amount = float(presentment.get("amount", gross))
        customer_currency = presentment.get("currency_code", order.get("currency", "EUR"))

        # Shop money (EUR)
        shop_money = order.get("total_price_set", {}).get("shop_money", {})
        shop_amount = float(shop_money.get("amount", gross))
        shop_currency = shop_money.get("currency_code", "EUR")

        # Exchange rate: customer → shop
        if customer_amount > 0 and customer_currency != shop_currency:
            exchange_rate = round(shop_amount / customer_amount, 6)
        else:
            exchange_rate = 1.0

        # ── Refunds ──
        total_refunded = sum(
            float(r.get("transactions", [{}])[0].get("amount", 0))
            for r in order["_refunds"]
            if r.get("transactions")
        )

        # ── Real transaction data (fee, payment method) ──
        tx_data = _extract_transaction_data(order["_transactions"])

        # ── Populate order fields ──
        # Revenue = total_price in shop currency (EUR) — excluding shipping
        order["_gross_revenue"] = shop_amount - shipping_shop
        order["_tax"] = tax
        order["_discount"] = discount
        order["_shipping"] = shipping_shop
        order["_total_refunded"] = total_refunded

        # Currency and exchange
        order["_customer_amount"] = customer_amount
        order["_customer_currency"] = customer_currency
        order["_shop_amount"] = shop_amount
        order["_shop_currency"] = shop_currency
        order["_exchange_rate"] = exchange_rate
        order["_original_currency"] = customer_currency

        # Transaction / Gateway
        order["_gateway"] = tx_data["gateway_name"] or (order.get("payment_gateway_names") or ["unknown"])[0]
        order["_payment_method"] = tx_data["payment_method"]
        order["_transaction_id"] = tx_data["transaction_id"]

        # Gateway fee — convert to EUR if in different currency (e.g. PayPal in NZD/SEK)
        fee_raw = tx_data["gateway_fee"]
        fee_currency = tx_data.get("gateway_fee_currency", "EUR")
        if fee_raw > 0 and fee_currency != shop_currency and exchange_rate > 0:
            # Convert using the same exchange rate as the order
            order["_gateway_fee"] = round(fee_raw * exchange_rate, 2)
        else:
            order["_gateway_fee"] = fee_raw
        order["_gateway_fee_currency"] = fee_currency
        order["_gateway_fee_original"] = fee_raw       # Fee in original currency

        # Hold: pending or on-hold orders
        financial_status = order.get("financial_status", "")
        order["_is_on_hold"] = financial_status in ("pending", "on_hold", "partially_paid")

        enriched.append(order)

    # ── Batch fetch REAL fees via GraphQL ──────────────────────────────────────
    print(f"      📊 Fetching real gateway fees via GraphQL...")
    order_ids = [o["id"] for o in enriched]
    try:
        gql_fees = client.get_fees_for_orders_graphql(order_ids)
        n_matched = 0
        for o in enriched:
            oid = o["id"]
            if oid in gql_fees and gql_fees[oid]["fee"] > 0:
                # Only overwrite if GraphQL has real fees (avoid zeroing PayPal fees)
                o["_gateway_fee"] = gql_fees[oid]["fee"]
                o["_gateway_fee_details"] = gql_fees[oid]["details"]
                n_matched += 1
        print(f"      ✅ Real fees obtained for {n_matched}/{total} orders")
    except Exception as e:
        print(f"      ⚠️  GraphQL fee error: {e} — using REST API fees")

    print(f"      ✅ {total} orders enriched with real transaction data")
    return enriched
