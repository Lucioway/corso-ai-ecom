"""
Supplier A Dropshipping COGS Client — Finance KPI Agent

Pulls per-order precise costs from supplier-a.example.com (Supplier A system) via REST API:
  - Product cost (USD) from productCostLadder, per commodity, scaled by quantity
  - Shipping cost (USD) from preShippingCost / shippingCost
  - Matched to Shopify orders by platformOrderId (== Shopify order.id) AND orderNumber

Auth flow:
  - Playwright headless login on first run (or when cookies expired)
  - storage_state persisted to cache/supplier_a_session.json
  - Subsequent runs reuse cookies via `requests`

Public API:
    client = SupplierACogsClient(config, cache_dir="cache")
    client.refresh_orders(states=[1, 2, 3])  # pulls all unfulfilled+paid orders
    cogs = client.get_cogs_for_shopify_order(shopify_order_dict)  # → dict or None

Output of get_cogs_for_shopify_order():
    {
        "product_cost_usd": 6.72,
        "shipping_cost_usd": 9.69,
        "total_cogs_usd":   16.41,
        "currency":         "USD",
        "country_code":     "IT",
        "items": [{"sku","qty","unit_cost_usd","line_cost_usd","variant","name"}],
        "source":           "supplier_api",
        "supplier_a_order_id":      "1P2V247FTE40F",
        "matched_by":       "platform_order_id"  # or "order_number"
    }
"""
from __future__ import annotations

import json
import os
import re
import time
from pathlib import Path
from typing import Optional, Iterable

import requests


SUPPLIER_A_BASE_URL = "https://system.supplier-a.example.com"
SUPPLIER_A_ORDER_PAGE_API = "/api/v2/order/get_own_order_page"
SUPPLIER_A_INVENTORY_API = "/api/v2/inventory/get_user_inventory"
SUPPLIER_A_USER_API = "/api/v2/user/get_own"
SUPPLIER_A_FREEZE_RECORD_API = "/api/v2/wallet/get_freeze_record"

# State values:
#   1 = Unfulfilled (waiting for payment to be claimed / awaiting fulfillment)
#   2 = Paid (in fulfillment pipeline)
#   3 = Sub-state inside processing
# We pull [1, 2, 3] to cover everything from new orders to actively-shipping.
DEFAULT_STATES = [1, 2, 3, 4]


# ─────────────────────────────────────────────────────────────────────────────
# Cost extraction helpers
# ─────────────────────────────────────────────────────────────────────────────
def _pick_cost_ladder(ladder: list, qty: int) -> Optional[int]:
    """
    Return the per-unit USD cents from the productCostLadder for the given qty.

    Ladder format: [{"moq": int, "amount": cents, "enterpriseAmount": cents}, ...]
    Pick the highest moq <= qty (best volume discount available).
    If qty < min moq, still use the first ladder row (suppliers honor the min).
    """
    if not ladder:
        return None
    eligible = [r for r in ladder if int(r.get("moq", 1)) <= qty]
    chosen = eligible[-1] if eligible else ladder[0]
    return int(chosen.get("amount", 0))


def _commodity_cost_usd(commodity: dict) -> tuple[float, int]:
    """Returns (line_cost_usd, unit_cost_cents) for a single Supplier A commodity."""
    qty = int(commodity.get("quantity", 1)) or 1
    ladder = (commodity.get("listing") or {}).get("productCostLadder") or []
    unit_cents = _pick_cost_ladder(ladder, qty) or 0
    line_usd = (unit_cents * qty) / 100.0
    return round(line_usd, 4), unit_cents


def _order_cogs_usd(supplier_order: dict, freeze_shipping_cents: Optional[int] = None) -> dict:
    """
    Reduce a single Supplier A order record into a flat COGS dict.

    Shipping priority: shippingCost (SETTLED — only present on Fulfilled/Success
    orders, == the "Shipping" value in Supplier A's Fulfilled Orders tab) → freeze_record
    (wallet hold) → preShippingCost (estimate). All amounts in USD.
    """
    product_total = 0.0
    items = []
    for c in supplier_order.get("commodities", []) or []:
        line_usd, unit_cents = _commodity_cost_usd(c)
        product_total += line_usd
        items.append({
            "sku":           c.get("sku") or c.get("exportSku") or "",
            "qty":           int(c.get("quantity", 1)),
            "unit_cost_usd": round(unit_cents / 100.0, 4),
            "line_cost_usd": line_usd,
            "variant":       c.get("variant", "") or c.get("exportVariant", ""),
            "name":          c.get("productName", ""),
        })

    if int(supplier_order.get("shippingCost") or 0) > 0:
        # Settled cost on a Fulfilled/Success order — the ground truth.
        shipping_cents = int(supplier_order["shippingCost"])
        ship_src = "fulfilled_settled"
    elif freeze_shipping_cents is not None and freeze_shipping_cents > 0:
        shipping_cents = freeze_shipping_cents
        ship_src = "wallet_freeze"
    else:
        shipping_cents = int(supplier_order.get("preShippingCost") or 0)
        ship_src = "pre_shipping_estimate"
    shipping_usd = round(shipping_cents / 100.0, 4)
    total = round(product_total + shipping_usd, 2)

    return {
        "product_cost_usd":  round(product_total, 2),
        "shipping_cost_usd": shipping_usd,
        "total_cogs_usd":    total,
        "currency":          "USD",
        "country_code":      supplier_order.get("countryCode") or "",
        "items":             items,
        "source":            "supplier_api",
        "supplier_a_order_id":       supplier_order.get("orderId") or "",
        "shipping_source":   ship_src,
    }


# ─────────────────────────────────────────────────────────────────────────────
# Client
# ─────────────────────────────────────────────────────────────────────────────
class SupplierACogsClient:
    def __init__(self, config: dict, cache_dir: str = "cache"):
        self.config = config
        supplier_cfg = (config or {}).get("supplier_a", {})
        # Backwards compat: legacy config used "supplier_b" key
        if not supplier_cfg:
            supplier_cfg = (config or {}).get("supplier_b", {}) or {}
        self.cfg = supplier_cfg
        self.email = supplier_cfg.get("email")
        self.password = supplier_cfg.get("password")
        self.enabled = bool(supplier_cfg.get("enabled"))
        self.cache_dir = Path(cache_dir) / "supplier_a"
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.storage_state_path = self.cache_dir / "session.json"

        self.session = requests.Session()
        self.session.headers.update({
            "Accept": "application/json, text/plain, */*",
            "Content-Type": "application/json",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0 Safari/537.36",
            "Origin": SUPPLIER_A_BASE_URL,
            "Referer": SUPPLIER_A_BASE_URL + "/order",
        })

        # Order index built by refresh_orders()
        self._by_platform_id: dict[str, dict] = {}   # Shopify order GID/id (str) → supplier_a order
        self._by_order_number: dict[str, dict] = {}  # "B#101005" stripped → supplier_a order
        # Wallet freeze records (real shipping debits) by transactionNo == platformOrderId
        self._freeze_by_platform_id: dict[str, int] = {}

    # ── Auth ────────────────────────────────────────────────────────────────
    def _load_storage(self) -> bool:
        if not self.storage_state_path.exists():
            return False
        try:
            data = json.loads(self.storage_state_path.read_text())
            for c in data.get("cookies", []):
                self.session.cookies.set(
                    c["name"], c["value"],
                    domain=c.get("domain") or ".supplier-a.example.com",
                    path=c.get("path", "/"),
                )
            return True
        except Exception as e:
            print(f"[Supplier A] ⚠️ Could not load session.json: {e}")
            return False

    def _save_storage_from_playwright(self, context):
        state = context.storage_state()
        self.storage_state_path.write_text(json.dumps(state, indent=2))

    def _login_playwright(self):
        """Headless login via Playwright; persists cookies to storage_state."""
        from playwright.sync_api import sync_playwright

        if not self.email or not self.password:
            raise RuntimeError("Supplier A credentials missing in config.supplier_a.email/password")

        print(f"[Supplier A] 🔑 Logging in via Playwright as {self.email}…")
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=True)
            context = browser.new_context()
            page = context.new_page()
            page.goto(SUPPLIER_A_BASE_URL + "/login", wait_until="networkidle")
            page.get_by_role("textbox", name="Email").fill(self.email)
            page.get_by_role("textbox", name="Password").fill(self.password)
            page.get_by_role("button", name="Sign in").click()
            page.wait_for_url("**/dashboard", timeout=20000)
            # Briefly poll until accessToken cookie shows up
            for _ in range(10):
                cookies = context.cookies()
                if any(c["name"] == "accessToken" for c in cookies):
                    break
                time.sleep(0.5)
            self._save_storage_from_playwright(context)
            # Copy fresh cookies into requests session
            self.session.cookies.clear()
            for c in cookies:
                self.session.cookies.set(c["name"], c["value"],
                                        domain=c.get("domain", ".supplier-a.example.com"),
                                        path=c.get("path", "/"))
            browser.close()
        print("[Supplier A] ✅ Login OK, session cached")

    def ensure_session(self):
        """Make sure self.session has valid cookies. Re-login if expired."""
        if not self._load_storage():
            self._login_playwright()
            return
        # Quick probe
        r = self.session.get(SUPPLIER_A_BASE_URL + SUPPLIER_A_USER_API, timeout=15)
        if r.status_code == 200 and r.json().get("success"):
            return
        print(f"[Supplier A] ⚠️ Cached session invalid ({r.status_code}); re-login…")
        self._login_playwright()

    # ── API: fetch orders (paginated) ───────────────────────────────────────
    def _fetch_orders_page(self, states: list[int], current: int, size: int) -> dict:
        body = {"page": {"current": current, "size": size}, "sort": [], "conditions": {"states": states}}
        r = self.session.post(SUPPLIER_A_BASE_URL + SUPPLIER_A_ORDER_PAGE_API, json=body, timeout=30)
        r.raise_for_status()
        j = r.json()
        if not j.get("success"):
            raise RuntimeError(f"Supplier A API error: {j.get('message')}")
        return j["data"]

    def fetch_all_orders(self, states: Iterable[int] = DEFAULT_STATES, page_size: int = 200) -> list[dict]:
        self.ensure_session()
        states = list(states)
        all_records = []
        current = 1
        while True:
            data = self._fetch_orders_page(states, current, page_size)
            recs = data.get("records") or []
            all_records.extend(recs)
            if len(recs) < page_size:
                break
            current += 1
            if current > 50:  # safety cap (10k orders)
                break
        return all_records

    # ── API: inventory (catalog) ────────────────────────────────────────────
    def fetch_inventory(self) -> list[dict]:
        self.ensure_session()
        r = self.session.post(
            SUPPLIER_A_BASE_URL + SUPPLIER_A_INVENTORY_API,
            json={"page": {"current": 1, "size": 500}, "sort": [], "conditions": {}},
            timeout=30,
        )
        r.raise_for_status()
        return (r.json().get("data") or {}).get("records") or []

    # ── API: wallet freeze records (real per-order shipping debits) ─────────
    def fetch_freeze_records(self, page_size: int = 200) -> list[dict]:
        """Pull all wallet freeze records (each order has a shipping freeze)."""
        self.ensure_session()
        all_records = []
        current = 1
        while True:
            body = {"page": {"current": current, "size": page_size}, "sort": [], "conditions": {}}
            r = self.session.post(SUPPLIER_A_BASE_URL + SUPPLIER_A_FREEZE_RECORD_API, json=body, timeout=30)
            r.raise_for_status()
            data = (r.json() or {}).get("data") or {}
            recs = data.get("records") or []
            all_records.extend(recs)
            if len(recs) < page_size:
                break
            current += 1
            if current > 50:
                break
        return all_records

    # ── Index build + lookup ────────────────────────────────────────────────
    @staticmethod
    def _norm_order_number(s: str) -> str:
        """Strip leading 'B#', '#', whitespace from order number for matching."""
        return re.sub(r"^[B#]+", "", str(s or "").strip(), flags=re.IGNORECASE)

    def refresh_orders(self, states: Iterable[int] = DEFAULT_STATES, use_cache_hours: float = 0.5):
        """Fetch Supplier A orders + wallet freeze records, build lookup indexes."""
        cache_path = self.cache_dir / "orders_all.json"
        freeze_cache = self.cache_dir / "freeze_all.json"
        fresh_enough = (
            cache_path.exists()
            and (time.time() - cache_path.stat().st_mtime) < use_cache_hours * 3600
        )
        if fresh_enough:
            records = json.loads(cache_path.read_text())
            print(f"[Supplier A] ↺ Loaded {len(records)} orders from cache ({cache_path.name})")
        else:
            records = self.fetch_all_orders(states=states)
            cache_path.write_text(json.dumps(records))
            print(f"[Supplier A] ✅ Fetched {len(records)} orders from API → cached")

        # Freeze records (real shipping costs)
        freeze_fresh = (
            freeze_cache.exists()
            and (time.time() - freeze_cache.stat().st_mtime) < use_cache_hours * 3600
        )
        if freeze_fresh:
            freezes = json.loads(freeze_cache.read_text())
            print(f"[Supplier A] ↺ Loaded {len(freezes)} freeze records from cache")
        else:
            try:
                freezes = self.fetch_freeze_records()
                freeze_cache.write_text(json.dumps(freezes))
                print(f"[Supplier A] ✅ Fetched {len(freezes)} freeze records → cached")
            except Exception as e:
                print(f"[Supplier A] ⚠️ Freeze records fetch failed ({e}); using preShipping estimates")
                freezes = []

        self._by_platform_id.clear()
        self._by_order_number.clear()
        self._freeze_by_platform_id.clear()

        def _state_rank(o: dict) -> int:
            # Prefer Fulfilled/Success (4) — it carries the settled shippingCost.
            v = (o.get("state") or {}).get("value") if isinstance(o.get("state"), dict) else o.get("state")
            return 1 if v == 4 else 0

        for supplier_a in records:
            pid = supplier_a.get("platformOrderId")
            if pid:
                cur = self._by_platform_id.get(str(pid))
                if cur is None or _state_rank(supplier_a) >= _state_rank(cur):
                    self._by_platform_id[str(pid)] = supplier_a
            num = self._norm_order_number(supplier_a.get("orderNumber"))
            if num:
                cur = self._by_order_number.get(num)
                if cur is None or _state_rank(supplier_a) >= _state_rank(cur):
                    self._by_order_number[num] = supplier_a
        # Build freeze index — transactionNo == platformOrderId, type 10 = Order Shipping Fees Prepaid
        for fr in freezes:
            tno = str(fr.get("transactionNo") or "")
            ftype = (fr.get("type") or {}).get("value") if isinstance(fr.get("type"), dict) else fr.get("type")
            if tno and ftype == 10:
                # Sum if multiple freezes per order (shouldn't happen but safe)
                self._freeze_by_platform_id[tno] = self._freeze_by_platform_id.get(tno, 0) + int(fr.get("amount") or 0)
        return records

    def get_cogs_for_shopify_order(self, shopify_order: dict) -> Optional[dict]:
        """
        Match a Shopify order against the Supplier A index and return COGS dict.
        Match priority: order.id (== Supplier A platformOrderId) → order.name/order_number.
        """
        if not (self._by_platform_id or self._by_order_number):
            return None

        sid = str(shopify_order.get("id") or "")
        if sid and sid in self._by_platform_id:
            supplier_a = self._by_platform_id[sid]
            freeze = self._freeze_by_platform_id.get(str(supplier_a.get("platformOrderId") or ""))
            cogs = _order_cogs_usd(supplier_a, freeze_shipping_cents=freeze)
            cogs["matched_by"] = "platform_order_id"
            return cogs

        name = self._norm_order_number(shopify_order.get("name") or "")
        if not name:
            name = str(shopify_order.get("order_number") or "")
        if name and name in self._by_order_number:
            supplier_a = self._by_order_number[name]
            freeze = self._freeze_by_platform_id.get(str(supplier_a.get("platformOrderId") or ""))
            cogs = _order_cogs_usd(supplier_a, freeze_shipping_cents=freeze)
            cogs["matched_by"] = "order_number"
            return cogs

        return None

    # ── Catalog builder (simplified, grouped by site product) ───────────────
    def build_catalog_rows(self, target_country: str = "IT") -> list[dict]:
        """
        Build a per-PRODUCT cost catalog (variants collapsed — all variants
        share the same cost). Output rows:
            product_name_supplier_a, product_name_site, quantity, cost_usd, shipping_usd, country

        For each unique site-product, emit one row per MOQ tier with the
        per-tier total cost (qty × unit). Shipping = avg observed cost
        for orders shipped to `target_country`.
        """
        inv = self.fetch_inventory()
        all_orders = list(self._by_platform_id.values()) or self.fetch_all_orders()

        # SKU → site product name (from order commodities, where site name lives)
        sku_to_site_name: dict[str, str] = {}
        for o in all_orders:
            for c in o.get("commodities") or []:
                sku = c.get("sku") or c.get("exportSku") or ""
                name = c.get("productName") or ""
                if sku and name and sku not in sku_to_site_name:
                    sku_to_site_name[sku] = name

        # Avg shipping per country
        ship_samples: dict[str, list[float]] = {}
        for o in all_orders:
            cc = o.get("countryCode") or ""
            cost = int(o.get("shippingCost") or 0) or int(o.get("preShippingCost") or 0)
            if cc and cost:
                ship_samples.setdefault(cc, []).append(cost / 100.0)
        ship_avg = {cc: round(sum(v) / len(v), 2) for cc, v in ship_samples.items() if v}
        avg_ship = ship_avg.get(target_country, 0.0)

        # Group inventory by site-product (collapse variants).
        # Each site-product → take the FIRST ladder (cost is identical across variants).
        site_products: dict[str, dict] = {}
        for item in inv:
            sku = item.get("sku", "")
            site_name = sku_to_site_name.get(sku) or item.get("productName", "")
            supplier_name = item.get("productName", "")
            ladder = item.get("productCostLadder") or []
            if not ladder:
                continue
            # Use site_name as group key
            existing = site_products.get(site_name)
            if not existing:
                site_products[site_name] = {
                    "product_name_site": site_name,
                    "product_name_supplier_a":   supplier_name,
                    "ladder":            ladder,
                }

        rows = []
        for site_name, data in site_products.items():
            for tier in data["ladder"]:
                qty = int(tier.get("moq", 1))
                unit_cents = int(tier.get("amount", 0))
                total_cost_usd = round((unit_cents * qty) / 100.0, 2)
                rows.append({
                    "product_name_site": data["product_name_site"],
                    "product_name_supplier_a":   data["product_name_supplier_a"],
                    "quantity":          qty,
                    "cost_usd":          total_cost_usd,
                    "shipping_usd":      avg_ship,
                    "country":           target_country,
                })
        return rows


# ─────────────────────────────────────────────────────────────────────────────
# CLI smoke test
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    import argparse, sys
    sys.path.insert(0, str(Path(__file__).parent.parent))

    parser = argparse.ArgumentParser(description="Supplier A COGS Client smoke test")
    parser.add_argument("--date", help="Filter Supplier A orderCreatedAt to this date (YYYY-MM-DD)")
    parser.add_argument("--config", default="config.json")
    parser.add_argument("--catalog", action="store_true", help="Dump variant×country catalog")
    args = parser.parse_args()

    cfg = json.loads(Path(args.config).read_text())
    # Force enabled for CLI test
    cfg.setdefault("supplier_a", cfg.get("supplier_b", {})).setdefault("enabled", True)

    client = SupplierACogsClient(cfg)
    records = client.refresh_orders(use_cache_hours=0)
    if args.date:
        records = [r for r in records if (r.get("orderCreatedAt") or "").startswith(args.date)]
        print(f"\n📅 Orders on {args.date}: {len(records)}")
    total_p = total_s = 0.0
    for r in records:
        c = _order_cogs_usd(r)
        total_p += c["product_cost_usd"]
        total_s += c["shipping_cost_usd"]
        print(f"  {r.get('orderNumber'):<10} "
              f"prod ${c['product_cost_usd']:>6.2f}  "
              f"ship ${c['shipping_cost_usd']:>6.2f}  "
              f"= ${c['total_cogs_usd']:>6.2f}  "
              f"[{c['country_code']}] "
              f"({len(c['items'])} items, plat_id={r.get('platformOrderId')})")
    print(f"\n  TOTAL: prod ${total_p:.2f} + ship ${total_s:.2f} = ${total_p + total_s:.2f}")

    if args.catalog:
        rows = client.build_catalog_rows("IT")
        print(f"\n📦 Catalog ({len(rows)} rows):")
        for r in rows[:20]:
            print(f"  {r['sku']:<12} {r['variant'][:25]:<25} "
                  f"x{r['moq']:>2}: ${r['unit_cost_usd']:.2f} (+${r['avg_shipping_usd']:.2f} ship)")
