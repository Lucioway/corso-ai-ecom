#!/bin/bash
# FINANCE KPI — daily report runner (delegates to cli.py engine).
cd "$(dirname "$0")"
venv/bin/python cli.py report "$@"
