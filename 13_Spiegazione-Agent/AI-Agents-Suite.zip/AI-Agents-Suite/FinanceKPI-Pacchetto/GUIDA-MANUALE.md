# FinanceKPI — Guida Manuale

Il tuo conto economico Shopify, self-hosted e in tempo reale. Una dashboard di
Profit & Loss che legge i dati veri del tuo store (ordini, commissioni, resi),
ci somma il costo della merce e ti mostra il **margine reale**, più un report
giornaliero/settimanale che puoi schedulare. Gira a casa tua o sul tuo cloud, i
tuoi dati restano tuoi.

---

## Indice

1. [Cos'è FinanceKPI](#1-cosè-financekpi)
2. [Requisiti](#2-requisiti)
3. [Installazione e primo avvio](#3-installazione-e-primo-avvio)
4. [Architettura: i 3 strati](#4-architettura-i-3-strati)
5. [Il wizard di configurazione](#5-il-wizard-di-configurazione)
6. [I comandi (`cli.py`)](#6-i-comandi-clipy)
7. [La dashboard live](#7-la-dashboard-live)
8. [I KPI spiegati](#8-i-kpi-spiegati)
9. [Il report batch (giornaliero/settimanale)](#9-il-report-batch-giornalierosettimanale)
10. [COGS — porta i tuoi numeri](#10-cogs--porta-i-tuoi-numeri)
11. [Integrazioni opzionali (off di default)](#11-integrazioni-opzionali-off-di-default)
12. [Scheduling (automazione)](#12-scheduling-automazione)
13. [Deploy sul cloud](#13-deploy-sul-cloud)
14. [Personalizzazione](#14-personalizzazione)
15. [Struttura dei file](#15-struttura-dei-file)
16. [Sicurezza e privacy](#16-sicurezza-e-privacy)
17. [Risoluzione problemi](#17-risoluzione-problemi)
18. [FAQ](#18-faq)

---

## 1. Cos'è FinanceKPI

FinanceKPI è un toolkit di Profit & Loss per negozi Shopify. Due componenti che
condividono un solo codice:

- **Dashboard live** — una vista P&L in tempo reale (vendite, ordini, ad spend,
  COGS, margine, ROAS, ROAS di break-even) servita dalla tua macchina o dal tuo
  host cloud.
- **Report batch** — un generatore di report giornalieri/settimanali che lanci a
  richiesta o su schedule, con il COGS già incorporato per ogni giorno.

Entrambi leggono lo **stesso** `config.json` e la stessa logica Shopify + finanza
in `core/`. Nessun database: lo stato sono file (config, cache ordini, xlsx). Se
copi la cartella, copi tutto.

---

## 2. Requisiti

- **Python** 3.10+ (consigliato 3.13) e `pip`.
- Un **negozio Shopify** con una *custom app* e relativo **Admin API access
  token** (`shpat_...`), con permessi di lettura su Orders, Products e scope
  finanziari correlati.
- Un **browser** moderno (Chrome consigliato) per la dashboard.
- Sistema: macOS, Linux o Windows. Per il deploy della dashboard, un host con
  disco persistente (es. Render).
- Le integrazioni esterne (Triple Whale, Google Drive, Telegram, WhatsApp, email
  watcher) sono **opzionali** e richiedono le rispettive credenziali solo se le
  abiliti.

---

## 3. Installazione e primo avvio

1. Scompatta la cartella `FinanceKPI` dove preferisci.
2. Crea un ambiente virtuale e installa le dipendenze:
   ```bash
   cd FinanceKPI
   python3 -m venv venv && . venv/bin/activate
   pip install -r requirements.txt
   ```
3. Lancia il wizard interattivo:
   ```bash
   ./setup.sh
   ```
   (vedi §5). Genera `config.json` + `.env`.
4. Avvia la dashboard o fai un report:
   ```bash
   python cli.py dashboard --port 8890
   python cli.py report --date 2026-01-31
   ```

Apri **http://127.0.0.1:8890** e fai il login con le credenziali scelte nel
wizard.

---

## 4. Architettura: i 3 strati

| Strato | Cartella | Cosa fa |
|---|---|---|
| **Core (condiviso)** | `core/` | Client Shopify, client ad-spend, logica COGS, loader di config. Un'unica fonte di verità usata da entrambi i runtime. |
| **Web (dashboard)** | `web/` | Web server Python che serve la dashboard P&L su `:8789` (default) e legge ordini/commissioni/resi live. |
| **Report (batch)** | `report/` | Genera l'xlsx P&L giornaliero/settimanale; può caricarlo su Drive e notificare (opzionale). |

Il **motore unico** è `cli.py`: un solo punto d'ingresso che orchestra report e
dashboard. È quello che lanci tu, che schedula launchd/cron e che il cloud
esegue.

---

## 5. Il wizard di configurazione

`./setup.sh` raccoglie i tuoi dati e scrive **un solo `config.json` canonico** in
root, poi lo copia in `report/config.json` e `web/config.json` così che report,
dashboard e `core/` leggano lo **stesso** file. Scrive anche un `.env` con
l'auth dashboard e un session secret generato fresco.

Cosa ti chiede:

| Domanda | Esempio | Note |
|---|---|---|
| Brand / app name | `MyBrand` | Appare in dashboard e nel nome dei file report |
| Currency | `EUR` | Imposta simbolo valuta e currency di Triple Whale |
| Shopify shop URL | `my-store-1234.myshopify.com` | Il tuo dominio `.myshopify.com` |
| Shopify Admin API token | `shpat_...` | Va in `shopify.api_password` |
| Dashboard username/password | `admin` / *(tua scelta)* | Login della dashboard |
| Report file prefix | `Report_COGS` | Prefisso degli xlsx generati |

Puoi rilanciarlo quando vuoi: chiede prima di sovrascrivere un `config.json`
esistente. Tutte le integrazioni opzionali restano `enabled: false`.

> **Preferisci farlo a mano?** Copia `report/config.example.json` in
> `config.json`, compila il blocco `shopify` + `report.company_name`, poi copia
> quel file in `report/config.json` e `web/config.json`. Copia `.env.example` in
> `.env` e compila le credenziali dashboard.

---

## 6. I comandi (`cli.py`)

`cli.py` è il motore. Comandi disponibili:

```bash
# Dashboard live (default porta 8789)
python cli.py dashboard --port 8890

# Report giornaliero per una data specifica
python cli.py report --date 2026-01-31

# Giornaliero + settimanale
python cli.py report --date 2026-01-31 --week

# Un intervallo di date
python cli.py report-range --from 2026-01-01 --to 2026-01-31

# Health check auth/config (Shopify + Drive creds + config COGS)
python cli.py status

# Scarica i contratti di abbonamento Shopify (attivi/in pausa/annullati)
python cli.py subs --store my-store-1234           # --login la prima volta
python cli.py subs --login                          # forza il login visibile una volta

# Ricostruisce la matrice di stima COGS dei bundle dagli ordini evasi
python cli.py cogs-matrix --min-n 3
```

`status` stampa lo stato dell'auth Shopify, la presenza delle credenziali Drive
e lo stato del fornitore COGS (esce `OK` o `DEGRADED`). `subs` usa un browser
autenticato per leggere i contratti di abbonamento e li salva in
`report/cache/subscriptions.json`. `cogs-matrix` calcola, dai tuoi ordini
realmente evasi, il costo medio per combo prodotto×accessorio e lo scrive in
`config.cogs.matrix`, così la dashboard può **stimare** il COGS dei giorni
recenti non ancora evasi (i giorni precisi continuano a usare l'xlsx esatto).

---

## 7. La dashboard live

Avvia con `python cli.py dashboard --port 8890`, poi apri
`http://127.0.0.1:8890` e fai il login. La dashboard:

- legge ordini, commissioni e resi **live** dalle Shopify Admin API per lo store
  nel tuo `config.json`;
- li mette in **cache** locale (per non rifare ogni volta le chiamate);
- calcola e mostra il P&L con le card KPI.

Le **pagine** (tab in alto):

| Pagina | Cosa mostra |
|---|---|
| **Dashboard** | Il P&L principale: vendite, ordini, ad spend, fees, COGS, margine, ROAS, BE ROAS. |
| **Subscriptions** | I KPI degli abbonamenti: MRR, nuovi iscritti, ricorrenti, AOV abbonati (richiede `cli.py subs`). |
| **COGS (fornitore)** | Il dettaglio del costo merce per bundle, dalla matrice/xlsx fornitore. |
| **Costi Fissi** | Costi fissi e variabili mensili letti dal foglio costi, ripartiti per giorno. |
| **Customer Care** | KPI opzionali del supporto, se colleghi una fonte (`CC_URL`). |

**Selettore date / range** in alto: scegli giorno singolo o intervallo; i KPI
si aggregano di conseguenza. Pulsante **Refresh** per riscaldare/ricalcolare la
cache. Pulsante **Stealth** per sfocare i valori sensibili (utile per
screenshot/demo). Endpoint di servizio: `GET /healthz` per il check di salute.

> Alla prima richiesta la cache ordini è fredda: le card si popolano entro
> 1-2 minuti.

---

## 8. I KPI spiegati

I KPI principali della pagina Dashboard:

| KPI | Significato |
|---|---|
| **Orders** | Numero ordini nel periodo. |
| **Revenue / Net** | Ricavo lordo e netto. |
| **Ads / ROAS** | Spesa pubblicitaria e Return On Ad Spend (ricavo / spesa). |
| **Meta ROAS / Google Ads ROAS** | ROAS per canale (richiede le integrazioni ad). |
| **CPA Blended** | Costo per acquisizione medio su tutti i canali. |
| **COGS / COGS %** | Costo della merce in valore e in % sul ricavo. |
| **Gateway Fees / SP Fee % / PayPal Fee %** | Commissioni di incasso (Shopify Payments, PayPal) in valore e %. |
| **Net Margin** | Margine netto dopo COGS, ads e commissioni. |
| **BE ROAS** | ROAS di break-even = `1 / (1 − COGS% − gateway%)`: sotto questa soglia perdi. |
| **Operating Net / Net − Costi Fissi** | Netto operativo e netto al netto dei costi fissi. |
| **MRR / AOV abbonati / Sub orders** | Metriche abbonamenti (pagina Subscriptions). |

Le soglie di colore del ROAS e gli obiettivi (COGS %, margine, ROAS minimo) si
configurano nel blocco `finance` di `config.json`
(`target_*`, `roas_color_thresholds`, `payment_gateway_fees`).

---

## 9. Il report batch (giornaliero/settimanale)

Il report produce un **xlsx P&L** con il COGS incorporato. Lancialo con:

```bash
python cli.py report --date 2026-01-31            # giornaliero
python cli.py report --date 2026-01-31 --week     # + settimanale
python cli.py report-range --from ... --to ...    # intervallo
```

Il file viene nominato col prefisso `report.file_prefix` (default `Report_COGS`)
e l'identità `report.company_name` dal tuo config. La dashboard legge gli stessi
xlsx, quindi il **prefisso deve combaciare** da entrambi i lati (è già il caso di
default). Lo scheduler integrato e le notifiche sono opzionali (vedi §11–12).

---

## 10. COGS — porta i tuoi numeri

Il costo della merce lo fornisci **tu**: lo strumento non inventa costi. Tre
modi, non esclusivi:

1. **File fornitore** — metti l'`.xlsx`/CSV dei costi nella cartella indicata da
   `cogs.supplier_csv_folder`. Naming atteso descritto inline in
   `report/config.example.json` (es. `orders_YYYYMMDD_all.csv`). Letto in
   automatico.
2. **Matrice diretta** — compila `cogs.matrix` in `config.json` (costo per
   combinazione prodotto/quantità).
3. **Stima dagli ordini evasi** — `python cli.py cogs-matrix` calcola la media
   reale dai tuoi ordini già evasi e popola la matrice (per stimare i giorni
   recenti non ancora evasi).

Se per un giorno manca la fonte, il COGS di quel giorno resta **vuoto** invece
di essere indovinato. Le parole-chiave per riconoscere i tuoi prodotti
("prodotto principale" vs "accessorio") si impostano in `cogs.title_hints` —
adattale ai titoli dei tuoi articoli.

---

## 11. Integrazioni opzionali (off di default)

`config.json` parte con questi blocchi a `"enabled": false`. Accendine uno solo
**dopo** aver inserito le sue credenziali. Ogni blocco ha un campo
`_note` / `_instructions` inline che spiega cosa compilare.

| Integrazione | Cosa fa |
|---|---|
| **Google Drive** | Carica i report in una cartella Drive. |
| **Triple Whale** | Pesca le metriche ad-spend "blended". |
| **Telegram / WhatsApp** | Invia il recap giornaliero in una chat/gruppo. |
| **Email watcher** | Scarica in automatico il file COGS fornitore da Gmail (IMAP + app password). |
| **Fornitore dropship** | COGS per-ordine da un portale fornitore (es. login portale). Off finché non configurato. |

Con tutte le integrazioni spente, il report produce comunque l'xlsx locale e la
dashboard funziona sui dati Shopify.

---

## 12. Scheduling (automazione)

Il runner giornaliero è `run_daily.sh` (delega a `cli.py report`). Per farlo
girare ogni giorno a un orario fisso:

- **macOS** → un job **launchd** (`.plist` in `~/Library/LaunchAgents/`).
- **Linux** → un **systemd timer** o una riga di **cron**.
- **Windows** → **Task Scheduler**.

L'orario e il fuso si impostano in `report.report_time` / `report.timezone`
(default `07:00`, `Europe/Rome`). I giorni della settimana per il report
settimanale in `report.weekly_start_day` / `weekly_end_day`.

---

## 13. Deploy sul cloud

La dashboard è un singolo web service Python. La guida completa è in
`FinanceKPI/DEPLOY.md` (esempio su **Render**). In sintesi:

1. **Web service** con Root Directory `web`, build `pip install -r requirements.txt`,
   start `python server.py`, health check path `/healthz`. Il servizio si lega
   alla `PORT` assegnata su `HOST=0.0.0.0`.
2. **Disco persistente** montato su `/data` (`DATA_DIR=/data`) per far
   sopravvivere la cache ordini/fees/resi ai riavvii.
3. **Variabili d'ambiente** (i segreti vanno aggiunti a mano):
   `DASHBOARD_USER`, `DASHBOARD_PASS`, `DASHBOARD_SESSION_SECRET`,
   `SHOPIFY_SHOP_URL`, `SHOPIFY_API_PASSWORD` (+ `SHOPIFY_API_KEY` /
   `SHOPIFY_API_SECRET` solo se usi il refresh del token via client-credentials),
   e le chiavi opzionali (`TRIPLE_WHALE_API_KEY`, `GOOGLE_SERVICE_ACCOUNT_JSON`)
   solo se attivi quelle integrazioni.

Sul cloud il servizio legge la config dalle **variabili d'ambiente**
(`core/config.py` → `load_from_env()`): non serve caricare un `config.json`. In
locale resta tutto invariato (`./setup.sh` + `cli.py dashboard`).

---

## 14. Personalizzazione

- **Identità** — nome brand, valuta, simbolo, prefisso file: blocchi `report` e
  `finance` di `config.json` (o rilancia `./setup.sh`).
- **Obiettivi e soglie** — `finance.target_*`, `roas_color_thresholds`,
  `payment_gateway_fees`, quote Shopify Payments/PayPal.
- **Riconoscimento prodotti** — `cogs.title_hints` (parole-chiave per "prodotto"
  vs "accessorio") e le label dei bundle in `web/aggregate_cogs.py` /
  `report/modules/report_generator.py`: rinominale sui tuoi articoli.
- **Nome mostrato in dashboard** — l'endpoint `GET /api/config/app` restituisce
  `app_name` (da config o env `APP_NAME`, default `FinanceKPI`); il titolo della
  pagina diventa `<nome> · KPI`.

---

## 15. Struttura dei file

```
FinanceKPI/
  cli.py                       # motore unico: report / report-range / dashboard / status / subs / cogs-matrix
  setup.sh                     # wizard interattivo → config.json + .env
  run_daily.sh                 # runner giornaliero (per scheduler)
  requirements.txt             # set dipendenze combinato (canonico)
  .env.example                 # template auth dashboard
  README.md  DEPLOY.md  LICENSE.txt

  core/                        # logica condivisa
    shopify_client.py          # client Admin API (auth custom-app)
    ads_client.py              # ad-spend (Triple Whale, ...)
    supplier_a_cogs.py         # COGS per-ordine via fornitore (opzionale)
    subscriptions_scraper.py   # scraping contratti abbonamento
    config.py                  # loader unificato (JSON locale / ENV cloud)

  web/                         # dashboard live
    server.py                  # web server (:8789)
    index.html                 # UI
    render.yaml                # config deploy Render
    bundles.example.json       # template bundle COGS (vuoto: lo definisci tu)
    aggregate_cogs.py costs_reader.py fx_converter.py xlsx_daily_reader.py
    modules/                   # shim + adattatori

  report/                      # batch giornaliero/settimanale
    main.py                    # entry-point report
    config.example.json        # TEMPLATE config (copialo in config.json)
    scheduler.py telegram_bot.py
    modules/                   # cogs_reader, drive_uploader, weekly_report, ...
    README.md  README_WINDOWS.md  SETUP.md
```

I file generati per-installazione (`config.json`, `report/config.json`,
`web/config.json`, `.env`, cache, xlsx, token) sono **gitignored**: non vanno
mai committati né condivisi.

---

## 16. Sicurezza e privacy

- **I tuoi dati restano tuoi.** Lo strumento gira sulla tua macchina o sul tuo
  cloud. Nessun dato di business viene mandato a terzi (a parte le API che tu
  stesso configuri: Shopify, eventuale Triple Whale, ecc.).
- **Token Shopify** e credenziali stanno in `config.json` / `.env`, gitignored.
  Sul cloud usa le variabili d'ambiente come segreti.
- **Dashboard protetta** da username/password e session cookie. Se la esponi
  pubblica, mettici davanti HTTPS / reverse-proxy.
- **Stealth mode** sfoca i valori sensibili per screen-share e screenshot.

---

## 17. Risoluzione problemi

| Problema | Soluzione |
|---|---|
| `cli.py status` → Shopify FAIL | Token errato o scope mancanti. Rigenera l'Admin API token e rilancia `./setup.sh`. |
| Dashboard chiede sempre login | Cookie di sessione perso o `DASHBOARD_SESSION_SECRET` cambiato. Verifica il `.env`. |
| 401 anche con credenziali | `DASHBOARD_USER` / `DASHBOARD_PASS` non combaciano col `.env`. Ricontrolla. |
| Le card KPI restano vuote | Cache ordini fredda al primo giro: attendi 1-2 minuti o premi Refresh. |
| COGS sempre a zero/vuoto | Manca la fonte COGS per quei giorni. Metti l'xlsx/CSV in `cogs.supplier_csv_folder` o popola `cogs.matrix` / `cli.py cogs-matrix`. |
| Il report non si carica su Drive | L'integrazione Drive è `enabled: false` o mancano le credenziali. Vedi §11. |
| La dashboard non parte sul cloud | Controlla `/healthz`, le env `SHOPIFY_*` / `DASHBOARD_*` e che il disco persistente sia montato su `/data`. |
| Avvio dashboard si blocca | Se la chiamata Shopify iniziale è lenta/errata, verifica shop URL e token; punta a creds valide. |

---

## 18. FAQ

**I miei numeri di vendita vanno in giro?**
No. FinanceKPI gira da te; lo stato sono file locali (o sul tuo cloud). Parla
solo con le API che tu configuri.

**Devo saper programmare per usarlo?**
No per l'uso base: `./setup.sh` ti guida, poi due comandi (`dashboard` e
`report`). La personalizzazione avanzata è editing di file JSON.

**Funziona con qualsiasi store Shopify?**
Sì, serve solo una *custom app* con l'Admin API token e i permessi di lettura su
Orders/Products.

**Da dove arriva il COGS?**
Da te. Carichi il file costi del fornitore (xlsx/CSV) o compili la matrice. Lo
strumento non inventa costi.

**Posso usare solo la dashboard, o solo il report?**
Sì. Sono due runtime sullo stesso codice: deploya quello che ti serve
(`web/requirements.txt` e `report/requirements.txt` sono i sottoinsiemi).

**In che valuta lavora?**
Nella valuta che scegli nel wizard (default EUR). Le metriche esterne in USD
vengono convertite con i tassi di cambio configurati.

---

*FinanceKPI v1.0 — il tuo conto economico Shopify, self-hosted, a casa tua.*
