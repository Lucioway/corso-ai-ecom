# AI Agents Suite

Una collezione di agenti AI self-hosted, pronti all'uso, in italiano. Ogni
agente è un prodotto a sé: lo installi sul tuo computer/server e gira a casa
tua. I tuoi dati restano tuoi.

---

## Come si usa (per qualsiasi agente)

1. Apri la sottocartella del prodotto che ti interessa (es. `JarvisOS-Pacchetto/`).
2. Dentro trovi sempre:
   - **`SETUP.md`** — le istruzioni di installazione
   - **`GUIDA-MANUALE.md`** + **`GUIDA-MANUALE.pdf`** — il manuale completo
   - una **sottocartella** col codice dell'agente, pronto
3. Apri **Claude Code** dentro quella sottocartella del prodotto e scrivi:
   > *"Leggi SETUP.md e installa questo agente nel mio sistema, fatto bene — controlla tutto."*
4. Claude Code installa, configura e verifica tutto da solo.

> **Serve:** Node.js, Python 3, e la **CLI Claude Code** installata e loggata.

---

## I prodotti

### 🧠 JarvisOS
Il centro di comando AI personale: una dashboard vocale in italiano per gestire
qualsiasi business o progetto — numeri, task, agenti automatici, roadmap. Voce,
Task Planner drag&drop, brand e agenti customizzabili via file. **Il prodotto di
punta.**
→ `JarvisOS-Pacchetto/`

### 💬 Customer Care Agent
Legge la casella di supporto (email), abbina ordine Shopify e tracking, e scrive
**bozze di risposta** nel tono del brand con l'AI. Non invia mai da solo: tu
approvi. Con dashboard stile Gmail.
→ `CustomerCareAgent-Pacchetto/`

### 📦 Fulfillment Agent
Evade in blocco gli ordini Shopify partendo dal foglio di tracking del
fornitore (email/CSV): rileva il corriere, fa il fulfillment via API Shopify e
può girare ogni giorno con avvisi Telegram.
→ `FulfillmentAgent-Pacchetto/`

### 🛒 Order Agent
Ogni notte prende gli ordini Shopify del giorno, li trasforma nel CSV nativo
Shopify (76 colonne), li manda al fornitore via email e posta un riepilogo su
Telegram.
→ `OrderAgent-Pacchetto/`

### 📊 Finance KPI
Dashboard P&L per Shopify: legge ordini/commissioni/resi dall'API, ci somma i
tuoi COGS e calcola margine, ROAS e ROAS di break-even. Dashboard live + report
giornaliero/settimanale.
→ `FinanceKPI-Pacchetto/`

### 🎠 Carousel Builder
Trasforma qualsiasi documento/ebook in un carosello Instagram pronto (10 slide
1080×1350): copy + immagine di copertina AI + caption, renderizzati in PNG su
template brandizzabile.
→ `CarouselBuilder-Pacchetto/`

### ✍️ Creative Strategist
Uno stratega creativo + copywriter direct-response: produce hook, copy per ads,
sezioni landing/PDP, email, script VSL e ricerca di angoli, partendo dal file di
verità del tuo brand + un canone di framework di marketing. Migliora nel tempo
con un loop winners/losers.
→ `CreativeStrategist-Pacchetto/`

---

## Note

- Ogni agente richiede le **tue** credenziali (token Shopify, email, Telegram,
  chiavi AI) — si mettono in un file `.env` durante l'installazione (vedi il
  SETUP.md del singolo prodotto).
- Tutti i pacchetti sono puliti: nessun dato personale, solo esempi generici.
- Il codice non include `node_modules`/dipendenze: si rigenerano in fase di
  installazione (`npm install` / `pip install`).

---

*AI Agents Suite — agenti AI self-hosted, in italiano, a casa tua.*
