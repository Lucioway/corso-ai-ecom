# Disclaimer — AI Agents Suite

**Leggi prima di installare e usare.**

---

## Cosa sono questi agenti

Gli agenti contenuti in questa suite sono strumenti software **creati con
l'intelligenza artificiale**. Sono stati progettati, sviluppati e **testati sul
mio dispositivo**, per i **miei processi** e per le **mie aziende**.

Non sono prodotti industriali certificati: sono strumenti reali che uso io,
condivisi così come sono.

## Possibili problemi

Trattandosi di software costruito con l'AI e provato nel mio contesto specifico,
**potrebbero contenere errori, bug o comportarsi in modo imprevisto** sul tuo
sistema, con le tue configurazioni, i tuoi dati o i tuoi fornitori/servizi.

Ogni ambiente è diverso: ciò che funziona perfettamente da me potrebbe richiedere
aggiustamenti da te.

## Te li do gratis

**Sto condividendo questi agenti gratuitamente.** Non c'è alcun pagamento, alcun
abbonamento e alcun obbligo. Sono un dono "così com'è" (*as is*).

## Nessuna garanzia · uso a tuo rischio

- Il software è fornito **"COSÌ COM'È", senza alcuna garanzia** di funzionamento,
  affidabilità, idoneità a uno scopo o assenza di errori.
- **Tu sei l'unico responsabile** dell'installazione, della configurazione (incluse
  le tue credenziali e chiavi API), dell'uso e di qualsiasi conseguenza derivante.
- Prima di usarli su dati o account reali, **provali in sicurezza** (modalità di
  prova / `--dry-run` dove disponibile) e fai un backup.
- **LCWY LLC e l'autore non sono responsabili** per eventuali danni diretti o
  indiretti, perdite di dati, costi, interruzioni di servizio o problemi con
  piattaforme di terze parti (Shopify, email, Telegram, fornitori, ecc.)
  derivanti dall'uso di questi agenti.

## Servizi e piattaforme di terze parti

Alcuni agenti si collegano a servizi esterni (es. Shopify, Gmail, Telegram,
fornitori, API AI). Sei tu a dover rispettare i **termini di servizio** e i
limiti di quelle piattaforme, e a fornire le tue credenziali. Io non ho accesso
ai tuoi dati: tutto gira sul **tuo** sistema.

## Onestà di fondo

Te lo dico apertamente: sono strumenti che funzionano per me, te li passo gratis
perché possano essere utili anche a te. Se trovano un problema, fa parte del
gioco di un software dato gratuitamente e da personalizzare sul proprio caso.

---

*AI Agents Suite — © 2026 LCWY LLC. Software fornito gratuitamente e "così com'è".
Usandolo, accetti questo disclaimer.*
