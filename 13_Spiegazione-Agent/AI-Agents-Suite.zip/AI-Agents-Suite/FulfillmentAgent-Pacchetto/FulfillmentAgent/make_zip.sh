#!/usr/bin/env bash
# Build the FulfillmentAgent distributable zip.
# Run from the FulfillmentAgent-Template root.
set -euo pipefail

DIST="dist"
ZIP="$DIST/fulfillmentagent.zip"
STAGING=$(mktemp -d)

# ── Allowlist (only known-shippable paths) ─────────────────────────────────────
SHIP=(
    "scripts/config.py"
    "scripts/fulfill.py"
    "scripts/fulfill_from_email.py"
    "scripts/daily_fulfill.py"
    "scripts/email_watcher_tracking.py"
    "scripts/carrier_detect.py"
    "scripts/batch_validator.py"
    "scripts/shopify_fulfillment.py"
    "scripts/tracking_parser.py"
    "scripts/test_tracking_parser.py"
    "requirements.txt"
    ".env.example"
    ".gitignore"
    "README.md"
    "LICENSE.txt"
)

echo "→ Staging to $STAGING"
for f in "${SHIP[@]}"; do
    if [ ! -f "$f" ]; then
        echo "  MISSING: $f" && exit 1
    fi
    mkdir -p "$STAGING/$(dirname "$f")"
    cp "$f" "$STAGING/$f"
done

# ── Manifest leak-grep (hard fail on brand strings) ───────────────────────────
echo "→ Checking for brand leaks..."
if grep -rniE "your-brand|your-store-handle|supplier@|/Users/yourname" "$STAGING/" \
    --include="*.py" --include="*.md" --include="*.txt" --include="*.yaml" 2>/dev/null; then
    echo "❌ Brand leak detected — fix before shipping"
    rm -rf "$STAGING"
    exit 1
fi
echo "  ✅ No brand leaks"

# ── Build zip ─────────────────────────────────────────────────────────────────
mkdir -p "$DIST"
rm -f "$ZIP"
(cd "$STAGING" && zip -r - .) > "$ZIP"
rm -rf "$STAGING"

COUNT=$(unzip -l "$ZIP" | tail -1 | awk '{print $2}')
SIZE=$(du -sh "$ZIP" | cut -f1)
echo "→ Built $ZIP  ($COUNT files, $SIZE)"

# ── Smoke: unzip to /tmp + py_compile ─────────────────────────────────────────
TMPDIR=$(mktemp -d)
unzip -q "$ZIP" -d "$TMPDIR"
python3 -m compileall -q "$TMPDIR/scripts/"
echo "  ✅ py_compile OK"
rm -rf "$TMPDIR"

echo "Done → $ZIP"
