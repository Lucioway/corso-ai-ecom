#!/usr/bin/env python3
"""Daily fulfillment runner (18:00 via launchd).

For each recent order-date not yet fulfilled, pull the supplier's tracking email
and fulfill. Telegram-ping when the supplier hasn't sent the file or a batch errors.
Successful fulfillments are logged but don't ping (per request).

Run from FulfillmentAgent root:  python scripts/daily_fulfill.py
Self-check:                      python scripts/daily_fulfill.py --selfcheck

ponytail: subprocess-per-date reuse of fulfill_from_email.py + stdlib-only
telegram, instead of importing internals or adding deps.
"""
import glob
import json
import re
import subprocess
import sys
import urllib.parse
import urllib.request
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent          # FulfillmentAgent/
SCRIPT = ROOT / "scripts" / "fulfill_from_email.py"
ENV = ROOT / ".env"
PY = sys.executable
WINDOW_DAYS = 7
DATE_RE = re.compile(r"(\d{4}-\d{2}-\d{2})\.xlsx$")
COUNT_RE = re.compile(r"(\d+) ok / (\d+)")


def _env(key):
    for line in ENV.read_text().splitlines():
        line = line.strip()
        if line.startswith(key + "="):
            return line.split("=", 1)[1].strip()
    return None


def telegram(text):
    tok, chat = _env("TELEGRAM_BOT_TOKEN"), _env("TELEGRAM_CHAT_ID")
    if not (tok and chat):
        print("[daily] telegram creds missing — skip notify")
        return
    data = urllib.parse.urlencode(
        {"chat_id": chat, "text": text, "parse_mode": "HTML"}
    ).encode()
    try:
        urllib.request.urlopen(
            f"https://api.telegram.org/bot{tok}/sendMessage", data=data, timeout=15
        )
    except Exception as e:
        print(f"[daily] telegram error: {e}")


def fulfilled_dates():
    """Order-dates already fulfilled, from log source_xlsx names (…_YYYY-MM-DD.xlsx)."""
    done = set()
    for lf in glob.glob(str(ROOT / "logs" / "fulfill_email_*.json")):
        try:
            src = json.load(open(lf)).get("source_xlsx", "")
        except Exception:
            continue
        m = DATE_RE.search(src)
        if m:
            done.add(m.group(1))
    return done


def run_date(d):
    """Run fulfill for one date. Returns (status, detail)."""
    p = subprocess.run(
        [PY, str(SCRIPT), "--date", d], cwd=str(ROOT),
        capture_output=True, text=True, timeout=1800,
    )
    out = p.stdout + p.stderr
    if p.returncode == 3:
        return "not_sent", None
    if p.returncode == 0:
        m = COUNT_RE.search(out)
        return "ok", (m.group(1) if m else "?")
    tail = out.strip().splitlines()[-1] if out.strip() else ""
    return "problem", f"exit {p.returncode}: {tail[:200]}"


def main():
    done = fulfilled_dates()
    today = date.today()
    # ponytail: today included so the 18:00 run flags a same-day no-show from supplier.
    candidates = [(today - timedelta(days=i)).isoformat() for i in range(WINDOW_DAYS)]
    ok_lines, not_sent, problems = [], [], []
    for d in sorted(candidates):
        if d in done:
            continue
        status, detail = run_date(d)
        if status == "ok":
            ok_lines.append(f"{d}: {detail} fulfilled")
        elif status == "not_sent":
            not_sent.append(d)
        else:
            problems.append(f"{d}: {detail}")

    parts = ["📦 <b>Fulfillment giornaliero</b>"]
    if ok_lines:
        parts.append("✅ Fulfillati:\n" + "\n".join(ok_lines))
    if not_sent:
        parts.append("📭 Supplier has not sent tracking for:\n" + "\n".join(not_sent))
    if problems:
        parts.append("🚨 Problemi:\n" + "\n".join(problems))

    msg = "\n\n".join(parts)
    print(msg)
    # Ping only when there's something to act on: supplier missing or a batch errored.
    if not_sent or problems:
        telegram(msg)


def _selfcheck():
    assert DATE_RE.search("Tracking__Orders_1000-1200_2024-01-15.xlsx").group(1) == "2024-01-15"
    assert COUNT_RE.search("📊 179 ok / 0 failed-or-skipped (total 179)").group(1) == "179"
    print("selfcheck ok")


def _agentos_heartbeat(_id):
    """TCC-safe last-run marker for Agent OS dashboard (launchd can't read ~/Documents)."""
    try:
        import datetime, pathlib
        d = pathlib.Path("/tmp/fulfillmentagent/heartbeats"); d.mkdir(parents=True, exist_ok=True)
        (d / _id).write_text(datetime.datetime.now().isoformat())
    except Exception:
        pass


if __name__ == "__main__":
    if "--selfcheck" in sys.argv:
        _selfcheck()
    else:
        import atexit; atexit.register(_agentos_heartbeat, "fulfill")
        main()
