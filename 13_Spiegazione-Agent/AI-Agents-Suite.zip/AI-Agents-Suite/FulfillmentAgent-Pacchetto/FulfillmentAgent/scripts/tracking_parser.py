"""Supplier tracking XLSX parser.

Expected format — a 2-column XLSX:
    col A: order number (optionally prefixed; default prefix '#', e.g. '#24714')
    col B: tracking number (e.g. 'LP1000047089555CN')

Header rows are auto-skipped. Common header variants seen across batches:
    - ('Name', 'Tracking #')
    - ('NO.', 'tracking number')
    - (20260508, None) then ('NO.', 'tracking number')

The order-id prefix is configurable via ORDER_ID_PREFIX (config.py / env).
When a prefix is set (default '#'): a row is a data row when col A starts with
that prefix; the prefix is stripped from the order number.
When the prefix is empty (""): a row is a data row when col B is a valid tracking
number AND col A is a non-empty, non-header token.
"""

import openpyxl
from pathlib import Path
from typing import Iterator

from config import ORDER_ID_PREFIX

# Reject obviously invalid trackings sometimes used as placeholders.
INVALID_TOKENS = {"#N/A", "N/A", "NA", "0", "-", "TBD", "PENDING", ""}

# Header words to reject in the order-id column when no prefix is configured.
_HEADER_TOKENS = {
    "no.", "no", "name", "order", "order #", "order number", "order no",
    "tracking", "tracking #", "tracking number",
}


def _is_valid_tracking(t: str) -> bool:
    if not t:
        return False
    if t.upper() in INVALID_TOKENS:
        return False
    # Must have at least 6 alphanumeric chars (real trackings are >=10)
    return len(t) >= 6 and any(c.isalnum() for c in t)


def _sheet_has_data(ws, prefix: str) -> bool:
    """True if the first 20 rows of ws contain a plausible data row."""
    for row in ws.iter_rows(values_only=True, max_row=20):
        if not row or len(row) < 2:
            continue
        a, b = row[0], row[1]
        if a is None:
            continue
        a_str = str(a).strip()
        if prefix:
            if a_str.startswith(prefix):
                return True
        else:
            b_str = str(b).strip() if b is not None else ""
            if (
                a_str
                and a_str.lower() not in _HEADER_TOKENS
                and _is_valid_tracking(b_str)
            ):
                return True
    return False


def parse(xlsx_path: Path) -> list[tuple[str, str]]:
    """Return list of (order_number, tracking_number).
    Skips invalid placeholder trackings (#N/A, 0, etc.) and header rows silently.
    Caller can compare len(parse(...)) vs raw row count to detect skips.
    """
    prefix = ORDER_ID_PREFIX
    wb = openpyxl.load_workbook(xlsx_path, read_only=True, data_only=True)
    # Pick the sheet that actually contains order rows. Some batches put data in
    # 'Orders_<range>_<date>' and leave 'Sheet1' empty.
    chosen = None
    for ws in wb.worksheets:
        if _sheet_has_data(ws, prefix):
            chosen = ws
            break
    if chosen is None:
        chosen = wb["Sheet1"] if "Sheet1" in wb.sheetnames else wb.worksheets[0]
    ws = chosen
    out: list[tuple[str, str]] = []
    for row in ws.iter_rows(values_only=True):
        if not row or len(row) < 2:
            continue
        a, b = row[0], row[1]
        if a is None or b is None:
            continue
        a_str = str(a).strip()
        b_str = str(b).strip()

        if prefix:
            if not a_str.startswith(prefix):
                continue
            order_num = a_str.lstrip(prefix).strip()
        else:
            # No prefix: rely on a valid tracking + a non-header order token.
            if a_str.lower() in _HEADER_TOKENS:
                continue
            order_num = a_str

        if not order_num:
            continue
        if not _is_valid_tracking(b_str):
            continue
        out.append((order_num, b_str))
    wb.close()
    return out


def parse_iter(xlsx_path: Path) -> Iterator[tuple[str, str]]:
    """Streaming variant."""
    yield from parse(xlsx_path)
