"""Self-check for tracking_parser.py.

Run: python scripts/test_tracking_parser.py
"""
import os
import sys
import tempfile
from pathlib import Path

# Allow running from repo root or scripts/
sys.path.insert(0, str(Path(__file__).parent))
os.environ.setdefault("ORDER_ID_PREFIX", "#")

import openpyxl
from tracking_parser import parse, _is_valid_tracking


def _make_xlsx(rows: list[tuple]) -> Path:
    """Write rows to a temp XLSX and return its path."""
    wb = openpyxl.Workbook()
    ws = wb.active
    for row in rows:
        ws.append(row)
    p = Path(tempfile.mktemp(suffix=".xlsx"))
    wb.save(p)
    return p


def test_basic_prefix():
    p = _make_xlsx([
        ("Name", "Tracking #"),
        ("#1234", "LP100004708CN"),
        ("#1235", "SF123456789012"),
    ])
    result = parse(p)
    assert result == [("1234", "LP100004708CN"), ("1235", "SF123456789012")], result
    p.unlink()


def test_header_skipped():
    p = _make_xlsx([
        ("NO.", "tracking number"),
        ("#1234", "LP100004708CN"),
    ])
    result = parse(p)
    assert len(result) == 1
    assert result[0][0] == "1234"
    p.unlink()


def test_invalid_tracking_skipped():
    p = _make_xlsx([
        ("#1234", "#N/A"),
        ("#1235", "LP100004708CN"),
    ])
    result = parse(p)
    assert len(result) == 1
    assert result[0][0] == "1235"
    p.unlink()


def test_no_prefix_mode():
    import tracking_parser as tp
    original = tp.ORDER_ID_PREFIX
    tp.ORDER_ID_PREFIX = ""  # patch directly

    p = _make_xlsx([
        ("order", "tracking"),
        ("1234", "LP100004708CN"),
        ("1235", "SF123456789012"),
    ])
    result = tp.parse(p)
    assert len(result) == 2, f"expected 2 rows, got {result}"
    p.unlink()
    tp.ORDER_ID_PREFIX = original  # restore


def test_valid_tracking():
    assert _is_valid_tracking("LP100004708CN")
    assert _is_valid_tracking("1Z999AA10123456784")
    assert not _is_valid_tracking("")
    assert not _is_valid_tracking("N/A")
    assert not _is_valid_tracking("0")


if __name__ == "__main__":
    tests = [test_basic_prefix, test_header_skipped, test_invalid_tracking_skipped,
             test_no_prefix_mode, test_valid_tracking]
    failed = 0
    for t in tests:
        try:
            t()
            print(f"  ✅ {t.__name__}")
        except Exception as e:
            print(f"  ❌ {t.__name__}: {e}")
            failed += 1
    print(f"\n{'all pass' if not failed else f'{failed} FAILED'} ({len(tests)} tests)")
    sys.exit(failed)
