"""FulfillmentAgent CLI.

Usage:
    python fulfill.py <csv_path> [--dry-run] [--no-notify]

CSV format (header required):
    order_number,tracking_number
    1234,1Z999AA10123456784
    1235,JD014600003123456789

Behavior:
    - Looks up each order in Shopify
    - Auto-detects carrier from tracking number pattern
    - Creates fulfillment for ALL open fulfillment_orders of the order
    - Sends Shopify default shipping-confirmation email to customer (notify_customer=true)
    - Logs results to logs/fulfill_YYYY-MM-DD.log
    - Exits non-zero if any row failed
"""

import argparse
import csv
import json
import sys
from datetime import datetime
from pathlib import Path

from config import LOGS_DIR, TRACKING_URL_OVERRIDE, validate, ensure_dirs
from carrier_detect import detect
from shopify_fulfillment import (
    find_order_by_name,
    get_fulfillment_orders,
    create_fulfillment,
    check_connection,
)


def process_row(order_number: str, tracking_number: str, dry_run: bool, notify: bool) -> dict:
    """Process one CSV row. Returns result dict for logging."""
    result = {
        "order_number": order_number,
        "tracking_number": tracking_number,
        "status": "pending",
        "company": None,
        "url": None,
        "fulfillment_ids": [],
        "error": None,
    }

    company, url = detect(tracking_number)
    # Override URL with central template (e.g. your tracking app URL)
    if TRACKING_URL_OVERRIDE:
        url = TRACKING_URL_OVERRIDE.format(tracking=tracking_number)
    result["company"] = company
    result["url"] = url

    try:
        order = find_order_by_name(order_number)
        if not order:
            result["status"] = "skipped"
            result["error"] = "order not found"
            return result

        order_id = order["id"]
        fos = get_fulfillment_orders(order_id)
        open_fos = [fo for fo in fos if fo.get("status") in ("open", "in_progress", "scheduled")]

        if not open_fos:
            result["status"] = "skipped"
            result["error"] = f"no open fulfillment_orders (statuses: {[fo.get('status') for fo in fos]})"
            return result

        if dry_run:
            result["status"] = "dry-run"
            result["fulfillment_ids"] = [fo["id"] for fo in open_fos]
            return result

        for fo in open_fos:
            f = create_fulfillment(
                fulfillment_order_id=fo["id"],
                tracking_number=tracking_number,
                tracking_company=company,
                tracking_url=url,
                notify_customer=notify,
            )
            result["fulfillment_ids"].append(f.get("id"))

        result["status"] = "ok"
        return result

    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)
        return result


def main():
    ap = argparse.ArgumentParser(description="FulfillmentAgent — bulk fulfill from CSV")
    ap.add_argument("csv_path", help="Path to CSV with columns: order_number, tracking_number")
    ap.add_argument("--dry-run", action="store_true", help="Lookup only, don't create fulfillments")
    ap.add_argument("--no-notify", action="store_true", help="Don't send Shopify email to customer")
    args = ap.parse_args()

    csv_path = Path(args.csv_path)
    if not csv_path.exists():
        print(f"❌ CSV not found: {csv_path}", file=sys.stderr)
        sys.exit(2)

    validate()
    ensure_dirs()

    try:
        shop = check_connection()
        print(f"✅ Connected to Shopify: {shop}")
    except Exception as e:
        print(f"❌ Shopify connection failed: {e}", file=sys.stderr)
        sys.exit(2)

    notify = not args.no_notify
    print(f"⚙  dry_run={args.dry_run}  notify_customer={notify}")
    print()

    results = []
    with open(csv_path, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        # Normalize headers (strip + lowercase)
        reader.fieldnames = [h.strip().lower() for h in (reader.fieldnames or [])]
        required = {"order_number", "tracking_number"}
        if not required.issubset(set(reader.fieldnames)):
            print(f"❌ CSV missing required columns. Found: {reader.fieldnames}", file=sys.stderr)
            sys.exit(2)

        for i, row in enumerate(reader, 1):
            on = (row.get("order_number") or "").strip()
            tn = (row.get("tracking_number") or "").strip()
            if not on or not tn:
                print(f"  [{i}] skip — missing order_number or tracking_number")
                continue

            r = process_row(on, tn, args.dry_run, notify)
            results.append(r)
            icon = {"ok": "✅", "dry-run": "🔸", "skipped": "⚠️", "error": "❌", "pending": "…"}.get(r["status"], "?")
            extra = ""
            if r["error"]:
                extra = f" — {r['error']}"
            elif r["fulfillment_ids"]:
                extra = f" — fid={r['fulfillment_ids']}"
            print(f"  [{i}] {icon} #{on} → {r['company']} {tn}{extra}")

    # Log
    log_file = LOGS_DIR / f"fulfill_{datetime.now().strftime('%Y-%m-%d_%H%M%S')}.json"
    log_file.write_text(json.dumps(results, indent=2, ensure_ascii=False))
    print(f"\n📝 Log: {log_file}")

    ok = sum(1 for r in results if r["status"] in ("ok", "dry-run"))
    bad = sum(1 for r in results if r["status"] in ("error", "skipped"))
    print(f"📊 {ok} ok / {bad} failed-or-skipped (total {len(results)})")
    sys.exit(0 if bad == 0 else 1)


if __name__ == "__main__":
    main()
