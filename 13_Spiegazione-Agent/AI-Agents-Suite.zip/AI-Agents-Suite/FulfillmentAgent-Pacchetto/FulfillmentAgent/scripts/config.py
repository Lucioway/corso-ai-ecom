"""FulfillmentAgent config — Shopify creds + paths."""

import os
from pathlib import Path
from dotenv import load_dotenv

PROJECT_DIR = Path(__file__).resolve().parent.parent
INBOX_DIR = PROJECT_DIR / "inbox"
PROCESSED_DIR = PROJECT_DIR / "processed"
LOGS_DIR = PROJECT_DIR / "logs"

load_dotenv(PROJECT_DIR / ".env")

SHOPIFY_STORE_URL = os.getenv("SHOPIFY_STORE_URL", "").rstrip("/")
SHOPIFY_API_TOKEN = os.getenv("SHOPIFY_API_TOKEN", "")
SHOPIFY_API_VERSION = os.getenv("SHOPIFY_API_VERSION", "2024-10")

TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# Order id prefix used in your supplier tracking sheet (e.g. "#" for "#1234").
# Leave empty ("") if your order numbers are bare (e.g. "1234").
ORDER_ID_PREFIX = os.getenv("ORDER_ID_PREFIX", "#")

# Tracking URL override — when set, ALL fulfillments use this template instead of
# the carrier-specific URL from carrier_detect. Point it at your ParcelPanel /
# tracking app URL so every carrier (China Post, SF Express, YunExpress, Poste,
# UPS, etc.) shows in one branded UI. {tracking} is the placeholder.
# Empty ("") = use the carrier-detected URL instead.
TRACKING_URL_OVERRIDE = os.getenv(
    "TRACKING_URL_OVERRIDE",
    "",
)


def validate():
    missing = [k for k in ("SHOPIFY_STORE_URL", "SHOPIFY_API_TOKEN") if not os.getenv(k)]
    if missing:
        raise SystemExit(f"Missing env vars: {', '.join(missing)}")


def ensure_dirs():
    for d in (INBOX_DIR, PROCESSED_DIR, LOGS_DIR):
        d.mkdir(exist_ok=True)
