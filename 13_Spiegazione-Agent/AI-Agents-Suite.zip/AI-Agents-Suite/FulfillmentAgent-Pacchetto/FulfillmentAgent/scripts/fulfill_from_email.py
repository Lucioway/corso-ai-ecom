"""End-to-end orchestrator: pull supplier tracking email → parse → fulfill in Shopify.

Usage:
    python fulfill_from_email.py [--date YYYY-MM-DD] [--dry-run] [--no-notify] [--limit N]

Examples:
    # Test single (most recent batch, dry-run, only first row):
    python fulfill_from_email.py --dry-run --limit 1

    # Full real run for a specific supplier batch (date matches subject/filename):
    python fulfill_from_email.py --date 2026-05-11
"""

import argparse
import json
import sys
from datetime import datetime
from pathlib import Path

from config import LOGS_DIR, INBOX_DIR, validate, ensure_dirs
from email_watcher_tracking import fetch_latest_tracking_xlsx
from tracking_parser import parse as parse_tracking
from shopify_fulfillment import check_connection
from batch_validator import validate_batch, print_validation
from fulfill import process_row


def main():
    ap = argparse.ArgumentParser(description="Pull supplier tracking email → fulfill all orders")
    ap.add_argument("--date", help="Target date YYYY-MM-DD (must appear in email subject or filename)")
    ap.add_argument("--dry-run", action="store_true", help="Lookup only, no fulfillment")
    ap.add_argument("--no-notify", action="store_true", help="Don't email customer")
    ap.add_argument("--limit", type=int, default=0, help="Process only first N rows (0 = all)")
    ap.add_argument("--xlsx", help="Skip email pull, use this XLSX directly (for re-runs)")
    ap.add_argument("--force", action="store_true",
                    help="Skip batch validation (date/range/Shopify-sample). Use only if you know what you're doing.")
    ap.add_argument("--sample-size", type=int, default=3,
                    help="How many orders to sample-check vs Shopify processed_at (default 3)")
    args = ap.parse_args()

    validate()
    ensure_dirs()

    try:
        shop = check_connection()
        print(f"✅ Shopify connected: {shop}")
    except Exception as e:
        print(f"❌ Shopify connection failed: {e}", file=sys.stderr)
        sys.exit(2)

    # 1) Get the XLSX
    if args.xlsx:
        xlsx_path = Path(args.xlsx)
        if not xlsx_path.exists():
            print(f"❌ XLSX not found: {xlsx_path}", file=sys.stderr)
            sys.exit(2)
    else:
        xlsx_path = fetch_latest_tracking_xlsx(INBOX_DIR, target_date_iso=args.date)
        if not xlsx_path:
            print("❌ No tracking email found. Try --date YYYY-MM-DD or pass --xlsx PATH.", file=sys.stderr)
            sys.exit(3)

    # 2) Parse
    rows = parse_tracking(xlsx_path)
    print(f"📋 Parsed {len(rows)} (order, tracking) rows from {xlsx_path.name}\n")

    # 2b) Validate batch BEFORE any fulfillment (filename date + range + Shopify sample)
    if args.force:
        print("⚠️  --force passed: skipping batch validation\n")
    else:
        vres = validate_batch(xlsx_path, rows, user_date=args.date, sample_size=args.sample_size)
        print_validation(vres)
        if not vres.ok:
            print("❌ Batch validation FAILED — aborting (use --force to bypass)", file=sys.stderr)
            sys.exit(4)

    if args.limit and args.limit > 0:
        rows = rows[: args.limit]
        print(f"⚙  --limit {args.limit} → processing {len(rows)} rows")

    notify = not args.no_notify
    print(f"⚙  dry_run={args.dry_run}  notify_customer={notify}\n")

    # 3) Fulfill loop
    results = []
    for i, (on, tn) in enumerate(rows, 1):
        r = process_row(on, tn, args.dry_run, notify)
        results.append(r)
        icon = {"ok": "✅", "dry-run": "🔸", "skipped": "⚠️", "error": "❌"}.get(r["status"], "?")
        extra = f" — {r['error']}" if r["error"] else (f" — fid={r['fulfillment_ids']}" if r["fulfillment_ids"] else "")
        print(f"  [{i}/{len(rows)}] {icon} #{on} → {r['company']} {tn}{extra}")

    # 4) Log
    ts = datetime.now().strftime("%Y-%m-%d_%H%M%S")
    log_file = LOGS_DIR / f"fulfill_email_{ts}.json"
    log_file.write_text(json.dumps(
        {"source_xlsx": str(xlsx_path), "results": results}, indent=2, ensure_ascii=False
    ))
    print(f"\n📝 Log: {log_file}")

    ok = sum(1 for r in results if r["status"] in ("ok", "dry-run"))
    bad = sum(1 for r in results if r["status"] in ("error", "skipped"))
    print(f"📊 {ok} ok / {bad} failed-or-skipped (total {len(results)})")
    sys.exit(0 if bad == 0 else 1)


if __name__ == "__main__":
    main()
