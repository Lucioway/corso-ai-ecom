"""Carrier auto-detect from tracking number pattern.

Returns Shopify-canonical 'company' name. When company is in Shopify's known
list, Shopify auto-builds the tracking URL — no need to pass `url`. For the
ones it doesn't know natively (BRT), we pass `url` explicitly.
"""

import re
from typing import Optional

# Each rule: (regex, company, url_template_or_None)
# url_template uses {tracking} placeholder; None = let Shopify build it.
RULES = [
    # China Post: LP*CN, LZ*CN, RU*CN, etc. — Shopify knows "China Post"
    (re.compile(r"^[A-Z]{2}\d{8,16}CN$", re.I), "China Post", None),
    # SF Express International: SF + 12-13 digits
    (re.compile(r"^SF\d{10,16}$", re.I), "SF Express", "https://www.sf-express.com/sf-service-web/service/bills/{tracking}/routes"),
    # UPS: 1Z + 16 alphanumeric
    (re.compile(r"^1Z[0-9A-Z]{16}$", re.I), "UPS", None),
    # FedEx: 12 or 15 digits (broad — checked AFTER more specific patterns)
    # DHL Express: 10 digits, often starts with specific prefixes
    (re.compile(r"^JJD[0-9A-Z]+$", re.I), "DHL Express", None),
    (re.compile(r"^JD[0-9]{12,}$"), "YunExpress", "https://www.yuntrack.com/parcelTracking?id={tracking}"),
    # Poste Italiane (Raccomandata/Posta1/SDA): typical formats
    (re.compile(r"^(RR|CY|CP|RA|RB|RC|RD|RE|RF|RG|RH|RJ|RK|RL|RM|RN|RO|RQ|RS|RT|RU|RV|RW|RX|RY|RZ|LX|LZ|UV|EE|EM|EN|EP|EQ|ES|ET|EU|EV|EW|EX|EY|EZ)\d{9}IT$", re.I),
     "Poste Italiane", "https://www.poste.it/cerca/index.html#/risultati-spedizioni/{tracking}"),
    # SDA (Italy): 12 digits starting with 0 or 1, plus letter checksum sometimes
    (re.compile(r"^[0-9]{12,13}$"), "SDA", "https://www.sda.it/wps/portal/sdait/landing-tracking?locale=it&tracingNumber={tracking}"),
    # BRT (Italy): 12 digits starting with 0 (overlaps with SDA — order matters; BRT often passes via numero spedizione 12 digits)
    # GLS Italy: 12 digit numeric (sequence varies)
    # NOTE: Italian BRT/GLS/SDA all use numeric → ambiguous. Default falls to SDA above.
    # YunExpress: YT + digits
    (re.compile(r"^YT\d{10,}$"), "YunExpress", "https://www.yuntrack.com/parcelTracking?id={tracking}"),
    # USPS: 20 or 22 digits
    (re.compile(r"^9\d{19,21}$"), "USPS", None),
]


def detect(tracking: str) -> tuple[str, Optional[str]]:
    """Return (company, url_or_None). Falls back to ('Other', None)."""
    t = (tracking or "").strip().upper()
    if not t:
        return ("Other", None)
    for rgx, company, url_tpl in RULES:
        if rgx.match(t):
            url = url_tpl.format(tracking=t) if url_tpl else None
            return (company, url)
    return ("Other", None)
