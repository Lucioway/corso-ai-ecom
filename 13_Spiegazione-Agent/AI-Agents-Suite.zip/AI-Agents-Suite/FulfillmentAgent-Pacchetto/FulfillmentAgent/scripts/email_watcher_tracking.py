"""Gmail watcher: fetch supplier tracking attachments (XLSX with 'tracking' in name).

IMAP credentials are read from environment variables (set in .env):
    IMAP_HOST       — default: imap.gmail.com
    IMAP_PORT       — default: 993
    IMAP_USER       — your Gmail address (or any IMAP inbox)
    IMAP_PASSWORD   — Gmail App Password (or IMAP password)
    SUPPLIER_SENDER — supplier's FROM address used to filter emails
"""

import imaplib
import email
import os
import re
from datetime import datetime, timedelta
from email.header import decode_header
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv

load_dotenv(Path(__file__).resolve().parent.parent / ".env")


def _load_gmail_cfg() -> dict:
    return {
        "imap_host": os.getenv("IMAP_HOST", "imap.gmail.com"),
        "imap_port": int(os.getenv("IMAP_PORT", "993")),
        "gmail_address": os.getenv("IMAP_USER", ""),
        "app_password": os.getenv("IMAP_PASSWORD", ""),
        "supplier_sender": os.getenv("SUPPLIER_SENDER", ""),
    }


def _decode(s: Optional[str]) -> str:
    parts = decode_header(s or "")
    return " ".join(
        d.decode(c or "utf-8", errors="replace") if isinstance(d, bytes) else str(d)
        for d, c in parts
    )


def fetch_latest_tracking_xlsx(
    output_dir: Path,
    target_date_iso: Optional[str] = None,
    max_age_hours: int = 336,
) -> Optional[Path]:
    """Pull the most recent supplier email containing a 'tracking' XLSX attachment.

    Args:
        output_dir: where to save the file
        target_date_iso: YYYY-MM-DD; if set, requires it in subject OR filename
        max_age_hours: search window

    Returns: path to saved XLSX or None
    """
    cfg = _load_gmail_cfg()
    if not (cfg.get("gmail_address") and cfg.get("app_password")):
        print("[EmailWatcherTracking] Gmail creds missing — set IMAP_USER + IMAP_PASSWORD in .env")
        return None

    output_dir.mkdir(parents=True, exist_ok=True)

    host = cfg["imap_host"]
    port = cfg["imap_port"]
    sender = cfg["supplier_sender"]

    since = (datetime.now() - timedelta(hours=max_age_hours)).strftime("%d-%b-%Y")
    print(f"[EmailWatcherTracking] Connecting {cfg['gmail_address']}, since {since}, FROM {sender}")

    conn = imaplib.IMAP4_SSL(host, port)
    try:
        conn.login(cfg["gmail_address"], cfg["app_password"])
        conn.select("INBOX")
        search_criteria = f'(SINCE "{since}" FROM "{sender}")' if sender else f'(SINCE "{since}")'
        _, raw = conn.search(None, search_criteria)
        ids = raw[0].split()
        print(f"[EmailWatcherTracking] {len(ids)} supplier emails in window")

        # Newest first
        for mid in reversed(ids):
            _, data = conn.fetch(mid, "(RFC822)")
            msg = email.message_from_bytes(data[0][1])
            subj = _decode(msg.get("Subject", ""))
            for part in msg.walk():
                fn_raw = part.get_filename()
                if not fn_raw:
                    continue
                fn = _decode(fn_raw)
                fn_low = fn.lower()
                # Match "tracking" or common typos; exclude "price" files
                if "track" not in fn_low or "price" in fn_low:
                    continue
                if not (fn_low.endswith(".xlsx") or fn_low.endswith(".xls")):
                    continue
                if target_date_iso and target_date_iso not in subj and target_date_iso not in fn:
                    continue
                payload = part.get_payload(decode=True)
                if not payload:
                    continue
                safe = re.sub(r"[^\w\-_.]", "_", fn)
                outp = output_dir / safe
                outp.write_bytes(payload)
                print(f"[EmailWatcherTracking] Saved → {outp.name} ({len(payload):,} bytes) | subject: {subj[:60]}")
                return outp

        print("[EmailWatcherTracking] No tracking XLSX found in window")
        return None
    finally:
        try:
            conn.logout()
        except Exception:
            pass
