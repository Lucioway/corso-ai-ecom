"""Batch validator — sanity-check supplier XLSX before fulfilling.

Three checks:
  1) Filename date check — supplier XLSX filename contains YYYY-MM-DD.
     If user passed --date, must match.
  2) Order-range check — filename contains 'NNNN-NNNN'. All parsed order_numbers
     must fall inside that range. Catches mixed-batch corruption.
  3) Shopify date sample — fetch K random orders, check processed_at falls on the
     expected date in Europe/Rome timezone. Catches "supplier sent yesterday's tracking
     for today's orders" or any drift.

Returns ValidationResult(ok, target_date, range, reasons[]). Caller decides to abort.
"""

import random
import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional
from zoneinfo import ZoneInfo

from shopify_fulfillment import find_order_by_name

ROME_TZ = ZoneInfo("Europe/Rome")

DATE_RX = re.compile(r"(20\d{2}-\d{2}-\d{2})")
# Order range: support both "1234-5678" and "1234_to__5678" (older supplier batches)
RANGE_RX = re.compile(r"(\d{4,6})\s*(?:-|_+to_+)\s*(\d{4,6})")


@dataclass
class ValidationResult:
    ok: bool
    target_date: Optional[str] = None         # YYYY-MM-DD extracted from filename
    expected_range: Optional[tuple[int, int]] = None
    reasons: list[str] = field(default_factory=list)
    sampled_orders: list[dict] = field(default_factory=list)

    def add(self, reason: str):
        self.ok = False
        self.reasons.append(reason)


def _parse_filename(xlsx_path: Path) -> tuple[Optional[str], Optional[tuple[int, int]]]:
    """Return (date_iso, (range_lo, range_hi)) parsed from supplier filename, or (None, None)."""
    name = xlsx_path.name
    date_m = DATE_RX.search(name)
    range_m = RANGE_RX.search(name)
    target_date = date_m.group(1) if date_m else None
    expected_range = None
    if range_m:
        lo, hi = int(range_m.group(1)), int(range_m.group(2))
        expected_range = (min(lo, hi), max(lo, hi))
    return target_date, expected_range


def _processed_date_rome(order: dict) -> Optional[str]:
    """Return processed_at (or created_at fallback) as YYYY-MM-DD in Europe/Rome."""
    iso = order.get("processed_at") or order.get("created_at")
    if not iso:
        return None
    try:
        dt = datetime.fromisoformat(iso)
    except ValueError:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    return dt.astimezone(ROME_TZ).date().isoformat()


def validate_batch(
    xlsx_path: Path,
    parsed_rows: list[tuple[str, str]],
    user_date: Optional[str] = None,
    sample_size: int = 3,
    date_tolerance_days: int = 1,
) -> ValidationResult:
    """Run all checks. `user_date` = explicit --date arg, optional.

    `date_tolerance_days`: supplier batch date may legitimately be ±1 day off vs Shopify
    processed_at (orders processed near midnight). Default ±1 day window.
    """
    res = ValidationResult(ok=True)

    if not parsed_rows:
        res.add("No rows parsed from XLSX")
        return res

    # CHECK 1 — filename date (fallback to user_date for older supplier filename formats)
    target_date, expected_range = _parse_filename(xlsx_path)
    if not target_date and user_date:
        target_date = user_date
        print(f"   ⚠  filename has no date — using --date {user_date} as authority (older supplier format)")
    res.target_date = target_date
    res.expected_range = expected_range

    if not target_date:
        res.add(f"Could not extract YYYY-MM-DD from filename or --date: {xlsx_path.name}")
    elif user_date and user_date != target_date:
        res.add(f"--date {user_date} does NOT match filename date {target_date}")

    # CHECK 2 — order range
    if expected_range:
        lo, hi = expected_range
        # Allow tolerance: supplier sometimes includes 1-2 stragglers from neighboring batch
        out_of_range = []
        for on, _ in parsed_rows:
            try:
                num = int(on)
            except ValueError:
                continue
            if not (lo <= num <= hi):
                out_of_range.append(on)
        if out_of_range:
            res.add(
                f"{len(out_of_range)} order(s) out of expected range [{lo}-{hi}]: "
                f"{out_of_range[:5]}{'...' if len(out_of_range) > 5 else ''}"
            )
    else:
        res.add(f"Could not extract order range from filename: {xlsx_path.name}")

    # CHECK 3 — Shopify date sample
    if target_date:
        try:
            ref_date = datetime.fromisoformat(target_date).date()
        except ValueError:
            ref_date = None

        if ref_date:
            # Pick K random rows; always include first + last (boundaries)
            sample_idx = {0, len(parsed_rows) - 1}
            while len(sample_idx) < min(sample_size, len(parsed_rows)):
                sample_idx.add(random.randint(0, len(parsed_rows) - 1))

            mismatches = []
            for idx in sorted(sample_idx):
                on, _ = parsed_rows[idx]
                try:
                    order = find_order_by_name(on)
                except Exception as e:
                    res.add(f"Shopify lookup failed for #{on}: {e}")
                    continue
                if not order:
                    res.add(f"Order #{on} from XLSX not found in Shopify")
                    continue
                actual = _processed_date_rome(order)
                res.sampled_orders.append({
                    "order_number": on, "actual_date_rome": actual, "expected_date": target_date,
                })
                if not actual:
                    res.add(f"Order #{on}: no processed_at/created_at")
                    continue
                actual_date_obj = datetime.fromisoformat(actual).date()
                drift_days = abs((actual_date_obj - ref_date).days)
                if drift_days > date_tolerance_days:
                    mismatches.append(f"#{on} processed on {actual} (expected ~{target_date}, drift {drift_days}d)")
            if mismatches:
                res.add(
                    f"{len(mismatches)} sampled order(s) have processed_at outside ±{date_tolerance_days}d window: "
                    + " | ".join(mismatches)
                )

    return res


def print_validation(res: ValidationResult) -> None:
    print(f"🔍 Validation:")
    print(f"   target_date (filename):  {res.target_date}")
    print(f"   expected_range (filename): {res.expected_range}")
    if res.sampled_orders:
        print(f"   sampled orders ({len(res.sampled_orders)}):")
        for s in res.sampled_orders:
            mark = "✓" if s["actual_date_rome"] == s["expected_date"] else "?"
            print(f"     {mark} #{s['order_number']}  shopify={s['actual_date_rome']}  expected={s['expected_date']}")
    if res.ok:
        print(f"   ✅ all checks passed\n")
    else:
        print(f"   ❌ {len(res.reasons)} issue(s):")
        for r in res.reasons:
            print(f"     - {r}")
        print()
