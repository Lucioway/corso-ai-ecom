"""Shopify fulfillment client.

Modern flow (Shopify API 2022-07+):
  1) GET order by name (#1234)
  2) GET fulfillment_orders for that order
  3) For each open fulfillment_order, POST /fulfillments with tracking_info + notify_customer

Docs: https://shopify.dev/docs/api/admin-rest/2024-10/resources/fulfillment
"""

import requests
from typing import Optional
from config import SHOPIFY_STORE_URL, SHOPIFY_API_TOKEN, SHOPIFY_API_VERSION


def _headers():
    return {
        "X-Shopify-Access-Token": SHOPIFY_API_TOKEN,
        "Content-Type": "application/json",
    }


def _api(path: str) -> str:
    return f"{SHOPIFY_STORE_URL}/admin/api/{SHOPIFY_API_VERSION}{path}"


def find_order_by_name(name: str) -> Optional[dict]:
    """Lookup order by Shopify name (e.g. '1234' or '#1234').
    Returns the order dict or None.
    """
    n = name.lstrip("#").strip()
    # Shopify search supports name=#1234 (with #)
    url = _api("/orders.json")
    params = {"name": f"#{n}", "status": "any", "limit": 5}
    resp = requests.get(url, headers=_headers(), params=params, timeout=30)
    resp.raise_for_status()
    orders = resp.json().get("orders", [])
    if not orders:
        return None
    # Exact match on name
    for o in orders:
        if str(o.get("order_number")) == n or o.get("name") == f"#{n}":
            return o
    return orders[0]


def get_fulfillment_orders(order_id: int) -> list[dict]:
    """Get all fulfillment_orders for an order."""
    url = _api(f"/orders/{order_id}/fulfillment_orders.json")
    resp = requests.get(url, headers=_headers(), timeout=30)
    resp.raise_for_status()
    return resp.json().get("fulfillment_orders", [])


def create_fulfillment(
    fulfillment_order_id: int,
    tracking_number: str,
    tracking_company: str,
    tracking_url: Optional[str] = None,
    notify_customer: bool = True,
) -> dict:
    """POST /fulfillments — fulfills the FO and triggers Shopify notification."""
    url = _api("/fulfillments.json")
    tracking_info = {
        "number": tracking_number,
        "company": tracking_company,
    }
    if tracking_url:
        tracking_info["url"] = tracking_url

    body = {
        "fulfillment": {
            "message": "Spedito",
            "notify_customer": notify_customer,
            "tracking_info": tracking_info,
            "line_items_by_fulfillment_order": [
                {"fulfillment_order_id": fulfillment_order_id}
            ],
        }
    }
    resp = requests.post(url, headers=_headers(), json=body, timeout=30)
    if resp.status_code >= 400:
        raise RuntimeError(f"Shopify {resp.status_code}: {resp.text[:500]}")
    return resp.json().get("fulfillment", {})


def check_connection() -> str:
    """Quick sanity check — returns shop name."""
    resp = requests.get(_api("/shop.json"), headers=_headers(), timeout=10)
    resp.raise_for_status()
    return resp.json()["shop"]["name"]
