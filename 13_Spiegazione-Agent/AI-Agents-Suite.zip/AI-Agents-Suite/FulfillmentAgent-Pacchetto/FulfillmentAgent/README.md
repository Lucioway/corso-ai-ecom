# FulfillmentAgent

Bulk-fulfill Shopify orders from a supplier tracking XLSX or CSV.
Auto-detects carrier, posts fulfillment via Shopify Admin API, and optionally
triggers Shopify shipping-confirmation emails to customers.

## Quick start

```bash
# 1) Install dependencies
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 2) Configure
cp .env.example .env
# Edit .env — add your Shopify credentials + optional Telegram + email creds

# 3) Dry-run: looks up orders, doesn't fulfill
python scripts/fulfill.py inbox/test.csv --dry-run

# 4) Real run: fulfills + emails customer
python scripts/fulfill.py inbox/test.csv

# 5) Real run, suppress Shopify email
python scripts/fulfill.py inbox/test.csv --no-notify

# 6) End-to-end from supplier email (fetch XLSX → parse → fulfill)
python scripts/fulfill_from_email.py --dry-run
python scripts/fulfill_from_email.py --date 2026-06-23
```

## CSV format

Header required. Two columns:

```csv
order_number,tracking_number
1234,1Z999AA10123456784
1235,JD014600003123456789
```

## Supplier XLSX format

Two-column XLSX (col A = order number, col B = tracking number).
Header rows are auto-skipped. Example:

| Name    | Tracking #           |
|---------|----------------------|
| #1234   | LP100004708CN        |
| #1235   | SF123456789012       |

Set `ORDER_ID_PREFIX` in `.env` to match your supplier's format (default `#`).
Set to empty (`ORDER_ID_PREFIX=`) if order numbers have no prefix.

## Carrier auto-detection

See [scripts/carrier_detect.py](scripts/carrier_detect.py). Recognised:
- China Post (`LP*CN`, `LZ*CN`, `RU*CN`, etc.)
- SF Express (`SF…`)
- UPS (`1Z…`)
- DHL Express (`JJD…`)
- YunExpress (`JD…`, `YT…`)
- Poste Italiane (`RR…IT`, `LX…IT`, `EE…IT`, etc.)
- USPS (`9…` long)
- SDA (12–13 digits)
- Anything else → `Other` (Shopify accepts tracking without a link)

To add a carrier, append a rule to `RULES` in [scripts/carrier_detect.py](scripts/carrier_detect.py).

Set `TRACKING_URL_OVERRIDE` in `.env` to route all carriers through a single
tracking app (e.g. ParcelPanel, AfterShip). Use `{tracking}` as placeholder.

## Environment variables

Copy `.env.example` to `.env` and fill in:

| Variable | Required | Description |
|---|---|---|
| `SHOPIFY_STORE_URL` | ✅ | e.g. `your-store.myshopify.com` |
| `SHOPIFY_API_TOKEN` | ✅ | Admin API token (`shpat_…`) |
| `SHOPIFY_API_VERSION` | — | default `2024-10` |
| `IMAP_USER` | email flow | Gmail address for supplier email |
| `IMAP_PASSWORD` | email flow | Gmail App Password |
| `IMAP_HOST` | — | default `imap.gmail.com` |
| `IMAP_PORT` | — | default `993` |
| `SUPPLIER_SENDER` | — | supplier FROM address to filter on |
| `TELEGRAM_BOT_TOKEN` | — | for daily runner notifications |
| `TELEGRAM_CHAT_ID` | — | your Telegram chat ID |
| `ORDER_ID_PREFIX` | — | default `#`; set empty if bare order numbers |
| `TRACKING_URL_OVERRIDE` | — | e.g. `https://yourstore.com/apps/parcelpanel?nums={tracking}` |

## Required Shopify scopes

The Admin API token must have:
- `read_orders`
- `write_merchant_managed_fulfillment_orders`
- `write_third_party_fulfillment_orders` (only if using a 3PL app)
- `write_assigned_fulfillment_orders` (only if assigned location)

If you get a 403 on `POST /fulfillments`, the token is missing scopes — re-issue
in Shopify admin → Apps → your custom app → API credentials.

## Daily automated run

`scripts/daily_fulfill.py` is designed to run at 18:00 via launchd (macOS) or
cron. It checks the last 7 days for unfulfilled dates, pulls the supplier email,
and Telegram-pings you when the supplier hasn't sent tracking or a batch errors.

```bash
# Self-check
python scripts/daily_fulfill.py --selfcheck
```
