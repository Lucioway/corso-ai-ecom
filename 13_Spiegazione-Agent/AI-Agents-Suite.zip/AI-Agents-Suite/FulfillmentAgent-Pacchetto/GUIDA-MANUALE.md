# FulfillmentAgent — Guida Manuale

L'agente che evade in massa i tuoi ordini Shopify a partire dal foglio di tracking
del fornitore. Legge i numeri di tracciamento, riconosce il corriere, registra la
spedizione su Shopify e avvisa il cliente — in automatico. Gira sul tuo computer o
server, i tuoi dati restano tuoi.

---

## Indice

1. [Cos'è FulfillmentAgent](#1-cosè-fulfillmentagent)
2. [Requisiti](#2-requisiti)
3. [Installazione e primo avvio](#3-installazione-e-primo-avvio)
4. [Configurazione (.env)](#4-configurazione-env)
5. [Come funziona (il flusso)](#5-come-funziona-il-flusso)
6. [Comando 1 — Evadere da CSV](#6-comando-1--evadere-da-csv)
7. [Comando 2 — Evadere dall'email del fornitore](#7-comando-2--evadere-dallemail-del-fornitore)
8. [Comando 3 — Runner giornaliero](#8-comando-3--runner-giornaliero)
9. [Formati di input (CSV e XLSX)](#9-formati-di-input-csv-e-xlsx)
10. [Riconoscimento corriere](#10-riconoscimento-corriere)
11. [La validazione del lotto](#11-la-validazione-del-lotto)
12. [Notifiche al cliente e Telegram](#12-notifiche-al-cliente-e-telegram)
13. [Scheduling (avvio automatico)](#13-scheduling-avvio-automatico)
14. [Personalizzazione](#14-personalizzazione)
15. [Struttura dei file](#15-struttura-dei-file)
16. [Risoluzione problemi](#16-risoluzione-problemi)
17. [FAQ](#17-faq)

---

## 1. Cos'è FulfillmentAgent

È uno strumento da riga di comando (Python) che automatizza l'evasione degli
ordini su Shopify. Il problema che risolve: ogni giorno il fornitore ti manda un
foglio con i numeri di tracking, e tu dovresti aprire Shopify ordine per ordine,
incollare il tracking, scegliere il corriere e mandare la mail al cliente.
FulfillmentAgent fa tutto questo in blocco, in pochi secondi, per centinaia di
ordini.

Cosa fa, in concreto, per ogni riga (ordine + tracking):

1. Cerca l'ordine su Shopify per numero.
2. Riconosce il corriere dal pattern del tracking (China Post, SF Express, UPS,
   Poste Italiane, ecc.).
3. Crea il **fulfillment** su tutti i `fulfillment_orders` aperti dell'ordine.
4. (Opzionale) fa partire l'email di conferma spedizione di Shopify al cliente.
5. Scrive un log dettagliato in `logs/`.

Nessun database: gli input sono file, lo stato è nei log. Le credenziali stanno
solo in `.env`.

---

## 2. Requisiti

- **Python 3.10+** (usa `list[tuple]`, `zoneinfo`, dataclass moderne).
- **pip** e idealmente un **venv**.
- Un **negozio Shopify** con un'app custom e un **token Admin API** (`shpat_…`)
  con gli scope giusti (vedi §4).
- **Solo per il flusso email:** un account **Gmail/IMAP** con **App Password** e
  l'indirizzo email del fornitore.
- **Solo per le notifiche:** un **bot Telegram** (token + chat id).
- Sistema: macOS, Linux o Windows.

Dipendenze Python (in `requirements.txt`):
```
requests>=2.31.0
python-dotenv>=1.0.0
openpyxl>=3.1.0
```

---

## 3. Installazione e primo avvio

```bash
cd FulfillmentAgent
python3 -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env          # poi compila .env (vedi §4)
```

Verifica che tutto regga (non tocca Shopify):
```bash
python3 scripts/test_tracking_parser.py     # → "all pass (5 tests)"
python3 scripts/daily_fulfill.py --selfcheck # → "selfcheck ok"
```

Primo contatto con Shopify, **senza evadere nulla** (dry-run):
```bash
python3 scripts/fulfill.py inbox/test.csv --dry-run
```

---

## 4. Configurazione (.env)

Copia `.env.example` in `.env` e compila:

| Variabile | Obbligatoria | Descrizione |
|---|---|---|
| `SHOPIFY_STORE_URL` | ✅ | Es. `il-tuo-store.myshopify.com` |
| `SHOPIFY_API_TOKEN` | ✅ | Token Admin API (`shpat_…`) |
| `SHOPIFY_API_VERSION` | — | Default `2024-10` |
| `IMAP_HOST` | — | Default `imap.gmail.com` |
| `IMAP_PORT` | — | Default `993` |
| `IMAP_USER` | flusso email | Indirizzo Gmail/IMAP della casella |
| `IMAP_PASSWORD` | flusso email | App Password Gmail (non la password normale) |
| `SUPPLIER_SENDER` | — | Indirizzo FROM del fornitore su cui filtrare |
| `TELEGRAM_BOT_TOKEN` | — | Per le notifiche del runner giornaliero |
| `TELEGRAM_CHAT_ID` | — | La tua chat id Telegram |
| `ORDER_ID_PREFIX` | — | Default `#`; lascia vuoto se i numeri ordine sono nudi |
| `TRACKING_URL_OVERRIDE` | — | Instrada tutti i corrieri su un'unica app di tracking; usa `{tracking}` |

**Scope Shopify richiesti** sul token (Admin → Apps → la tua app custom → API
credentials):
- `read_orders`
- `write_merchant_managed_fulfillment_orders`
- `write_third_party_fulfillment_orders` (solo se usi un'app 3PL)
- `write_assigned_fulfillment_orders` (solo se location assegnata)

Se ottieni un **403** sul `POST /fulfillments`, al token mancano scope: rigeneralo.

> **App Password Gmail:** è una password dedicata, generata in
> Account Google → Sicurezza → Verifica in due passaggi → Password per le app.
> Serve perché Gmail non accetta la password normale via IMAP.

---

## 5. Come funziona (il flusso)

Ci sono **due modi** per dare in pasto i dati all'agente:

**A) CSV manuale** — hai già un file con ordini e tracking → `fulfill.py`.

**B) Email del fornitore** — il fornitore manda un'email con allegato XLSX →
`fulfill_from_email.py` lo scarica, lo valida e lo evade da solo.

Il flusso B, passo per passo:
```
email fornitore (IMAP)
   → email_watcher_tracking.py  (scarica l'allegato XLSX in inbox/)
   → tracking_parser.py         (estrae le coppie ordine,tracking)
   → batch_validator.py         (controlla data, range e campione Shopify)
   → fulfill.process_row()      (per ogni riga: trova ordine → crea fulfillment)
   → logs/fulfill_email_*.json
```

Il runner giornaliero (`daily_fulfill.py`) richiama il flusso B per ogni data
recente non ancora evasa e ti avvisa su Telegram in caso di problemi.

---

## 6. Comando 1 — Evadere da CSV

```bash
python3 scripts/fulfill.py <percorso_csv> [--dry-run] [--no-notify]
```

| Opzione | Effetto |
|---|---|
| (nessuna) | Evade e **invia** l'email di conferma al cliente |
| `--dry-run` | Cerca gli ordini ma **non** crea fulfillment (prova a vuoto) |
| `--no-notify` | Evade ma **non** invia l'email al cliente |

Esempio:
```bash
python3 scripts/fulfill.py inbox/test.csv --dry-run   # prova
python3 scripts/fulfill.py inbox/test.csv             # reale + email
```

Cosa fa per ogni riga: cerca l'ordine, salta se non trovato o se non ha
`fulfillment_orders` aperti, altrimenti crea il fulfillment su **tutti** quelli
aperti. Alla fine scrive `logs/fulfill_YYYY-MM-DD_HHMMSS.json` e stampa un
riepilogo `N ok / M failed-or-skipped`. **Esce con codice diverso da zero** se
almeno una riga è fallita o è stata saltata (utile per lo scripting).

---

## 7. Comando 2 — Evadere dall'email del fornitore

```bash
python3 scripts/fulfill_from_email.py [opzioni]
```

| Opzione | Effetto |
|---|---|
| `--date YYYY-MM-DD` | Cerca l'email/allegato di quella data (nel subject o nel nome file) |
| `--dry-run` | Nessun fulfillment, solo lookup |
| `--no-notify` | Non invia l'email al cliente |
| `--limit N` | Processa solo le prime N righe (test) |
| `--xlsx PERCORSO` | Salta l'email, usa direttamente questo XLSX (ri-run) |
| `--force` | Salta la validazione del lotto (usa con cautela) |
| `--sample-size N` | Quanti ordini campionare contro Shopify (default 3) |

Esempi:
```bash
# prova su una sola riga, senza evadere
python3 scripts/fulfill_from_email.py --dry-run --limit 1

# lotto reale per una data precisa
python3 scripts/fulfill_from_email.py --date 2024-01-15

# ri-evadi un file già scaricato, saltando l'email
python3 scripts/fulfill_from_email.py --xlsx inbox/Tracking_2024-01-15.xlsx
```

**Codici di uscita utili:** `0` ok · `2` connessione/credenziali · `3` nessuna
email di tracking trovata · `4` validazione del lotto fallita.

---

## 8. Comando 3 — Runner giornaliero

`scripts/daily_fulfill.py` è pensato per girare ogni giorno (es. 18:00) via
launchd/cron/Task Scheduler. Per ogni data degli ultimi **7 giorni** non ancora
evasa, lancia `fulfill_from_email.py --date <data>` e poi manda un riepilogo
Telegram **solo se c'è qualcosa da segnalare** (fornitore che non ha mandato il
tracking, oppure un lotto in errore). Le evasioni andate a buon fine vengono
loggate ma non generano ping.

```bash
python3 scripts/daily_fulfill.py             # esegue il giro completo
python3 scripts/daily_fulfill.py --selfcheck # test interno (no Shopify, no email)
```

Come capisce cosa è "già fatto": legge i file `logs/fulfill_email_*.json` e
ricava le date dal nome del file sorgente (`…_YYYY-MM-DD.xlsx`). Quelle date
vengono saltate. Scrive anche un heartbeat in `/tmp/fulfillmentagent/heartbeats/`
per dashboard di monitoraggio esterne.

---

## 9. Formati di input (CSV e XLSX)

### CSV (per `fulfill.py`)
Header obbligatorio, due colonne (gli header vengono normalizzati a minuscolo):
```csv
order_number,tracking_number
1234,1Z999AA10123456784
1235,JD014600003123456789
```

### XLSX del fornitore (per il flusso email)
Un foglio a 2 colonne: **col A = numero ordine**, **col B = numero tracking**.
Le righe di intestazione vengono saltate in automatico. Esempio:

| Name    | Tracking #        |
|---------|-------------------|
| #1234   | LP100004708CN     |
| #1235   | SF123456789012    |

- Se `ORDER_ID_PREFIX=#` (default): una riga è dati quando la col A inizia con `#`;
  il prefisso viene rimosso.
- Se `ORDER_ID_PREFIX=` (vuoto): una riga è dati quando la col B è un tracking
  valido e la col A non è una parola di intestazione.
- I tracking palesemente invalidi (`#N/A`, `N/A`, `0`, `-`, `TBD`, `PENDING`,
  vuoto) vengono scartati in silenzio.
- Il parser sceglie da solo il foglio giusto se il workbook ne ha più d'uno (alcuni
  fornitori lasciano `Sheet1` vuoto e mettono i dati in un foglio dal nome con
  data/range).

---

## 10. Riconoscimento corriere

`carrier_detect.py` riconosce il corriere dal pattern del numero di tracking e
restituisce il nome "canonico" per Shopify. Quando Shopify conosce il corriere,
costruisce da solo l'URL di tracking; per gli altri lo passiamo noi.

Corrieri riconosciuti:

| Corriere | Pattern (esempi) |
|---|---|
| China Post | `LP…CN`, `LZ…CN`, `RU…CN`, ecc. |
| SF Express | `SF` + 10–16 cifre |
| UPS | `1Z` + 16 alfanumerici |
| DHL Express | `JJD…` |
| YunExpress | `JD…`, `YT…` |
| Poste Italiane | `RR…IT`, `LX…IT`, `EE…IT`, ecc. |
| USPS | `9…` (20–22 cifre) |
| SDA | 12–13 cifre |
| Qualsiasi altro | → `Other` (Shopify accetta il tracking senza link) |

**Aggiungere un corriere:** apri `scripts/carrier_detect.py` e aggiungi una tupla
`(regex, "Nome Corriere", url_template_o_None)` alla lista `RULES`. Usa
`{tracking}` come segnaposto nell'URL. Le regole più specifiche vanno **prima**
(es. i numeri italiani 12 cifre di SDA/BRT/GLS sono ambigui: l'ordine conta).

**Override globale:** imposta `TRACKING_URL_OVERRIDE` in `.env` per far passare
**tutti** i corrieri attraverso un'unica app di tracking (ParcelPanel, AfterShip),
es. `https://il-tuo-store.com/apps/parcelpanel?nums={tracking}`.

---

## 11. La validazione del lotto

Prima di evadere, il flusso email passa per `batch_validator.py`, che fa tre
controlli per evitare disastri (es. "il fornitore ha mandato il tracking di ieri
per gli ordini di oggi"):

1. **Data dal nome file** — l'XLSX deve contenere `YYYY-MM-DD` nel nome. Se hai
   passato `--date`, deve coincidere.
2. **Range ordini** — se il nome file contiene un range `NNNN-NNNN`, tutti i
   numeri ordine parsati devono cadere dentro quel range (intercetta lotti misti).
3. **Campione su Shopify** — preleva K ordini a campione (primo + ultimo + casuali)
   e verifica che il loro `processed_at` cada sulla data attesa, fuso
   **Europe/Rome**, con tolleranza ±1 giorno (per gli ordini a cavallo della
   mezzanotte).

Se un controllo fallisce, l'esecuzione si **interrompe** (exit code `4`). Puoi
forzare con `--force`, ma fallo solo se sai cosa stai facendo.

---

## 12. Notifiche al cliente e Telegram

**Email al cliente (Shopify):** quando crei un fulfillment con
`notify_customer=true` (comportamento di default, disattivabile con `--no-notify`),
Shopify invia la sua email standard di conferma spedizione, con corriere, tracking
e link. Il messaggio interno del fulfillment è impostato su "Spedito".

**Telegram (runner):** `daily_fulfill.py` manda un riepilogo al gruppo/chat
configurato **solo quando serve**: fornitore che non ha inviato il tracking
(`📭`) o lotto in errore (`🚨`). Le evasioni riuscite vengono elencate solo se ci
sono altri motivi per il messaggio. Le credenziali sono `TELEGRAM_BOT_TOKEN` e
`TELEGRAM_CHAT_ID` in `.env`; se mancano, il runner salta la notifica e lo segnala
a video.

---

## 13. Scheduling (avvio automatico)

Per far girare il runner giornaliero da solo (es. 18:00):

- **macOS (launchd):** crea un `.plist` in `~/Library/LaunchAgents/` con
  `ProgramArguments` = [python del venv, percorso assoluto di
  `scripts/daily_fulfill.py`], `WorkingDirectory` = la cartella `FulfillmentAgent`,
  e uno `StartCalendarInterval` alle 18:00.
- **Linux (cron):** `0 18 * * * cd /percorso/FulfillmentAgent && .venv/bin/python
  scripts/daily_fulfill.py`.
- **Windows (Task Scheduler):** azione = `.venv\Scripts\python.exe
  scripts\daily_fulfill.py`, "Start in" = cartella del progetto, trigger
  giornaliero.

Usa sempre il **path assoluto** del Python del venv e imposta la working
directory sulla cartella del progetto (gli script risolvono i percorsi a partire
da lì). Verifica la logica con `--selfcheck` prima di schedularla.

---

## 14. Personalizzazione

| Voglio… | Dove |
|---|---|
| Cambiare il prefisso dei numeri ordine | `.env` → `ORDER_ID_PREFIX` |
| Usare una sola app di tracking per tutti | `.env` → `TRACKING_URL_OVERRIDE` |
| Aggiungere un corriere | `scripts/carrier_detect.py` → lista `RULES` |
| Cambiare il messaggio del fulfillment | `scripts/shopify_fulfillment.py` → campo `"message"` (ora "Spedito") |
| Allargare/stringere la finestra del runner | `scripts/daily_fulfill.py` → `WINDOW_DAYS` (default 7) |
| Cambiare la tolleranza sulla data del lotto | `scripts/batch_validator.py` → `date_tolerance_days` |
| Filtrare un mittente fornitore diverso | `.env` → `SUPPLIER_SENDER` |

Tutto il resto (store, token, credenziali) sta in `.env`: niente da toccare nel
codice per la configurazione normale.

---

## 15. Struttura dei file

```
FulfillmentAgent/
  scripts/
    fulfill.py                  # CLI evasione da CSV
    fulfill_from_email.py       # orchestratore end-to-end (email → fulfill)
    daily_fulfill.py            # runner giornaliero + Telegram
    email_watcher_tracking.py   # watcher IMAP/Gmail dell'allegato XLSX
    tracking_parser.py          # parser XLSX a 2 colonne
    carrier_detect.py           # riconoscimento corriere
    batch_validator.py          # validazione lotto (data/range/campione)
    shopify_fulfillment.py      # client Shopify Admin API
    config.py                   # carica .env + percorsi + validate()
    test_tracking_parser.py     # self-check del parser (5 test)
  inbox/        # input scaricati/manuali (creata al primo run)
  processed/    # file lavorati (creata al primo run)
  logs/         # log JSON delle esecuzioni (creata al primo run)
  .env.example  # template credenziali (copia in .env)
  .gitignore    # esclude .env, inbox/, logs/, *.xlsx, ecc.
  requirements.txt
  README.md
  LICENSE.txt
  make_zip.sh   # builder del distribuibile (uso interno)
```

`inbox/`, `processed/` e `logs/` vengono create automaticamente da `ensure_dirs()`
al primo avvio. `.env`, gli XLSX e i log **non** vanno mai nel repo (sono in
`.gitignore`).

---

## 16. Risoluzione problemi

| Problema | Soluzione |
|---|---|
| `Missing env vars: SHOPIFY_…` | `.env` assente o incompleto. Copia `.env.example` e compila store + token. |
| `❌ Shopify connection failed` | URL store o token errati. Controlla `SHOPIFY_STORE_URL` (senza `https://`) e il token. |
| **403** sul fulfillment | Al token mancano gli scope. Rigeneralo con `write_merchant_managed_fulfillment_orders` (vedi §4). |
| "order not found" | Il numero ordine non esiste o il prefisso è sbagliato. Controlla `ORDER_ID_PREFIX`. |
| "no open fulfillment_orders" | L'ordine è già evaso o non è evadibile. Normale: viene saltato. |
| "No tracking email found" (exit 3) | Nessuna email del fornitore nella finestra. Prova `--date` o passa `--xlsx`. |
| "Gmail creds missing" | Imposta `IMAP_USER` + `IMAP_PASSWORD` (App Password) in `.env`. |
| Validazione fallita (exit 4) | Data/range/campione non tornano. Controlla il file; in casi noti usa `--force`. |
| Telegram non arriva | Mancano `TELEGRAM_BOT_TOKEN`/`TELEGRAM_CHAT_ID`, oppure non c'è nulla da segnalare. |
| Righe scartate dal parser | Tracking placeholder (`#N/A`, `0`…) o righe di intestazione: è voluto. |

---

## 17. FAQ

**Devo evadere subito per davvero?**
No, e non dovresti. Fai sempre prima un `--dry-run`: cerca gli ordini ma non crea
nulla. Quando il dry-run è pulito, lancia il run reale.

**Il cliente riceve l'email di spedizione?**
Sì, di default (`notify_customer=true`). Disattivala con `--no-notify`. È l'email
standard di Shopify, non una mail dell'agente.

**Cosa succede se evado due volte lo stesso ordine?**
Shopify non lo ri-evade: l'ordine non ha più `fulfillment_orders` aperti, quindi
la riga viene saltata. È idempotente.

**Funziona senza il flusso email?**
Sì. Puoi usare solo `fulfill.py` con un CSV tuo, senza configurare IMAP/Gmail.

**Posso usarlo con più store?**
Ogni installazione punta a uno store (le credenziali sono in `.env`). Per più
store, tieni una cartella/`.env` separato per ciascuno.

**Quali corrieri supporta?**
China Post, SF Express, UPS, DHL Express, YunExpress, Poste Italiane, USPS, SDA, e
"Other" per tutto il resto. Ne aggiungi altri in `carrier_detect.py` (§10).

**I miei dati vanno nel cloud?**
No. Gira sul tuo computer/server. L'unica chiamata esterna è verso Shopify (Admin
API), Gmail (IMAP, solo se usi il flusso email) e Telegram (solo se attivi le
notifiche).

---

*FulfillmentAgent v1.0 — evasione ordini Shopify automatica, self-hosted.*
