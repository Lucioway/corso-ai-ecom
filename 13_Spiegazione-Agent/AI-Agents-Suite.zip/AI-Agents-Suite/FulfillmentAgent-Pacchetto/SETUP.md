# SETUP — Istruzioni per Claude Code

> **Per l'utente:** apri Claude Code, dai accesso a questa cartella e scrivi:
> *"Leggi SETUP.md e installa FulfillmentAgent nel mio sistema, fatto bene,
> deve essere production-grade e vendibile — controlla tutto."*
> Claude farà il resto seguendo questo file.

---

## Cosa stai installando

**FulfillmentAgent** — un agente self-hosted che **evade in massa gli ordini
Shopify** a partire dal foglio di tracking del fornitore. Legge i numeri di
tracciamento (da un'email del fornitore con allegato XLSX, oppure da un CSV/XLSX
locale), riconosce automaticamente il corriere, registra la spedizione su
Shopify tramite Admin API e — se vuoi — fa partire l'email di conferma spedizione
al cliente. Può girare anche da solo ogni giorno a un orario fisso e avvisarti su
Telegram quando il fornitore non ha mandato il tracking o un lotto va in errore.

| Componente | A cosa serve |
|---|---|
| `scripts/fulfill.py` | Evasione da CSV (`order_number,tracking_number`) |
| `scripts/fulfill_from_email.py` | Flusso end-to-end: scarica email fornitore → parse XLSX → valida → evade |
| `scripts/daily_fulfill.py` | Runner giornaliero (es. 18:00) con notifica Telegram |
| `scripts/email_watcher_tracking.py` | Watcher IMAP/Gmail per l'allegato di tracking |
| `scripts/tracking_parser.py` | Parser dell'XLSX a 2 colonne (ordine, tracking) |
| `scripts/carrier_detect.py` | Riconoscimento corriere dal pattern del tracking |
| `scripts/batch_validator.py` | Validazione del lotto prima di evadere (data/range/campione Shopify) |
| `scripts/shopify_fulfillment.py` | Client Shopify Admin API (ricerca ordine + crea fulfillment) |

Tutto è **stateless**: nessun database. Gli input vivono in `inbox/`, i log in
`logs/`. Le credenziali stanno solo in `.env` (mai committato).

**Documentazione completa:** `GUIDA-MANUALE.md` in questa cartella — leggila per
capire ogni comando, opzione, corriere supportato e personalizzazione.

Il codice completo è nella sottocartella **`FulfillmentAgent/`**.

---

## Il tuo compito (Claude Code)

Installa, configura e verifica FulfillmentAgent **a regola d'arte**, pronto per
essere usato e venduto. Adatta ogni comando, percorso e launcher all'ambiente
reale (macOS / Linux / Windows / server cloud) senza chiedere conferme banali.

### Fase 0 — Rileva l'ambiente
- Sistema operativo, versione di **Python 3.10+**, presenza di `pip`/`venv`.
- Verifica se l'utente vuole il flusso **email** (serve un account Gmail/IMAP con
  App Password) o solo il flusso **CSV/XLSX manuale**.
- Verifica se vuole le **notifiche Telegram** (serve un bot token + chat id).

### Fase 1 — Installa le dipendenze
```bash
cd FulfillmentAgent
python3 -m venv .venv && source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
```
Dipendenze: `requests`, `python-dotenv`, `openpyxl`. Nient'altro.

### Fase 2 — Configura `.env`
```bash
cp .env.example .env
```
Compila in `.env`:
- **Obbligatorie:** `SHOPIFY_STORE_URL` (es. `il-tuo-store.myshopify.com`) e
  `SHOPIFY_API_TOKEN` (token Admin API `shpat_…`).
- **Flusso email (opzionale):** `IMAP_USER`, `IMAP_PASSWORD` (App Password Gmail),
  `SUPPLIER_SENDER` (l'indirizzo FROM del fornitore da filtrare).
- **Telegram (opzionale):** `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`.
- **Comportamento:** `ORDER_ID_PREFIX` (default `#`; vuoto se i numeri ordine sono
  nudi tipo `1234`), `TRACKING_URL_OVERRIDE` (per instradare tutti i corrieri su
  un'unica app di tracking come ParcelPanel/AfterShip; usa `{tracking}` come
  segnaposto).

Token Shopify — **scope richiesti** (Admin → Apps → app custom → API credentials):
`read_orders`, `write_merchant_managed_fulfillment_orders`, e se usi un 3PL anche
`write_third_party_fulfillment_orders` / `write_assigned_fulfillment_orders`.

### Fase 3 — Verifica (NON saltare)
```bash
cd FulfillmentAgent
python3 scripts/test_tracking_parser.py        # deve stampare "all pass (5 tests)"
python3 scripts/daily_fulfill.py --selfcheck   # deve stampare "selfcheck ok"
python3 -m compileall -q scripts/              # deve uscire 0
```
Poi verifica la connessione Shopify con un **dry-run** (non evade nulla):
```bash
# prepara un CSV di prova con 1-2 ordini reali ancora da evadere:
#   order_number,tracking_number
#   1234,1Z999AA10123456784
python3 scripts/fulfill.py inbox/test.csv --dry-run
```
Atteso: `✅ Connected to Shopify: <nome store>` e per ogni riga un `🔸 dry-run`
con corriere riconosciuto. Se vedi un **403** sul fulfillment, mancano gli scope
del token — torna alla Fase 2.

### Fase 4 — Primo run reale (con consenso dell'utente)
```bash
# evade + invia email al cliente
python3 scripts/fulfill.py inbox/test.csv
# evade SENZA email al cliente
python3 scripts/fulfill.py inbox/test.csv --no-notify
```
Flusso da email del fornitore:
```bash
python3 scripts/fulfill_from_email.py --dry-run --limit 1     # prova su 1 riga
python3 scripts/fulfill_from_email.py --date 2024-01-15       # lotto reale per data
```

### Fase 5 — Scheduling (se richiesto)
Cabla `scripts/daily_fulfill.py` per girare ogni giorno (es. 18:00):
- **macOS** → launchd (un `.plist` in `~/Library/LaunchAgents/`)
- **Linux** → cron oppure systemd timer
- **Windows** → Task Scheduler

Usa il **path assoluto** del Python del venv e imposta la working directory sulla
cartella `FulfillmentAgent/`. Verifica con:
```bash
python3 scripts/daily_fulfill.py --selfcheck
```

### Fase 6 — Controllo qualità finale (must)
- **Sicurezza:** nessuna chiave hardcoded; `.env` NON committato (è in
  `.gitignore`); il token Shopify ha solo gli scope necessari.
- **Pulizia dati:** `inbox/`, `processed/`, `logs/` partono vuote; nessun file
  `.xlsx`/`.csv` reale di terzi nel pacchetto (`grep -ri` non deve trovare nomi
  store, fornitori o ordini reali).
- **Dry-run prima del reale:** mai evadere senza un dry-run andato a buon fine.
- **Idempotenza:** un ordine già evaso viene saltato da Shopify; il
  `batch_validator` blocca lotti con data/range sbagliati (puoi forzare con
  `--force` solo consapevolmente).

### Fase 7 — Consegna
Scrivi un breve report all'utente: cosa è attivo, come fare un dry-run, come
evadere per davvero, se/come è schedulato il run giornaliero, e qualsiasi cosa che
richieda la sua attenzione (es. App Password Gmail, scope del token, bot Telegram).

---

## Regole

- **Production-grade:** niente scorciatoie, niente passi saltati. Se una verifica
  non passa, fermati e sistemala prima di proseguire.
- **Adatta all'OS:** comandi, percorsi e launcher cambiano per sistema — fallo
  senza chiedere.
- **Mai evadere senza dry-run:** è denaro e spedizioni reali. Prima `--dry-run`,
  poi reale.
- **Non inventare dati:** store, fornitore e ordini reali li fornisce l'utente; tu
  prepari la struttura e verifichi che tutto regga.
- **Leggi la Guida Manuale** per ogni dettaglio (corrieri, formati XLSX,
  validazione, troubleshooting) prima di cambiare comportamenti.

---

*Pacchetto FulfillmentAgent v1.0 — pronto per l'installazione.*
