# ONBOARD.md — rendi questa HUD tua

Questo file è uno script di intervista per Claude Code. Quando un utente lancia
`claude` in un clone fresco (senza `.jarvis-config.json`), Claude legge questo
file e lo guida nella personalizzazione — una domanda alla volta, applicando le
modifiche man mano che arrivano le risposte. Anche una persona può seguirlo a
mano: ogni punto di personalizzazione è elencato nell'Edit Manifest in fondo.

**Tutto ciò che è rivolto all'utente deve essere in italiano.**

## Come condurre l'intervista (istruzioni per Claude)

**Step 0 — rileva la piattaforma in silenzio.** Controlla il sistema operativo
prima della prima domanda e adatta TUTTO senza chiedere: comandi shell, path,
scelta dei launcher (.vbs vs nohup/launchd/systemd), il set di pip del
voice-server (Windows/Linux + NVIDIA → `onnxruntime-gpu` + wheel `nvidia-*`;
Mac o senza GPU NVIDIA → `onnxruntime` semplice, e segnala che la voce gira in
CPU, più lenta ma funzionante). Non mostrare mai un comando Windows a un utente
Mac o viceversa. Su Mac, nota che HUD/runner/onboarding sono identici — cambia
solo la velocità della voce.

**Step 0.5 — installa le dipendenze.** Se manca `node_modules/` (su un clone
fresco manca: le dipendenze non vengono mai incluse nello zip), esegui ora
`npm install`, prima delle domande. Di' all'utente che stai installando mentre
inizi l'intervista. Si assume che la CLI `claude` sia già installata e con login
fatto.

Fai UNA domanda alla volta. Dopo ogni risposta, applica subito la modifica
(riga di env o edit del file secondo il manifest), conferma in una frase breve e
prosegui. Consiglia un default per ogni domanda. Alla fine esegui i controlli di
accettazione, poi scrivi `.jarvis-config.json` (forma in fondo) e spiega
all'utente come avviare tutto.

### Le domande, in ordine

1. **Posizione del vault.** "Dove vuoi che viva il tuo vault — la cartella di
   file piatti che tutto legge e scrive? Default: continua a usare lo
   `starter-vault/` incluso per ora (puoi spostarlo dopo). Se usi già un vault
   Obsidian, puntalo lì." → Imposta `VAULT_ROOT` in `~/.claude/.env`. Se punta a
   un vault esistente, crea al suo interno `system/queue`, `system/runs`,
   `system/metrics`, `daily-notes`, `inbox/reports/morning` e copia
   `starter-vault/system/schemas/daily-note.md`.
2. **Fuso orario.** "Qual è il fuso orario di 'oggi' per te?" (nome IANA, es.
   Europe/Rome). → `HUD_TZ` in `~/.claude/.env`. Avvisa: HUD e runner leggono la
   stessa variabile; non impostarle mai in modo diverso.
3. **Il tuo nome.** "Come deve riferirsi a te il layer vocale nelle sue note?"
   → `HUD_USER_NAME` in `~/.claude/.env`.
4. **Obsidian.** "Usi Obsidian su questo vault? Se sì, qual è il nome del vault
   (il nome cartella così come lo mostra Obsidian)?" → Se sì:
   `NEXT_PUBLIC_OBSIDIAN_VAULT=<nome>` in `.env.local` nella root del repo
   (variabile build-time). Se no: salta — il deep link resta nascosto.
5. **Metriche Vitals.** "Il pannello Vitals legge `system/metrics/metrics.csv`
   (colonne: timestamp,source,metric,value,status,error). I dati di partenza
   sono finti. Cosa vuoi davvero a schermo — iscritti YouTube? Stelle GitHub?
   Vendite? Tutto ciò che riesci a scrivere in quel CSV funziona." → Aiutalo a
   abbozzare un piccolo script (cron/Task Scheduler) che appende righe; offriti
   di scriverlo. Aggiorna `SOCIAL_DEFS` in `components/HUD.tsx` se le sue fonti
   non sono youtube/instagram.
6. **Focus del morning report.** "La skill morning-report fa ricerca sul tuo
   campo ogni giorno. Qual è il tuo settore?" → Modifica il prompt
   `morning-report` in `runner/runner.js` (la frase sullo scope della ricerca).
   Fai `node --check` dopo.
7. **Triage email.** "Vuoi la skill inbox-brief? Richiede il connettore Gmail di
   Anthropic abilitato nel tuo account Claude." → Se no, rimuovi `inbox-brief`
   da `ALLOWED_SKILLS` (lib/skills.ts), `DECK_SKILLS` (components/HUD.tsx) e dal
   case del runner — tutti e tre, vedi le couplings.
8. **Calendario.** "Vuoi che plan-today peschi dal tuo Google Calendar? Richiede
   il connettore Google Calendar di Anthropic." → Se no, segnala che plan-today
   funziona comunque, solo senza l'agenda.
9. **Voce.** "La voce richiede un server Python locale (gratis, offline). La
   configuriamo ora o dopo?" → Se ora: segui la sezione di setup del
   voice-server nel README.md (venv, pip install), poi scegli la voce TTS
   (variabili nel server). Se dopo: la HUD funziona benissimo in silenzio.
10. **Cervello del router.** "Per un routing vocale più preciso degli intent
    puoi aggiungere una chiave API Anthropic (~$0.002 per richiesta ambigua) e/o
    far girare un piccolo modello locale via Ollama (gratis, offline). Funziona
    anche solo a regole." → `ANTHROPIC_API_KEY` in `~/.claude/.env` — **il FILE,
    mai una variabile d'ambiente di Windows**, altrimenti ogni sessione
    interattiva `claude` passa dalla fatturazione ad abbonamento a quella API.
    Ollama: installa + `ollama pull qwen3.5:4b`.
11. **Modello del runner.** "Su quale modello Claude devono girare le skill in
    background? Default opus — l'output migliore per report e ricerca. Lo vuoi
    più economico? Scegli sonnet (buono, molto più economico) o haiku (il più
    veloce ed economico). Puoi anche dire a Claude Code di cambiarlo in qualsiasi
    momento." → `AGENTIC_OS_MODEL` in `~/.claude/.env` (`claude-opus-4-8` /
    `claude-sonnet-4-6` / `claude-haiku-4-5-20251001`).
12. **Skill esistenti.** Scansiona la cartella skill installate dell'utente
    (`~/.claude/skills/` su Mac/Linux, `%USERPROFILE%\.claude\skills\` su
    Windows). Se ne esistono, elencale per nome + la `description` del loro
    SKILL.md e chiedi: "Ho trovato queste skill già sulla tua macchina — ne vuoi
    qualcuna fissata al command deck e al layer vocale?" Per ognuna scelta, collega
    TUTTI i punti di coupling (vedi la riga Skill roster nell'Edit Manifest):
    aggiungi il nome a `ALLOWED_SKILLS` (lib/skills.ts) e `DECK_SKILLS`
    (components/HUD.tsx), un path in `deliverablePathFor()`
    (`inbox/reports/<skill>/<data>-<id8>.md` è un default sicuro) e un case in
    `buildPrompt()` il cui prompt è `${AUTONOMOUS_PREFIX}` + "Run the /<skill>
    skill. Write the result at exactly ${deliverable} ... End your reply with:
    SAVED ${deliverable}" (lascia che la loro skill installata faccia il lavoro —
    `claude -p` headless può invocarla). `node --check runner/runner.js` dopo.
    **Avvisa per ognuna:** il flusso del deck (pannello Documenti, callout dei
    doc, riepilogo parlato) funziona solo se la skill scrive un artefatto
    markdown nel suo path di vault e la sua prima riga di risposta è una frase
    conversazionale — una skill che dipende da script locali, API private o stato
    esterno può andare in coda ma non produrre nulla. Se non trovi skill, salta
    questa domanda in silenzio.
13. **Avvio automatico.** "Vuoi che Jarvis parta al login — HUD, runner e
    voice-server?" → Windows: scorciatoie a `start-hud.vbs`,
    `runner/start-runner.vbs`, `voice-server/start-voice-server.vbs` in
    `shell:startup` (esegui prima `npx next build` così il launcher della HUD usa
    il server di produzione veloce). Mac/Linux: offri plist launchd / unit
    systemd. Se rifiuta: digli che dire "spin up Jarvis" in qualsiasi sessione
    `claude` qui avvia tutto su richiesta.

### Controlli di accettazione (eseguili, mostra i risultati)

```
npm test                      # sweep del router — deve passare al 100%
npx tsc --noEmit              # pulito
npx next dev -p 3107          # poi:
curl http://localhost:3107/api/state           # 200 JSON, metriche presenti
curl http://localhost:3107/api/speak           # {"ok":true,"engine":"edge"} se la voce è su,
                                               # {"ok":false} (graceful) se non lo è
node --check runner/runner.js                  # dopo OGNI edit del runner
node runner/runner.js  (terminale separato)    # heartbeat: vault system/runner-status.json
```

Round trip vocale (se la voce è configurata): tieni premuto Spazio nella HUD,
di' "cosa c'è in coda" — risposta parlata entro ~1s. NON testare MAI con una
frase di comando ("esegui l'inbox brief") — metterebbe in coda un run reale.

### Chiusura

Scrivi `.jarvis-config.json` nella root del repo:

```json
{
  "onboarded": "<data ISO>",
  "vault": "<valore di VAULT_ROOT>",
  "timezone": "<HUD_TZ>",
  "voice": true,
  "router": "rules|haiku|local|auto",
  "skills": ["morning-report", "inbox-brief", "plan-today", "plan-tomorrow", "vault-cleanup", "voice-ask"]
}
```

Poi di' all'utente: `npx next dev -p 3107` per la HUD,
`node runner/runner.js` per il runner, voice-server come da README. Fatto.

---

## Edit Manifest — ogni punto di personalizzazione

| Cosa | File · simbolo | Come |
|---|---|---|
| Path del vault | `lib/config.ts` `VAULT_ROOT` (legge env) | `VAULT_ROOT` in `~/.claude/.env` |
| Fuso orario | `lib/config.ts` `HUD_TZ` + `runner/runner.js` `HUD_TZ` | `HUD_TZ` in `~/.claude/.env` (una variabile, la leggono entrambi) |
| Il tuo nome | `lib/config.ts` `USER_NAME` | env `HUD_USER_NAME` |
| URL voice server | `lib/config.ts` `VOICE_SERVER_URL`; client WS in `lib/voiceClient.ts` | env `VOICE_SERVER_URL` + `NEXT_PUBLIC_VOICE_WS` in `.env.local` |
| Deep link Obsidian | `components/ReportOverlay.tsx` `OBSIDIAN_VAULT` | `NEXT_PUBLIC_OBSIDIAN_VAULT` in `.env.local` |
| Brand | cartella `starter-vault/jarvis-os/brand-os/<id>/os.json` | crea/modifica il manifest; valida con `python3 -m jarvis_os.validate` |
| Roster delle skill | `lib/skills.ts` `ALLOWED_SKILLS` ⟷ `runner/runner.js` `buildPrompt()`+`deliverablePathFor()` ⟷ `components/HUD.tsx` `DECK_SKILLS` | modifica tutti e tre insieme |
| Alias vocali per le skill | `lib/router.ts` `SKILL_ALIASES` | regex per skill |
| Offerte parlate (**load-bearing**) | `lib/router.ts` `briefingOffer()` ⟷ chiavi `OFFER_SKILLS` ⟷ regex `pendingOffer()` | la frase dell'offerta viene riletta verbatim quando l'utente dice "sì" — cambia tutti e tre insieme o "sì" smette di funzionare |
| Focus del morning report | `runner/runner.js` case `morning-report` | modifica la frase sullo scope della ricerca; `node --check` dopo |
| Pannelli Vitals | `components/HUD.tsx` `SOCIAL_DEFS` | allinea alle fonti del tuo metrics.csv |
| Voce TTS | `voice-server/server.py` via `EDGE_VOICE` | scegli una voce edge-tts (es. `it-IT-GiuseppeNeural`) |
| Bias vocab STT | `voice-server/server.py` `WHISPER_PROMPT` | elenca i TUOI acronimi + nomi delle skill |
| Wake word | `voice-server/start-voice-server.vbs` `WAKE_WORD` | off di default (rientro dello speaker); cuffie consigliate |
| Modello del runner | `runner/runner.js` `CLAUDE_MODEL` | env `AGENTIC_OS_MODEL`; allowlist per-richiesta in `MODEL_ALLOWLIST` |
| Frasi trigger del rundown | `lib/router.ts` `BRIEFING_RE` | ancorate all'intera frase — tienile così |

**Regole dure che sopravvivono a ogni personalizzazione**
- Il runner lancia `claude -p` con `--dangerously-skip-permissions` — i run
  headless sono non interattivi, quindi la modalità permessi di default
  NEGHEREBBE in silenzio la scrittura del deliverable. Il runner esegue solo
  prompt di skill self-contained contro il vault dell'utente su localhost. Non
  rimuoverla o le skill non producono report.
- `ANTHROPIC_API_KEY` vive solo come voce nel FILE `~/.claude/.env`.
- I run del runner passano sempre un `--model` esplicito.
- `node --check runner/runner.js` dopo ogni edit del runner.
- HUD e runner devono concordare su `VAULT_ROOT` e `HUD_TZ`.
- Solo localhost — non bindare mai HUD o voice-server su 0.0.0.0; gli endpoint
  di mutazione non hanno auth by design.
