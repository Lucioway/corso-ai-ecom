#!/usr/bin/env python3
"""Agent status → vault/system/agents.json (manifest-driven).

Source of truth = the agent manifests under `starter-vault/jarvis-os/`
(platform/agents + brand-os/*/agents). For backend agents this reads
`launchctl list` exit codes + each agent's heartbeat/log mtime; frontend-only
agents (backend null) are treated as links → status "ok", no launchd check.
The HUD's /api/agents serves the produced agents.json; the AutoAgents panel
renders one mini-sphere per agent (green=ok, red=error, dim=stale).

Run:  python3 agents_status.py
"""
import json, subprocess, datetime as dt, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
OUT = HERE / "starter-vault" / "system" / "agents.json"
MANIFESTS = HERE / "starter-vault" / "jarvis-os"
STALE_H = 30   # daily agents older than this with no run = stale


def load_manifests():
    """Load agent manifests from disk. Skips os.json (no scope / has
    roadmap_stage) and malformed files (warns to stderr, never crashes)."""
    paths = list((MANIFESTS / "platform" / "agents").glob("*.json"))
    paths += list(MANIFESTS.glob("brand-os/*/agents/*.json"))
    manifests = []
    for p in sorted(paths):
        try:
            m = json.loads(p.read_text(encoding="utf-8"))
        except (ValueError, OSError) as e:
            print(f"WARN: skip {p} (parse error: {e})", file=sys.stderr)
            continue
        if not isinstance(m, dict) or "roadmap_stage" in m or "scope" not in m:
            # os.json or non-agent manifest → not an agent
            continue
        manifests.append(m)
    return manifests


def launchctl_exit(label):
    try:
        out = subprocess.run(["launchctl", "list"], capture_output=True, text=True, timeout=10).stdout
    except Exception:
        return False, None
    for line in out.splitlines():
        p = line.split("\t")
        if len(p) == 3 and p[2].strip() == label:
            return True, (None if p[1].strip() == "-" else int(p[1]))
    return False, None


def humanize(ts):
    h = (dt.datetime.now() - ts).total_seconds() / 3600
    if h < 1:  return f"{int(h*60)} min fa"
    if h < 24: return f"{int(h)}h fa"
    return f"{int(h//24)}g fa"


def last_run(backend):
    """Resolve last-run datetime from a backend dict: heartbeat ISO file first,
    then mtime path stat, then None."""
    hb = backend.get("heartbeat")
    if hb and Path(hb).exists():
        try:
            return dt.datetime.fromisoformat(Path(hb).read_text().strip())
        except (ValueError, OSError):
            pass
    mp = backend.get("mtime")
    if mp and Path(mp).exists():
        try:
            return dt.datetime.fromtimestamp(Path(mp).stat().st_mtime)
        except OSError:
            pass
    return None


def main():
    now = dt.datetime.now()
    rows = []
    for m in load_manifests():
        scope = m["scope"]
        brand = "all" if scope == "shared" else "overview" if scope == "overview" else scope
        backend = m.get("backend")

        if backend is None:
            # link / frontend-only agent
            status = "ok"
            code = None
            run_dt = None
        else:
            loaded, code = launchctl_exit(backend["launchd"])
            run_dt = last_run(backend)
            if not loaded:
                status = "off"
            elif code not in (0, None):
                status = "error"
            elif run_dt and (now - run_dt).total_seconds() / 3600 > STALE_H:
                status = "stale"
            else:
                status = "ok"

        fe = m.get("frontend")
        url = fe["url"] if fe else None

        rows.append({
            "id": m["id"], "label": m["label"], "brief": m.get("brief", ""),
            "sched": m.get("schedule", ""),
            "status": status,
            "last_run": humanize(run_dt) if run_dt else "—",
            "exit": code,
            "url": url,
            "brand": brand,
        })

    rows.sort(key=lambda r: (r["brand"], r["id"]))
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps({"updated": now.isoformat(), "agents": rows}, ensure_ascii=False, indent=2))
    for r in rows:
        print(f"{r['status']:6} {r['label']:16} last={r['last_run']:9} {r['brief']}")


if __name__ == "__main__":
    main()
