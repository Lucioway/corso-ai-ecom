import fs from "fs";
import path from "path";
import { VAULT_ROOT } from "./config";

// Task planner state — plain JSON under the vault, same as everything else.
// One file, all brands; the UI filters by brand. Five fields the user asked
// for: cosa (text), stato (status: done/doing/todo), quando (start), entro
// quando (due).

export type TaskStatus = "todo" | "doing" | "done";
// A brand id (slug) — brands are declarative (os.json manifests), so this is
// any lowercase slug, not a fixed union.
export type TaskBrand = string;

export interface Task {
  id: string;
  brand: TaskBrand;
  text: string;
  status: TaskStatus;
  start: string | null; // YYYY-MM-DD — quando farlo
  due: string | null; // YYYY-MM-DD — entro quando
  created: string; // ISO
}

const FILE = path.join(VAULT_ROOT, "system", "tasks.json");

export function readTasks(): Task[] {
  try {
    const raw = fs.readFileSync(FILE, "utf-8");
    const data = JSON.parse(raw);
    return Array.isArray(data?.tasks) ? data.tasks : [];
  } catch {
    return [];
  }
}

function writeTasks(tasks: Task[]): void {
  fs.mkdirSync(path.dirname(FILE), { recursive: true });
  fs.writeFileSync(FILE, JSON.stringify({ tasks }, null, 2));
}

const STATUSES: TaskStatus[] = ["todo", "doing", "done"];
const ymd = /^\d{4}-\d{2}-\d{2}$/;
// a valid brand id is any lowercase slug (matches the manifest scope rule)
const slug = /^[a-z0-9]+(?:[-_][a-z0-9]+)*$/;

export function addTask(input: {
  brand: unknown;
  text: unknown;
  start?: unknown;
  due?: unknown;
}): Task | null {
  const brand = String(input.brand ?? "").trim() as TaskBrand;
  const text = String(input.text ?? "").trim();
  if (!slug.test(brand) || !text) return null;
  const start = typeof input.start === "string" && ymd.test(input.start) ? input.start : null;
  const due = typeof input.due === "string" && ymd.test(input.due) ? input.due : null;
  const tasks = readTasks();
  const task: Task = {
    id: `t_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`,
    brand,
    text: text.slice(0, 300),
    status: "todo",
    start,
    due,
    created: new Date().toISOString(),
  };
  tasks.push(task);
  writeTasks(tasks);
  return task;
}

export function updateTask(
  id: string,
  patch: { status?: unknown; text?: unknown; start?: unknown; due?: unknown }
): boolean {
  const tasks = readTasks();
  const t = tasks.find((x) => x.id === id);
  if (!t) return false;
  if (STATUSES.includes(patch.status as TaskStatus)) t.status = patch.status as TaskStatus;
  if (typeof patch.text === "string" && patch.text.trim()) t.text = patch.text.trim().slice(0, 300);
  if (patch.start !== undefined)
    t.start = typeof patch.start === "string" && ymd.test(patch.start) ? patch.start : null;
  if (patch.due !== undefined)
    t.due = typeof patch.due === "string" && ymd.test(patch.due) ? patch.due : null;
  writeTasks(tasks);
  return true;
}

export function deleteTask(id: string): boolean {
  const tasks = readTasks();
  const next = tasks.filter((x) => x.id !== id);
  if (next.length === tasks.length) return false;
  writeTasks(next);
  return true;
}
