"""Self-check assert-based per lo schema dei manifest JARVIS AI OS.

Eseguibile sia con pytest sia direttamente:
    python3 -m jarvis_os.test_validate   # stampa "ALL OK", exit 0
Copre happy path + ogni caso di rifiuto del contratto.
"""

import json
from pathlib import Path

from .schema import validate_agent, validate_brand_os

EXAMPLES_DIR = Path(__file__).resolve().parent / "examples"


# --- fixtures inline (dict validi minimi) -----------------------------------

def _good_agent() -> dict:
    return {
        "id": "k",
        "label": "K",
        "scope": "shared",
        "kind": "tool",
        "backend": None,
        "frontend": {"url": "http://127.0.0.1:3100"},
        "schedule": "live",
    }


def _good_brand_os() -> dict:
    return {
        "id": "acme",
        "label": "Acme",
        "target_daily_eur": 1000,
        "roadmap_stage": 5,
    }


# --- agent tests ------------------------------------------------------------

def test_valid_agent_passes():
    assert validate_agent(_good_agent()) == []


def test_bad_scope_rejected():
    # scope con spazi non e uno slug valido
    a = _good_agent()
    a["scope"] = "tutti i brand"
    errs = validate_agent(a)
    assert errs and "scope" in " ".join(errs)


def test_overview_scope_valid():
    a = _good_agent()
    a["scope"] = "overview"
    assert validate_agent(a) == []


def test_arbitrary_brand_scope_valid():
    # un brand id qualsiasi (slug lowercase) e uno scope valido — zero edit al codice
    a = _good_agent()
    a["scope"] = "mybrand"
    assert validate_agent(a) == []
    a["scope"] = "brand-2"
    assert validate_agent(a) == []


def test_uppercase_scope_rejected():
    a = _good_agent()
    a["scope"] = "Acme"  # maiuscole non ammesse in uno slug
    errs = validate_agent(a)
    assert errs and "scope" in " ".join(errs)


def test_backend_optional_heartbeat_mtime_valid():
    a = _good_agent()
    a["scope"] = "acme"
    a["backend"] = {"launchd": "com.x.y", "health": None, "mtime": "/tmp/x.log"}
    a["frontend"] = None
    assert validate_agent(a) == []
    a["backend"] = {"launchd": "com.x.y", "heartbeat": "/tmp/hb"}
    assert validate_agent(a) == []


def test_bad_kind_rejected():
    a = _good_agent()
    a["kind"] = "robot"
    errs = validate_agent(a)
    assert errs and "kind" in " ".join(errs)


def test_backend_only_and_frontend_only_both_valid():
    # frontend:null (backend-only)
    backend_only = {
        "id": "worker",
        "label": "Worker",
        "scope": "acme",
        "kind": "scheduled",
        "backend": {"launchd": "com.example.worker", "health": None},
        "frontend": None,
        "schedule": "00:01 · 07 · 10 · 14",
    }
    # backend:null (frontend-only)
    frontend_only = _good_agent()  # backend already None, frontend set
    assert validate_agent(backend_only) == []
    assert validate_agent(frontend_only) == []


def test_both_null_rejected():
    a = _good_agent()
    a["backend"] = None
    a["frontend"] = None
    errs = validate_agent(a)
    assert errs and "backend" in " ".join(errs) and "frontend" in " ".join(errs)


def test_missing_required_field_rejected():
    a = _good_agent()
    del a["label"]
    errs = validate_agent(a)
    assert errs and "label" in " ".join(errs)


def test_backend_object_missing_launchd_rejected():
    a = _good_agent()
    a["backend"] = {"health": None}  # launchd mancante
    a["frontend"] = None
    errs = validate_agent(a)
    assert errs and "backend.launchd" in " ".join(errs)


# --- brand os tests ---------------------------------------------------------

def test_brand_os_valid():
    assert validate_brand_os(_good_brand_os()) == []


def test_brand_os_arbitrary_slug_id_valid():
    # un brand id qualsiasi (slug lowercase) e valido — zero edit al codice
    o = _good_brand_os()
    o["id"] = "my-brand"
    o["label"] = "My Brand"
    assert validate_brand_os(o) == []


def test_brand_os_reserved_id_rejected():
    # "shared"/"overview" sono scope riservati, non brand id
    o = _good_brand_os()
    o["id"] = "shared"
    errs = validate_brand_os(o)
    assert errs and "id" in " ".join(errs)


def test_brand_os_non_slug_id_rejected():
    o = _good_brand_os()
    o["id"] = "Acme Brand"  # spazi/maiuscole non ammessi
    errs = validate_brand_os(o)
    assert errs and "id" in " ".join(errs)


def test_roadmap_stage_out_of_range_rejected():
    o = _good_brand_os()
    o["roadmap_stage"] = 99
    errs = validate_brand_os(o)
    assert errs and "roadmap_stage" in " ".join(errs)


def test_roadmap_stage_bool_rejected():
    o = _good_brand_os()
    o["roadmap_stage"] = True  # bool non e un intero valido qui
    errs = validate_brand_os(o)
    assert errs and "roadmap_stage" in " ".join(errs)


def test_roadmap_now_string_valid():
    o = _good_brand_os()
    o["roadmap_now"] = "primo cliente · prime 10 vendite · alza il margine"
    assert validate_brand_os(o) == []


def test_roadmap_now_non_string_rejected():
    o = _good_brand_os()
    o["roadmap_now"] = 123  # numero, non stringa
    errs = validate_brand_os(o)
    assert errs and "roadmap_now" in " ".join(errs)


# --- example files ----------------------------------------------------------

def test_all_example_files_validate():
    files = sorted(EXAMPLES_DIR.glob("*.json"))
    assert files, "nessun file di esempio trovato"
    for f in files:
        data = json.loads(f.read_text(encoding="utf-8"))
        if "roadmap_stage" in data or f.name.startswith("os"):
            errs = validate_brand_os(data)
        else:
            errs = validate_agent(data)
        assert errs == [], f"{f.name} dovrebbe validare pulito, invece: {errs}"


if __name__ == "__main__":
    import sys

    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    for t in tests:
        t()
        print(f"  ok  {t.__name__}")
    print("ALL OK")
    sys.exit(0)
