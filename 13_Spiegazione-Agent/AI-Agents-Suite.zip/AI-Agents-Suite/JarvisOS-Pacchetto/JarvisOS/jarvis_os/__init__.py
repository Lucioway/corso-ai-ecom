"""jarvis_os — il contratto dei manifest dell'AI OS di JARVIS.

v1, stdlib only. Espone i validatori dei manifest agente e Brand OS.
"""

from .schema import (
    RESERVED_SCOPES,
    VALID_KINDS,
    validate_agent,
    validate_brand_os,
)

__all__ = [
    "RESERVED_SCOPES",
    "VALID_KINDS",
    "validate_agent",
    "validate_brand_os",
]
