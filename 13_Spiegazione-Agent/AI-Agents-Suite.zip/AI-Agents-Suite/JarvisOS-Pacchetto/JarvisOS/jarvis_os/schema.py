"""Schema dei manifest JARVIS AI OS — validatori stdlib-only.

Due contratti, ognuno una funzione `validate_*(dict) -> list[str]`:
- `validate_agent`     — un agente (servizio / scheduled / tool)
- `validate_brand_os`  — un Brand OS (`os.json`)

Ogni stringa d'errore nomina il CAMPO offending + il MOTIVO. Il nome del file
viene anteposto dalla CLI (`validate.py`). Lista vuota = manifest valido.
"""

# --- Allowed-value sets (contratto) ------------------------------------------

# Scope speciali sempre validi. Oltre a questi, ogni brand id (uno slug
# lowercase, es. "acme") e un scope valido: aggiungere un brand non richiede
# modifiche al codice — basta che lo scope sia uno slug ben formato.
RESERVED_SCOPES = {"shared", "overview"}
VALID_KINDS = {"service", "scheduled", "tool"}

import re as _re

# slug lowercase: lettere/numeri minuscoli separati da - o _ (es. "acme",
# "my-brand", "brand_2"). Niente spazi, niente maiuscole.
_SLUG_RE = _re.compile(r"^[a-z0-9]+(?:[-_][a-z0-9]+)*$")


def _is_slug(v) -> bool:
    return isinstance(v, str) and bool(_SLUG_RE.match(v))


def _is_nonempty_str(v) -> bool:
    return isinstance(v, str) and v.strip() != ""


def validate_agent(m: dict) -> list[str]:
    """Valida un manifest agente. Ritorna lista di errori (vuota = valido)."""
    errors: list[str] = []

    if not isinstance(m, dict):
        return ["manifest non e un oggetto JSON (atteso: dict)"]

    # id
    if "id" not in m:
        errors.append("campo 'id' mancante (richiesto)")
    elif not _is_nonempty_str(m["id"]):
        errors.append("campo 'id' deve essere una stringa non vuota")

    # label
    if "label" not in m:
        errors.append("campo 'label' mancante (richiesto)")
    elif not _is_nonempty_str(m["label"]):
        errors.append("campo 'label' deve essere una stringa non vuota")

    # scope — "shared" / "overview" oppure un brand id (slug lowercase)
    if "scope" not in m:
        errors.append("campo 'scope' mancante (richiesto)")
    elif not isinstance(m["scope"], str) or (
        m["scope"] not in RESERVED_SCOPES and not _is_slug(m["scope"])
    ):
        errors.append(
            f"campo 'scope' valore {m.get('scope')!r} non valido "
            f"(atteso: 'shared', 'overview' o un brand id slug-lowercase, es. 'acme')"
        )

    # kind
    if "kind" not in m:
        errors.append("campo 'kind' mancante (richiesto)")
    elif not isinstance(m["kind"], str) or m["kind"] not in VALID_KINDS:
        errors.append(
            f"campo 'kind' valore {m['kind']!r} non valido "
            f"(atteso: service|scheduled|tool)"
        )

    # backend — chiave richiesta; null o oggetto {launchd: str, health: str|null}
    backend_null = False
    if "backend" not in m:
        errors.append("campo 'backend' mancante (richiesto, puo essere null)")
        backend_null = True
    else:
        b = m["backend"]
        if b is None:
            backend_null = True
        elif isinstance(b, dict):
            if "launchd" not in b:
                errors.append(
                    "campo 'backend.launchd' mancante (richiesto quando backend non e null)"
                )
            elif not _is_nonempty_str(b["launchd"]):
                errors.append("campo 'backend.launchd' deve essere una stringa non vuota")
            if "health" in b and b["health"] is not None and not isinstance(b["health"], str):
                errors.append("campo 'backend.health' deve essere una stringa o null")
            if "heartbeat" in b and not _is_nonempty_str(b["heartbeat"]):
                errors.append("campo 'backend.heartbeat' deve essere una stringa non vuota (se presente)")
            if "mtime" in b and not _is_nonempty_str(b["mtime"]):
                errors.append("campo 'backend.mtime' deve essere una stringa non vuota (se presente)")
        else:
            errors.append("campo 'backend' deve essere null oppure un oggetto")

    # frontend — chiave richiesta; null o oggetto {url: str}
    frontend_null = False
    if "frontend" not in m:
        errors.append("campo 'frontend' mancante (richiesto, puo essere null)")
        frontend_null = True
    else:
        f = m["frontend"]
        if f is None:
            frontend_null = True
        elif isinstance(f, dict):
            if "url" not in f:
                errors.append(
                    "campo 'frontend.url' mancante (richiesto quando frontend non e null)"
                )
            elif not _is_nonempty_str(f["url"]):
                errors.append("campo 'frontend.url' deve essere una stringa non vuota")
        else:
            errors.append("campo 'frontend' deve essere null oppure un oggetto")

    # schedule
    if "schedule" not in m:
        errors.append("campo 'schedule' mancante (richiesto)")
    elif not _is_nonempty_str(m["schedule"]):
        errors.append("campo 'schedule' deve essere una stringa non vuota")

    # brief (opzionale)
    if "brief" in m and not isinstance(m["brief"], str):
        errors.append("campo 'brief' deve essere una stringa (se presente)")

    # Regola di coerenza: almeno uno tra backend / frontend non-null.
    if backend_null and frontend_null:
        errors.append(
            "manca almeno uno tra 'backend' e 'frontend' (non possono essere entrambi null)"
        )

    return errors


def validate_brand_os(m: dict) -> list[str]:
    """Valida un manifest Brand OS (`os.json`). Ritorna lista di errori."""
    errors: list[str] = []

    if not isinstance(m, dict):
        return ["manifest non e un oggetto JSON (atteso: dict)"]

    # id — un brand id slug lowercase (es. "acme"); NON puo essere uno scope
    # riservato ("shared"/"overview" non sono brand).
    if "id" not in m:
        errors.append("campo 'id' mancante (richiesto)")
    elif not _is_slug(m["id"]) or m["id"] in RESERVED_SCOPES:
        errors.append(
            f"campo 'id' valore {m.get('id')!r} non valido "
            f"(atteso: un brand id slug-lowercase, es. 'acme'; non 'shared'/'overview')"
        )

    # label
    if "label" not in m:
        errors.append("campo 'label' mancante (richiesto)")
    elif not _is_nonempty_str(m["label"]):
        errors.append("campo 'label' deve essere una stringa non vuota")

    # target_daily_eur — number (int o float), NO bool
    if "target_daily_eur" not in m:
        errors.append("campo 'target_daily_eur' mancante (richiesto)")
    elif isinstance(m["target_daily_eur"], bool) or not isinstance(
        m["target_daily_eur"], (int, float)
    ):
        errors.append("campo 'target_daily_eur' deve essere un numero")

    # roadmap_stage — integer 0..9 (rifiuta bool esplicitamente)
    if "roadmap_stage" not in m:
        errors.append("campo 'roadmap_stage' mancante (richiesto)")
    elif isinstance(m["roadmap_stage"], bool) or not isinstance(m["roadmap_stage"], int):
        errors.append("campo 'roadmap_stage' deve essere un intero (0-9)")
    elif not (0 <= m["roadmap_stage"] <= 9):
        errors.append(
            f"campo 'roadmap_stage' valore {m['roadmap_stage']} fuori range (atteso: 0-9)"
        )

    # brief (opzionale)
    if "brief" in m and not isinstance(m["brief"], str):
        errors.append("campo 'brief' deve essere una stringa (se presente)")

    # roadmap_now (opzionale) — testo "SIAMO QUI" della roadmap brand
    if "roadmap_now" in m and not isinstance(m["roadmap_now"], str):
        errors.append("campo 'roadmap_now' deve essere una stringa (se presente)")

    return errors
