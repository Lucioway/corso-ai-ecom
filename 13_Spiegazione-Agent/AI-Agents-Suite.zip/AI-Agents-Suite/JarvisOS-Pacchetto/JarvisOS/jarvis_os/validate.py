"""CLI validatore dei manifest JARVIS AI OS — stdlib only.

Uso:
    python3 -m jarvis_os.validate <file.json | directory>

Valida un singolo manifest oppure tutti i `*.json` di una cartella. Ogni errore
e prefissato dal path del file: `<file>: <campo> <motivo>`. Un JSON non parsabile
produce un errore leggibile (non un'eccezione). Exit 0 se tutto valido, 1 altrimenti.

Dispatch: un file e trattato come Brand OS se il suo dict top-level ha la chiave
`roadmap_stage` o se il nome file inizia con `os`; altrimenti come manifest agente.
"""

import json
import sys
from pathlib import Path

from .schema import validate_agent, validate_brand_os


def _is_brand_os(path: Path, data) -> bool:
    if isinstance(data, dict) and "roadmap_stage" in data:
        return True
    return path.name.startswith("os")


def validate_file(path: Path) -> list[str]:
    """Valida un singolo file. Ritorna errori gia prefissati dal path."""
    try:
        raw = path.read_text(encoding="utf-8")
    except OSError as e:
        return [f"{path}: impossibile leggere il file — {e}"]

    try:
        data = json.loads(raw)
    except json.JSONDecodeError as e:
        return [f"{path}: JSON non valido — {e}"]

    if _is_brand_os(path, data):
        errs = validate_brand_os(data)
    else:
        errs = validate_agent(data)

    return [f"{path}: {e}" for e in errs]


def _collect_files(target: Path) -> list[Path]:
    if target.is_dir():
        return sorted(target.glob("*.json"))
    return [target]


def main(argv=None) -> int:
    """Valida il path passato. Ritorna il numero totale di errori."""
    argv = sys.argv[1:] if argv is None else argv
    if not argv:
        print("uso: python3 -m jarvis_os.validate <file.json | directory>", file=sys.stderr)
        return 1

    target = Path(argv[0])
    if not target.exists():
        print(f"{target}: percorso inesistente", file=sys.stderr)
        return 1

    files = _collect_files(target)
    if not files:
        print(f"{target}: nessun file *.json da validare", file=sys.stderr)
        return 1

    total_errors = 0
    for f in files:
        errs = validate_file(f)
        for line in errs:
            print(line, file=sys.stderr)
        total_errors += len(errs)

    if total_errors == 0:
        print(f"OK: {len(files)} manifest validi")
    else:
        print(f"FALLITO: {total_errors} errore/i su {len(files)} file", file=sys.stderr)

    return total_errors


if __name__ == "__main__":
    sys.exit(0 if main() == 0 else 1)
