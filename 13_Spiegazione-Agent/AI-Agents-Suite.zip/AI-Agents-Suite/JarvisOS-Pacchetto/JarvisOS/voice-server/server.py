"""
Jarvis voice server — edge-tts (Microsoft Azure Neural) TTS + faster-whisper STT
on :3108.

GET  /health         -> {"ok": true, "voice": "...", "stt": {...}}
GET  /speak?text=... -> audio/mpeg — edge-tts streams MP3 directly
POST /stt            -> raw audio body (webm/opus/wav) -> {"text": "..."}
WS   /events         -> JSON events (wake word, etc.)
"""

import asyncio
import glob
import io
import json
import os
import sys
import threading
import time

# ctranslate2 (faster-whisper) needs cuDNN/cuBLAS DLLs on Windows.
if hasattr(os, "add_dll_directory"):
    for _d in glob.glob(os.path.join(sys.prefix, "Lib", "site-packages", "nvidia", "*", "bin")):
        os.add_dll_directory(_d)
        os.environ["PATH"] = _d + os.pathsep + os.environ["PATH"]

import edge_tts
import uvicorn
from fastapi import FastAPI, Request, Response, WebSocket, WebSocketDisconnect
from fastapi.responses import StreamingResponse
from faster_whisper import WhisperModel

from wakeword import WakeListener, WAKE_MODEL

HERE = os.path.dirname(os.path.abspath(__file__))
PORT = 3108
EDGE_VOICE = os.environ.get("EDGE_VOICE", "it-IT-GiuseppeNeural")  # neural IT male
WHISPER_MODEL = os.environ.get("WHISPER_MODEL", "medium")
WHISPER_PROMPT = os.environ.get(
    "WHISPER_PROMPT",
    # Vocab bias per lo STT. Aggiungi qui i nomi dei tuoi brand e i tuoi termini
    # ricorrenti per migliorare il riconoscimento vocale.
    "Comandi vocali per Jarvis in italiano. Termini: fatturato, margine, "
    "ROAS, report giornaliero, coda, agenti, roadmap, task, dashboard, "
    "conversion rate, upsell, cross-sell.",
)

app = FastAPI()


def load_whisper():
    if os.environ.get("WHISPER_DEVICE", "auto") != "cpu":
        try:
            m = WhisperModel(WHISPER_MODEL, device="cuda", compute_type="float16")
            return m, "cuda"
        except Exception as e:
            print(f"whisper cuda failed ({e}); falling back to cpu int8")
    return WhisperModel(WHISPER_MODEL, device="cpu", compute_type="int8"), "cpu"


whisper, WHISPER_DEVICE = load_whisper()
whisper_lock = threading.Lock()


def transcribe_pcm(audio_f32):
    with whisper_lock:
        segments, _info = whisper.transcribe(
            audio_f32, beam_size=5, language="it", vad_filter=True,
            initial_prompt=WHISPER_PROMPT,
        )
        return " ".join(s.text.strip() for s in segments).strip()


WAKE_ENABLED = os.environ.get("WAKE_WORD", "on").lower() not in ("off", "0", "false")
WAKE_THRESHOLD = float(os.environ.get("WAKE_THRESHOLD", "0.5"))

ws_clients: set = set()
main_loop = None


def emit_event(payload: dict):
    if main_loop is None:
        return
    msg = json.dumps(payload)

    async def _send():
        for ws in list(ws_clients):
            try:
                await ws.send_text(msg)
            except Exception:
                ws_clients.discard(ws)

    asyncio.run_coroutine_threadsafe(_send(), main_loop)


wake = WakeListener(transcribe_pcm, emit_event, threshold=WAKE_THRESHOLD) if WAKE_ENABLED else None


@app.websocket("/events")
async def events(ws: WebSocket):
    await ws.accept()
    await ws.send_text(json.dumps({"type": "hello", "wake": bool(wake and wake.ok)}))
    ws_clients.add(ws)
    try:
        while True:
            await ws.receive_text()
    except WebSocketDisconnect:
        pass
    finally:
        ws_clients.discard(ws)


@app.on_event("startup")
async def _startup():
    global main_loop
    main_loop = asyncio.get_running_loop()
    if wake is not None:
        wake.start()


@app.get("/health")
def health():
    return {
        "ok": True,
        "engine": "edge-tts",
        "voice": EDGE_VOICE,
        "stt": {"ok": True, "model": WHISPER_MODEL, "device": WHISPER_DEVICE},
        "wake": {
            "enabled": WAKE_ENABLED,
            "ok": bool(wake and wake.ok),
            "model": WAKE_MODEL,
            "threshold": WAKE_THRESHOLD,
            "error": wake.error if wake else None,
        },
    }


@app.post("/stt")
async def stt(req: Request):
    audio = await req.body()
    if len(audio) < 1000:
        return Response(status_code=400, content="clip too short")
    t0 = time.time()
    with whisper_lock:
        segments, _info = whisper.transcribe(
            io.BytesIO(audio), beam_size=5, language="it", vad_filter=True,
            initial_prompt=WHISPER_PROMPT,
        )
        text = " ".join(s.text.strip() for s in segments).strip()
    return {"text": text, "ms": int((time.time() - t0) * 1000)}


@app.get("/speak")
async def speak(text: str = ""):
    text = text.strip()[:900]
    if not text:
        return Response(status_code=400, content="empty text")

    async def gen():
        communicate = edge_tts.Communicate(text, EDGE_VOICE)
        async for chunk in communicate.stream():
            if chunk["type"] == "audio":
                yield chunk["data"]

    return StreamingResponse(gen(), media_type="audio/mpeg",
                             headers={"Cache-Control": "no-store"})


if __name__ == "__main__":
    # warm whisper — edge-tts is cloud so no local warmup needed
    warm_wav = io.BytesIO(b"RIFF$\x00\x00\x00WAVEfmt \x10\x00\x00\x00\x01\x00\x01\x00"
                          b"\x80>\x00\x00\x00}\x00\x00\x02\x00\x10\x00data\x00\x00\x00\x00")
    with whisper_lock:
        list(whisper.transcribe(warm_wav, beam_size=1, language="it")[0])
    print(f"edge-tts({EDGE_VOICE}) + whisper({WHISPER_MODEL}/{WHISPER_DEVICE}) — serving :{PORT}")
    uvicorn.run(app, host="127.0.0.1", port=PORT, log_level="warning")
