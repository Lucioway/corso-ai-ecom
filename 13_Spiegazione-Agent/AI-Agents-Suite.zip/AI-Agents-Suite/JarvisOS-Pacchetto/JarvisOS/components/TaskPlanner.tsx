"use client";

import { useCallback, useEffect, useState } from "react";

// Task planner overlay — the systematic home for per-brand work. Five fields:
// cosa (text), stato (todo/doing/done columns), quando (start), entro (due).
// Reads/writes /api/tasks → system/tasks.json.

type Status = "todo" | "doing" | "done";
type Brand = string; // runtime brand id from the os.json manifests
interface Task {
  id: string;
  brand: Brand;
  text: string;
  status: Status;
  start: string | null;
  due: string | null;
  created: string;
}

const COLS: { key: Status; label: string }[] = [
  { key: "todo", label: "Da Fare" },
  { key: "doing", label: "In Corso" },
  { key: "done", label: "Fatto" },
];
const NEXT: Record<Status, Status> = { todo: "doing", doing: "done", done: "todo" };

const todayYMD = () => new Date().toLocaleDateString("en-CA"); // local YYYY-MM-DD
const ddmm = (ymd: string | null) => (ymd ? ymd.slice(8, 10) + "/" + ymd.slice(5, 7) : null);
// dated tasks first (soonest due wins), undated last — surfaces deadlines/overdue
const byDue = (a: Task, b: Task) =>
  a.due && b.due ? (a.due < b.due ? -1 : 1) : a.due ? -1 : b.due ? 1 : 0;

export default function TaskPlanner({
  brand,
  onClose,
}: {
  // brand is a runtime brand id (string) from the manifests; this planner only
  // recognises its four known brands, so an unknown id falls back to "all".
  brand: string;
  onClose: () => void;
}) {
  // brands come from the os.json manifests (/api/brands), not hardcoded — so a
  // clean install with its own brands shows them here with zero code changes
  const [brands, setBrands] = useState<{ id: string; label: string }[]>([]);
  const labelOf = (id: string) => brands.find((b) => b.id === id)?.label ?? id;
  const [tasks, setTasks] = useState<Task[]>([]);
  const [filter, setFilter] = useState<string>(brand !== "all" ? brand : "all");
  // drag-and-drop + inline edit
  const [dragId, setDragId] = useState<string | null>(null);
  const [overCol, setOverCol] = useState<Status | null>(null);
  const [editId, setEditId] = useState<string | null>(null); // editing card text
  const [dateId, setDateId] = useState<string | null>(null); // editing card dates
  const [form, setForm] = useState({ brand, text: "", start: "", due: "" });

  useEffect(() => {
    fetch("/api/brands", { cache: "no-store" })
      .then((r) => r.json())
      .then((d) => {
        const list = (Array.isArray(d) ? d : d.brands ?? []).map((x: { id: string; label: string }) => ({
          id: x.id,
          label: x.label,
        }));
        setBrands(list);
        // default the new-task brand to the first real brand if none chosen yet
        setForm((f) => ({ ...f, brand: f.brand && f.brand !== "all" ? f.brand : list[0]?.id ?? "" }));
      })
      .catch(() => {});
  }, []);

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/tasks", { cache: "no-store" });
      const j = await r.json();
      setTasks(j.tasks || []);
    } catch {
      /* keep what we have */
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [onClose]);

  const post = useCallback(
    async (body: Record<string, unknown>) => {
      await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      await load();
    },
    [load]
  );

  const submit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.text.trim()) return;
    await post({ action: "add", ...form });
    setForm((f) => ({ ...f, text: "", start: "", due: "" }));
  };

  const today = todayYMD();
  const shown = tasks.filter((t) => filter === "all" || t.brand === filter);

  return (
    <div className="planner-overlay" onClick={onClose}>
      <div className="planner" onClick={(e) => e.stopPropagation()}>
        <div className="planner-head">
          <div className="planner-title">
            Pianificatore Task
            <span className="planner-sub">cosa · stato · quando · entro quando — per brand</span>
          </div>
          <button className="planner-x" onClick={onClose} aria-label="chiudi">
            ×
          </button>
        </div>

        {/* brand filter */}
        <div className="planner-filter">
          {["all", ...brands.map((x) => x.id)].map((b) => (
            <button
              key={b}
              className={`pf-tab ${filter === b ? "on" : ""}`}
              onClick={() => setFilter(b)}
            >
              {b === "all" ? "Tutti" : labelOf(b)}
              <span className="pf-count">
                {tasks.filter((t) => (b === "all" || t.brand === b) && t.status !== "done").length}
              </span>
            </button>
          ))}
        </div>

        {/* new task */}
        <form className="planner-new" onSubmit={submit}>
          <select
            value={form.brand}
            onChange={(e) => setForm((f) => ({ ...f, brand: e.target.value }))}
          >
            {brands.map((b) => (
              <option key={b.id} value={b.id}>
                {b.label}
              </option>
            ))}
          </select>
          <input
            className="pn-text"
            placeholder="Cosa fare esattamente…"
            value={form.text}
            onChange={(e) => setForm((f) => ({ ...f, text: e.target.value }))}
          />
          <label className="pn-date">
            quando
            <input
              type="date"
              value={form.start}
              onChange={(e) => setForm((f) => ({ ...f, start: e.target.value }))}
            />
          </label>
          <label className="pn-date">
            entro
            <input
              type="date"
              value={form.due}
              onChange={(e) => setForm((f) => ({ ...f, due: e.target.value }))}
            />
          </label>
          <button type="submit" className="pn-add">
            + Aggiungi
          </button>
        </form>

        {/* board — drag a card between columns; click text/dates to edit */}
        <div className="planner-board">
          {COLS.map((col) => {
            const items = shown.filter((t) => t.status === col.key).sort(byDue);
            return (
              <div
                className={`pcol pcol-${col.key} ${overCol === col.key && dragId ? "drop-over" : ""}`}
                key={col.key}
                onDragOver={(e) => {
                  if (!dragId) return;
                  e.preventDefault();
                  setOverCol(col.key);
                }}
                onDragLeave={() => setOverCol((c) => (c === col.key ? null : c))}
                onDrop={() => {
                  if (dragId) void post({ action: "update", id: dragId, status: col.key });
                  setDragId(null);
                  setOverCol(null);
                }}
              >
                <div className="pcol-head">
                  {col.label}
                  <span className="pcol-n">{items.length}</span>
                </div>
                <div className="pcol-body">
                  {items.map((t) => {
                    const overdue = t.due && t.due < today && t.status !== "done";
                    return (
                      <div
                        className={`pcard ${overdue ? "overdue" : ""} ${dragId === t.id ? "dragging" : ""}`}
                        key={t.id}
                        draggable={editId !== t.id && dateId !== t.id}
                        onDragStart={() => setDragId(t.id)}
                        onDragEnd={() => {
                          setDragId(null);
                          setOverCol(null);
                        }}
                      >
                        <div className="pcard-top">
                          {filter === "all" && (
                            <span className="pcard-brand">{labelOf(t.brand)}</span>
                          )}
                          <button
                            className="pcard-del"
                            onClick={() => post({ action: "delete", id: t.id })}
                            aria-label="elimina"
                          >
                            ×
                          </button>
                        </div>

                        {/* text — click to edit inline */}
                        {editId === t.id ? (
                          <textarea
                            className="pcard-edit"
                            defaultValue={t.text}
                            autoFocus
                            rows={2}
                            onBlur={(e) => {
                              const v = e.target.value.trim();
                              if (v && v !== t.text) void post({ action: "update", id: t.id, text: v });
                              setEditId(null);
                            }}
                            onKeyDown={(e) => {
                              if (e.key === "Enter" && !e.shiftKey) {
                                e.preventDefault();
                                (e.target as HTMLTextAreaElement).blur();
                              }
                              if (e.key === "Escape") setEditId(null);
                            }}
                          />
                        ) : (
                          <div
                            className="pcard-text"
                            role="button"
                            title="clicca per modificare"
                            onClick={() => setEditId(t.id)}
                          >
                            {t.text}
                          </div>
                        )}

                        {/* dates — click to edit inline */}
                        {dateId === t.id ? (
                          <div className="pcard-dateedit">
                            <label>
                              dal
                              <input
                                type="date"
                                defaultValue={t.start ?? ""}
                                onChange={(e) =>
                                  post({ action: "update", id: t.id, start: e.target.value || null })
                                }
                              />
                            </label>
                            <label>
                              entro
                              <input
                                type="date"
                                defaultValue={t.due ?? ""}
                                onChange={(e) =>
                                  post({ action: "update", id: t.id, due: e.target.value || null })
                                }
                              />
                            </label>
                            <button className="pde-done" onClick={() => setDateId(null)} aria-label="ok">
                              ✓
                            </button>
                          </div>
                        ) : (
                          <div
                            className="pcard-dates"
                            role="button"
                            title="clicca per le date"
                            onClick={() => setDateId(t.id)}
                          >
                            {t.start && <span className="pd-when">dal {ddmm(t.start)}</span>}
                            {t.due && (
                              <span className={`pd-due ${overdue ? "late" : ""}`}>
                                entro {ddmm(t.due)}
                              </span>
                            )}
                            {!t.start && !t.due && <span className="pd-none">+ data</span>}
                          </div>
                        )}

                        <button
                          className="pcard-move"
                          onClick={() => post({ action: "update", id: t.id, status: NEXT[t.status] })}
                        >
                          {t.status === "todo"
                            ? "→ In Corso"
                            : t.status === "doing"
                              ? "✓ Fatto"
                              : "↺ Riapri"}
                        </button>
                      </div>
                    );
                  })}
                  {items.length === 0 && <div className="pcol-empty">trascina qui</div>}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
