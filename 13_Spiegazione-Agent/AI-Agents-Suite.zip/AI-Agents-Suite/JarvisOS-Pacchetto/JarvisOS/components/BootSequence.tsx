"use client";

import { useEffect, useRef, useState } from "react";

// Jarvis-style pre-launch screen: expanding reactor rings, rotating reticle,
// scanline sweep, a streaming boot log and a 0→100 counter, then fades out and
// reveals the HUD. Pure CSS/raf — no deps.

const BOOT_LINES = [
  "Avvio nucleo JARVIS…",
  "Calibrazione sensori vocali",
  "Montaggio vault · metriche brand",
  "Sincronizzazione agenti automatici",
  "Innesco reattore",
  "Sistemi online",
];

export default function BootSequence({ onDone }: { onDone: () => void }) {
  const [pct, setPct] = useState(0);
  const [lines, setLines] = useState<string[]>([]);
  const [out, setOut] = useState(false);
  // onDone identity changes every parent render — keep it in a ref so the boot
  // timer runs ONCE (deps []), otherwise the HUD's 5s poll restarts the counter
  const doneRef = useRef(onDone);
  doneRef.current = onDone;

  useEffect(() => {
    let i = 0;
    const li = setInterval(() => {
      setLines((l) => [...l, BOOT_LINES[i]]);
      if (++i >= BOOT_LINES.length) clearInterval(li);
    }, 430);

    const t0 = performance.now();
    const DUR = 3600;
    let raf = 0;
    const step = (t: number) => {
      const p = Math.min((t - t0) / DUR, 1);
      setPct(Math.round(p * 100));
      if (p < 1) raf = requestAnimationFrame(step);
      else {
        setOut(true); // trigger fade
        setTimeout(() => doneRef.current(), 650);
      }
    };
    raf = requestAnimationFrame(step);
    return () => {
      clearInterval(li);
      cancelAnimationFrame(raf);
    };
  }, []);

  return (
    <div className={`boot-seq ${out ? "out" : ""}`}>
      <div className="boot-core">
        <span className="boot-ring r1" />
        <span className="boot-ring r2" />
        <span className="boot-ring r3" />
        <span className="boot-reticle" />
        <span className="boot-dot" />
      </div>
      <div className="boot-title">J · A · R · V · I · S</div>
      <div className="boot-sub">Regìa Operativa · Comando Vocale</div>
      <div className="boot-pct">
        {pct}
        <span>%</span>
      </div>
      <div className="boot-log">
        {lines.map((l, i) => (
          <div key={i} className="boot-log-line">
            ▸ {l}
          </div>
        ))}
      </div>
      <div className="boot-scan" aria-hidden="true" />
      <div className="boot-grid" aria-hidden="true" />
    </div>
  );
}
