"use client";

import { useCallback, useEffect, useState } from "react";

// Minimal per-brand checklist. Checkbox toggles done, click text to rename,
// add bar on top. Open tasks sorted by due (overdue first); done collapsed
// at the bottom. /api/tasks → system/tasks.json.

type Status = "todo" | "doing" | "done";
interface Task {
  id: string;
  brand: string;
  text: string;
  status: Status;
  due: string | null;
}

const today = () => new Date().toLocaleDateString("en-CA");
const ddmm = (y: string | null) => (y ? y.slice(8, 10) + "/" + y.slice(5, 7) : null);
const byDue = (a: Task, b: Task) =>
  a.due && b.due ? (a.due < b.due ? -1 : 1) : a.due ? -1 : b.due ? 1 : 0;

export default function BrandTasks({ brand }: { brand: string }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [text, setText] = useState("");
  const [due, setDue] = useState("");
  const [editing, setEditing] = useState<string | null>(null);

  const load = useCallback(async () => {
    try {
      const r = await fetch("/api/tasks", { cache: "no-store" });
      const j = await r.json();
      setTasks((j.tasks || []).filter((t: Task) => t.brand === brand));
    } catch {
      /* keep */
    }
  }, [brand]);
  useEffect(() => {
    load();
  }, [load]);

  const post = useCallback(
    async (body: Record<string, unknown>) => {
      await fetch("/api/tasks", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });
      await load();
    },
    [load]
  );

  const add = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    await post({ action: "add", brand, text, due });
    setText("");
    setDue("");
  };

  const td = today();
  const open = tasks.filter((t) => t.status !== "done").sort(byDue);
  const done = tasks.filter((t) => t.status === "done");

  const row = (t: Task, isDone: boolean) => {
    const od = !isDone && t.due && t.due < td;
    return (
      <div className={`tk-row ${isDone ? "done" : ""} ${od ? "late" : ""}`} key={t.id}>
        <button
          className="tk-check"
          onClick={() => post({ action: "update", id: t.id, status: isDone ? "todo" : "done" })}
          aria-label={isDone ? "riapri" : "completa"}
        >
          {isDone ? "✓" : "○"}
        </button>
        {editing === t.id ? (
          <input
            className="tk-edit"
            defaultValue={t.text}
            autoFocus
            onBlur={(e) => {
              const v = e.target.value.trim();
              if (v && v !== t.text) void post({ action: "update", id: t.id, text: v });
              setEditing(null);
            }}
            onKeyDown={(e) => {
              if (e.key === "Enter") (e.target as HTMLInputElement).blur();
              if (e.key === "Escape") setEditing(null);
            }}
          />
        ) : (
          <span className="tk-text" onClick={() => !isDone && setEditing(t.id)}>
            {t.text}
          </span>
        )}
        {t.due && <span className="tk-due">{ddmm(t.due)}</span>}
        <button className="tk-del" onClick={() => post({ action: "delete", id: t.id })} aria-label="elimina">
          ×
        </button>
      </div>
    );
  };

  return (
    <section className="bp-tasks">
      <div className="sec-title">
        <span>Task</span>
        <span className="tick">{open.length} APERTI</span>
      </div>
      <form className="tk-add" onSubmit={add}>
        <input
          className="tk-add-text"
          placeholder="Nuovo task…"
          value={text}
          onChange={(e) => setText(e.target.value)}
        />
        <input
          className="tk-add-date"
          type="date"
          title="entro"
          value={due}
          onChange={(e) => setDue(e.target.value)}
        />
        <button type="submit" className="tk-add-btn">
          +
        </button>
      </form>

      <div className="tk-list">
        {open.map((t) => row(t, false))}
        {open.length === 0 && <div className="tk-empty">Nessun task aperto</div>}
      </div>

      {done.length > 0 && (
        <details className="tk-done">
          <summary>Fatto · {done.length}</summary>
          {done.map((t) => row(t, true))}
        </details>
      )}
    </section>
  );
}
