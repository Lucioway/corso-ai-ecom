"use client";

import { useEffect, useState } from "react";

// Overview "Oggi" panel — the most urgent open tasks across every brand, by
// due date (overdue first, dated before undated). Click opens the planner.

type Task = { id: string; brand: string; text: string; status: string; due: string | null };

// Brand badge = first 3 letters of the brand id, uppercased. Brands are
// declarative (os.json), so there's no hardcoded label map.
const badge = (brand: string) => brand.slice(0, 3).toUpperCase();
const today = () => new Date().toLocaleDateString("en-CA");
const ddmm = (y: string | null) => (y ? y.slice(8, 10) + "/" + y.slice(5, 7) : null);

export default function TodayTasks({ onOpen }: { onOpen?: () => void }) {
  const [tasks, setTasks] = useState<Task[]>([]);
  useEffect(() => {
    const pull = () =>
      fetch("/api/tasks", { cache: "no-store" })
        .then((r) => r.json())
        .then((d) => setTasks(d.tasks || []))
        .catch(() => {});
    pull();
    const id = setInterval(pull, 30_000);
    return () => clearInterval(id);
  }, []);

  const td = today();
  const open = tasks
    .filter((t) => t.status !== "done")
    .sort((a, b) => (a.due && b.due ? (a.due < b.due ? -1 : 1) : a.due ? -1 : b.due ? 1 : 0))
    .slice(0, 5);
  if (open.length === 0) return null;

  return (
    <section className="block today" role={onOpen ? "button" : undefined} onClick={onOpen}>
      <div className="sec-title">
        <span>Oggi</span>
        <span className="tick">PRIORITÀ</span>
      </div>
      {open.map((t) => {
        const od = t.due && t.due < td;
        return (
          <div className="today-row" key={t.id}>
            <span className="today-brand">{badge(t.brand)}</span>
            <span className="today-text">{t.text}</span>
            {t.due && <span className={`today-due ${od ? "late" : ""}`}>{ddmm(t.due)}</span>}
          </div>
        );
      })}
    </section>
  );
}
