"use client";

import { memo, useEffect, useRef, useState } from "react";

type Agent = {
  id: string;
  label: string;
  brief: string;
  sched: string;
  status: "ok" | "error" | "stale" | "off";
  last_run: string;
  url?: string | null;
  brand?: string;
};

const COLOR: Record<Agent["status"], string> = {
  ok: "#37f0a0",     // green — the V.A.U.L.T. node-cloud look
  error: "#ff4338",
  stale: "#c9a24b",
  off: "#56707d",
};

// small particle-sphere, one per agent, tinted by status
const MiniSphere = memo(function MiniSphere({ color, live }: { color: string; live: boolean }) {
  const ref = useRef<HTMLCanvasElement | null>(null);
  useEffect(() => {
    const cv = ref.current;
    if (!cv) return;
    const ctx = cv.getContext("2d");
    if (!ctx) return;
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    const S = 56;
    cv.width = S * dpr;
    cv.height = S * dpr;
    const N = 70;
    const pts: { x: number; y: number; z: number }[] = [];
    for (let i = 0; i < N; i++) {
      const y = 1 - (i / (N - 1)) * 2;
      const r = Math.sqrt(1 - y * y);
      const th = i * 2.39996323;
      pts.push({ x: Math.cos(th) * r, y, z: Math.sin(th) * r });
    }
    const CX = (S * dpr) / 2;
    const CY = (S * dpr) / 2;
    const RAD = S * dpr * 0.4;
    let ang = 0;
    let raf = 0;
    function frame() {
      ang += live ? 0.02 : 0.008;
      ctx!.clearRect(0, 0, S * dpr, S * dpr);
      const sa = Math.sin(ang);
      const ca = Math.cos(ang);
      const proj = pts.map((p) => {
        const x = p.x * ca - p.z * sa;
        const z = p.x * sa + p.z * ca;
        return { sx: CX + x * RAD, sy: CY + p.y * RAD, depth: (z + 1) / 2 };
      });
      ctx!.strokeStyle = color;
      ctx!.lineWidth = dpr * 0.4;
      for (let i = 0; i < proj.length; i += 2) {
        for (let j = i + 1; j < Math.min(i + 7, proj.length); j++) {
          const a = proj[i];
          const b = proj[j];
          const dx = a.sx - b.sx;
          const dy = a.sy - b.sy;
          if (dx * dx + dy * dy < (RAD * 0.5) ** 2) {
            ctx!.globalAlpha = 0.12 + 0.25 * Math.min(a.depth, b.depth);
            ctx!.beginPath();
            ctx!.moveTo(a.sx, a.sy);
            ctx!.lineTo(b.sx, b.sy);
            ctx!.stroke();
          }
        }
      }
      ctx!.fillStyle = color;
      for (const p of proj) {
        ctx!.globalAlpha = 0.3 + 0.6 * p.depth;
        ctx!.beginPath();
        ctx!.arc(p.sx, p.sy, dpr * (0.6 + 1.1 * p.depth), 0, 6.283);
        ctx!.fill();
      }
      ctx!.globalAlpha = 1;
      raf = requestAnimationFrame(frame);
    }
    raf = requestAnimationFrame(frame);
    return () => cancelAnimationFrame(raf);
  }, [color, live]);
  return <canvas ref={ref} className="agent-sphere" style={{ width: 56, height: 56 }} />;
});

export default function AutoAgents({ brand = "all" }: { brand?: string }) {
  const [agents, setAgents] = useState<Agent[]>([]);
  useEffect(() => {
    const pull = () =>
      fetch("/api/agents", { cache: "no-store" })
        .then((r) => r.json())
        .then((d) => setAgents(d.agents || []))
        .catch(() => {});
    pull();
    const id = setInterval(pull, 60_000);
    return () => clearInterval(id);
  }, []);

  // Overview shows all; a brand page shows that brand's agents + shared ("all")
  const shown =
    brand === "all" ? agents : agents.filter((a) => (a.brand ?? "all") === "all" || a.brand === brand);

  return (
    <section className="auto-agents">
      <div className="sec-title">
        <span>Agent Automatici</span>
        <span className="tick">CRON.LIVE</span>
      </div>
      <div className="agent-grid">
        {shown.map((a) => {
          const Tag = a.url ? "a" : "div";
          return (
            <Tag
              key={a.id}
              className={`agent-card st-${a.status}${a.url ? " has-link" : ""}`}
              {...(a.url ? { href: a.url, target: "_blank", rel: "noreferrer" } : {})}
            >
              <MiniSphere color={COLOR[a.status]} live={a.status === "ok"} />
              <div className="agent-meta">
                <div className="agent-name">
                  {a.label}
                  <i className="agent-dot" style={{ background: COLOR[a.status] }} />
                  {a.url && <span className="agent-link-arrow">↗</span>}
                </div>
                <div className="agent-brief">{a.brief}</div>
                <div className="agent-foot">
                  <span>{a.status === "ok" ? "attivo" : a.status === "error" ? "errore" : a.status === "stale" ? "in ritardo" : "spento"}</span>
                  <span>· ultimo {a.last_run}</span>
                  <span>· {a.sched}</span>
                </div>
              </div>
            </Tag>
          );
        })}
        {shown.length === 0 && <div className="agent-brief">caricamento…</div>}
      </div>
    </section>
  );
}
