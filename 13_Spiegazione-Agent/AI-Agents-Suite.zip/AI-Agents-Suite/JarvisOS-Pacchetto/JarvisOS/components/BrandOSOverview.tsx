"use client";

import { useEffect, useState } from "react";

type Health = "ok" | "stale" | "error" | "off";

type Brand = {
  id: string;
  label: string;
  target_daily_eur: number;
  roadmap_stage: number;
  brief: string;
  agents_total: number;
  agents_ok: number;
  health: Health;
};

type Platform = {
  id: string;
  label: string;
  status: Health;
  url: string | null;
  brief: string;
};

// identical status palette to AutoAgents — never reinvent these
const COLOR: Record<Health, string> = {
  ok: "#37f0a0",
  error: "#ff4338",
  stale: "#c9a24b",
  off: "#56707d",
};

// Hormozi roadmap stage labels (0–9), short form — from Roadmap.tsx STAGES
const STAGE_LABEL = [
  "Improvvisa",
  "Monetizza",
  "Pubblicizza",
  "Stabilizza",
  "Dai priorità",
  "Crea prodotto",
  "Ottimizza",
  "Categorizza",
  "Specializza",
  "Capitalizza",
];

// €30000 → "30k", €500 → "500"
function fmt(n: number): string {
  return n >= 1000 ? `${Math.round(n / 1000)}k` : String(n);
}

export default function BrandOSOverview() {
  const [data, setData] = useState<{ brands: Brand[]; platform: Platform[] }>({
    brands: [],
    platform: [],
  });

  useEffect(() => {
    const pull = () =>
      fetch("/api/brand-os", { cache: "no-store" })
        .then((r) => r.json())
        .then(setData)
        .catch(() => {});
    pull();
    const id = setInterval(pull, 60_000);
    return () => clearInterval(id);
  }, []);

  const { brands, platform } = data;

  if (brands.length === 0 && platform.length === 0) {
    return <div className="agent-brief">caricamento…</div>;
  }

  return (
    <section className="brand-os">
      <div className="sec-title">
        <span>Brand OS</span>
        <span className="tick">PANORAMICA</span>
      </div>
      <div className="brand-os-grid">
        {brands.map((b) => (
          <div key={b.id} className={`brand-os-card st-${b.health}`}>
            <div className="brand-os-top">
              <span className="brand-name">{b.label}</span>
              <i className="brand-os-dot" style={{ background: COLOR[b.health] }} />
            </div>
            <div className="brand-os-target">
              €{fmt(b.target_daily_eur)}/g
              <span className="brand-os-stage">
                {STAGE_LABEL[b.roadmap_stage] ?? `stage ${b.roadmap_stage}`}
              </span>
            </div>
            <div className="brand-os-count">
              {b.agents_ok}/{b.agents_total} agenti
            </div>
            {b.brief && <div className="brand-os-brief">{b.brief}</div>}
          </div>
        ))}
      </div>

      <div className="sec-title brand-os-platform-title">
        <span>Platform</span>
        <span className="tick">CONDIVISI</span>
      </div>
      <div className="platform-list">
        {platform.map((p) =>
          p.url ? (
            <a
              key={p.id}
              className="kpi-link"
              href={p.url}
              target="_blank"
              rel="noreferrer"
            >
              <i className="kpi-dot" />
              {p.label}
              <span className="kpi-arrow">↗</span>
            </a>
          ) : (
            <div key={p.id} className="platform-item">
              <i className="platform-dot" style={{ background: COLOR[p.status] }} />
              {p.label}
            </div>
          )
        )}
      </div>
    </section>
  );
}
