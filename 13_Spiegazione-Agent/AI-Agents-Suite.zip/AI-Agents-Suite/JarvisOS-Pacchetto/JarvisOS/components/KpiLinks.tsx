"use client";

// Hosted KPI dashboards — one per brand. Click opens the live board.
// Add your own here: { label: "<Brand>", url: "https://your-dashboard" }.
// The label must match the brand id (case-insensitive) for the panel to show.
const LINKS: { label: string; url: string }[] = [];

export default function KpiLinks({ brand = "all" }: { brand?: string }) {
  // Overview hides the dashboards; a brand tab shows only that brand's board.
  // Brands without a configured board → panel drops out.
  if (brand === "all") return null;
  const links = LINKS.filter((l) => l.label.toLowerCase() === brand);
  if (links.length === 0) return null;

  return (
    <section className="kpi-board">
      <div className="sec-title">
        <span>Dashboard KPI</span>
        <span className="tick">DASHBOARDS</span>
      </div>
      <div className="kpi-links">
        {links.map((l) => (
          <a key={l.label} className="kpi-link" href={l.url} target="_blank" rel="noreferrer">
            <i className="kpi-dot" />
            {l.label}
            <span className="kpi-arrow">↗</span>
          </a>
        ))}
      </div>
    </section>
  );
}
