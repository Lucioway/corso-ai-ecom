"use client";

// Per-brand scaling roadmap as a vertical stepper — dots + connecting line,
// with a "SIAMO QUI" marker at the brand's current stage. Brands ride the
// Stages 0–9 ladder; Overview rides the combined revenue phases. Static
// strategy content; the left-rail tab picks which track shows.

// "all" is the Overview pseudo-brand; any other string is a real brand id
// loaded from the os.json manifests at runtime.
export type BrandKey = string;

type Node = { label: string; sub: string };

// the 0–9 ladder, shared by every brand
const STAGES: Node[] = [
  { label: "0 · Improvvisa", sub: "fai provare gratis" },
  { label: "1 · Monetizza", sub: "prima vendita" },
  { label: "2 · Pubblicizza", sub: "lead consistenti — Regola del 100" },
  { label: "3 · Stabilizza", sub: "prendi aiuto" },
  { label: "4 · Dai priorità", sub: "nicchia giù" },
  { label: "5 · Crea prodotto", sub: "2° prodotto premium" },
  { label: "6 · Ottimizza", sub: "meglio, non di più" },
  { label: "7 · Categorizza", sub: "2° canale + triage" },
  { label: "8 · Specializza", sub: "team dedicati" },
  { label: "9 · Capitalizza", sub: "scommessa sul futuro" },
];

// Overview track — the combined revenue phases
const OVERVIEW: { nodes: Node[]; idx: number; now: string } = {
  nodes: [
    { label: "€11.5k/d", sub: "oggi" },
    { label: "€25k/d", sub: "Fase A — spremi driver, accendi gli zero" },
    { label: "€50k/d", sub: "Fase B — nicchia + 2° prodotto" },
    { label: "€100k/d", sub: "Fase C — 2° canale, productize" },
    { label: "100M", sub: "Fase D — Capitalize" },
  ],
  idx: 0,
  now: "primo cliente · prime 10 vendite · alza il margine",
};

// `stage`/`now` come from the active brand's os.json fields roadmap_stage /
// roadmap_now (via /api/brands), passed down by HUD. STAGES + OVERVIEW stay
// hardcoded — they're generic ladders, not brand data. If `now` (roadmap_now)
// is absent the stage's own generic `sub` shows instead.
export default function Roadmap({
  brand,
  stage,
  now: nowProp,
}: {
  brand: BrandKey;
  stage?: number;
  now?: string;
}) {
  const track = brand === "all" ? OVERVIEW.nodes : STAGES;
  // clamp the brand stage into the 0–9 ladder so a bad manifest never indexes off-track
  const brandIdx = Math.min(Math.max(stage ?? 0, 0), STAGES.length - 1);
  const cur = brand === "all" ? OVERVIEW.idx : brandIdx;
  const now = brand === "all" ? OVERVIEW.now : nowProp ?? STAGES[brandIdx].sub;
  const tick = brand === "all" ? "€11.5K → 100M" : "FASI 0–9";

  return (
    <section className="block roadmap boot-stagger" style={{ animationDelay: "0.14s" }}>
      <div className="sec-title">
        <span>Roadmap</span>
        <span className="tick">{tick}</span>
      </div>
      <div className="rm-track">
        {track.map((n, i) => {
          const state = i < cur ? "done" : i === cur ? "now" : "future";
          return (
            <div className={`rm-node ${state}`} key={i}>
              <div className="rm-marker">
                <span className="rm-dot" />
              </div>
              <div className="rm-body">
                <div className="rm-row">
                  <span className="rm-label">{n.label}</span>
                  {state === "now" && <span className="rm-here">SIAMO QUI</span>}
                </div>
                <div className="rm-sub">{state === "now" ? now : n.sub}</div>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
