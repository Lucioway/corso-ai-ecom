# Changelog

## 1.0 — release iniziale

Prima release pubblica di JarvisOS.
