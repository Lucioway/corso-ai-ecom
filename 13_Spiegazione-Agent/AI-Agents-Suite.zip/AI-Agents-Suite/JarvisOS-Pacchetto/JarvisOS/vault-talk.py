#!/usr/bin/env python3
"""Native push-to-talk for V.A.U.L.T. — bypasses the browser mic entirely.

Records from the Samson (which works) → POSTs to the HUD's /api/voice → speaks
the Italian reply via /api/speak (afplay). Same pipeline the browser uses, just
a working mic.

Run:  python3 JarvisHUD/vault-talk.py
Then: press ENTER, speak, it records until you go quiet (or 8s), then answers.
"""
import sys, io, wave, time, urllib.request, subprocess, tempfile
import sounddevice as sd, numpy as np

HUD = "http://localhost:3107"
MIC = "Meteor"          # substring; Samson Meteor
SR = 44100
SILENCE = 0.9           # s of quiet ends the clip
FLOOR = 0.015           # rms below this = quiet
MAXLEN = 9.0


def mic_index():
    for i, d in enumerate(sd.query_devices()):
        if d["max_input_channels"] > 0 and MIC.lower() in d["name"].lower():
            return i, d["name"]
    return None, "(default)"


def record(dev):
    buf, sil, started, t0 = [], 0.0, False, time.monotonic()
    block = 2048
    with sd.InputStream(device=dev, channels=1, samplerate=SR, blocksize=block, dtype="float32") as s:
        while True:
            data, _ = s.read(block)
            buf.append(data[:, 0].copy())
            rms = float(np.sqrt(np.mean(data[:, 0] ** 2)))
            if rms > FLOOR * 1.6:
                started = True
            sil = sil + block / SR if rms < FLOOR else 0.0
            dur = time.monotonic() - t0
            if (started and sil > SILENCE and dur > 0.6) or dur > MAXLEN:
                break
            if not started and dur > 4.0:
                break
    return np.concatenate(buf) if buf else np.zeros(1, "float32")


def to_wav(a):
    pcm = (np.clip(a, -1, 1) * 32767).astype("<i2").tobytes()
    b = io.BytesIO(); w = wave.open(b, "wb")
    w.setnchannels(1); w.setsampwidth(2); w.setframerate(SR); w.writeframes(pcm); w.close()
    return b.getvalue()


def send(wav):
    req = urllib.request.Request(f"{HUD}/api/voice", data=wav,
                                 headers={"Content-Type": "audio/wav"}, method="POST")
    import json
    return json.loads(urllib.request.urlopen(req, timeout=45).read())


def speak(text):
    if not text:
        return
    url = f"{HUD}/api/speak?text=" + urllib.parse.quote(text)
    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as f:
        f.write(urllib.request.urlopen(url, timeout=45).read())
        path = f.name
    subprocess.run(["afplay", path], check=False)


import urllib.parse
if __name__ == "__main__":
    dev, name = mic_index()
    print(f"J.A.R.V.I.S push-to-talk — mic: {name}")
    print("Premi INVIO, parla, vai a capo quando hai finito (o resta zitto). Ctrl-C esci.\n")
    while True:
        try:
            input("⏎ per parlare > ")
            print("  🎙  registro… (parla)")
            a = record(dev)
            peak = float(np.abs(a).max())
            if peak < 0.03:
                print("  (silenzio — il Samson non ha sentito nulla)\n"); continue
            r = send(to_wav(a))
            tx = r.get("transcript", ""); reply = r.get("reply", "")
            print(f"  📝 «{tx}»")
            print(f"  🗣  {reply}\n")
            speak(reply)
        except KeyboardInterrupt:
            print("\nciao."); break
        except Exception as e:
            print("  errore:", e, "\n")
