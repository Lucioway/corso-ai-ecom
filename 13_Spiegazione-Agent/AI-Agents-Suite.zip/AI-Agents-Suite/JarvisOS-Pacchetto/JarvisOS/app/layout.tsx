import type { Metadata } from "next";
import { Space_Grotesk, JetBrains_Mono, Inter } from "next/font/google";
import "./globals.css";

// SHIN-EN 深淵 — Space Grotesk (display) · Inter (body) · JetBrains Mono (log)
const display = Space_Grotesk({
  subsets: ["latin"],
  weight: ["700"],
  variable: "--font-display",
});

const mono = JetBrains_Mono({
  subsets: ["latin"],
  variable: "--font-mono",
});

const body = Inter({
  subsets: ["latin"],
  weight: ["400", "500"],
  variable: "--font-body",
});

export const metadata: Metadata = {
  title: "JARVIS — Regìa Operativa · Comando Vocale",
  description: "HUD Ember Core sopra il vault dell'OS agentico",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="it">
      <body className={`${display.variable} ${mono.variable} ${body.variable}`} suppressHydrationWarning>{children}</body>
    </html>
  );
}
