import { NextResponse } from "next/server";
import { readTasks, addTask, updateTask, deleteTask } from "@/lib/tasks";

// GET /api/tasks — all tasks (UI filters by brand).
// POST /api/tasks {action: "add"|"update"|"delete", ...} — mutate the planner.

export const dynamic = "force-dynamic";

export async function GET() {
  return NextResponse.json({ tasks: readTasks() });
}

export async function POST(req: Request) {
  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "bad body" }, { status: 400 });
  }

  switch (body.action) {
    case "add": {
      const t = addTask(body as never);
      return t
        ? NextResponse.json({ ok: true, task: t })
        : NextResponse.json({ error: "need {brand, text}" }, { status: 400 });
    }
    case "update": {
      const ok = updateTask(String(body.id), body as never);
      return ok
        ? NextResponse.json({ ok: true })
        : NextResponse.json({ error: "no such task" }, { status: 404 });
    }
    case "delete": {
      const ok = deleteTask(String(body.id));
      return ok
        ? NextResponse.json({ ok: true })
        : NextResponse.json({ error: "no such task" }, { status: 404 });
    }
    default:
      return NextResponse.json({ error: "unknown action" }, { status: 400 });
  }
}
