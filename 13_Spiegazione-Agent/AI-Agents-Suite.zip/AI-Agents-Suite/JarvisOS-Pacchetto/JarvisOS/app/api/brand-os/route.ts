import { NextResponse } from "next/server";
import { VAULT_ROOT } from "@/lib/config";
import { readFile, readdir } from "fs/promises";
import path from "path";

export const dynamic = "force-dynamic";

type Health = "ok" | "stale" | "error" | "off";

type Agent = {
  id: string;
  label: string;
  brief?: string;
  status: Health;
  url?: string | null;
  brand?: string;
};

type BrandOS = {
  id: string;
  label: string;
  target_daily_eur: number;
  roadmap_stage: number;
  brief: string;
};

const BRAND_OS_DIR = path.join(VAULT_ROOT, "jarvis-os", "brand-os");
const AGENTS_FILE = path.join(VAULT_ROOT, "system", "agents.json");
const osPath = (id: string) => path.join(BRAND_OS_DIR, id, "os.json");

// Brands are discovered by directory — adding a brand = adding a folder under
// jarvis-os/brand-os/<id>/os.json. No hardcoded list.
async function brandIds(): Promise<string[]> {
  try {
    const entries = await readdir(BRAND_OS_DIR, { withFileTypes: true });
    return entries
      .filter((e) => e.isDirectory())
      .map((e) => e.name)
      .sort((a, b) => a.localeCompare(b));
  } catch {
    return [];
  }
}

// worst status among a brand's own agents (error > stale > off > ok); 0 → off
function worstHealth(agents: Agent[]): Health {
  if (agents.length === 0) return "off";
  if (agents.some((a) => a.status === "error")) return "error";
  if (agents.some((a) => a.status === "stale")) return "stale";
  if (agents.some((a) => a.status === "off")) return "off";
  return "ok";
}

// GET /api/brand-os — Panoramica summary. Reads the per-brand os.json manifests
// + the resolver's agents.json (already fresh from /api/agents — we never run
// agents_status.py here). Returns per-brand health + the shared Platform list.
export async function GET() {
  try {
    // agents.json — read-only; missing/corrupt file → empty roster
    let agents: Agent[] = [];
    try {
      const raw = await readFile(AGENTS_FILE, "utf8");
      agents = JSON.parse(raw).agents ?? [];
    } catch {
      agents = [];
    }

    // load each discovered brand manifest, skipping any that are missing
    const brands = [];
    for (const id of await brandIds()) {
      let os: BrandOS;
      try {
        os = JSON.parse(await readFile(osPath(id), "utf8"));
      } catch {
        continue;
      }
      // only the brand's OWN agents (shared "all"/"overview" go to Platform)
      const own = agents.filter((a) => a.brand === os.id);
      brands.push({
        id: os.id,
        label: os.label,
        target_daily_eur: os.target_daily_eur,
        roadmap_stage: os.roadmap_stage,
        brief: os.brief,
        agents_total: own.length,
        agents_ok: own.filter((a) => a.status === "ok").length,
        health: worstHealth(own),
      });
    }

    // shared + overview services
    const platform = agents
      .filter((a) => a.brand === "all" || a.brand === "overview")
      .map((a) => ({
        id: a.id,
        label: a.label,
        status: a.status,
        url: a.url ?? null,
        brief: a.brief ?? "",
      }));

    return NextResponse.json({ brands, platform });
  } catch {
    return NextResponse.json({ brands: [], platform: [] });
  }
}
