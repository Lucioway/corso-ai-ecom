import { NextResponse } from "next/server";
import { readVaultState } from "@/lib/vault";
import { VAULT_ROOT } from "@/lib/config";
import { stat } from "fs/promises";
import path from "path";
import { execFile } from "child_process";
import { promisify } from "util";

const pexec = promisify(execFile);
export const dynamic = "force-dynamic";

const METRICS = path.join(VAULT_ROOT, "system", "metrics", "metrics.csv");
const SYNC = path.resolve(process.cwd(), "metrics_build.py");

// Sync brand numbers from the live goal_state.json when the csv goes stale
// (>5 min). goal_state is kept fresh by the AgentOS launchd pipeline; this
// pulls those live numbers into the HUD's append-only metrics.csv.
async function refreshMetricsIfStale() {
  try {
    const s = await stat(METRICS);
    if (Date.now() - s.mtimeMs < 300_000) return; // fresh enough
  } catch {
    /* no file yet — build it */
  }
  try {
    await pexec("python3", [SYNC], { timeout: 15_000 });
  } catch {
    /* goal_state missing or python hiccup — serve whatever's cached */
  }
}

export async function GET() {
  await refreshMetricsIfStale();
  const state = readVaultState();
  return NextResponse.json(state, {
    headers: { "Cache-Control": "no-store" },
  });
}
