import { NextResponse } from "next/server";
import { VAULT_ROOT } from "@/lib/config";
import { readFile, readdir } from "fs/promises";
import path from "path";

export const dynamic = "force-dynamic";

// Lean brand list for the HUD: discovered by directory, not a hardcoded list —
// adding a brand = adding a folder under jarvis-os/brand-os/<id>/os.json.
type Brand = {
  id: string;
  label: string;
  target_daily_eur: number;
  roadmap_stage: number;
  roadmap_now?: string;
};

const BRAND_OS_DIR = path.join(VAULT_ROOT, "jarvis-os", "brand-os");

// Brands are listed alphabetically by id — no hardcoded order. To pin a
// specific order, rename the folders or sort on a manifest field.
function orderBrands(brands: Brand[]): Brand[] {
  return [...brands].sort((a, b) => a.id.localeCompare(b.id));
}

// GET /api/brands — the brand list straight from the os.json manifests.
// Skips folders without a readable/valid os.json. Errors → empty list (the HUD
// keeps "Panoramica" as a built-in first tab regardless).
export async function GET() {
  try {
    let dirs: string[] = [];
    try {
      const entries = await readdir(BRAND_OS_DIR, { withFileTypes: true });
      dirs = entries.filter((e) => e.isDirectory()).map((e) => e.name);
    } catch {
      return NextResponse.json({ brands: [] });
    }

    const brands: Brand[] = [];
    for (const id of dirs) {
      try {
        const raw = await readFile(
          path.join(BRAND_OS_DIR, id, "os.json"),
          "utf8"
        );
        const os = JSON.parse(raw) as Partial<Brand>;
        // a manifest is only usable if it has the fields the HUD relies on
        if (
          typeof os.id !== "string" ||
          typeof os.label !== "string" ||
          typeof os.target_daily_eur !== "number" ||
          typeof os.roadmap_stage !== "number"
        ) {
          continue;
        }
        brands.push({
          id: os.id,
          label: os.label,
          target_daily_eur: os.target_daily_eur,
          roadmap_stage: os.roadmap_stage,
          ...(typeof os.roadmap_now === "string"
            ? { roadmap_now: os.roadmap_now }
            : {}),
        });
      } catch {
        continue; // missing/corrupt os.json → skip this folder
      }
    }

    return NextResponse.json({ brands: orderBrands(brands) });
  } catch {
    return NextResponse.json({ brands: [] });
  }
}
