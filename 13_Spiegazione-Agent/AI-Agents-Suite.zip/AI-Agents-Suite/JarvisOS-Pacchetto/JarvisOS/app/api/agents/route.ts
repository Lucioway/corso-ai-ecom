import { NextResponse } from "next/server";
import { VAULT_ROOT } from "@/lib/config";
import { readFile, stat } from "fs/promises";
import path from "path";
import { execFile } from "child_process";
import { promisify } from "util";

const pexec = promisify(execFile);
export const dynamic = "force-dynamic";

const FILE = path.join(VAULT_ROOT, "system", "agents.json");
const SCRIPT = path.resolve(process.cwd(), "agents_status.py");

// GET /api/agents — status of the user's autonomous launchd agents.
// Refreshes via agents_status.py when the cache is older than 2 min.
export async function GET() {
  try {
    let fresh = false;
    try {
      const s = await stat(FILE);
      fresh = Date.now() - s.mtimeMs < 120_000;
    } catch {
      /* no file yet */
    }
    if (!fresh) {
      try {
        await pexec("python3", [SCRIPT], { timeout: 15_000 });
      } catch {
        /* launchctl/python hiccup — serve whatever's cached */
      }
    }
    const data = await readFile(FILE, "utf8");
    return NextResponse.json(JSON.parse(data));
  } catch {
    return NextResponse.json({ updated: null, agents: [] });
  }
}
