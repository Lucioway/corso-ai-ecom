#!/usr/bin/env python3
"""Sync the HUD's metrics.csv from a goal_state.json.

If you run an external pipeline that produces a goal_state.json (one entry per
brand with rev_day / margin_pct / source), point GOAL_STATE at it and this
script appends one row per brand (+ combined total) to the HUD's append-only
metrics.csv, so the Vitals / North-Star panels read live numbers. The HUD's
/api/state runs this when the csv goes stale. With no goal_state.json the csv
is left untouched (the HUD renders whatever rows already exist).

Set the source path via the GOAL_STATE env var, or drop the file at the
default below.

Run:  python3 metrics_build.py
"""
import csv, datetime as dt, json, os
from pathlib import Path

HERE = Path(__file__).resolve().parent
VAULT = Path(os.environ.get("VAULT_ROOT", HERE / "starter-vault"))
OUT = VAULT / "system" / "metrics" / "metrics.csv"

# Where the brand revenue snapshot lives. Override with the GOAL_STATE env var;
# otherwise look for it inside the vault. Missing → csv left untouched.
GOAL_CANDIDATES = [
    Path(os.environ["GOAL_STATE"]) if os.environ.get("GOAL_STATE") else None,
    VAULT / "system" / "metrics" / "goal_state.json",
]
GOAL_CANDIDATES = [p for p in GOAL_CANDIDATES if p is not None]

HEADER = ["timestamp", "source", "metric", "value", "status", "error"]
CAP = 400  # keep the csv bounded (header + last CAP rows)


def load_goal():
    for p in GOAL_CANDIDATES:
        if p.exists():
            try:
                return json.loads(p.read_text())
            except (ValueError, OSError):
                continue
    return None


def main():
    goal = load_goal()
    if not goal:
        return  # nothing to sync — leave existing csv untouched
    now = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")

    rows = []
    total = 0
    margin_num = 0.0  # Σ(rev × margin%) — numerator of the revenue-weighted blend
    for b in goal.get("brands", []):
        rev = int(round(float(b.get("rev_day", 0))))
        margin = float(b.get("margin_pct", 0))
        total += rev
        margin_num += rev * margin
        # live brands report ok; manual brands at 0 stay flagged mock (SIM)
        status = "ok" if b.get("source") == "live" else "mock"
        rows.append([now, "business", b["key"], rev, status, ""])
        rows.append([now, "business", f"margin_{b['key']}", round(margin, 1), status, ""])
    rows.append([now, "business", "revenue_total", total, "ok", ""])
    # combined margin = revenue-weighted average of brand margins
    margin_total = round(margin_num / total, 1) if total else 0
    rows.append([now, "business", "margin_total", margin_total, "ok", ""])

    OUT.parent.mkdir(parents=True, exist_ok=True)
    existing = []
    if OUT.exists():
        with OUT.open() as f:
            existing = [r for r in csv.reader(f) if r and r[0] != "timestamp"]
    allrows = (existing + rows)[-CAP:]

    with OUT.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(HEADER)
        w.writerows(allrows)

    print(f"synced {len(rows)} rows @ {now} — total €{total}/day")


if __name__ == "__main__":
    main()
