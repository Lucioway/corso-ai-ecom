# SETUP — Istruzioni per Claude Code

> **Per l'utente:** apri Claude Code, dai accesso a questa cartella e scrivi:
> *"Leggi SETUP.md e implementa JarvisOS nel mio sistema, fatto bene, deve
> essere production-grade e vendibile — controlla tutto."*
> Claude farà il resto seguendo questo file.

---

## Cosa stai installando

**JarvisOS** — un centro di comando AI personale, self-hosted, in italiano:
una dashboard vocale per gestire qualsiasi business o progetto (numeri, task,
agenti automatici, roadmap). Tre servizi:

| Servizio | Porta | Stack |
|---|---|---|
| Dashboard (HUD) | 3107 | Next.js 15 |
| Voce | 3108 | Python — edge-tts (TTS) + faster-whisper (STT) |
| Esecutore (runner) | — | Node — esegue skill via `claude -p` |

Il codice completo è nella sottocartella **`JarvisOS/`**. Lo stato è in file
(`JarvisOS/starter-vault/`), nessun database. Brand e agenti sono **manifest
JSON** dichiarativi — personalizzabili senza toccare codice.

**Documentazione completa:** `GUIDA-MANUALE.md` (e `.pdf`) in questa cartella.

---

## Il tuo compito (Claude Code)

Installa, configura e verifica JarvisOS **a regola d'arte**, pronto per essere
usato e venduto. Adatta ogni comando, percorso e launcher all'ambiente reale
(macOS / Linux / Windows / server cloud) senza chiedere conferme banali.

### Fase 0 — Rileva l'ambiente
OS, GPU NVIDIA (per la voce), Node, Python, e la CLI `claude` (deve essere
installata e loggata per le skill). Su server cloud headless: dashboard e
agenti girano lo stesso; la voce (microfono/altoparlanti) è opzionale o via
browser del client. Documenta cosa è attivo.

### Fase 1 — Installa le dipendenze
```bash
cd JarvisOS
npm install
cd voice-server && python3 -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
```
Con GPU NVIDIA usa `onnxruntime-gpu`; senza, `onnxruntime` (voce in CPU).

### Fase 2 — Onboarding
Esegui l'intervista in `JarvisOS/ONBOARD.md` (italiano): punta il vault, nomina
le metriche, scegli le opzioni voce, scrivi `.jarvis-config.json`. Aiuta
l'utente a creare il **suo primo brand** (`starter-vault/jarvis-os/brand-os/<id>/os.json`)
al posto di "Acme".

### Fase 3 — Build e verifica (NON saltare)
```bash
cd JarvisOS
npx tsc --noEmit          # deve uscire 0
npm run build             # deve compilare
npm test                  # router sweep, 16/16
python3 -m jarvis_os.test_validate                                   # ALL OK
python3 -m jarvis_os.validate starter-vault/jarvis-os/brand-os/<id>  # OK
```

### Fase 4 — Avvia i 3 servizi (persistenti)
Voce (`voice-server/server.py`), runner (`runner/runner.js`), dashboard
(`next start -p 3107`) in modo detached/keep-alive (launchd/systemd/pm2/
supervisor). Verifica:
- `http://localhost:3107` → carica
- `http://127.0.0.1:3108/health` → `{"ok": true, "engine": "edge-tts"}`
- `/api/brands`, `/api/brand-os`, `/api/agents`, `/api/state` → 200
- `/api/speak?text=prova` → audio
- POST `/api/voice/text` `{"transcript":"che ore sono"}` → risposta italiana

### Fase 5 — Controllo qualità finale (must)
- **Sicurezza**: nessun segreto hardcoded; `.env` non committati; esponi solo le
  porte necessarie; su cloud pubblico metti auth/reverse-proxy davanti.
- **Pulizia dati**: parte con un brand d'esempio "Acme" e zero dati personali.
- **Italiano**: UI e voce 100% italiane.
- **Robustezza**: i 3 servizi si riavviano da soli; avvio automatico configurato.
- **Smoke test E2E**: boot (click + schiocco), parla ("che ore sono"), aggiungi un
  task nel Pianificatore, trascinalo tra le colonne, lancia una skill.

### Fase 6 — Consegna
Report all'utente: cosa è attivo, URL/porte, come avviare/fermare, come
aggiungere un brand (Guida §13–14), e cosa richiede la sua attenzione (login
`claude`, chiavi metriche).

---

## Regole
- **Production-grade**: niente scorciatoie, niente passi saltati. Se una verifica
  fallisce, fermati e sistema prima di proseguire.
- **Adatta all'OS** senza chiedere.
- **Non inventare dati**: i brand/agenti reali li crea l'utente.
- **Leggi la Guida Manuale** per ogni dettaglio prima di modificare comportamenti.

---

*Pacchetto JarvisOS v1.0 — pronto per l'installazione.*
