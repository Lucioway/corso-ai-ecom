# JarvisOS — Guida Manuale

Il tuo centro di comando AI personale. Una dashboard vocale in italiano per
gestire qualsiasi business o progetto: numeri, task, agenti automatici e
roadmap, in un'unica interfaccia che parla e ascolta. Gira a casa tua, i tuoi
dati restano tuoi.

---

## Indice

1. [Cos'è JarvisOS](#1-cosè-jarvisos)
2. [Requisiti](#2-requisiti)
3. [Installazione e primo avvio](#3-installazione-e-primo-avvio)
4. [Architettura: i 3 servizi](#4-architettura-i-3-servizi)
5. [Avviare JarvisOS](#5-avviare-jarvisos)
6. [La sequenza di avvio (boot)](#6-la-sequenza-di-avvio-boot)
7. [Comandi vocali](#7-comandi-vocali)
8. [Tasti rapidi](#8-tasti-rapidi)
9. [La dashboard — Panoramica](#9-la-dashboard--panoramica)
10. [La dashboard — pagina Brand](#10-la-dashboard--pagina-brand)
11. [Il Task Planner](#11-il-task-planner)
12. [Agenti automatici e manifest](#12-agenti-automatici-e-manifest)
13. [Personalizzazione: aggiungere un brand](#13-personalizzazione-aggiungere-un-brand)
14. [Personalizzazione: aggiungere un agente](#14-personalizzazione-aggiungere-un-agente)
15. [Le Skill (pannello Comandi)](#15-le-skill-pannello-comandi)
16. [Notizie AI / Report Mattino](#16-notizie-ai--report-mattino)
17. [Privacy (oscura brand)](#17-privacy-oscura-brand)
18. [Struttura dei file (il vault)](#18-struttura-dei-file-il-vault)
19. [Risoluzione problemi](#19-risoluzione-problemi)
20. [FAQ](#20-faq)

---

## 1. Cos'è JarvisOS

JarvisOS è un'app che gira sul tuo computer (non sul cloud) ed è composta da:

- **una dashboard** stile "centro di comando" (interfaccia web su `localhost:3107`)
- **una voce italiana** che ascolta i tuoi comandi e ti risponde
- **un esecutore di automazioni** (agenti) che lavorano per te in background

La cosa centrale: **brand e agenti sono dichiarativi**. Tutto vive in file JSON
leggibili (i "manifest"). Aggiungere un business = creare una cartella.
Aggiungere un agente = un file. Zero codice da toccare.

---

## 2. Requisiti

- **Node.js** 18+ (per la dashboard e l'esecutore)
- **Python** 3.10+ (per la voce e gli script)
- **Claude Code CLI** installato e loggato (`claude`) — serve all'esecutore per
  far girare le skill (report, pianificazione, ecc.)
- Un **browser** moderno (Chrome consigliato per audio/microfono)
- **Microfono** (per i comandi vocali; opzionale — la dashboard funziona anche
  muta)
- Sistema: macOS, Windows o Linux. Su Mac/Linux senza GPU NVIDIA la voce gira in
  modalità CPU (più lenta ma pienamente funzionante).

> La voce usa **edge-tts** (sintesi vocale neurale Microsoft, gratuita, nessuna
> chiave) e **faster-whisper** per capire l'italiano. Nessun modello pesante da
> scaricare a mano.

---

## 3. Installazione e primo avvio

1. Scompatta la cartella `JarvisOS` dove preferisci.
2. Apri **Claude Code** dentro la cartella (`cd JarvisOS` poi `claude`).
3. Alla prima apertura non esiste ancora `.jarvis-config.json`: Claude legge
   `ONBOARD.md` e ti guida con un'**intervista in italiano** per personalizzare
   tutto (vault, metriche, voce, esecutore). Basta dire *"configura questo per
   me"*.
4. L'intervista installa le dipendenze, prepara i servizi e scrive
   `.jarvis-config.json` per segnare l'onboarding come completato.

Manualmente, l'installazione delle dipendenze è:
```bash
npm install                       # dashboard + esecutore
cd voice-server && pip install -r requirements.txt   # voce (in un venv consigliato)
```

---

## 4. Architettura: i 3 servizi

| Servizio | Porta | Cosa fa |
|---|---|---|
| **Dashboard (HUD)** | `:3107` | L'interfaccia Next.js che vedi nel browser |
| **Voce (voice-server)** | `:3108` | Sintesi (edge-tts) + ascolto (Whisper) in Python |
| **Esecutore (runner)** | — | Demone Node che esegue le skill via `claude -p` |

Lo **stato** è tutto in file dentro il vault (`starter-vault/`). Nessun
database. Se copi il vault, copi tutto.

---

## 5. Avviare JarvisOS

Chiedi a Claude Code *"avvia Jarvis"* e parte tutto in ordine. Oppure a mano:

```bash
# 1) Voce
cd voice-server && python server.py          # :3108
# 2) Esecutore
node runner/runner.js                          # demone skill
# 3) Dashboard
npx next build && npx next start -p 3107       # :3107
```

Poi apri **http://localhost:3107** nel browser.

> Per l'avvio automatico al login: macOS → launchd, Linux → systemd, Windows →
> collegamenti in `shell:startup`. Chiedi a Claude di cablarlo per te.

---

## 6. La sequenza di avvio (boot)

All'apertura vedi una **schermata di pre-lancio** stile Jarvis. L'avvio è in 3
passi:

1. **Click** nella pagina → sblocca microfono e audio (regola del browser).
2. **Doppio schiocco di dita** 👏👏 → avvia il sistema. Parte l'animazione di
   boot.
3. A boot finito → la dashboard appare e Jarvis ti **saluta a voce**.

Dopo l'avvio, l'attivazione vocale è solo con la **barra Spazio** (vedi sotto).
Lo schiocco serve solo una volta, per accendere il sistema.

---

## 7. Comandi vocali

**Tieni premuto SPAZIO** per parlare, rilascia per inviare. **ESC** ferma la
voce di Jarvis (barge-in). Tutto in italiano.

Esempi che Jarvis capisce e a cui risponde **all'istante** (senza eseguire
nulla):

| Dici… | Risponde |
|---|---|
| "che ore sono" | "Sono le 14:30, signore." |
| "come va" / "a che punto siamo" | riepilogo della giornata |
| "ciao Jarvis" / "salve" | saluto + stato |
| "quanti task ho aperti" | conteggio task |
| "quanti task per [brand]" | conteggio per quel brand |
| "cosa devo fare oggi" | i primi task aperti |
| "qual è il fatturato di oggi" | il combinato in euro |

Comandi che **eseguono una skill** (richiedono l'esecutore acceso):

| Dici… | Fa partire |
|---|---|
| "lancia il report di stamattina" | morning-report |
| "pianifica oggi" | plan-today |
| "controlla la inbox" | inbox-brief |

Aggiungere/completare task a voce:
- "aggiungi un task per [brand]: [cosa]"
- "ho completato [parte del task]"

---

## 8. Tasti rapidi

| Tasto | Azione |
|---|---|
| **Spazio** (tieni premuto) | Parla (push-to-talk) |
| **Esc** | Ferma la voce / chiudi overlay |
| **1–5** | Forza modalità core (1 inattivo · 2 al lavoro · 3 ascolto · 4 voce · 5 errore) |
| **0** | Torna a modalità automatica |
| **b** | Cambia lo stile dello sfondo (orb) |

---

## 9. La dashboard — Panoramica

La vista **Panoramica** (tab in alto a sinistra) è il quadro d'insieme di tutti
i tuoi brand. I pannelli:

- **Oggi · Priorità** — i task aperti più urgenti di tutti i brand, per scadenza.
- **Vitali** — le metriche chiave (es. fatturato/giorno per brand, follower).
- **Comandi** — i pulsanti che lanciano le skill (vedi §15) + lo stato della coda.
- **Audio I/O** — l'onda della voce e il mini-feed di cosa è stato detto/fatto.
- **Direttive** — le tue Top 3 priorità del giorno (dal report di pianificazione).
- **Documenti** — gli ultimi file prodotti dalle skill (click per aprirli).
- **Notizie AI** — le headline del Report Mattino (vedi §16).
- **Agenda** — gli appuntamenti del giorno.
- **Brand OS** — una card per ogni brand: obiettivo €/giorno, stage roadmap,
  numero agenti attivi, pallino di salute.
- **Platform** — i servizi condivisi tra tutti i brand (es. ricerca, news).
- **Obiettivo** (al centro in basso) — il fatturato combinato verso la tua meta.
- **Agenti automatici** (in basso a destra) — lo stato live di ogni agente.

L'**orb** centrale reagisce alla voce: si illumina quando Jarvis parla o ascolta.

---

## 10. La dashboard — pagina Brand

Clicca una tab brand (es. "Acme") per la **pagina dedicata** di quel business:

- **Obiettivo** — €/giorno del brand verso il suo target.
- **Roadmap** — la scala di crescita (Stage 0–9): un pallino "SIAMO QUI" segna a
  che punto sei, con la prossima mossa.
- **Vitali** — le metriche del brand.
- **Dashboard KPI** — link alle dashboard esterne del brand (se configurate).
- **Task** — la checklist dei task del brand.
- **Agenti** — gli agenti di quel brand + quelli condivisi (Platform).

---

## 11. Il Task Planner

Apri il **Pianificatore** (pulsante ▦ in basso). È una lavagna kanban a 3
colonne: **Da Fare · In Corso · Fatto**.

- **Trascina** una card da una colonna all'altra (drag & drop) per cambiarne lo
  stato. La colonna di arrivo si illumina.
- **Clicca sul testo** di una card per modificarlo al volo (Invio salva, Esc
  annulla).
- **Clicca sulle date** (o su "+ data") per impostare *dal* / *entro*.
- Dentro ogni colonna i task si ordinano per **scadenza** (i più urgenti in
  cima, i senza data in fondo). I task scaduti sono evidenziati in rosso.
- Il pulsante **→ In Corso / ✓ Fatto / ↺ Riapri** fa la stessa cosa con un
  click (comodo su touch).
- Filtra per brand con le tab in alto. Aggiungi un task col form (brand, cosa,
  quando, entro).

I task vivono in `starter-vault/system/tasks.json` e sono modificabili anche a
voce.

---

## 12. Agenti automatici e manifest

Un "agente" è un'automazione (un job che gira a orari, o uno strumento con una
dashboard). JarvisOS **non li crea**: li **monitora e li comanda**. Ogni agente
è descritto da un **manifest** JSON.

Schema di un agente:
```json
{
  "id": "report-giornaliero",
  "label": "Report Giornaliero",
  "scope": "acme",            // un brand, oppure "shared" / "overview"
  "kind": "scheduled",        // service | scheduled | tool
  "backend":  { "launchd": "com.example.report", "health": null },
  "frontend": null,            // oppure { "url": "https://..." }
  "schedule": "17:00",
  "brief": "P&L giornaliero del brand"
}
```

- **scope** decide dove appare: un brand (solo lì), `shared` (in tutti i brand +
  Panoramica), `overview` (solo Panoramica).
- **backend** = un processo reale (job di sistema) → mostrato come **sfera di
  stato** (verde ok, rosso errore, giallo in ritardo, grigio spento).
- **frontend** = una dashboard → mostrato come **link "Apri ↗"** (apre in una
  tab nuova).

Lo stato degli agenti si calcola con `agents_status.py`, che la dashboard legge
da `/api/agents`.

---

## 13. Personalizzazione: aggiungere un brand

JarvisOS parte con un brand d'esempio ("Acme"). Per aggiungere il tuo:

1. Crea la cartella e il manifest:
   `starter-vault/jarvis-os/brand-os/mio-brand/os.json`
   ```json
   {
     "id": "mio-brand",
     "label": "Il Mio Brand",
     "target_daily_eur": 5000,
     "roadmap_stage": 1,
     "roadmap_now": "prossima mossa concreta",
     "brief": "descrizione breve"
   }
   ```
2. Crea la cartella agenti (anche vuota):
   `starter-vault/jarvis-os/brand-os/mio-brand/agents/`
3. Ricarica la dashboard. Il brand appare come tab, con obiettivo e roadmap.

**Zero codice.** `id` dev'essere uno slug minuscolo (lettere, numeri, trattini).
`roadmap_stage` è 0–9 (la scala di crescita).

Per togliere il brand d'esempio: cancella la cartella `brand-os/acme/`.

---

## 14. Personalizzazione: aggiungere un agente

1. Per un agente **di un brand**:
   `starter-vault/jarvis-os/brand-os/mio-brand/agents/mio-agente.json`
2. Per un agente **condiviso** (tutti i brand):
   `starter-vault/jarvis-os/platform/agents/mio-agente.json` con `"scope": "shared"`
3. Usa lo schema della §12. Ricarica la dashboard.

Verifica che un manifest sia valido:
```bash
python3 -m jarvis_os.validate starter-vault/jarvis-os/brand-os/mio-brand
```
Stampa un errore chiaro (file + campo) se qualcosa non va.

---

## 15. Le Skill (pannello Comandi)

Le skill sono automazioni eseguite dall'esecutore via Claude. Le lanci dai
pulsanti del pannello **Comandi** (o a voce):

| Skill | Cosa fa |
|---|---|
| **Report Mattino** | Briefing AI/tech delle ultime 24h → popola "Notizie AI" |
| **Brief Inbox** | Tria la posta in arrivo e ne fa un riepilogo |
| **Pianifica Oggi** | Prepara la nota del giorno con le Top 3 priorità |
| **Pianifica Domani** | Bozza delle priorità di domani |
| **Pulizia Vault** | Archivia i file vecchi/inattivi e fa un report |

Quando premi un pulsante, l'intent va nella coda (`system/queue/`) e l'esecutore
lo lavora; l'output appare nel pannello **Documenti**. Richiede l'esecutore
acceso e `claude` loggato.

---

## 16. Notizie AI / Report Mattino

Il pannello **Notizie AI** mostra le headline del Report Mattino. Su
un'installazione nuova c'è un report di **esempio** (sostituibile). Per le
notizie vere:

- premi **Report Mattino** nei Comandi, **oppure**
- programma l'esecuzione automatica (es. ogni mattina alle 07:00).

Se non c'è il report di oggi, la dashboard mostra il **più recente disponibile**
(così il pannello resta sempre vivo). Se non c'è alcun report, mostra l'invito a
generarne uno.

---

## 17. Privacy (oscura brand)

Il pulsante **Oscura brand** (in basso) sfoca tutti i nomi dei brand e i dati
sensibili nella dashboard — utile per screen-share, demo o screenshot. Il
layout resta identico, cambia solo la visibilità. Clicca di nuovo per
ripristinare.

---

## 18. Struttura dei file (il vault)

Tutto lo stato è in `starter-vault/`:

```
starter-vault/
  jarvis-os/
    brand-os/<brand>/os.json        # identità + obiettivo + roadmap del brand
    brand-os/<brand>/agents/*.json  # agenti del brand
    platform/agents/*.json          # agenti condivisi (scope shared/overview)
  system/
    tasks.json                      # i task del planner
    agents.json                     # stato agenti (generato)
    queue/                          # intent in attesa per l'esecutore
    runs/                           # log delle esecuzioni
    metrics/                        # metriche
    schemas/daily-note.md           # template nota giornaliera
  inbox/
    reports/morning/                # i Report Mattino (Notizie AI)
    voice/                          # trascrizioni vocali
  daily-notes/                      # le note di pianificazione
  archive/                          # file archiviati
```

Il validatore dei manifest è in `jarvis_os/` (Python, stdlib, nessuna
dipendenza). La dashboard è in `app/` + `components/`, la voce in
`voice-server/`, l'esecutore in `runner/`.

---

## 19. Risoluzione problemi

| Problema | Soluzione |
|---|---|
| La voce non parte | Verifica `http://127.0.0.1:3108/health`. Se è giù, riavvia `voice-server/server.py`. |
| "voce in coda — clic per sbloccare audio" | Fai un click nella pagina: il browser blocca l'audio finché non c'è un gesto. |
| Doppio audio | Hai due tab aperte. Tienine una sola. |
| Le skill non partono | L'esecutore non gira o `claude` non è loggato. Riavvia il runner da un terminale autenticato. |
| Un brand non appare | Controlla che `os.json` sia valido: `python3 -m jarvis_os.validate ...`. |
| Un agente sempre "spento" | Il suo job di sistema (launchd/systemd) non è caricato. Verifica il campo `backend.launchd`. |
| La dashboard non carica | Riavvia `next start -p 3107`. Se si blocca dopo un errore di build, cancella `.next/` e ricostruisci. |
| Microfono sbagliato | JarvisOS preferisce un mic esterno (USB/Samson). Collega quello giusto e ricarica. |

---

## 20. FAQ

**I miei dati vanno nel cloud?**
No. Tutto gira a casa tua; lo stato sono file nel vault. La voce usa edge-tts
(sintesi) che è un servizio Microsoft gratuito, ma i tuoi dati di business
restano locali.

**Devo saper programmare per personalizzarlo?**
No. Brand e agenti si aggiungono creando file JSON (manifest). La dashboard li
legge da sola.

**Funziona in inglese?**
L'interfaccia e la voce sono in italiano. Si possono cambiare, ma la versione di
serie è italiana.

**Posso usarlo per qualsiasi attività?**
Sì — ecommerce, social, agenzia, freelance, progetti personali. I "brand" sono
solo contenitori: chiamali come vuoi.

**Come lo aggiorno con i miei numeri reali?**
Collega i tuoi script di metriche al vault (`system/metrics/`) seguendo
`ONBOARD.md`. La dashboard mostrerà i tuoi dati.

---

*JarvisOS v1.0 — il tuo centro di comando AI, in italiano, a casa tua.*
