# SETUP — Istruzioni per Claude Code

> **Per l'utente:** apri Claude Code, dai accesso a questa cartella e scrivi:
> *"Leggi SETUP.md e installa OrderAgent nel mio sistema, fatto bene, deve
> essere production-grade e affidabile — controlla tutto."*
> Claude farà il resto seguendo questo file.

---

## Cosa stai installando

**OrderAgent** — un agente self-hosted, in Python, che ogni notte:

1. scarica via **Shopify Admin API** tutti gli ordini del **giorno precedente**;
2. genera un **CSV nel formato di export nativo Shopify** (76 colonne);
3. lo invia **via email (Gmail SMTP)** al tuo fornitore;
4. manda un **riepilogo su Telegram**. Se non ci sono ordini, manda solo la
   notifica Telegram (nessuna email).

Il codice completo è nella sottocartella **`OrderAgent/`**. Non usa database:
lo stato è un singolo file (`state/last_processed.txt`) per l'idempotenza, e i
CSV già spediti finiscono in `archive/`. Tutta la configurazione vive nel file
`.env` (a partire da `.env.example`).

| Componente | Cosa fa |
|---|---|
| `scripts/main.py` | Entry point CLI + scheduler (APScheduler) |
| `scripts/shopify_export.py` | Scarica ordini via API → CSV formato Shopify |
| `scripts/email_sender.py` | Invia il CSV al fornitore via Gmail SMTP |
| `scripts/telegram_notifier.py` | Notifiche Telegram (successo / zero ordini / errore) |
| `scripts/config.py` | Carica `.env`, espone le costanti, valida la config |
| `run_daily.sh` | Launcher giornaliero (per launchd/cron) |

**Documentazione completa:** `GUIDA-MANUALE.md` in questa cartella — leggila per
capire ogni comando, variabile e dettaglio del formato CSV.

---

## Il tuo compito (Claude Code)

Installa, configura e verifica OrderAgent **a regola d'arte**, pronto per girare
in produzione ogni notte. Adatta ogni comando, percorso e launcher all'ambiente
reale (macOS / Linux / server cloud) senza chiedere conferme banali.

### Fase 0 — Rileva l'ambiente
- Sistema operativo, versione di **Python 3.9+** (serve `zoneinfo`, incluso da
  3.9), e disponibilità di `python3 -m venv`.
- Verifica l'accesso in uscita verso `*.myshopify.com`, `smtp.gmail.com:587` e
  `api.telegram.org`.
- Se è un **server cloud headless**: gira tutto lo stesso (nessuna UI, nessun
  audio). Documenta come avviare lo scheduler in modo persistente.

### Fase 1 — Installa le dipendenze
```bash
cd OrderAgent
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```
Dipendenze (3, leggere): `python-dotenv`, `requests`, `APScheduler`.

### Fase 2 — Configura le credenziali
```bash
cp .env.example .env
```
Poi compila `.env`. Variabili **obbligatorie**:

| Variabile | Descrizione |
|---|---|
| `SHOPIFY_STORE_URL` | es. `https://tuo-store.myshopify.com` |
| `SHOPIFY_API_TOKEN` | token Admin API (`shpat_…`), scope **`read_orders`** |
| `SMTP_EMAIL` | indirizzo Gmail mittente |
| `SMTP_PASSWORD` | **App Password** Gmail a 16 caratteri (non la password normale) |
| `SUPPLIER_EMAIL` | indirizzo del fornitore che riceve il CSV |
| `TELEGRAM_BOT_TOKEN` | token del bot (da @BotFather) |
| `TELEGRAM_CHAT_ID` | chat ID destinatario (da @userinfobot) |

Opzionali: `STORE_NAME` (nome nell'oggetto email; default = sottodominio del
negozio), `SCHEDULE_HOUR` (default `1`), `SCHEDULE_MINUTE` (default `0`),
`TIMEZONE` (default `Europe/Rome`).

> **Token Shopify:** Admin → Settings → Apps → *Develop apps* → crea una Custom
> App con il solo scope `read_orders`. **App Password Gmail:** Account Google →
> Sicurezza → 2FA → App Passwords.

### Fase 3 — Verifica la configurazione (NON saltare)
```bash
python scripts/main.py --check
```
Deve stampare tutto verde: `.env` completo, **Shopify API connessa** (mostra il
nome del negozio), **bot Telegram connesso** (mostra @username), **SMTP
connesso**. Se qualcosa è rosso, fermati e sistemalo prima di proseguire.

### Fase 4 — Test a vuoto (dry-run)
```bash
python scripts/main.py --dry-run
```
Conta gli ordini di ieri e simula tutto **senza inviare** email o notifiche.
Serve a confermare che il conteggio combaci con la dashboard Shopify.

### Fase 5 — Prima esecuzione reale
```bash
python scripts/main.py --once
```
Esecuzione singola: scarica → CSV → email al fornitore → Telegram → archivia il
CSV in `archive/`. Scrive la data in `state/last_processed.txt` (idempotenza:
una seconda `--once` nello stesso giorno viene saltata; per forzare usa
`--force`).

### Fase 6 — Schedulazione persistente
Imposta l'esecuzione automatica giornaliera. **Due opzioni:**

**A) Scheduler interno (processo sempre attivo):**
```bash
python scripts/main.py --schedule    # gira ogni giorno alle 01:00 TIMEZONE
```
Avvialo in modo persistente (launchd/systemd/pm2 a seconda dell'OS).

**B) Launcher one-shot via launchd/cron (consigliato su macOS):**
usa `run_daily.sh`, che fa una singola `--once` e logga in `logs/scheduled.log`.
Esempio launchd: vedi `OrderAgent/README.md` (plist con `StartCalendarInterval`
alle 01:00). Su macOS aggiungi `sudo pmset repeat wakeorpoweron MTWRFSU
00:00:00` perché il Mac si svegli a mezzanotte e launchd parta puntuale.

### Fase 7 — Controllo qualità finale (must)
- **Sicurezza**: nessuna chiave nel codice; `.env` **non** committato (è già in
  `.gitignore`); permessi `chmod 600 .env`.
- **Pulizia dati**: il pacchetto parte con zero dati reali — solo `.env.example`
  con placeholder. Conferma che `state/`, `archive/`, `downloads/`, `logs/` non
  esistano o siano vuoti.
- **Robustezza**: lo scheduler/launcher si riavvia da solo dopo reboot.
- **Smoke end-to-end**: `--check` verde, `--dry-run` con conteggio coerente,
  `--once` reale che recapita CSV + Telegram, idempotenza confermata.

### Fase 8 — Consegna
Scrivi un breve report all'utente: cosa è attivo, l'orario di esecuzione, dove
sono i log (`logs/`) e gli archivi (`archive/`), come fare un run manuale
(`--once`) e cosa richiede la sua attenzione (token Shopify, App Password Gmail,
chat ID Telegram).

---

## Regole

- **Production-grade**: niente scorciatoie. Se una verifica non passa, fermati e
  sistemala prima di proseguire.
- **Adatta all'OS**: comandi, percorsi e launcher cambiano per sistema — fallo
  senza chiedere.
- **Non inventare dati**: token, email e chat ID li fornisce l'utente; tu prepari
  la struttura e verifichi che tutto regga.
- **Leggi la Guida Manuale** per ogni dettaglio (formato CSV, idempotenza, fusi
  orari) prima di modificare comportamenti.

---

*Pacchetto OrderAgent v1.0 — pronto per l'installazione.*
