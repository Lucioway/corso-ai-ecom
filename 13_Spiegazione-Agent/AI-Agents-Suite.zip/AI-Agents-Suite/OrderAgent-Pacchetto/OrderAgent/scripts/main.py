"""Shopify Order Agent — CLI + scheduler entry point."""

import argparse
import logging
import sys
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

# Logger
LOG_DIR = Path(__file__).resolve().parent.parent / "logs"
LOG_DIR.mkdir(exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "agent.log"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("shopify-order-agent")

from config import (
    validate_env, ensure_dirs, SUPPLIER_EMAIL,
    SCHEDULE_HOUR, SCHEDULE_MINUTE, TIMEZONE,
)
from shopify_export import fetch_yesterday_orders, check_api_connection
from email_sender import send_order_email
from telegram_notifier import (
    notify_success, notify_no_orders, notify_error, check_connection,
)

STORE_TZ = ZoneInfo(TIMEZONE)

STATE_FILE = Path(__file__).resolve().parent.parent / "state" / "last_processed.txt"


def _already_processed(date_str: str) -> bool:
    """Idempotency guard: True if date_str already successfully sent."""
    if not STATE_FILE.exists():
        return False
    return STATE_FILE.read_text().strip() == date_str


def _mark_processed(date_str: str) -> None:
    STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    STATE_FILE.write_text(date_str)


def run_once(dry_run=False, force=False):
    """Single run: export yesterday's orders, email CSV to supplier, notify via Telegram.

    'Yesterday' is computed in TIMEZONE (default Europe/Rome) so it aligns
    with the Shopify dashboard regardless of the host system timezone.
    Idempotency: uses state/last_processed.txt; bypass with force=True.
    """
    yesterday = (datetime.now(STORE_TZ) - timedelta(days=1)).date()
    date_str = yesterday.strftime("%Y-%m-%d")

    print(f"\n{'='*50}")
    print(f"🚀 Shopify Order Agent — {date_str}")
    print(f"{'='*50}\n")

    if not force and not dry_run and _already_processed(date_str):
        print(f"⏭️  {date_str} already processed (state/last_processed.txt). Skip.")
        print(f"   Override with --force to resend.")
        return True

    ensure_dirs()

    try:
        # 1. Fetch orders via API
        print("1️⃣  Fetching orders from Shopify API...")
        csv_path, order_count, first_order, last_order = fetch_yesterday_orders(dry_run=dry_run)

        # 2. Zero orders
        if order_count == 0:
            print("\n📭 No orders yesterday")
            notify_no_orders(date_str, dry_run=dry_run)
            return True

        if dry_run:
            print(f"\n🔸 DRY-RUN: {order_count} orders found ({first_order}-{last_order})")
            notify_success(order_count, first_order, last_order, SUPPLIER_EMAIL, date_str, dry_run=True)
            return True

        if not csv_path:
            notify_error("CSV generation failed", dry_run=dry_run)
            return False

        # 3. Send email
        print(f"\n2️⃣  Sending email to {SUPPLIER_EMAIL}...")
        email_ok = send_order_email(csv_path, order_count, first_order, last_order, dry_run=dry_run)

        if email_ok:
            _mark_processed(date_str)

        # 4. Telegram notification
        print("\n3️⃣  Telegram notification...")
        if email_ok:
            notify_success(order_count, first_order, last_order, SUPPLIER_EMAIL, date_str, dry_run=dry_run)
        else:
            notify_error(f"Email not sent — {order_count} orders exported", dry_run=dry_run)

        # 5. Archive CSV before cleanup
        archive_dir = Path(__file__).resolve().parent.parent / "archive"
        archive_dir.mkdir(exist_ok=True)
        try:
            archived = archive_dir / Path(csv_path).name
            Path(csv_path).replace(archived)
            print(f"  📦 CSV archived to archive/{archived.name}")
        except Exception as e:
            logger.debug("CSV archive error: %s", e)

        print(f"\n{'='*50}")
        print(f"✅ Done — {order_count} orders (#{first_order}-#{last_order})")
        print(f"{'='*50}\n")
        return True

    except Exception as e:
        print(f"\n❌ Error: {e}")
        notify_error(str(e), dry_run=dry_run)
        return False


def check_config():
    """Verify config: .env, API connections."""
    print("\n🔍 Checking configuration...\n")
    ok = True

    if not validate_env():
        ok = False

    print("\n  🛒 Testing Shopify API...")
    if not check_api_connection():
        ok = False

    print("\n  🤖 Testing Telegram...")
    if not check_connection():
        ok = False

    print("\n  📧 Testing SMTP...")
    try:
        import smtplib
        from config import SMTP_EMAIL, SMTP_PASSWORD
        with smtplib.SMTP("smtp.gmail.com", 587, timeout=10) as server:
            server.starttls()
            server.login(SMTP_EMAIL, SMTP_PASSWORD)
        print(f"  ✅ SMTP connected ({SMTP_EMAIL})")
    except Exception as e:
        print(f"  ❌ SMTP error: {e}")
        ok = False

    print(f"\n{'✅ All OK' if ok else '❌ Issues found — check .env'}\n")
    return ok


def start_scheduler():
    """Start APScheduler with daily execution."""
    from apscheduler.schedulers.blocking import BlockingScheduler
    from apscheduler.triggers.cron import CronTrigger

    scheduler = BlockingScheduler()
    trigger = CronTrigger(
        hour=SCHEDULE_HOUR,
        minute=SCHEDULE_MINUTE,
        timezone=TIMEZONE,
    )
    scheduler.add_job(run_once, trigger, id="shopify_orders")

    print(f"\n⏰ Scheduler started — daily at {SCHEDULE_HOUR:02d}:{SCHEDULE_MINUTE:02d} {TIMEZONE}")
    print("   Press Ctrl+C to stop\n")

    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        print("\n👋 Scheduler stopped")


def main():
    parser = argparse.ArgumentParser(description="Shopify Order Agent — export and email daily orders")
    parser.add_argument("--dry-run", action="store_true", help="Simulate without sending email/notifications")
    parser.add_argument("--once", action="store_true", help="Single run and exit")
    parser.add_argument("--schedule", action="store_true", help="Start daily scheduler")
    parser.add_argument("--check", action="store_true", help="Verify configuration")
    parser.add_argument("--force", action="store_true", help="Bypass idempotency guard (resend already-processed date)")

    args = parser.parse_args()

    if args.check:
        sys.exit(0 if check_config() else 1)

    if args.dry_run or args.once:
        success = run_once(dry_run=args.dry_run, force=args.force)
        sys.exit(0 if success else 1)

    # Default: scheduler
    if not validate_env():
        sys.exit(1)
    start_scheduler()


if __name__ == "__main__":
    main()
