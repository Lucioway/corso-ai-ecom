"""Modulo Shopify API: scarica ordini del giorno precedente come CSV."""

import csv
import requests
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
from pathlib import Path

from config import SHOPIFY_STORE_URL, SHOPIFY_API_TOKEN, DOWNLOAD_DIR

ROME_TZ = ZoneInfo("Europe/Rome")


def fetch_yesterday_orders(dry_run=False):
    """
    Scarica ordini di ieri via Shopify Admin API.
    Ritorna (csv_path, order_count, first_order, last_order) o (None, 0, None, None).
    """
    now_rome = datetime.now(ROME_TZ)
    yesterday = (now_rome - timedelta(days=1)).date()
    # Creo datetime espliciti a mezzanotte e fine giornata in timezone Roma (DST-aware)
    start_dt = datetime(yesterday.year, yesterday.month, yesterday.day, 0, 0, 0, tzinfo=ROME_TZ)
    end_dt = datetime(yesterday.year, yesterday.month, yesterday.day, 23, 59, 59, tzinfo=ROME_TZ)
    date_min = start_dt.isoformat()
    date_max = end_dt.isoformat()
    date_str = yesterday.strftime("%Y-%m-%d")

    print(f"📦 Recupero ordini del {date_str} via API...")

    # Fetch ordini
    orders = _fetch_all_orders(date_min, date_max)
    order_count = len(orders)
    print(f"  📋 Ordini trovati: {order_count}")

    if order_count == 0:
        return None, 0, None, None

    # Estrai numeri ordine (ordinati)
    order_numbers = sorted([o.get("order_number", 0) for o in orders])
    first_order = str(order_numbers[0])
    last_order = str(order_numbers[-1])

    if dry_run:
        print(f"  🔸 DRY-RUN: skip generazione CSV")
        return None, order_count, first_order, last_order

    # Genera CSV
    csv_path = _orders_to_csv(orders, first_order, last_order, date_str)
    print(f"  ✅ CSV generato: {csv_path.name}")

    return csv_path, order_count, first_order, last_order


def _fetch_all_orders(date_min, date_max):
    """Fetch tutti gli ordini nel range data con paginazione."""
    all_orders = []
    url = f"{SHOPIFY_STORE_URL}/admin/api/2024-01/orders.json"
    headers = {
        "X-Shopify-Access-Token": SHOPIFY_API_TOKEN,
        "Content-Type": "application/json",
    }
    # NB: filtro su processed_at (data pagamento) per match con Shopify dashboard.
    # Dashboard usa processed_at; created_at può differire di pochi secondi a cavallo mezzanotte.
    params = {
        "processed_at_min": date_min,
        "processed_at_max": date_max,
        "status": "any",
        "financial_status": "any",
        "limit": 250,
    }

    while url:
        resp = requests.get(url, headers=headers, params=params, timeout=30)
        if resp.status_code != 200:
            print(f"  ❌ Shopify API errore: {resp.status_code} — {resp.text[:200]}")
            return []

        data = resp.json()
        all_orders.extend(data.get("orders", []))

        # Paginazione via Link header
        url = _get_next_page(resp.headers.get("Link", ""))
        params = None

    return all_orders


def _get_next_page(link_header):
    """Estrae URL della pagina successiva dal Link header."""
    if not link_header:
        return None
    for part in link_header.split(","):
        if 'rel="next"' in part:
            url = part.split(";")[0].strip().strip("<>")
            return url
    return None


def _fmt_date(iso_str):
    """Converte data ISO 8601 nel formato Shopify export: '2026-03-28 23:57:11 +0100'."""
    if not iso_str:
        return ""
    try:
        # Parse ISO: 2026-03-28T23:57:11+01:00
        dt = datetime.fromisoformat(iso_str)
        # Format: 2026-03-28 23:57:11 +0100
        offset = dt.strftime("%z")  # +0100
        return dt.strftime(f"%Y-%m-%d %H:%M:%S {offset}")
    except (ValueError, TypeError):
        return iso_str


def _fmt_zip(zip_code):
    """Aggiunge apostrofo ai zip code numerici come fa Shopify (previene troncamento Excel)."""
    if not zip_code:
        return ""
    z = str(zip_code).strip()
    # Shopify aggiunge ' davanti ai zip puramente numerici o che iniziano con 0
    if z and z[0].isdigit():
        return f"'{z}"
    return z


def _combine_street(addr1, addr2):
    """Combina address1 + address2 nel campo Street come fa Shopify."""
    a1 = (addr1 or "").strip()
    a2 = (addr2 or "").strip()
    if a1 and a2:
        return f"{a1}, {a2}"
    return a1 or a2


def _orders_to_csv(orders, first_order, last_order, date_str):
    """Converte ordini JSON in CSV — replica esatta del formato export nativo Shopify."""
    DOWNLOAD_DIR.mkdir(exist_ok=True)
    filename = f"Orders_{first_order}-{last_order}_{date_str}.csv"
    csv_path = DOWNLOAD_DIR / filename

    fieldnames = [
        "Name", "Email", "Financial Status", "Paid at", "Fulfillment Status",
        "Fulfilled at", "Accepts Marketing", "Currency", "Subtotal", "Shipping",
        "Taxes", "Total", "Discount Code", "Discount Amount", "Shipping Method",
        "Created at", "Lineitem quantity", "Lineitem name", "Lineitem price",
        "Lineitem compare at price", "Lineitem sku", "Lineitem requires shipping",
        "Lineitem taxable", "Lineitem fulfillment status",
        "Billing Name", "Billing Street", "Billing Address1", "Billing Address2",
        "Billing Company", "Billing City", "Billing Zip", "Billing Province",
        "Billing Country", "Billing Phone",
        "Shipping Name", "Shipping Street", "Shipping Address1", "Shipping Address2",
        "Shipping Company", "Shipping City", "Shipping Zip", "Shipping Province",
        "Shipping Country", "Shipping Phone",
        "Notes", "Note Attributes", "Cancelled at", "Payment Method",
        "Payment Reference", "Refunded Amount", "Vendor", "Outstanding Balance",
        "Employee", "Location", "Device ID", "Id", "Tags", "Risk Level", "Source",
        "Lineitem discount", "Tax 1 Name", "Tax 1 Value", "Tax 2 Name", "Tax 2 Value",
        "Tax 3 Name", "Tax 3 Value", "Tax 4 Name", "Tax 4 Value",
        "Tax 5 Name", "Tax 5 Value", "Phone", "Receipt Number", "Duties",
        "Billing Province Name", "Shipping Province Name",
        "Payment ID", "Payment Terms Name", "Next Payment Due At",
        "Payment References", "Business Entity Name", "Business Entity ID",
    ]

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()

        for order in orders:
            shipping = order.get("shipping_address") or {}
            billing = order.get("billing_address") or {}
            line_items = order.get("line_items", [])

            # Note attributes — formato Shopify: "key: value\nkey: value"
            note_attrs = order.get("note_attributes", [])
            note_attrs_str = "\n".join(
                f"{a.get('name', '')}: {a.get('value', '')}" for a in note_attrs
            ) if note_attrs else ""

            # Payment info
            gateways = order.get("payment_gateway_names", [])
            payment_method = ", ".join(gateways) if gateways else ""

            # Refunded amount
            refunded = sum(
                float(r.get("transactions", [{}])[0].get("amount", 0))
                for r in order.get("refunds", [])
                if r.get("transactions")
            )

            # Shipping method
            shipping_lines = order.get("shipping_lines", [])
            shipping_method = shipping_lines[0].get("title", "") if shipping_lines else ""

            # Checkout token
            checkout_token = order.get("checkout_token", "") or ""

            # Accepts marketing
            accepts_marketing = "yes" if order.get("buyer_accepts_marketing") else "no"

            # Outstanding balance
            outstanding = order.get("total_outstanding", "0.00")

            # Fulfillment dates
            fulfillments = order.get("fulfillments", [])
            fulfilled_at = ""
            if fulfillments:
                fulfilled_at = _fmt_date(fulfillments[0].get("created_at", ""))

            # Phone
            phone = order.get("phone", "") or shipping.get("phone", "")

            # Paid at — Shopify usa processed_at (timestamp pagamento)
            paid_at = order.get("processed_at", "") or order.get("created_at", "")
            # Solo se effettivamente pagato
            financial_status = order.get("financial_status", "")
            if financial_status != "paid":
                paid_at = ""

            # Created at formattato
            created_at_fmt = _fmt_date(order.get("created_at", ""))

            # Province names (full name)
            billing_province_name = billing.get("province", "") or ""
            shipping_province_name = shipping.get("province", "") or ""

            # Skip line item rimossi via Order Editing: restano nell'array ma current_quantity=0
            # (quantity = ordine originale immutabile; current_quantity riflette removals/refund)
            # ponytail: current_quantity fallback a quantity per ordini vecchi senza il campo
            line_items = [
                li for li in line_items
                if int(li.get("current_quantity", li.get("quantity", 0)) or 0) > 0
            ] or [{}]

            # Per ogni line item, costruisci la riga
            for idx, item in enumerate(line_items or [{}]):
                row = {f: "" for f in fieldnames}

                # -- Lineitem fields (sempre presenti su ogni riga) --
                variant_title = item.get("variant_title", "") or ""
                item_title = item.get("title", "") or ""
                if variant_title:
                    lineitem_name = f"{item_title} - {variant_title}"
                else:
                    lineitem_name = item_title

                row["Lineitem quantity"] = item.get("current_quantity", item.get("quantity", ""))
                row["Lineitem name"] = lineitem_name
                row["Lineitem price"] = item.get("price", "")
                row["Lineitem compare at price"] = item.get("compare_at_price", "") or ""
                row["Lineitem sku"] = item.get("sku", "") or ""
                row["Lineitem requires shipping"] = str(item.get("requires_shipping", True)).lower()
                row["Lineitem taxable"] = str(item.get("taxable", True)).lower()
                row["Lineitem fulfillment status"] = item.get("fulfillment_status", "") or "pending"
                row["Vendor"] = item.get("vendor", "")

                # Discount per line item
                item_discounts = item.get("discount_allocations", [])
                total_item_discount = sum(float(d.get("amount", 0)) for d in item_discounts)
                row["Lineitem discount"] = f"{total_item_discount:.2f}"

                # Name, Email, Created at — su ogni riga
                row["Name"] = f"#{order.get('order_number', '')}"
                row["Email"] = order.get("email", "") or order.get("contact_email", "")
                row["Created at"] = created_at_fmt

                # Phone — su ogni riga nel sample
                row["Phone"] = phone if idx == 0 else (phone if phone and idx > 0 else "")

                # -- Prima riga dell'ordine: tutti i campi ordine --
                if idx == 0:
                    row["Financial Status"] = financial_status
                    row["Paid at"] = _fmt_date(paid_at)
                    row["Fulfillment Status"] = order.get("fulfillment_status", "") or "unfulfilled"
                    row["Fulfilled at"] = fulfilled_at
                    row["Accepts Marketing"] = accepts_marketing
                    row["Currency"] = order.get("currency", "")
                    row["Subtotal"] = order.get("subtotal_price", "")
                    row["Shipping"] = _get_shipping_total(order)
                    row["Taxes"] = order.get("total_tax", "")
                    row["Total"] = order.get("total_price", "")
                    row["Discount Code"] = _get_discount_codes(order)
                    row["Discount Amount"] = order.get("total_discounts", "")
                    row["Shipping Method"] = shipping_method

                    # Billing address
                    row["Billing Name"] = billing.get("name", "")
                    row["Billing Street"] = _combine_street(billing.get("address1"), billing.get("address2"))
                    row["Billing Address1"] = billing.get("address1", "") or ""
                    row["Billing Address2"] = billing.get("address2", "") or ""
                    row["Billing Company"] = billing.get("company", "") or ""
                    row["Billing City"] = billing.get("city", "")
                    row["Billing Zip"] = _fmt_zip(billing.get("zip", ""))
                    row["Billing Province"] = billing.get("province_code", "") or ""
                    row["Billing Country"] = billing.get("country_code", "") or ""
                    row["Billing Phone"] = billing.get("phone", "") or ""

                    # Shipping address
                    row["Shipping Name"] = shipping.get("name", "")
                    row["Shipping Street"] = _combine_street(shipping.get("address1"), shipping.get("address2"))
                    row["Shipping Address1"] = shipping.get("address1", "") or ""
                    row["Shipping Address2"] = shipping.get("address2", "") or ""
                    row["Shipping Company"] = shipping.get("company", "") or ""
                    row["Shipping City"] = shipping.get("city", "")
                    row["Shipping Zip"] = _fmt_zip(shipping.get("zip", ""))
                    row["Shipping Province"] = shipping.get("province_code", "") or ""
                    row["Shipping Country"] = shipping.get("country_code", "") or ""
                    row["Shipping Phone"] = shipping.get("phone", "") or ""

                    row["Notes"] = order.get("note", "") or ""
                    row["Note Attributes"] = note_attrs_str
                    row["Cancelled at"] = _fmt_date(order.get("cancelled_at", ""))
                    row["Payment Method"] = payment_method
                    row["Payment Reference"] = checkout_token
                    row["Refunded Amount"] = f"{refunded:.2f}"
                    row["Outstanding Balance"] = outstanding
                    row["Employee"] = ""
                    row["Location"] = ""
                    row["Device ID"] = ""
                    row["Id"] = str(order.get("id", ""))
                    row["Tags"] = order.get("tags", "") or ""
                    row["Risk Level"] = "Low"
                    row["Source"] = order.get("source_name", "")

                    # Tax lines
                    tax_lines = order.get("tax_lines", [])
                    for t_idx, tax in enumerate(tax_lines[:5]):
                        row[f"Tax {t_idx+1} Name"] = tax.get("title", "")
                        row[f"Tax {t_idx+1} Value"] = tax.get("price", "")

                    row["Receipt Number"] = ""
                    row["Duties"] = ""
                    row["Billing Province Name"] = billing_province_name
                    row["Shipping Province Name"] = shipping_province_name
                    row["Payment ID"] = checkout_token
                    row["Payment Terms Name"] = ""
                    row["Next Payment Due At"] = ""
                    row["Payment References"] = checkout_token
                    row["Business Entity Name"] = order.get("company", {}).get("name", "") if isinstance(order.get("company"), dict) else ""
                    row["Business Entity ID"] = ""

                writer.writerow(row)

    return csv_path


def _get_shipping_total(order):
    """Estrae il totale spedizione."""
    lines = order.get("shipping_lines", [])
    if lines:
        return lines[0].get("price", "0.00")
    return "0.00"


def _get_discount_codes(order):
    """Estrae i codici sconto."""
    codes = order.get("discount_codes", [])
    return ", ".join(c.get("code", "") for c in codes)


def check_api_connection():
    """Verifica che l'API Shopify sia raggiungibile."""
    url = f"{SHOPIFY_STORE_URL}/admin/api/2024-01/shop.json"
    headers = {"X-Shopify-Access-Token": SHOPIFY_API_TOKEN}
    try:
        resp = requests.get(url, headers=headers, timeout=10)
        if resp.ok:
            shop_name = resp.json()["shop"]["name"]
            print(f"  ✅ Shopify API connessa: {shop_name}")
            return True
        else:
            print(f"  ❌ Shopify API errore: {resp.status_code} — {resp.text[:100]}")
            return False
    except Exception as e:
        print(f"  ❌ Shopify API errore: {e}")
        return False
