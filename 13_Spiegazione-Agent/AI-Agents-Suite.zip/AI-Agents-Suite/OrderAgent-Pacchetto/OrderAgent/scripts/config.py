"""Central config — loads .env and exposes constants."""

import os
from pathlib import Path
from dotenv import load_dotenv

# Paths
PROJECT_DIR = Path(__file__).resolve().parent.parent
SCRIPTS_DIR = PROJECT_DIR / "scripts"
DOWNLOAD_DIR = PROJECT_DIR / "downloads"

load_dotenv(PROJECT_DIR / ".env")

# --- Shopify API ---
SHOPIFY_STORE_URL = os.getenv("SHOPIFY_STORE_URL", "").rstrip("/")
SHOPIFY_API_TOKEN = os.getenv("SHOPIFY_API_TOKEN", "")

# --- Store display name (used in email subject) ---
# Defaults to the subdomain extracted from SHOPIFY_STORE_URL if not set.
STORE_NAME = os.getenv("STORE_NAME", "")

# --- Gmail SMTP ---
SMTP_EMAIL = os.getenv("SMTP_EMAIL", "")
SMTP_PASSWORD = os.getenv("SMTP_PASSWORD", "")
SUPPLIER_EMAIL = os.getenv("SUPPLIER_EMAIL", "")

# --- Telegram ---
TELEGRAM_BOT_TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# --- Scheduling ---
SCHEDULE_HOUR = int(os.getenv("SCHEDULE_HOUR", "1"))
SCHEDULE_MINUTE = int(os.getenv("SCHEDULE_MINUTE", "0"))
TIMEZONE = os.getenv("TIMEZONE", "Europe/Rome")

# --- Required vars ---
REQUIRED_VARS = {
    "SHOPIFY_STORE_URL": SHOPIFY_STORE_URL,
    "SHOPIFY_API_TOKEN": SHOPIFY_API_TOKEN,
    "SMTP_EMAIL": SMTP_EMAIL,
    "SMTP_PASSWORD": SMTP_PASSWORD,
    "SUPPLIER_EMAIL": SUPPLIER_EMAIL,
    "TELEGRAM_BOT_TOKEN": TELEGRAM_BOT_TOKEN,
    "TELEGRAM_CHAT_ID": TELEGRAM_CHAT_ID,
}


def validate_env():
    """Check all required env vars are set."""
    missing = [k for k, v in REQUIRED_VARS.items() if not v]
    if missing:
        print(f"❌ Missing .env vars: {', '.join(missing)}")
        return False
    print("✅ All .env vars configured")
    return True


def ensure_dirs():
    """Create required directories."""
    DOWNLOAD_DIR.mkdir(exist_ok=True)
