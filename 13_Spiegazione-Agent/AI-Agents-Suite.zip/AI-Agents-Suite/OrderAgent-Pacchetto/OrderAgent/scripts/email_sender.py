"""Send daily order CSV to supplier via SMTP Gmail."""

import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from email.mime.base import MIMEBase
from email import encoders
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

from config import SMTP_EMAIL, SMTP_PASSWORD, SUPPLIER_EMAIL, SHOPIFY_STORE_URL, STORE_NAME, TIMEZONE

STORE_TZ = ZoneInfo(TIMEZONE)


def send_order_email(csv_path, order_count, first_order, last_order, dry_run=False):
    """Send order CSV to supplier. Returns True on success."""
    yesterday = (datetime.now(STORE_TZ) - timedelta(days=1)).date()
    date_str = yesterday.strftime("%Y-%m-%d")

    # Derive display name: STORE_NAME env > subdomain from URL
    store = STORE_NAME or SHOPIFY_STORE_URL.replace("https://", "").replace(".myshopify.com", "")

    subject = f"{store} #{first_order} to #{last_order} {date_str}"
    body = (
        f"Orders for {date_str}\n\n"
        f"Total orders: {order_count}\n"
        f"Range: #{first_order} - #{last_order}\n\n"
        f"CSV file attached.\n"
    )

    if dry_run:
        print(f"  🔸 DRY-RUN: email not sent")
        print(f"     From: {SMTP_EMAIL}")
        print(f"     To:   {SUPPLIER_EMAIL}")
        print(f"     Subject: {subject}")
        print(f"     Attachment: {Path(csv_path).name}")
        return True

    msg = MIMEMultipart()
    msg["From"] = SMTP_EMAIL
    msg["To"] = SUPPLIER_EMAIL
    msg["Subject"] = subject
    msg.attach(MIMEText(body, "plain"))

    csv_path = Path(csv_path)
    with open(csv_path, "rb") as f:
        part = MIMEBase("application", "octet-stream")
        part.set_payload(f.read())
        encoders.encode_base64(part)
        part.add_header("Content-Disposition", f'attachment; filename="{csv_path.name}"')
        msg.attach(part)

    max_retries = 2
    for attempt in range(1, max_retries + 1):
        try:
            with smtplib.SMTP("smtp.gmail.com", 587) as server:
                server.starttls()
                server.login(SMTP_EMAIL, SMTP_PASSWORD)
                server.send_message(msg)
            print(f"  ✅ Email sent to {SUPPLIER_EMAIL}")
            return True
        except Exception as e:
            print(f"  ⚠️ Attempt {attempt}/{max_retries} failed: {e}")
            if attempt == max_retries:
                print(f"  ❌ Email failed after {max_retries} attempts")
                return False
