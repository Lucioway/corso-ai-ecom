"""Modulo notifica Telegram via Bot API."""

import requests
from config import TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID


def _send_message(text):
    """Invia un messaggio Telegram."""
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
    payload = {
        "chat_id": TELEGRAM_CHAT_ID,
        "text": text,
        "parse_mode": "HTML",
    }
    try:
        resp = requests.post(url, json=payload, timeout=10)
        if resp.ok:
            print("  ✅ Notifica Telegram inviata")
            return True
        else:
            print(f"  ❌ Telegram errore: {resp.status_code} — {resp.text}")
            return False
    except Exception as e:
        print(f"  ❌ Telegram errore: {e}")
        return False


def notify_success(order_count, first_order, last_order, email_to, date_str, dry_run=False):
    """Notifica ordini inviati con successo."""
    text = (
        f"📦 <b>Orders sent</b>\n\n"
        f"📅 Date: {date_str}\n"
        f"📋 Orders: {order_count}\n"
        f"🔢 Range: #{first_order} - #{last_order}\n"
        f"📧 Sent to: {email_to}"
    )
    if dry_run:
        print(f"  🔸 DRY-RUN: notifica Telegram NON inviata")
        print(f"     Messaggio: {text}")
        return True
    return _send_message(text)


def notify_no_orders(date_str, dry_run=False):
    """Notifica nessun ordine trovato."""
    text = (
        f"📭 <b>No orders</b>\n\n"
        f"📅 Date: {date_str}\n"
        f"No orders yesterday — no email sent."
    )
    if dry_run:
        print(f"  🔸 DRY-RUN: notifica Telegram NON inviata")
        print(f"     Messaggio: {text}")
        return True
    return _send_message(text)


def notify_error(error_msg, dry_run=False):
    """Notifica errore."""
    text = f"🚨 <b>Shopify Order Agent Error</b>\n\n{error_msg}"
    if dry_run:
        print(f"  🔸 DRY-RUN: notifica errore NON inviata")
        print(f"     Messaggio: {text}")
        return True
    return _send_message(text)


def check_connection():
    """Verifica che il bot Telegram sia raggiungibile."""
    url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/getMe"
    try:
        resp = requests.get(url, timeout=10)
        if resp.ok:
            bot_name = resp.json()["result"]["username"]
            print(f"  ✅ Bot Telegram connesso: @{bot_name}")
            return True
        else:
            print(f"  ❌ Bot Telegram non raggiungibile: {resp.status_code}")
            return False
    except Exception as e:
        print(f"  ❌ Bot Telegram errore: {e}")
        return False
