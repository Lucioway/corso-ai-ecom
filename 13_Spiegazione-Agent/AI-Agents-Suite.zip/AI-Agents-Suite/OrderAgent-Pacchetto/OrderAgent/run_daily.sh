#!/usr/bin/env bash
# OrderAgent — daily launcher (called by launchd or cron)
# Single pass: fetch yesterday's orders → CSV → email supplier → Telegram

set -euo pipefail

PROJECT_DIR="$(cd "$(dirname "$0")" && pwd)"
VENV="$PROJECT_DIR/.venv"
LOGDIR="$PROJECT_DIR/logs"
mkdir -p "$LOGDIR"

LOG="$LOGDIR/scheduled.log"
echo "[$(date '+%Y-%m-%d %H:%M:%S')] === START run_daily.sh ===" >> "$LOG"

cd "$PROJECT_DIR"

if [[ -f "$VENV/bin/python" ]]; then
  PY="$VENV/bin/python"
else
  PY="$(command -v python3)"
fi

"$PY" scripts/main.py --once >> "$LOG" 2>&1
EXIT=$?

echo "[$(date '+%Y-%m-%d %H:%M:%S')] === END run_daily.sh (exit=$EXIT) ===" >> "$LOG"
exit $EXIT
