# OrderAgent — Shopify Daily Order Exporter

Every night, automatically exports the previous day's Shopify orders via API,
generates a CSV in native Shopify format, and emails it to your supplier.
Sends a Telegram summary. If no orders, sends Telegram-only.

## Quick start

```bash
# 1) Install
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# 2) Configure
cp .env.example .env
# Edit .env — add Shopify token, Gmail App Password, supplier email, Telegram bot

# 3) Verify
python scripts/main.py --check

# 4) Test (no email/notifications sent)
python scripts/main.py --dry-run

# 5) Real run
python scripts/main.py --once

# 6) Start daily scheduler (01:00 TIMEZONE by default)
python scripts/main.py --schedule
```

## Automate with launchd (macOS)

Create `~/Library/LaunchAgents/com.yourstore.orderagent.plist`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN"
    "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>        <string>com.yourstore.orderagent</string>
  <key>ProgramArguments</key>
  <array>
    <string>/path/to/OrderAgent/.venv/bin/python</string>
    <string>/path/to/OrderAgent/scripts/main.py</string>
    <string>--once</string>
  </array>
  <key>StartCalendarInterval</key>
  <dict><key>Hour</key><integer>1</integer><key>Minute</key><integer>0</integer></dict>
  <key>StandardOutPath</key> <string>/path/to/OrderAgent/logs/launchd.log</string>
  <key>StandardErrorPath</key><string>/path/to/OrderAgent/logs/launchd.log</string>
</dict>
</plist>
```

```bash
launchctl load ~/Library/LaunchAgents/com.yourstore.orderagent.plist
```

> **Tip (macOS):** Run `sudo pmset repeat wakeorpoweron MTWRFSU 00:00:00` so the
> Mac wakes at midnight, ensuring launchd fires at 01:00 rather than deferring
> until the next user login.

## Environment variables

| Variable | Required | Description |
|---|---|---|
| `SHOPIFY_STORE_URL` | ✅ | e.g. `your-store.myshopify.com` |
| `SHOPIFY_API_TOKEN` | ✅ | Admin API token (`shpat_…`), scope `read_orders` |
| `STORE_NAME` | — | Display name used in email subject (default: store subdomain) |
| `SMTP_EMAIL` | ✅ | Gmail address for outgoing email |
| `SMTP_PASSWORD` | ✅ | Gmail App Password (16-char) |
| `SUPPLIER_EMAIL` | ✅ | Supplier address to receive the CSV |
| `TELEGRAM_BOT_TOKEN` | ✅ | Telegram bot token |
| `TELEGRAM_CHAT_ID` | ✅ | Telegram chat ID for notifications |
| `SCHEDULE_HOUR` | — | Hour for daily run (default: `1`) |
| `SCHEDULE_MINUTE` | — | Minute for daily run (default: `0`) |
| `TIMEZONE` | — | IANA timezone (default: `Europe/Rome`) |

## CSV format

Generated in native Shopify export format (76 columns) — compatible with most
supplier order management systems out of the box.

## Idempotency

The agent writes `state/last_processed.txt` after each successful send.
Re-runs on the same date are skipped automatically. Override with `--force`.

## Required Shopify scopes

The Admin API token must have `read_orders`.
