# OrderAgent — Guida Manuale

Il tuo esportatore automatico di ordini Shopify. Ogni notte scarica gli ordini
del giorno prima, li impacchetta in un CSV identico all'export nativo di Shopify
e lo manda via email al tuo fornitore, con un riepilogo su Telegram. Gira a casa
tua (o sul tuo server), i tuoi dati restano tuoi. Nessun database, nessun
servizio esterno a pagamento.

---

## Indice

1. [Cos'è OrderAgent](#1-cosè-orderagent)
2. [Requisiti](#2-requisiti)
3. [Installazione e primo avvio](#3-installazione-e-primo-avvio)
4. [Configurazione (.env)](#4-configurazione-env)
5. [Come prelevare i token](#5-come-prelevare-i-token)
6. [I comandi](#6-i-comandi)
7. [Cosa succede a ogni esecuzione](#7-cosa-succede-a-ogni-esecuzione)
8. [Idempotenza e --force](#8-idempotenza-e---force)
9. [Il formato CSV](#9-il-formato-csv)
10. [Fusi orari e "ieri"](#10-fusi-orari-e-ieri)
11. [Le notifiche Telegram](#11-le-notifiche-telegram)
12. [L'email al fornitore](#12-lemail-al-fornitore)
13. [Schedulazione automatica](#13-schedulazione-automatica)
14. [Struttura dei file](#14-struttura-dei-file)
15. [Log e archivio](#15-log-e-archivio)
16. [Risoluzione problemi](#16-risoluzione-problemi)
17. [FAQ](#17-faq)

---

## 1. Cos'è OrderAgent

OrderAgent è uno script Python che automatizza l'invio quotidiano degli ordini
al fornitore. Il flusso, ogni notte:

1. Interroga la **Shopify Admin API** e scarica tutti gli ordini con
   `processed_at` (data di pagamento) nella giornata di **ieri**.
2. Li converte in un **CSV** che replica esattamente l'export "Orders" nativo di
   Shopify (76 colonne, una riga per line item).
3. Allega il CSV a una **email** e la invia al fornitore via Gmail SMTP.
4. Manda un **riepilogo Telegram** (numero ordini, range, destinatario).

Se ieri non ci sono stati ordini, **non** invia email: manda solo una notifica
Telegram "nessun ordine".

Tutto è dichiarativo e leggibile: la configurazione è un file `.env`, lo stato è
un file di testo, gli output sono CSV. Zero magia, zero lock-in.

---

## 2. Requisiti

- **Python 3.9+** (serve il modulo standard `zoneinfo` per i fusi orari).
- **Tre dipendenze** Python: `python-dotenv`, `requests`, `APScheduler`.
- Un **negozio Shopify** con un token Admin API che abbia lo scope `read_orders`.
- Un **account Gmail** con 2FA attiva e una **App Password** (per inviare email).
- Un **bot Telegram** (creato con @BotFather) e il **chat ID** del destinatario.
- Sistema: macOS, Linux o un server cloud. Non serve interfaccia grafica.

> Tutto gira in locale. L'unico "cloud" coinvolto sono le API di Shopify,
> Telegram e il server SMTP di Gmail — i tuoi dati ordini non passano da terzi.

---

## 3. Installazione e primo avvio

1. Scompatta la cartella `OrderAgent` dove preferisci.
2. Crea l'ambiente virtuale e installa le dipendenze:
   ```bash
   cd OrderAgent
   python3 -m venv .venv && source .venv/bin/activate
   pip install -r requirements.txt
   ```
3. Copia il file di esempio e compila le tue credenziali:
   ```bash
   cp .env.example .env
   # poi apri .env e inserisci i tuoi valori (vedi §4)
   ```
4. Verifica che tutto sia collegato:
   ```bash
   python scripts/main.py --check
   ```
5. Fai un test a vuoto e poi il primo invio reale (§6).

> Suggerimento: apri **Claude Code** nella cartella e digli *"installa OrderAgent
> seguendo SETUP.md"* — fa l'intera procedura per te e la verifica.

---

## 4. Configurazione (.env)

Tutte le impostazioni stanno nel file `.env`. Punto di partenza: `.env.example`.

| Variabile | Obbligatoria | Descrizione |
|---|---|---|
| `SHOPIFY_STORE_URL` | ✅ | URL del negozio, es. `https://tuo-store.myshopify.com` |
| `SHOPIFY_API_TOKEN` | ✅ | Token Admin API (`shpat_…`), scope **`read_orders`** |
| `STORE_NAME` | — | Nome mostrato nell'oggetto email (default: sottodominio del negozio) |
| `SMTP_EMAIL` | ✅ | Indirizzo Gmail mittente |
| `SMTP_PASSWORD` | ✅ | **App Password** Gmail (16 caratteri, non la password normale) |
| `SUPPLIER_EMAIL` | ✅ | Indirizzo del fornitore che riceve il CSV |
| `TELEGRAM_BOT_TOKEN` | ✅ | Token del bot Telegram |
| `TELEGRAM_CHAT_ID` | ✅ | Chat ID del destinatario delle notifiche |
| `SCHEDULE_HOUR` | — | Ora di esecuzione giornaliera (default `1`) |
| `SCHEDULE_MINUTE` | — | Minuto di esecuzione (default `0`) |
| `TIMEZONE` | — | Fuso orario IANA (default `Europe/Rome`) |

Il comando `--check` ti dice subito se manca qualcosa: stampa l'elenco delle
variabili vuote.

---

## 5. Come prelevare i token

**Token Shopify (`SHOPIFY_API_TOKEN`)**
1. Nel pannello Shopify: **Settings → Apps and sales channels → Develop apps**.
2. *Create an app* → dai un nome (es. "OrderAgent").
3. *Configure Admin API scopes* → spunta **`read_orders`** (basta quello).
4. *Install app* → copia l'**Admin API access token** (inizia con `shpat_`).

**App Password Gmail (`SMTP_PASSWORD`)**
1. Attiva la **verifica in due passaggi** sull'account Google.
2. **Account Google → Sicurezza → App Passwords** → genera una password a 16
   caratteri e incollala in `.env` (gli spazi non contano).

**Bot e chat ID Telegram (`TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`)**
1. Su Telegram scrivi a **@BotFather** → `/newbot` → ottieni il token.
2. Scrivi un messaggio al tuo bot, poi a **@userinfobot** → `/start` per leggere
   il tuo **chat ID** numerico. (Per un gruppo, l'ID è negativo.)

---

## 6. I comandi

Tutti i comandi si lanciano con `python scripts/main.py <flag>`:

| Comando | Cosa fa |
|---|---|
| `--check` | Verifica `.env` + connessione Shopify, Telegram, SMTP. Non invia nulla. |
| `--dry-run` | Simula l'intero flusso **senza** inviare email/notifiche reali. Stampa cosa farebbe. |
| `--once` | Esecuzione singola reale: scarica → CSV → email → Telegram → esce. |
| `--schedule` | Avvia lo scheduler interno: gira ogni giorno all'orario configurato. |
| `--force` | Usato insieme a `--once`/`--dry-run`: ignora il guard di idempotenza e rielabora la data anche se già processata. |

Senza nessun flag, `main.py` avvia direttamente lo **scheduler** (equivalente a
`--schedule`), previa validazione del `.env`.

Esempi:
```bash
python scripts/main.py --check                # diagnostica
python scripts/main.py --dry-run              # prova a vuoto
python scripts/main.py --once                 # invio reale di oggi
python scripts/main.py --once --force         # reinvio forzato della stessa data
python scripts/main.py --schedule             # demone giornaliero
```

---

## 7. Cosa succede a ogni esecuzione

Una `--once` (o un tick dello scheduler) esegue, nell'ordine:

1. **Calcola "ieri"** nel fuso `TIMEZONE` (default Europe/Rome).
2. **Guard idempotenza**: se quella data è già in `state/last_processed.txt`,
   salta (a meno di `--force`).
3. **Scarica gli ordini** via Shopify API, filtrando per `processed_at` tra
   mezzanotte e le 23:59:59 di ieri (con paginazione automatica, fino a 250
   ordini per pagina).
4. **Zero ordini** → notifica Telegram "nessun ordine", fine (niente email).
5. **Genera il CSV** nella cartella `downloads/` (nome
   `Orders_<primo>-<ultimo>_<data>.csv`).
6. **Invia l'email** al fornitore con il CSV allegato (fino a 2 tentativi su
   errore SMTP).
7. **Se l'email parte**, marca la data come processata.
8. **Notifica Telegram** di successo (o di errore se l'email è fallita).
9. **Archivia** il CSV spostandolo in `archive/`.

Ogni passo stampa a video (e nel log) lo stato con emoji, così è facile seguirlo.

---

## 8. Idempotenza e --force

OrderAgent **non rispedisce due volte** la stessa giornata. Dopo un invio andato
a buon fine, scrive la data in `state/last_processed.txt`. Alla successiva
esecuzione, se la data di "ieri" coincide con quella salvata, l'agente la salta
e ti avvisa.

Questo rende sicuro lanciarlo più volte (es. launchd che riparte, run manuale di
controllo): non genererai email duplicate.

Per **forzare** un reinvio della stessa data (es. il fornitore non ha ricevuto):
```bash
python scripts/main.py --once --force
```

Il `--dry-run` non scrive mai lo stato: è sempre ripetibile.

---

## 9. Il formato CSV

Il CSV prodotto **replica l'export nativo "Orders" di Shopify**: 76 colonne, da
`Name`, `Email`, `Financial Status`… fino a `Business Entity ID`. Compatibile
con la maggior parte dei sistemi di gestione ordini dei fornitori, out of the
box.

Dettagli fedeli al comportamento Shopify:
- **Una riga per line item.** I dati dell'ordine (indirizzi, totali, pagamento)
  stanno solo sulla **prima riga** dell'ordine; le righe successive portano solo
  i campi `Lineitem …`.
- **Line item rimossi** via Order Editing (con `current_quantity = 0`) vengono
  **esclusi**; la quantità riportata è `current_quantity` (fallback a `quantity`
  per ordini vecchi).
- **CAP/Zip numerici** vengono prefissati con un apostrofo (`'`) come fa Shopify,
  per evitare che Excel li tronchi.
- **Date** nel formato `2026-03-28 23:57:11 +0100` (con offset del fuso).
- **`Paid at`** valorizzato solo se l'ordine è effettivamente `paid`.
- **`Street`** = `address1, address2` combinati come nell'export originale.

Il file viene salvato in `downloads/` con nome
`Orders_<primoNum>-<ultimoNum>_<YYYY-MM-DD>.csv`, poi spostato in `archive/`
dopo l'invio.

---

## 10. Fusi orari e "ieri"

"Ieri" è calcolato nel fuso `TIMEZONE` (default `Europe/Rome`), **non** nel fuso
del sistema. Questo allinea il risultato alla **dashboard Shopify**: il filtro
usa `processed_at` (timestamp del pagamento), che è ciò che mostra la dashboard,
ed è DST-aware (gestisce l'ora legale/solare automaticamente).

Se il tuo negozio opera in un altro fuso, imposta `TIMEZONE` di conseguenza (es.
`America/New_York`) così il conteggio combacerà sempre con quello che vedi su
Shopify.

---

## 11. Le notifiche Telegram

L'agente manda tre tipi di messaggio (in HTML):

- **Ordini inviati** 📦 — data, numero ordini, range `#primo–#ultimo`, email
  destinataria.
- **Nessun ordine** 📭 — data, nota che non è stata inviata alcuna email.
- **Errore** 🚨 — messaggio d'errore (es. CSV fallito, email non partita).

In `--dry-run` i messaggi vengono **stampati a video ma non inviati**. La
connessione al bot si verifica con `--check` (mostra lo @username del bot).

---

## 12. L'email al fornitore

- **Mittente:** `SMTP_EMAIL` (Gmail). **Destinatario:** `SUPPLIER_EMAIL`.
- **Oggetto:** `<STORE_NAME> #<primo> to #<ultimo> <data>` — se `STORE_NAME` è
  vuoto, usa il sottodominio del negozio.
- **Corpo:** data, totale ordini, range, nota dell'allegato.
- **Allegato:** il CSV della giornata.
- **Affidabilità:** invio via `smtp.gmail.com:587` con STARTTLS, fino a **2
  tentativi** in caso di errore transitorio.

---

## 13. Schedulazione automatica

Due modi per farlo girare ogni notte:

**A) Scheduler interno (APScheduler)**
```bash
python scripts/main.py --schedule
```
Resta in esecuzione e parte ogni giorno alle `SCHEDULE_HOUR:SCHEDULE_MINUTE` nel
fuso `TIMEZONE`. Va tenuto vivo da un supervisore (launchd, systemd, pm2…).

**B) Launcher one-shot via launchd/cron (consigliato)**
Usa `run_daily.sh`: esegue una singola `--once`, usa il `.venv` se presente, e
scrive in `logs/scheduled.log`.

Esempio **launchd** (macOS) — crea
`~/Library/LaunchAgents/com.tuostore.orderagent.plist` con esecuzione alle 01:00
(template completo in `OrderAgent/README.md`), poi:
```bash
launchctl load ~/Library/LaunchAgents/com.tuostore.orderagent.plist
```
Su macOS aggiungi `sudo pmset repeat wakeorpoweron MTWRFSU 00:00:00` perché il
Mac si svegli a mezzanotte e il job parta puntuale invece di rimandare al login.

Esempio **cron** (Linux): `0 1 * * * /percorso/OrderAgent/run_daily.sh`.

---

## 14. Struttura dei file

```
OrderAgent/
  scripts/
    main.py              # CLI + scheduler (entry point)
    config.py            # carica .env, espone costanti, valida
    shopify_export.py    # API Shopify → CSV formato nativo
    email_sender.py      # invio CSV al fornitore via Gmail SMTP
    telegram_notifier.py # notifiche Telegram
  run_daily.sh           # launcher giornaliero (launchd/cron)
  requirements.txt       # 3 dipendenze
  .env.example           # template configurazione (da copiare in .env)
  .gitignore
  README.md
  LICENSE.txt
  # --- create a runtime (non nel pacchetto) ---
  .env                   # le TUE credenziali (mai committare)
  downloads/             # CSV appena generati
  archive/               # CSV già spediti
  state/                 # last_processed.txt (idempotenza)
  logs/                  # agent.log, scheduled.log
```

Le cartelle `downloads/`, `archive/`, `state/`, `logs/` vengono create
automaticamente alla prima esecuzione.

---

## 15. Log e archivio

- **`logs/agent.log`** — log applicativo (livello INFO) di ogni esecuzione.
- **`logs/scheduled.log`** — output di `run_daily.sh` (start/end + exit code).
- **`archive/`** — ogni CSV spedito viene spostato qui, così hai lo storico
  completo degli invii.

---

## 16. Risoluzione problemi

| Problema | Soluzione |
|---|---|
| `--check` dice variabili mancanti | Apri `.env` e compila le variabili elencate. |
| Shopify API errore 401 | Token errato o scope mancante: serve `read_orders`. Rigenera il token. |
| Shopify API errore 403/404 | Controlla `SHOPIFY_STORE_URL` (deve essere `https://...myshopify.com`). |
| SMTP login fallito | Stai usando la password normale: serve una **App Password** Gmail con 2FA attiva. |
| Email non arriva | Controlla `SUPPLIER_EMAIL`; guarda lo spam; verifica `logs/agent.log`. |
| Telegram non notifica | Token o chat ID errati. Scrivi prima un messaggio al bot; per i gruppi l'ID è negativo. |
| Conteggio diverso dalla dashboard | Imposta `TIMEZONE` sul fuso del negozio: "ieri" si calcola lì. |
| "già processato — skip" | È l'idempotenza. Per rispedire la stessa data usa `--once --force`. |
| Lo scheduler non parte alla notte (Mac) | Configura `pmset` (vedi §13) e verifica che il job launchd sia caricato. |

---

## 17. FAQ

**I miei dati ordini vanno nel cloud?**
No. Lo script gira sul tuo computer/server. Si collega a Shopify (per leggere gli
ordini), a Gmail (per spedire) e a Telegram (per notificare) — ma i CSV e lo
stato restano in locale.

**Quanti ordini al giorno regge?**
La paginazione scarica fino a 250 ordini per pagina e continua finché ci sono
pagine: non c'è un limite pratico per un negozio normale.

**Posso cambiare l'orario di invio?**
Sì: `SCHEDULE_HOUR` e `SCHEDULE_MINUTE` nel `.env` (o l'orario nel plist/cron).

**Funziona con più negozi?**
Una copia = un negozio (un `.env`). Per più negozi, duplica la cartella con `.env`
distinti e schedulazioni separate.

**Devo saper programmare per usarlo?**
No. Si configura compilando `.env` e si lancia con i comandi della §6. Claude
Code può fare installazione e verifica per te seguendo `SETUP.md`.

**Il CSV è davvero identico a quello di Shopify?**
Sì, replica le 76 colonne e le convenzioni dell'export nativo (righe per line
item, apostrofo sui CAP, formato date, ecc.). Vedi §9.

---

*OrderAgent v1.0 — esportazione ordini Shopify automatica, self-hosted, in
italiano.*
