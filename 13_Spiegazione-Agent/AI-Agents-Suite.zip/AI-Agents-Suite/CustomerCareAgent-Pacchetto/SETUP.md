# SETUP — Istruzioni per Claude Code

> **Per l'utente:** apri Claude Code, dai accesso a questa cartella e scrivi:
> *"Leggi SETUP.md e installa questo agente, fatto bene — deve essere
> production-grade e vendibile, controlla tutto."*
> Claude farà il resto seguendo questo file.

---

## Cosa stai installando

**CustomerCareAgent** — un agente di customer care self-hosted, brand-agnostic,
per negozi **Shopify**. Legge la posta in arrivo della casella di supporto,
cerca l'ordine su Shopify e il tracking su ParcelPanel, e con **Claude** scrive
una bozza di risposta nel tono del brand. **Non invia mai da solo**: ogni
risposta resta come bozza, in attesa dell'approvazione umana.

| Componente | Cosa fa |
|---|---|
| **CLI** (`main.py`) | Verifica connessioni, fetch email, ciclo singolo, polling schedulato |
| **Dashboard web** (`web_server.py`) | Inbox stile Gmail su `:8899` — bozze AI, rifinitura, traduzione, chat, invio (sempre approvato a mano), learning DB |
| **Processor** (`processor.py`) | Pipeline per-email: fetch → arricchimento contesto → classifica → bozza → salva |
| **Connettori** (`connectors/`) | IMAP/SMTP, Shopify REST, Claude, ParcelPanel, screenshot tracking (Selenium), bridge opzionale |

Tutto lo stato è in **file** (`data/`, `logs/`, SQLite `data/learning.db`):
nessun database esterno da installare. Tutto è **brand-agnostic** — identità del
brand, casella email e store Shopify si configurano via `.env`.

**Documentazione completa:** `GUIDA-MANUALE.md` in questa cartella — leggila per
capire ogni funzione, comando e personalizzazione.

---

## Il tuo compito (Claude Code)

Installa, configura e verifica CustomerCareAgent **a regola d'arte**, pronto per
essere usato e venduto. Adatta ogni comando, percorso e launcher all'ambiente
reale (macOS / Linux / Windows / server cloud) senza chiedere conferme banali.

### Fase 0 — Rileva l'ambiente
- Sistema operativo, versione di **Python (3.11+)**, presenza di **Google
  Chrome** + **chromedriver** (servono solo per gli screenshot di tracking — è
  una funzione opzionale), e accesso di rete a IMAP/SMTP, `api.anthropic.com`,
  Shopify e ParcelPanel.
- Se è un **server cloud senza display**: tutto gira lo stesso. Gli screenshot
  Selenium usano Chrome headless; se Chrome non c'è, quella sola funzione va
  trattata come opzionale e documentata — il resto funziona.

### Fase 1 — Installa le dipendenze
```bash
python3 -m venv .venv
. .venv/bin/activate            # su Windows: .venv\Scripts\activate
pip install -r requirements.txt
```
Dipendenze: `python-dotenv`, `anthropic`, `requests`, `selenium`,
`APScheduler`, `fastapi`, `uvicorn`. (Gli script in `scripts/` usano anche
`openpyxl`/`xlrd` — installali se l'utente vuole usarli.)

### Fase 2 — Configurazione (`.env`)
Esegui il wizard interattivo, che genera `.env` (chmod 600) e una bozza di
`knowledge/brand_context.md`:
```bash
./setup.sh
```
In alternativa: `cp .env.example .env` e compila a mano. Chiavi **obbligatorie**:

| Chiave | Dove si trova |
|---|---|
| `BRAND_NAME`, `BRAND_DOMAIN` | li scegli tu (identità del brand) |
| `SUPPORT_EMAIL`, `MAIL_PASSWORD` | la casella di supporto (IMAP/SMTP, default Hostinger) |
| `SHOPIFY_STORE_URL`, `SHOPIFY_API_TOKEN` | Shopify Admin → Apps → Develop apps → API credentials (`shpat_...`, scope `read_orders`, `read_customers`, `read_products`) |
| `ANTHROPIC_API_KEY` | console Anthropic (`sk-ant-...`) |
| `WEB_AUTH_PASSWORD` | la scegli tu (login dashboard) |

Chiavi **opzionali**: `PARCELPANEL_API_KEY` (tracking), `TELEGRAM_BOT_TOKEN` +
`TELEGRAM_CHAT_ID` (notifiche), `CLOUDFLARE_TUNNEL_NAME` + `CLOUDFLARE_PUBLIC_URL`
(esporre la dashboard), `EMAIL_AGENT_REPORTS_DIR` (bridge — disattivato).

Poi **rifinisci `knowledge/brand_context.md`** con le policy reali del brand
(resi, rimborsi, tempi di spedizione, situazioni frequenti): è il file che guida
le risposte dell'AI. Compila anche `templates/customer_care_templates.md` con gli
script di risposta pronti del brand.

### Fase 3 — Verifica (NON saltare)
```bash
python main.py --check
```
Deve stampare **9/9 connessioni OK** (`.env`, IMAP, SMTP, Shopify, Claude,
ParcelPanel, Chrome/Selenium, Knowledge base, Email_agent bridge). Se una fallisce,
**fermati e sistemala** prima di proseguire. Note attese:
- ParcelPanel e il bridge sono opzionali: se non configurati danno un avviso
  "non configurato", non un errore bloccante.
- Chrome/Selenium fallisce se Chrome/chromedriver mancano — accettabile su server
  senza Chrome (la funzione screenshot resta disattivata).

Poi un dry-run reale (nessuna azione, solo lettura):
```bash
python main.py --dry-run --limit 5
```
Deve elencare 5 email recenti con mittente e oggetto.

### Fase 4 — Avvia la dashboard
```bash
python web_server.py            # http://localhost:8899
```
Login con `WEB_AUTH_USERNAME` / `WEB_AUTH_PASSWORD`. Verifica:
- la inbox carica e mostra le email;
- premendo **Genera bozza** su una email l'AI produce una risposta coerente col
  brand context;
- la bozza viene salvata (resta in attesa, **niente invio automatico**).

Su macOS c'è il launcher `start_all.sh` (avvia il web server in background, e il
tunnel Cloudflare se `cloudflared` è installato).

### Fase 5 — Scheduling (opzionale)
Per il polling automatico ogni `POLL_INTERVAL_MINUTES` (default 10):
```bash
python main.py --schedule
```
Rendilo persistente: **launchd** su macOS, **systemd** su Linux, **Task
Scheduler** su Windows, oppure **pm2/supervisor** su cloud. Cabla anche l'avvio
al login/boot e configuralo per riavviarsi da solo (keep-alive).

### Fase 6 — Controllo qualità finale (must)
- **Sicurezza**: nessuna chiave hardcoded; `.env` con chmod 600 e mai committato
  (`.gitignore` già lo esclude); esponi solo la porta della dashboard; se è cloud
  pubblico, metti il tunnel Cloudflare o un reverse-proxy con auth davanti.
- **Pulizia dati**: il pacchetto parte **senza dati clienti** (`data/` contiene
  solo struttura), senza brand reali, con `.env.example` di esempio. Confermalo.
- **Mai inviare in automatico**: verifica che il flusso si fermi sempre alla
  bozza, in attesa dell'umano.
- **Robustezza**: la dashboard e (se attivo) lo scheduler si riavviano da soli.
- **Smoke test end-to-end**: `--check` 9/9 → `--dry-run` ok → dashboard su :8899
  → genera una bozza → la bozza è salvata, non inviata.

### Fase 7 — Consegna
Scrivi un breve report all'utente: cosa è attivo, URL/porta della dashboard,
come avviarla e fermarla, come è configurato lo scheduling, e qualsiasi cosa che
richieda la sua attenzione (es. token Shopify, password casella, policy del brand
da rifinire in `knowledge/brand_context.md`). Rimanda alla Guida Manuale per i
dettagli.

---

## Regole

- **Production-grade**: niente scorciatoie, niente passi saltati. Se qualcosa non
  passa una verifica, fermati e sistemalo prima di proseguire.
- **Adatta all'OS**: comandi, percorsi e launcher cambiano per sistema — fallo
  senza chiedere.
- **Non inventare dati**: brand context, policy e template li compila l'utente con
  i dati reali; tu prepari la struttura e verifichi che tutto regga.
- **Mai auto-invio**: è la regola di sicurezza centrale del prodotto. L'agente
  prepara solo bozze.
- **Leggi la Guida Manuale** per ogni dettaglio funzionale prima di modificare
  comportamenti.

---

*Pacchetto CustomerCareAgent v1.0 — pronto per l'installazione.*
