# CustomerCareAgent — Guida Manuale

Il tuo agente di customer care self-hosted per Shopify. Legge la posta della
casella di supporto, capisce ogni richiesta, recupera ordine e tracking, e
prepara una bozza di risposta nel tono del tuo brand. Tu controlli e invii. Gira
a casa tua (o sul tuo server), i tuoi dati restano tuoi.

---

## Indice

1. [Cos'è CustomerCareAgent](#1-cosè-customercareagent)
2. [Requisiti](#2-requisiti)
3. [Installazione e primo avvio](#3-installazione-e-primo-avvio)
4. [Configurazione (.env)](#4-configurazione-env)
5. [Architettura: come funziona](#5-architettura-come-funziona)
6. [La pipeline di una email](#6-la-pipeline-di-una-email)
7. [La CLI (main.py)](#7-la-cli-mainpy)
8. [La dashboard web](#8-la-dashboard-web)
9. [Il knowledge base del brand](#9-il-knowledge-base-del-brand)
10. [I template di risposta](#10-i-template-di-risposta)
11. [Le categorie email](#11-le-categorie-email)
12. [Il learning DB (l'agente impara)](#12-il-learning-db-lagente-impara)
13. [Scheduling e avvio automatico](#13-scheduling-e-avvio-automatico)
14. [Integrazioni opzionali](#14-integrazioni-opzionali)
15. [Script di manutenzione](#15-script-di-manutenzione)
16. [Personalizzazione: onboarding di un nuovo brand](#16-personalizzazione-onboarding-di-un-nuovo-brand)
17. [Struttura dei file](#17-struttura-dei-file)
18. [Sicurezza e privacy](#18-sicurezza-e-privacy)
19. [Risoluzione problemi](#19-risoluzione-problemi)
20. [FAQ](#20-faq)

---

## 1. Cos'è CustomerCareAgent

CustomerCareAgent è un'app che gira sul tuo computer (non sul cloud di terzi) e
automatizza la parte più ripetitiva del customer care di un negozio Shopify:

- **legge** la posta in arrivo della casella di supporto (via IMAP);
- **arricchisce** ogni email con il contesto reale: l'ordine su Shopify, il
  tracking su ParcelPanel, le policy e i template del brand;
- **classifica** la richiesta (reso, ordine non arrivato, taglia, difetto, ecc.);
- **scrive una bozza** di risposta con Claude, nel tono e nella lingua del brand;
- **salva la bozza** — nella cartella Drafts della casella e/o nella dashboard —
  in attesa che una persona la controlli e la invii.

**La regola d'oro: non invia mai da solo.** Ogni risposta passa sempre da una
revisione umana. L'agente fa il 90% del lavoro; tu approvi.

La cosa centrale: **è brand-agnostic**. L'identità del brand, la casella email e
lo store Shopify vivono tutti in `.env`. Prompt e template usano segnaposto
`{{BRAND_NAME}}` resi automaticamente. Onboardare un nuovo brand = una copia
della cartella + il wizard. Zero codice da toccare.

---

## 2. Requisiti

- **Python 3.11+**
- **Una casella email** con accesso IMAP/SMTP (default Hostinger; va bene
  qualsiasi provider — Gmail con app-password, ecc.)
- **Un negozio Shopify** con un **Admin API token** (`shpat_...`)
- **Una chiave Anthropic** (`sk-ant-...`) per Claude
- *(opzionale)* **ParcelPanel API key** per il tracking spedizioni
- *(opzionale)* **Google Chrome + chromedriver** per gli screenshot delle pagine
  di tracking (è una funzione accessoria: senza, il resto funziona)
- *(opzionale)* `cloudflared` per esporre la dashboard via tunnel; un **bot
  Telegram** per le notifiche
- Sistema: macOS, Windows o Linux. Funziona anche su un server cloud senza
  display (la sola funzione screenshot richiede Chrome).

> Nessun database da installare: lo stato sono file, e l'apprendimento usa un
> file SQLite locale (`data/learning.db`).

---

## 3. Installazione e primo avvio

1. Scompatta la cartella `CustomerCareAgent` dove preferisci.
2. (consigliato) crea un ambiente virtuale e installa le dipendenze:
   ```bash
   python3 -m venv .venv
   . .venv/bin/activate          # Windows: .venv\Scripts\activate
   pip install -r requirements.txt
   ```
3. Lancia il **wizard di setup** (genera `.env` + una bozza di brand context):
   ```bash
   ./setup.sh
   ```
   Ti farà ~10 domande guidate (brand, email, Shopify, Claude, dashboard,
   integrazioni opzionali) e scriverà `.env` con permessi `600`.
4. Rifinisci `knowledge/brand_context.md` con le policy reali e
   `templates/customer_care_templates.md` con i tuoi script pronti.
5. Verifica tutto:
   ```bash
   python main.py --check          # deve dare 9/9 OK
   python main.py --dry-run --limit 5
   ```
6. Avvia la dashboard:
   ```bash
   python web_server.py            # http://localhost:8899
   ```

In alternativa al wizard puoi `cp .env.example .env` e compilare a mano.

---

## 4. Configurazione (.env)

Tutta la configurazione è in `.env` (vedi `.env.example` per la lista completa).

**Brand**
| Variabile | Esempio | Cosa fa |
|---|---|---|
| `BRAND_NAME` | `MyBrand` | nome del brand (usato nei prompt e nel sign-off) |
| `BRAND_DOMAIN` | `mybrand.com` | dominio (default per email e URL policy) |
| `BRAND_LANGUAGE` | `it` / `en` / `es`… | lingua delle risposte |
| `BRAND_PRODUCTS_DESC` | `shapewear & swimwear` | breve descrizione prodotti |
| `BRAND_SIGN_OFF` | `MyBrand Customer Care Team` | firma in calce |
| `ORDER_ID_PREFIX` | `LS` (o vuoto) | prefisso degli ID ordine, se presente |
| `BRAND_RETURNS_URL`, `BRAND_SHIPPING_URL` | URL policy pubbliche |

**Claude**
| `ANTHROPIC_API_KEY` | la tua chiave `sk-ant-...` |
| `CLAUDE_MODEL` | override modello (default `claude-sonnet-4-…`) |

**Email (IMAP/SMTP)**
| `SUPPORT_EMAIL` | la casella di supporto, es. `info@mybrand.com` |
| `MAIL_PASSWORD` | password della casella |
| `IMAP_SERVER` / `IMAP_PORT` | default `imap.hostinger.com` / `993` |
| `SMTP_SERVER` / `SMTP_PORT` | default `smtp.hostinger.com` / `465` |

> Le bozze vengono salvate via IMAP APPEND nella cartella Drafts. L'agente prova
> in automatico vari nomi di cartella (`Drafts`, `INBOX.Drafts`, `Bozze`,
> `[Gmail]/Drafts`, ecc.), così funziona con provider diversi.

**Shopify**
| `SHOPIFY_STORE_URL` | es. `https://my-store.myshopify.com` |
| `SHOPIFY_API_TOKEN` | `shpat_...` con scope `read_orders`, `read_customers`, `read_products` |
| `SHOPIFY_API_VERSION` | default `2024-01` |

**Dashboard**
| `WEB_PORT` | porta (default `8899`) |
| `WEB_AUTH_USERNAME` / `WEB_AUTH_PASSWORD` | login basic-auth |

**Opzionali**
| `PARCELPANEL_API_KEY` | tracking (da Shopify → App ParcelPanel → API & Webhook) |
| `TELEGRAM_BOT_TOKEN` / `TELEGRAM_CHAT_ID` | notifiche Telegram |
| `CLOUDFLARE_TUNNEL_NAME` / `CLOUDFLARE_PUBLIC_URL` | esporre la dashboard |
| `EMAIL_AGENT_REPORTS_DIR` | bridge a un Email_agent esterno (disattivato di default) |

**Scheduling / log**
| `POLL_INTERVAL_MINUTES` | ogni quanto fa polling (default 10) |
| `TEST_EMAIL_LIMIT` | quante email in dry-run/once (default 10) |
| `LOG_LEVEL` | `INFO`/`DEBUG`… |
| `TIMEZONE` | default `Europe/Rome` |

---

## 5. Architettura: come funziona

Tre modi di operare sopra lo stesso motore:

| Componente | File | A cosa serve |
|---|---|---|
| **CLI** | `main.py` | verifica, dry-run, ciclo singolo, scheduler |
| **Dashboard** | `web_server.py` | inbox web stile Gmail su `:8899` |
| **Processor** | `processor.py` | la pipeline che lavora ogni email |

I **connettori** (`connectors/`) parlano con i servizi esterni:
- `imap_connector.py` — lettura INBOX + salvataggio bozze (IMAP/SMTP)
- `shopify_connector.py` — ordini, clienti, prodotti, fulfillment (REST API)
- `claude_connector.py` — wrapper SDK Anthropic
- `parcelpanel_connector.py` — tracking spedizioni (API v2)
- `tracking_screenshot.py` — screenshot pagine tracking (Chrome headless)
- `email_agent_bridge.py` — bridge opzionale a report JSON esterni

Moduli di supporto: `priority_scorer.py` (priorità della email),
`learning_db.py` + `learning_matcher.py` (apprendimento), `idle_listener.py`
(rilevamento email in tempo reale via IMAP IDLE), `tunnel_manager.py` (tunnel
Cloudflare).

Lo **stato** è tutto in file: `data/drafts/`, `data/screenshots/`,
`data/processed/` e il file SQLite `data/learning.db`. I log giornalieri in
`logs/`.

---

## 6. La pipeline di una email

Per ogni email il `processor` esegue:

1. **Fetch** — scarica le email recenti dalla INBOX.
2. **Arricchimento contesto** — estrae l'eventuale numero d'ordine, lo cerca su
   Shopify (cliente, prodotti, fulfillment), recupera il tracking su ParcelPanel,
   e carica brand context + template.
3. **Classifica** — Claude assegna categoria, lingua, sentiment, urgenza,
   confidenza e un breve riassunto (vedi §11). Le categorie "da ignorare"
   (partnership, fornitori, spam) vengono saltate.
4. **Bozza** — Claude scrive la risposta usando contesto, policy e template, nel
   tono e nella lingua del brand, firmando con `BRAND_SIGN_OFF`.
5. **Salva** — la bozza finisce nella cartella Drafts della casella e/o nella
   dashboard, e viene registrata nel learning DB. **Niente invio automatico.**

---

## 7. La CLI (main.py)

```bash
python main.py --check                 # verifica tutte le connessioni (9 check)
python main.py --dry-run               # fetch email, nessuna azione
python main.py --dry-run --limit 5     # come sopra, max 5 email
python main.py --once                  # un ciclo singolo
python main.py --schedule              # polling ogni POLL_INTERVAL_MINUTES
python main.py --once --limit 20       # override del limite email
```

`--check` stampa l'esito di: `.env`, IMAP, SMTP, Shopify, Claude, ParcelPanel,
Chrome/Selenium, Knowledge base, Email_agent bridge — con `X/9 OK` finale.
ParcelPanel, Chrome e bridge possono risultare "non configurati/non disponibili"
senza bloccare: sono opzionali.

---

## 8. La dashboard web

Avvia con `python web_server.py` e apri **http://localhost:8899** (login
basic-auth con le credenziali in `.env`). È una **inbox stile Gmail** pensata per
il team. Cosa puoi fare:

- **Leggere** la inbox, aprire un'email e il suo thread, vedere gli allegati.
- **Generare una bozza AI** per una email (o per molte: c'è il processing
  singolo e quello in blocco).
- **Rifinire la bozza** (`/api/refine-draft`) con istruzioni in linguaggio
  naturale, **tradurla** (`/api/translate`) o **chiedere all'AI** in chat
  (`/api/chat`) usando il contesto dell'email.
- **Stelle, letto/non letto, archivia, cestino** per gestire il backlog.
- **Inviare** la risposta approvata (`/api/send`) — l'invio parte **solo** quando
  sei tu a premerlo.
- **Auto-processor**: puoi attivare l'elaborazione automatica delle bozze in
  arrivo (sempre come bozze, mai invio).
- **Learning**: la dashboard mostra statistiche e insight su quanto le bozze AI
  vengono usate così come sono (vedi §12).

Aggiornamenti in tempo reale via SSE (`/api/events`). Su macOS, `start_all.sh`
avvia la dashboard in background (e il tunnel Cloudflare se `cloudflared` è
presente).

---

## 9. Il knowledge base del brand

Il file `knowledge/brand_context.md` è **il cervello del tono di voce**. Lo crea
il wizard come bozza; tu lo rifinisci con i dati reali. Tipicamente contiene:

- **Voce & tono** (lingua, stile, firma)
- **Prodotti**
- **Policy** (resi, tempi di rimborso, spedizioni, sostituzioni)
- **Situazioni frequenti e risposte approvate** ("dov'è il mio ordine?", taglia
  sbagliata, prodotto difettoso, rimborso non ricevuto, cancellazione…)
- **Divieti** (mai promettere rimborsi fuori policy, mai rivelare dati interni o
  di altri clienti, escalation per minacce legali)

Più è concreto e aggiornato, migliori sono le bozze. È un semplice file Markdown:
modificalo quando cambiano le policy.

---

## 10. I template di risposta

`templates/customer_care_templates.md` contiene gli **script pronti** del brand
(reso/rimborso, ordine in transito, cambio taglia, conferma rimborso,
cancellazione, prodotto difettoso, indirizzo errato, mancata consegna, commenti
social…). L'AI li usa come base testuale per le risposte.

Usa i segnaposto, resi automaticamente al caricamento:
`{{BRAND_NAME}}`, `{{BRAND_DOMAIN}}`, `{{BRAND_RETURNS_URL}}`,
`{{BRAND_SHIPPING_URL}}`, `{{BRAND_SIGN_OFF}}`, `{{SUPPORT_EMAIL}}`,
`{{ORDER_ID_PREFIX}}`. Il loader carica **tutti i file `.md`** in `templates/`,
quindi puoi aggiungerne quanti vuoi.

---

## 11. Le categorie email

La classificazione usa etichette interne (configurabili in `config.py`):

`RESO_RIMBORSO`, `ORDINE_NON_ARRIVATO`, `TAGLIA_COLORE`, `PRODOTTO_DIFETTOSO`,
`INFO_PRODOTTO`, `MODIFICA_ORDINE`, `PAGAMENTO`, `FEEDBACK_POSITIVO`,
`FEEDBACK_NEGATIVO`, `PARTNERSHIP`, `FORNITORE`, `SPAM_MARKETING`, `ALTRO`.

Le categorie **da ignorare** (nessuna risposta) sono di default:
`PARTNERSHIP`, `FORNITORE`, `SPAM_MARKETING`. Puoi modificarle in `config.py`
(`EMAIL_CATEGORIES` e `SKIP_CATEGORIES`).

---

## 12. Il learning DB (l'agente impara)

Ogni bozza AI viene registrata nel file SQLite `data/learning.db`. Quando una
risposta viene **inviata** (da dashboard, webmail o mobile), il `learning_matcher`
ritrova l'email inviata (via header `In-Reply-To`), la confronta con la bozza AI
e calcola **quanto è stata modificata** (diff e similarity).

Risultato: la dashboard mostra **statistiche e insight** — ad esempio quante
bozze vengono inviate così come sono. Più usi l'agente, più capisci dove le sue
risposte sono già pronte e dove vanno migliorate (rifinendo brand context e
template). Endpoint dashboard: `/api/learning/stats`, `/api/learning/insights`,
`/api/learning/drafts`.

---

## 13. Scheduling e avvio automatico

Per far girare l'agente in continuo:
```bash
python main.py --schedule          # polling ogni POLL_INTERVAL_MINUTES (default 10)
```
Per il **rilevamento in tempo reale** (invece del polling) c'è `idle_listener.py`,
che tiene aperta una connessione IMAP IDLE e reagisce all'istante alle nuove
email (re-auth ogni 29 min per rispettare i limiti IMAP).

Per renderlo persistente e avviarlo al login/boot:
- **macOS** → `launchd` (`.plist`) oppure `start_all.sh` in background
- **Linux** → `systemd` service
- **Windows** → Task Scheduler / servizio
- **Cloud** → `pm2` o `supervisor`

Configura il keep-alive così che dashboard e scheduler si riavviino da soli.

---

## 14. Integrazioni opzionali

- **ParcelPanel** (`PARCELPANEL_API_KEY`) — aggiunge il tracking spedizioni al
  contesto. Senza, l'agente lavora lo stesso (niente tracking).
- **Screenshot tracking** (Chrome + chromedriver) — cattura un'immagine della
  pagina di tracking, salvata in `data/screenshots/`.
- **Telegram** (`TELEGRAM_BOT_TOKEN` + `TELEGRAM_CHAT_ID`) — notifiche al team.
- **Tunnel Cloudflare** (`CLOUDFLARE_TUNNEL_NAME`/`CLOUDFLARE_PUBLIC_URL`,
  `tunnel_manager.py`) — espone la dashboard a un URL pubblico, con auth davanti.
- **Email_agent bridge** (`EMAIL_AGENT_REPORTS_DIR`) — aggancia report JSON
  giornalieri esterni come contesto/filtro spam. Disattivato di default.

---

## 15. Script di manutenzione

In `scripts/` ci sono utility one-shot per il triage del backlog (tutte con
`--dry-run` di default dove applicabile):

| Script | Cosa fa |
|---|---|
| `bulk_seen_noise.py` | segna come letta la posta "rumore" (notifiche Shopify/Facebook/Google, newsletter) — **mai** le email dei clienti |
| `bulk_seen_replied.py` | segna come letti i thread a cui hai già risposto |
| `list_pending_stars.py` | elenca le email stellate ancora in sospeso |
| `star_cleanup_keep_top.py` | ripulisce le stelle tenendo solo le top |
| `unflag_resolved.py` | toglie il flag alle conversazioni risolte |
| `recheck_delivery_failed.py` | ri-verifica un export "Delivery Failed" contro lo stato reale ParcelPanel e produce un `.xlsx` colorato |

Esempio:
```bash
python scripts/recheck_delivery_failed.py /percorso/Delivery\ Failed.xls
# output: /percorso/Delivery Failed_recheck.xlsx (i percorsi sono argomenti)
```

---

## 16. Personalizzazione: onboarding di un nuovo brand

CustomerCareAgent è brand-agnostic: per un nuovo brand non si tocca codice.

1. Copia la cartella:
   ```bash
   cp -R CustomerCareAgent my-new-brand && cd my-new-brand
   ```
2. Lancia il wizard:
   ```bash
   ./setup.sh
   ```
3. Rifinisci `knowledge/brand_context.md` con le policy reali e
   `templates/customer_care_templates.md` con gli script del brand.
4. Verifica:
   ```bash
   python main.py --check
   ```
5. Opera dalla dashboard:
   ```bash
   python web_server.py
   ```

---

## 17. Struttura dei file

```
CustomerCareAgent/
├── config.py                  # configurazione centralizzata + render_template()
├── main.py                    # CLI: --check / --dry-run / --once / --schedule
├── web_server.py              # dashboard FastAPI (inbox stile Gmail)
├── processor.py               # pipeline per-email (classifica → lookup → bozza)
├── priority_scorer.py         # priorità delle email
├── idle_listener.py           # rilevamento email in tempo reale (IMAP IDLE)
├── learning_db.py             # registro bozze AI (SQLite)
├── learning_matcher.py        # match inviate ↔ bozze, calcolo similarity
├── tunnel_manager.py          # tunnel Cloudflare (opzionale)
├── connectors/                # IMAP/SMTP, Shopify, Claude, ParcelPanel, Selenium, bridge
├── knowledge/
│   ├── brand_context.md       # voce + policy del brand (creato dal wizard)
│   └── knowledge_loader.py
├── prompts/                   # classify.md, draft_response.md (template segnaposto)
├── templates/                 # customer_care_templates.md (script pronti)
├── policies/                  # policy aggiuntive (.md) — opzionale
├── static/                    # frontend della dashboard (HTML/CSS/JS)
├── scripts/                   # utility di manutenzione/triage
├── data/                      # bozze, screenshot, cache, learning.db (vuoto all'avvio)
├── logs/                      # log giornalieri
├── setup.sh                   # wizard di setup
├── start_all.sh               # launcher macOS (web + tunnel)
├── requirements.txt
└── .env.example               # tutte le variabili (copia in .env o usa setup.sh)
```

---

## 18. Sicurezza e privacy

- **I dati restano tuoi**: l'agente gira sul tuo sistema; lo stato sono file
  locali. Le API esterne che usa sono Shopify, ParcelPanel e Anthropic (Claude),
  per recuperare contesto e generare le bozze.
- **Mai invio automatico**: ogni risposta passa da revisione umana. È la
  protezione centrale contro errori imbarazzanti verso i clienti.
- **Credenziali**: stanno solo in `.env` (chmod 600), mai nel codice. `.gitignore`
  esclude `.env`, i dati e i log dal versionamento.
- **Esposizione**: di default la dashboard è su `localhost`. Se la pubblichi,
  usa il tunnel Cloudflare o un reverse-proxy e tieni una password robusta.
- **Divieti nel brand context**: ricorda all'AI di non rivelare dati interni o di
  altri clienti, e di non promettere nulla fuori policy.

---

## 19. Risoluzione problemi

| Problema | Soluzione |
|---|---|
| `--check` fallisce su IMAP/SMTP | Verifica `SUPPORT_EMAIL`/`MAIL_PASSWORD` e i server/porte. Su alcuni provider serve una app-password. |
| Le bozze non compaiono in casella | Il nome della cartella Drafts varia: l'agente prova vari nomi; se nessuno combacia, aggiungilo a `DRAFTS_FOLDER_NAMES` in `config.py`. |
| Shopify "non autorizzato" | Il token `shpat_...` deve avere scope `read_orders`, `read_customers`, `read_products`. |
| Claude non risponde | Controlla `ANTHROPIC_API_KEY` e il credito sull'account Anthropic. |
| Chrome/Selenium KO | Chrome e chromedriver devono avere la stessa versione major. È una funzione opzionale: senza, il resto funziona. |
| ParcelPanel "non configurato" | Normale se non hai messo `PARCELPANEL_API_KEY`. È opzionale. |
| La dashboard non carica | Riavvia `python web_server.py`; controlla che la `WEB_PORT` sia libera. |
| Le bozze sono fuori tono | Rifinisci `knowledge/brand_context.md` e i template: sono ciò che guida l'AI. |
| Troppa posta "rumore" in inbox | Usa `scripts/bulk_seen_noise.py --apply` per marcare le notifiche non-clienti. |

---

## 20. FAQ

**L'agente invia le risposte da solo?**
No, mai. Prepara bozze; sei tu (o il team) ad approvare e inviare. È la regola di
sicurezza fondamentale del prodotto.

**I dati dei clienti vanno nel cloud?**
L'app gira a casa tua e lo stato sono file locali. Per generare le bozze usa
Claude (Anthropic) e per il contesto Shopify/ParcelPanel: il testo dell'email e i
dati d'ordine pertinenti vengono inviati a quei servizi, come per qualsiasi
integrazione AI. Nessun database di terzi.

**Funziona solo con Shopify?**
Il lookup ordini è costruito su Shopify. Email, AI e bozze funzionano comunque;
senza Shopify perdi solo l'arricchimento dell'ordine.

**Devo saper programmare per usarlo?**
No per l'uso normale: wizard + dashboard. Per personalizzazioni fini (categorie,
prompt) basta modificare file di testo (`.md`) e poche costanti in `config.py`.

**In che lingua risponde?**
Nella lingua impostata in `BRAND_LANGUAGE` (e adatta alla lingua del cliente).
L'interfaccia e i messaggi sono in italiano.

**Posso usarlo per più brand?**
Sì: copia la cartella e rilancia `setup.sh`. Ogni brand è isolato nel suo `.env`,
knowledge base e dati.

**Come migliora nel tempo?**
Registra le bozze e le confronta con ciò che invii davvero (learning DB), così
vedi dove l'AI è già pronta e dove rifinire brand context e template.

---

*CustomerCareAgent v1.0 — customer care AI per Shopify, self-hosted, i tuoi dati
restano tuoi.*
