#!/bin/bash
# Tunnel monitor: restarts cloudflared if tunnel dies, sends new URL to Telegram.
# Reads all config from .env (set vars: TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID,
# WEB_PORT, WEB_AUTH_USERNAME, WEB_AUTH_PASSWORD, CLOUDFLARED_BIN).

set -a
[ -f "$(dirname "$0")/.env" ] && . "$(dirname "$0")/.env"
set +a

WEB_PORT="${WEB_PORT:-8899}"
LOCAL_URL="http://localhost:${WEB_PORT}"
CLOUDFLARED="${CLOUDFLARED_BIN:-cloudflared}"
CHECK_INTERVAL="${TUNNEL_CHECK_INTERVAL:-30}"

send_telegram() {
    [ -z "$TELEGRAM_BOT_TOKEN" ] && return 0
    [ -z "$TELEGRAM_CHAT_ID" ] && return 0
    curl -s "https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage" \
        -d "chat_id=${TELEGRAM_CHAT_ID}" \
        -d "text=$1" > /dev/null 2>&1
}

start_tunnel() {
    # Kill old tunnels
    ps aux | grep cloudflared | grep -v grep | awk '{print $2}' | xargs -r kill 2>/dev/null
    sleep 2

    LOGFILE="/tmp/cloudflared_$$.log"
    "$CLOUDFLARED" tunnel --url "$LOCAL_URL" > "$LOGFILE" 2>&1 &
    TUNNEL_PID=$!

    for i in $(seq 1 20); do
        sleep 1
        URL=$(grep -o 'https://[a-z0-9-]*\.trycloudflare\.com' "$LOGFILE" 2>/dev/null | head -1)
        if [ -n "$URL" ]; then
            echo "Tunnel URL: $URL"
            send_telegram "🔗 ${BRAND_NAME:-CustomerCare} Agent online: ${URL}"
            rm -f "$LOGFILE"
            return 0
        fi
    done
    echo "Failed to get tunnel URL"
    rm -f "$LOGFILE"
    return 1
}

echo "Starting tunnel monitor..."
start_tunnel

while true; do
    sleep "$CHECK_INTERVAL"

    AUTH_FLAG=()
    if [ -n "$WEB_AUTH_USERNAME" ] && [ -n "$WEB_AUTH_PASSWORD" ]; then
        AUTH_FLAG=(-u "${WEB_AUTH_USERNAME}:${WEB_AUTH_PASSWORD}")
    fi
    SERVER_OK=$(curl -s -o /dev/null -w "%{http_code}" "${AUTH_FLAG[@]}" "$LOCAL_URL/api/folders" 2>/dev/null)
    if [ "$SERVER_OK" != "200" ]; then
        echo "$(date): Server down (HTTP $SERVER_OK), skipping tunnel check"
        continue
    fi

    if ! ps aux | grep cloudflared | grep -v grep > /dev/null 2>&1; then
        echo "$(date): Tunnel process dead, restarting..."
        start_tunnel
        continue
    fi
done
