CUSTOMER CARE — READY SCRIPTS (template skeleton)

> ⚠️  FILL THIS FILE with your brand's stock reply scripts before running the agent.
> The agent will use these as base text for AI-drafted replies.
> Sign-off line is auto-injected from BRAND_SIGN_OFF in .env.
> Use {{BRAND_NAME}}, {{BRAND_DOMAIN}}, {{BRAND_RETURNS_URL}}, {{BRAND_SHIPPING_URL}}
> as placeholders — they get rendered automatically.

---

## RETURN / REFUND REQUEST (first contact, no reason given)

Hello Dear,

Thank you for your message.
We will be happy to assist you with your return request. Before providing the
return details, could you please let us know the reason for the return (size,
color, fit, defect, etc.)? This will help us support you in the best possible way.

Please note the following points from our Return Policy:
{{BRAND_RETURNS_URL}}

• Returns are accepted within 30 days of delivery.
• Return shipping costs are the responsibility of the customer.
• Products must be returned in their original packaging, in perfect condition.

Please let us know how you would like to proceed.

Kind regards,
{{BRAND_SIGN_OFF}}

---

## ORDER SHIPPED & IN TRANSIT

Hello Dear,

Thank you for your message.
We have checked your order and can confirm that it is currently in transit.

You can track your shipment here:
[TRACKING LINK]

Tracking updates may take 24–48 hours to refresh between scans.
If you notice no movement after a few days, feel free to contact us again.

Kind regards,
{{BRAND_SIGN_OFF}}

---

## SIZE EXCHANGE (free replacement, customer keeps wrong pair)

Hello Dear,

Thank you for your message.

No worries at all — we can offer you a free size exchange.
We can send you the correct size as requested.

Please kindly confirm:
• The product
• The correct size

Once we receive your confirmation, we will proceed with the new shipment.
You can keep the wrong pair without returning it.

Kind regards,
{{BRAND_SIGN_OFF}}

---

## FULL REFUND CONFIRMATION

Dear,

Thank you for your message.

We can confirm that the full refund has been issued to the original payment method
used for the purchase.

Depending on your bank or payment provider, it may take approximately 3–5 business
days for the refund to appear in your account.

Kind regards,
{{BRAND_SIGN_OFF}}

---

## ORDER CANCELLATION (before fulfillment)

Hello,

Thank you for contacting us. We have canceled your order as requested.
The refund has been processed and will be visible on your payment method within
the time frame specified by your bank.

If you don't mind, could you let us know the reason for the cancellation? We are
collecting feedback to improve our services and products.

Kind regards,
{{BRAND_SIGN_OFF}}

---

## REFUND REQUEST ON ALREADY SHIPPED ORDER

Dear,

Thank you for your message.
We understand your request. However, as your order has already been processed and
shipped, we are unfortunately unable to make any changes at this stage.

{{BRAND_SHIPPING_URL}}

Once an order enters the shipping process, it cannot be modified or intercepted.
We kindly ask you to wait until the package is delivered. As soon as you receive
it, please feel free to contact us again.

Kind regards,
{{BRAND_SIGN_OFF}}

---

## DEFECTIVE / WRONG PRODUCT (request photos first)

Dear,

Thank you for your message.
We're very sorry to hear that you're experiencing this issue.

To proceed, could you please send us:
• Clear photos of the item received
• A photo showing the issue
• A photo of the size/inner label
• A photo of the full product laid flat

This helps us verify the situation with our quality team and warehouse so we can
provide the correct solution right away.

Kind regards,
{{BRAND_SIGN_OFF}}

---

## WRONG / MISSING ADDRESS

Dear Customer,

Thank you for your purchase.
We are contacting you because the address provided for your order is incomplete
or incorrect, and we have been unable to proceed with the shipment.

We kindly ask you to reply to this email with your correct and complete address
(including house number and postal code).

Best regards,
{{BRAND_SIGN_OFF}}

---

## FAILED DELIVERY

Hello,

We have verified that your package has already been attempted for delivery, but
the courier was unable to complete it.

The courier is making another delivery attempt. You can monitor the situation
here: [TRACKING LINK]

If you need further assistance, we are at your disposal.

Kind regards,
{{BRAND_SIGN_OFF}}

---

## SOCIAL & DM COMMENTS

Hello! Thank you for contacting us. For any information regarding your order,
please write directly to {{SUPPORT_EMAIL}}, where our team will be happy to help
you with any queries you may have.
