# CustomerCareAgent

Brand-agnostic customer-care automation for Shopify stores. Reads inbound email,
looks up the order on Shopify and tracking on ParcelPanel, drafts a reply with
Claude, and parks it as an IMAP draft for human review. Never auto-sends.

## Quickstart (3 steps)

```bash
# 1. Install
pip install -r requirements.txt

# 2. Configure (interactive wizard — generates .env + brand_context.md)
./setup.sh

# 3. Verify and run
python main.py --check          # connection sanity check
python main.py --dry-run        # fetch recent mail, no actions
python web_server.py            # start dashboard (default :8899)
```

## What you need before setup

- **Shopify Admin API token** (`shpat_...`) — Shopify Admin → Apps → Develop apps → API credentials
- **Anthropic API key** (`sk-ant-...`)
- **Mailbox credentials** (IMAP/SMTP — Hostinger, Gmail-with-app-password, etc.)
- *(optional)* ParcelPanel API key, Telegram bot token, Cloudflare tunnel name

## CLI

```bash
python main.py --check                 # verify all connections
python main.py --dry-run --limit 5     # fetch 5 emails, no draft
python main.py --once                  # one full cycle
python main.py --schedule              # poll every N minutes (POLL_INTERVAL_MINUTES)
python web_server.py                   # dashboard at http://localhost:WEB_PORT
```

## Project layout

```
config.py                   Centralized env-driven config + render_template()
main.py                     CLI entry: --check / --dry-run / --once / --schedule
web_server.py               FastAPI dashboard (basic auth)
processor.py                Per-email pipeline (classify → lookup → draft)
priority_scorer.py          Priority signals
tunnel_manager.py           Optional Cloudflare named tunnel
connectors/                 IMAP/SMTP, Shopify, Claude, ParcelPanel, Selenium, Telegram, Email_agent bridge
knowledge/brand_context.md  Editable brand voice + policies (used by Claude)
prompts/                    Placeholder templates (classify.md, draft_response.md)
templates/                  Stock response scripts
static/                     Dashboard frontend (HTML/CSS/JS)
data/                       Drafts, screenshots, processed-state cache
logs/                       Daily rotating logs
setup.sh                    Interactive setup wizard
.env.example                All available env vars (copy to .env or use setup.sh)
```

## Brand customization

Everything brand-specific lives in `.env` (`BRAND_NAME`, `BRAND_DOMAIN`,
`BRAND_LANGUAGE`, `ORDER_ID_PREFIX`, etc.) and `knowledge/brand_context.md`.
Prompts and templates use `{{BRAND_NAME}}`-style placeholders rendered at load
time — no source edits needed to onboard a new brand.

## Deployment notes

- **Drafts only.** The agent never sends — every reply waits in IMAP Drafts for human approval.
- **Local first.** Runs on the operator's laptop / VM. Optional Cloudflare named tunnel exposes the dashboard.
- **No DB requirement.** Learning matcher uses a local SQLite file (`learning.db`).
- **Cloud deploy** (containerized / managed) is a future phase — not in scope today.

## License / credit

Internal tool. Adapt freely.
