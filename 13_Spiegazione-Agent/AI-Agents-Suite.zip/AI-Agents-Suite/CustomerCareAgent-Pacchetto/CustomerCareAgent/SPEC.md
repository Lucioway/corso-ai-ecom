# SPEC — CustomerCareAgent (Phase 1: Connessioni)

## Requisiti Funzionali

### RF-01: Connessione Email IMAP
- Connessione a `imap.hostinger.com:993` con SSL
- Account: `${SUPPORT_EMAIL}` (env-driven, e.g. `info@yourbrand.com`)
- Lettura INBOX con fetch email recenti
- Supporto header: From, To, Subject, Date, Message-ID, In-Reply-To, References
- Estrazione body text/plain e text/html

### RF-02: Connessione Email SMTP (Bozze)
- Connessione a `smtp.hostinger.com:465` con SSL
- Salvataggio bozze via IMAP APPEND nella cartella Drafts
- Nomi cartella da provare: "Drafts", "INBOX.Drafts", "Bozze"

### RF-03: Connessione Shopify API
- Store: `${SHOPIFY_STORE_URL}` (env-driven, e.g. `https://your-store.myshopify.com`)
- API version: `${SHOPIFY_API_VERSION}` (default `2024-01`)
- Endpoint: shop.json, orders.json, customers/search.json, products.json, fulfillments.json
- Paginazione via Link header
- Rate limiting: max 2 req/sec (bucket leaky)

### RF-04: Connessione Claude API
- SDK `anthropic` Python
- Model default: `claude-sonnet-4-20250514`
- Test connessione con messaggio triviale

### RF-05: Connessione ParcelPanel API v2
- Base URL: `https://open.parcelwill.com`
- Auth: header `x-parcelpanel-api-key`
- Endpoint: `GET /api/v2/tracking/order?order_number={num}`
- Rate limit: 120 req/min

### RF-06: Screenshot Tracking
- Chrome headless via Selenium
- Screenshot PNG di pagine tracking pubbliche
- Salvataggio in `data/screenshots/`

### RF-07: Knowledge Base Loader
- Carica `shared/brand_context.md`
- Carica `Marketing_KB/Marketing_KB_Vault/00_Brand/brand_context_completo.md`
- Carica email categories
- Carica template risposte da `templates/`

### RF-08: CLI Entry Point
- `--check`: verifica tutte le connessioni
- `--dry-run`: fetch N email senza azioni
- `--once`: singola esecuzione
- `--schedule`: polling ogni 10 minuti
- `--limit N`: override limite email

## Architettura Tecnica

### Stack
- Python 3.11+
- imaplib + smtplib (email)
- requests (Shopify, ParcelPanel)
- anthropic SDK (Claude)
- selenium + Chrome (screenshot)
- APScheduler (scheduling)
- python-dotenv (config)

### Struttura File
```
CustomerCareAgent/
├── config.py                  # Configurazione centralizzata
├── main.py                    # Entry point CLI
├── connectors/
│   ├── imap_connector.py      # IMAP + SMTP
│   ├── shopify_connector.py   # Shopify REST API
│   ├── claude_connector.py    # Anthropic SDK
│   ├── parcelpanel_connector.py # ParcelPanel API v2
│   └── tracking_screenshot.py # Selenium screenshot
└── knowledge/
    └── knowledge_loader.py    # Brand context, policy, template
```

### Flusso Dati (Phase 1)
```
main.py --check → [imap] → [smtp] → [shopify] → [claude] → [parcelpanel] → [selenium] → [knowledge]
main.py --dry-run → [imap] → fetch N email → print soggetti
```

## Criteri di Accettazione
1. `python main.py --check` stampa 8/8 connessioni OK
2. `python main.py --dry-run --limit 10` mostra 10 email con soggetto e mittente
3. Ogni connettore gestisce errori senza crash
4. Log con timestamp per ogni operazione
5. Zero credenziali hardcoded

## Dipendenze e Rischi
- ParcelPanel API key: deve essere generata da Shopify Admin
- Chromedriver: deve corrispondere alla versione Chrome installata
- Shopify token scope: verificare che includa read_orders, read_customers, read_products
- Nome cartella Drafts su Hostinger: potrebbe variare
