"""
Tunnel Manager — auto-restart cloudflared tunnel + Telegram notification.

Mantiene attivo il tunnel Cloudflare per il CustomerCareAgent.
Quando l'URL cambia, lo invia su Telegram.

Tutto brand-agnostic via env (.env):
  WEB_AUTH_USERNAME, WEB_AUTH_PASSWORD, WEB_PORT
  CLOUDFLARE_TUNNEL_NAME, CLOUDFLARE_PUBLIC_URL
  BRAND_NAME (per Telegram messages)

OPZIONALE: se cloudflared non è installato o tunnel non configurato, lo skip è graceful.
"""

import logging
import os
import shutil
import subprocess
import sys
import time
from pathlib import Path

import requests

sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import (
    TELEGRAM_BOT_TOKEN, TELEGRAM_CHAT_ID, LOGS_DIR,
    WEB_AUTH_USERNAME, WEB_AUTH_PASSWORD, WEB_PORT,
    TUNNEL_NAME, PUBLIC_URL, BRAND_NAME,
)

AUTH_USERNAME = WEB_AUTH_USERNAME
AUTH_PASSWORD = WEB_AUTH_PASSWORD


def _resolve_cloudflared() -> str:
    override = os.getenv("CLOUDFLARED_PATH")
    if override and Path(override).exists():
        return override
    found = shutil.which("cloudflared")
    if found:
        return found
    for candidate in (
        "/opt/homebrew/bin/cloudflared",
        "/usr/local/bin/cloudflared",
    ):
        if Path(candidate).exists():
            return candidate
    return "cloudflared"


CLOUDFLARED = _resolve_cloudflared()
LOCAL_URL = f"http://localhost:{WEB_PORT}"

LOGS_DIR.mkdir(parents=True, exist_ok=True)
URL_FILE = LOGS_DIR / "tunnel_url.txt"
TUNNEL_LOG = LOGS_DIR / "tunnel.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(LOGS_DIR / "tunnel_manager.log", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("tunnel_manager")


def send_telegram(message: str) -> bool:
    """Invia messaggio su Telegram al chat configurato."""
    if not TELEGRAM_BOT_TOKEN or not TELEGRAM_CHAT_ID:
        logger.warning("Telegram non configurato")
        return False
    try:
        url = f"https://api.telegram.org/bot{TELEGRAM_BOT_TOKEN}/sendMessage"
        resp = requests.post(url, json={
            "chat_id": TELEGRAM_CHAT_ID,
            "text": message,
            "parse_mode": "Markdown",
            "disable_web_page_preview": False,
        }, timeout=10)
        if resp.ok:
            logger.info("Telegram inviato")
            return True
        logger.error("Telegram errore: %s", resp.text[:200])
        return False
    except Exception as e:
        logger.error("Telegram exception: %s", e)
        return False


def wait_for_local_server(timeout: int = 300) -> bool:
    """Aspetta che il web server locale risponda."""
    logger.info("Aspetto che il web server sia pronto su %s ...", LOCAL_URL)
    start = time.time()
    while time.time() - start < timeout:
        try:
            resp = requests.get(f"{LOCAL_URL}/api/folders",
                                auth=(AUTH_USERNAME, AUTH_PASSWORD), timeout=3)
            if resp.status_code == 200:
                logger.info("Web server pronto")
                return True
        except Exception:
            pass
        time.sleep(5)
    logger.error("Web server non risponde dopo %ds", timeout)
    return False


def start_tunnel() -> tuple[subprocess.Popen | None, str | None]:
    """Avvia named tunnel (URL fisso da config.yml)."""
    if not TUNNEL_NAME:
        logger.error("CLOUDFLARE_TUNNEL_NAME non configurato")
        return None, None
    logger.info("Avvio tunnel cloudflared: %s", TUNNEL_NAME)
    try:
        with open(TUNNEL_LOG, "w", encoding="utf-8") as logfile:
            popen_kwargs = dict(stdout=logfile, stderr=subprocess.STDOUT)
            if sys.platform == "win32":
                popen_kwargs["creationflags"] = subprocess.CREATE_NO_WINDOW
            proc = subprocess.Popen(
                [CLOUDFLARED, "tunnel", "run", TUNNEL_NAME],
                **popen_kwargs,
            )
    except Exception as e:
        logger.error("Errore avvio cloudflared: %s", e)
        return None, None

    # Aspetta che il tunnel segnali "Registered" (max 30s)
    for _ in range(30):
        time.sleep(1)
        if proc.poll() is not None:
            logger.error("cloudflared terminato prematuramente")
            return None, None
        if not TUNNEL_LOG.exists():
            continue
        try:
            content = TUNNEL_LOG.read_text(encoding="utf-8", errors="replace")
            if "Registered tunnel connection" in content or "Connection" in content:
                logger.info("Tunnel attivo: %s", PUBLIC_URL)
                return proc, PUBLIC_URL
        except Exception:
            pass

    if proc.poll() is None:
        logger.info("Tunnel probabile attivo (no registrazione rilevata): %s", PUBLIC_URL)
        return proc, PUBLIC_URL
    logger.error("Tunnel non avviato")
    return None, None


def save_url(url: str) -> None:
    URL_FILE.write_text(url, encoding="utf-8")


def main_loop() -> None:
    logger.info("=== Tunnel Manager %s avviato ===", BRAND_NAME)

    if not PUBLIC_URL or not TUNNEL_NAME:
        logger.error("CLOUDFLARE_PUBLIC_URL o CLOUDFLARE_TUNNEL_NAME non configurati — exit")
        return

    if not wait_for_local_server(timeout=600):
        send_telegram(f"⚠️ *{BRAND_NAME} Care* — Web server non parte, tunnel non avviato")
        return

    last_url = None

    while True:
        proc, url = start_tunnel()
        if not proc or not url:
            logger.error("Fallito avvio tunnel, retry tra 30s")
            time.sleep(30)
            continue

        save_url(url)

        if url != last_url:
            msg = (
                f"🚀 *{BRAND_NAME} Customer Care* — tunnel attivo\n\n"
                f"🌐 [{url}]({url})\n\n"
                f"👤 User: `{AUTH_USERNAME}`\n"
                f"🔑 Pass: `{AUTH_PASSWORD}`"
            )
            send_telegram(msg)
            last_url = url

        try:
            proc.wait()
            logger.warning("Tunnel terminato, riavvio tra 10s...")
        except KeyboardInterrupt:
            logger.info("Interrupted")
            proc.terminate()
            break
        except Exception as e:
            logger.error("Errore wait: %s", e)
            try:
                proc.terminate()
            except Exception:
                pass

        time.sleep(10)


if __name__ == "__main__":
    main_loop()
