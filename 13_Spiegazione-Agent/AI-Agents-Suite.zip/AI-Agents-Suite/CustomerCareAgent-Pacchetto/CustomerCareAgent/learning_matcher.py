"""
Learning Matcher — match email inviate (da webmail, mobile, frontend)
con le bozze AI nel learning DB.

Scansiona periodicamente la cartella Sent, estrae l'In-Reply-To header,
e matcha con bozze AI non ancora marcate come sent.
Calcola diff e similarity tra bozza e risposta finale umana.
"""

import email as email_lib
import imaplib
import json
import logging
import sqlite3
import time
from datetime import datetime
from difflib import SequenceMatcher, unified_diff
from email.header import decode_header
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import (
    EMAIL_ADDRESS, EMAIL_PASSWORD, IMAP_SERVER, IMAP_PORT,
    DATA_DIR, PROCESSED_DIR,
)

logger = logging.getLogger(__name__)

DB_PATH = DATA_DIR / "learning.db"
STATE_PATH = PROCESSED_DIR / "matcher_state.json"

SENT_FOLDER_CANDIDATES = [
    "INBOX.Sent", "Sent", "Sent Messages", "Sent Items",
]


def _decode_header_value(value: str) -> str:
    if not value:
        return ""
    try:
        parts = decode_header(value)
        out = []
        for p, charset in parts:
            if isinstance(p, bytes):
                out.append(p.decode(charset or "utf-8", errors="replace"))
            else:
                out.append(p)
        return " ".join(out)
    except Exception:
        return value


def _extract_plain_body(msg: email_lib.message.Message) -> str:
    """Extract plain text body from a message, stripping HTML."""
    plain = ""
    html = ""

    if msg.is_multipart():
        for part in msg.walk():
            ct = part.get_content_type()
            try:
                charset = part.get_content_charset() or "utf-8"
                payload = part.get_payload(decode=True)
                if not payload:
                    continue
                text = payload.decode(charset, errors="replace")
                if ct == "text/plain" and not plain:
                    plain = text
                elif ct == "text/html" and not html:
                    html = text
            except Exception:
                continue
    else:
        try:
            charset = msg.get_content_charset() or "utf-8"
            payload = msg.get_payload(decode=True)
            if payload:
                text = payload.decode(charset, errors="replace")
                if msg.get_content_type() == "text/html":
                    html = text
                else:
                    plain = text
        except Exception:
            pass

    if plain:
        return plain[:10000]

    # Fallback: strip HTML tags roughly
    if html:
        import re
        s = re.sub(r"<style[^>]*>.*?</style>", "", html, flags=re.DOTALL | re.IGNORECASE)
        s = re.sub(r"<script[^>]*>.*?</script>", "", s, flags=re.DOTALL | re.IGNORECASE)
        s = re.sub(r"<[^>]+>", " ", s)
        s = re.sub(r"\s+", " ", s)
        return s.strip()[:10000]

    return ""


def _strip_quoted_reply(body: str) -> str:
    """
    Remove the quoted portion of a reply email.
    Keeps only the new content written by the human.
    """
    if not body:
        return ""

    lines = body.splitlines()
    result_lines = []

    # Common reply separators (English, Italian, etc.)
    separators = [
        "On ",  # "On Mon, Apr 10, 2026..."
        "Il ",  # "Il lun, 10 apr 2026..."
        "Am ",  # German
        "Op ",  # Dutch
        "Le ",  # French
        "-----Original Message-----",
        "From:",
        "Da:",
        "Von:",
    ]

    for line in lines:
        stripped = line.strip()
        # Stop at quoted lines (starting with >)
        if stripped.startswith(">"):
            break
        # Stop at reply separators if line contains "wrote:" or similar
        if any(stripped.startswith(sep) for sep in separators):
            if "wrote:" in stripped or "ha scritto:" in stripped or "schrieb:" in stripped or stripped.endswith(":"):
                break
        result_lines.append(line)

    cleaned = "\n".join(result_lines).strip()

    # Collapse multiple newlines
    import re
    cleaned = re.sub(r"\n{3,}", "\n\n", cleaned)

    return cleaned


def _load_state() -> dict:
    """Load matcher state (last seen sent UID per folder)."""
    if STATE_PATH.exists():
        try:
            return json.loads(STATE_PATH.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def _save_state(state: dict) -> None:
    STATE_PATH.parent.mkdir(parents=True, exist_ok=True)
    STATE_PATH.write_text(json.dumps(state), encoding="utf-8")


def _compute_diff(ai_draft: str, final: str) -> tuple[str, float]:
    """Compute unified diff and similarity ratio."""
    ai_lines = ai_draft.splitlines(keepends=True)
    final_lines = final.splitlines(keepends=True)
    diff = "".join(unified_diff(ai_lines, final_lines, fromfile="ai_draft", tofile="final"))
    similarity = SequenceMatcher(None, ai_draft, final).ratio()
    return diff, similarity


def match_sent_emails() -> dict:
    """
    Scan Sent folder for new emails and match with AI drafts in learning DB.
    Returns stats dict.
    """
    if not DB_PATH.exists():
        logger.warning("Learning DB not found")
        return {"matched": 0, "skipped": 0, "error": "DB not found"}

    state = _load_state()
    last_uid = int(state.get("last_sent_uid", 0))

    stats = {"matched": 0, "skipped": 0, "checked": 0}

    try:
        conn = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT, timeout=30)
        conn.login(EMAIL_ADDRESS, EMAIL_PASSWORD)

        # Find sent folder
        sent_folder = None
        for candidate in SENT_FOLDER_CANDIDATES:
            quoted = f'"{candidate}"' if " " in candidate else candidate
            status, _ = conn.select(quoted, readonly=True)
            if status == "OK":
                sent_folder = candidate
                break

        if not sent_folder:
            conn.logout()
            logger.error("Sent folder not found")
            return {"matched": 0, "skipped": 0, "error": "Sent folder not found"}

        # Fetch all UIDs in Sent
        status, data = conn.search(None, "ALL")
        if status != "OK" or not data[0]:
            conn.logout()
            return stats

        all_uids = data[0].split()
        # Only process UIDs greater than last_uid
        new_uids = [u for u in all_uids if int(u.decode()) > last_uid]

        if not new_uids:
            conn.logout()
            return stats

        # Limit to last 50 for safety
        new_uids = new_uids[-50:]
        logger.info("Matcher: processing %d new sent emails (last_uid=%d)", len(new_uids), last_uid)

        # Open DB
        db = sqlite3.connect(str(DB_PATH))
        db.row_factory = sqlite3.Row

        max_uid = last_uid

        for uid in new_uids:
            uid_int = int(uid.decode())
            max_uid = max(max_uid, uid_int)
            stats["checked"] += 1

            try:
                status, msg_data = conn.fetch(uid, "(RFC822)")
                if status != "OK" or not msg_data or not msg_data[0]:
                    continue

                raw = msg_data[0][1]
                msg = email_lib.message_from_bytes(raw)

                in_reply_to = (msg.get("In-Reply-To") or "").strip()
                references = (msg.get("References") or "").strip()
                to_addr = _decode_header_value(msg.get("To", ""))
                subject = _decode_header_value(msg.get("Subject", ""))

                # Se manca In-Reply-To, proveremo il match per subject+to (Hostinger webmail bug)
                has_references = bool(in_reply_to or references)

                # Extract body
                body = _extract_plain_body(msg)
                if not body:
                    continue

                # Strip quoted reply to get only the human-written part
                human_reply = _strip_quoted_reply(body)
                if len(human_reply) < 20:
                    # Too short to be meaningful
                    continue

                draft_row = None

                # Strategy 1: match by In-Reply-To / References (standard RFC)
                if has_references:
                    candidates_msg_ids = [in_reply_to] if in_reply_to else []
                    if references:
                        candidates_msg_ids.extend(references.split())
                    for mid in candidates_msg_ids:
                        mid = mid.strip()
                        if not mid:
                            continue
                        row = db.execute(
                            """
                            SELECT id, ai_draft, was_sent
                            FROM drafts
                            WHERE message_id = ? AND was_sent = 0
                            ORDER BY created_at DESC LIMIT 1
                            """,
                            (mid,),
                        ).fetchone()
                        if row:
                            draft_row = row
                            break

                # Strategy 2: fallback by subject + recipient (Hostinger webmail missing headers)
                if not draft_row:
                    # Normalize subject: strip "Re:", "Fwd:", etc.
                    import re as _re
                    norm_subj = _re.sub(r"^(Re|Fwd|Fw|R|I)\s*:\s*", "", subject, flags=_re.IGNORECASE).strip()
                    norm_subj = _re.sub(r"^(Re|Fwd|Fw|R|I)\s*:\s*", "", norm_subj, flags=_re.IGNORECASE).strip()

                    # Extract clean email from "Name <email>" format
                    from email.utils import parseaddr
                    _, clean_to = parseaddr(to_addr)

                    if norm_subj and clean_to:
                        # Look for drafts to this recipient with similar subject
                        # Get sent email date for timing constraint
                        sent_date = msg.get("Date", "")
                        from email.utils import parsedate_to_datetime
                        from datetime import timedelta
                        try:
                            sent_dt = parsedate_to_datetime(sent_date) if sent_date else None
                        except Exception:
                            sent_dt = None

                        # Only match drafts created in the last 7 days (avoid cross-thread matches)
                        cutoff = (sent_dt - timedelta(days=7)).isoformat() if sent_dt else "2020-01-01"

                        row = db.execute(
                            """
                            SELECT id, ai_draft, was_sent, subject, created_at
                            FROM drafts
                            WHERE was_sent = 0
                              AND LOWER(from_addr) LIKE ?
                              AND (LOWER(subject) LIKE ? OR LOWER(subject) LIKE ?)
                              AND created_at >= ?
                            ORDER BY created_at DESC LIMIT 1
                            """,
                            (
                                f"%{clean_to.lower()}%",
                                f"%{norm_subj.lower()}%",
                                f"%re: {norm_subj.lower()}%",
                                cutoff,
                            ),
                        ).fetchone()
                        if row:
                            draft_row = row
                            logger.info("Matcher: fallback subject+to match for UID %d", uid_int)

                if not draft_row:
                    stats["skipped"] += 1
                    continue

                # Compute diff
                ai_draft = draft_row["ai_draft"] or ""
                diff_text, similarity = _compute_diff(ai_draft, human_reply)
                was_modified = 1 if similarity < 0.95 else 0

                db.execute(
                    """
                    UPDATE drafts SET
                        final_response = ?,
                        diff_text = ?,
                        similarity = ?,
                        was_modified = ?,
                        was_sent = 1,
                        sent_at = ?,
                        notes = ?
                    WHERE id = ?
                    """,
                    (
                        human_reply,
                        diff_text,
                        similarity,
                        was_modified,
                        datetime.now().isoformat(),
                        "Matched from Sent folder (webmail/mobile)",
                        draft_row["id"],
                    ),
                )
                db.commit()

                stats["matched"] += 1
                logger.info(
                    "Matcher: matched draft id=%d with sent UID=%d similarity=%.1f%%",
                    draft_row["id"], uid_int, similarity * 100,
                )

            except Exception as e:
                logger.error("Matcher: error processing UID %s: %s", uid, e)

        db.close()
        conn.logout()

        # Update state
        if max_uid > last_uid:
            state["last_sent_uid"] = max_uid
            _save_state(state)

        logger.info(
            "Matcher run complete: checked=%d matched=%d skipped=%d",
            stats["checked"], stats["matched"], stats["skipped"],
        )

    except Exception as e:
        logger.error("Matcher error: %s", e)
        stats["error"] = str(e)

    return stats


def background_matcher(interval_seconds: int = 300) -> None:
    """Background loop: run match_sent_emails every N seconds."""
    time.sleep(60)  # Wait 1 min after startup
    while True:
        try:
            match_sent_emails()
        except Exception as e:
            logger.error("Matcher background error: %s", e)
        time.sleep(interval_seconds)


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
    result = match_sent_emails()
    print(f"Result: {result}")
