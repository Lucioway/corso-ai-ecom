"""
Bulk-mark noise emails as Seen in Hostinger INBOX.

Targets only NON-customer notifications so the team can focus on real
customer backlog. Customer emails (refunds, returns, WISMO, order
issues) are NEVER touched.

Noise patterns marked Seen:
  - mailer@shopify.com / *@shopify.com (auto order/inquiry notifications)
  - noreply@business.facebook.com / *@facebookmail.com (FB Business)
  - mail-noreply@google.com / *@accounts.google.com (Google security)
  - newsletter / marketing senders (klaviyo, mailchimp, sendgrid, ...)
  - Cold outreach Subject patterns ("winning products", "boost sales", ...)

Usage:
    python scripts/bulk_seen_noise.py              # dry-run (default)
    python scripts/bulk_seen_noise.py --apply      # actually mark Seen
    python scripts/bulk_seen_noise.py --limit 50   # cap inspection
"""
import argparse
import imaplib
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import EMAIL_ADDRESS, EMAIL_PASSWORD, IMAP_SERVER, IMAP_PORT


# ── Match rules ─────────────────────────────────────────────────────────

# Senders matched by exact address or domain suffix.
NOISE_SENDER_PATTERNS = [
    re.compile(r"@shopify\.com>?$", re.I),
    re.compile(r"@business\.facebook\.com>?$", re.I),
    re.compile(r"@facebookmail\.com>?$", re.I),
    re.compile(r"@accounts\.google\.com>?$", re.I),
    re.compile(r"@google\.com>?$", re.I),
    re.compile(r"@klaviyomail\.com>?$", re.I),
    re.compile(r"@klaviyo\.com>?$", re.I),
    re.compile(r"@mailchimp\.com>?$", re.I),
    re.compile(r"@sendgrid\.net>?$", re.I),
    re.compile(r"@mandrillapp\.com>?$", re.I),
    re.compile(r"@hubspot\.com>?$", re.I),
    re.compile(r"@trustpilot\.com>?$", re.I),
    re.compile(r"@apple\.com>?$", re.I),
    re.compile(r"@paypal\.com>?$", re.I),
    re.compile(r"@payments\.shopify\.com>?$", re.I),
    re.compile(r"^noreply@", re.I),
    re.compile(r"^no-reply@", re.I),
    re.compile(r"^donotreply@", re.I),
    re.compile(r"^do-not-reply@", re.I),
]

# Marketing/cold-outreach subject keywords.
NOISE_SUBJECT_PATTERNS = [
    re.compile(r"winning products?", re.I),
    re.compile(r"boost\s+(your\s+)?sales", re.I),
    re.compile(r"unsubscribe", re.I),
    re.compile(r"promotion(al)?", re.I),
    re.compile(r"newsletter", re.I),
    re.compile(r"black\s+friday", re.I),
    re.compile(r"limited\s+offer", re.I),
    re.compile(r"increase\s+your\s+(revenue|conversions?)", re.I),
    re.compile(r"shopify app", re.I),
    re.compile(r"partnership opportunity", re.I),
    re.compile(r"collab(oration)?", re.I),
]

# Customer signal Subject keywords — if matched, NEVER mark Seen even
# if sender looks like noise (defense-in-depth).
CUSTOMER_SUBJECT_PATTERNS = [
    re.compile(r"#?LS\s?\d{3,}", re.I),     # any order number
    re.compile(r"\border\s*(no|number|#)?", re.I),
    re.compile(r"\b(refund|return|reso|rimborso)\b", re.I),
    re.compile(r"\b(tracking|shipment|spedizione|tracciamento)\b", re.I),
    re.compile(r"\b(damaged?|broken|difettoso|rotto)\b", re.I),
    re.compile(r"\b(size|taglia|exchange|cambio)\b", re.I),
    re.compile(r"\bissue with purchase\b", re.I),
]


def is_noise(from_value: str, subject_value: str) -> tuple[bool, str]:
    """Return (is_noise, reason). Customer signals always win."""
    f = from_value or ""
    s = subject_value or ""
    # Customer signal short-circuits noise classification
    for cp in CUSTOMER_SUBJECT_PATTERNS:
        if cp.search(s):
            return False, ""
    for sp in NOISE_SENDER_PATTERNS:
        if sp.search(f):
            return True, f"sender:{sp.pattern}"
    for subp in NOISE_SUBJECT_PATTERNS:
        if subp.search(s):
            return True, f"subject:{subp.pattern}"
    return False, ""


# ── IMAP helpers ────────────────────────────────────────────────────────

UID_RE = re.compile(rb"UID (\d+)")
FROM_RE = re.compile(rb"^From:\s*(.*)$", re.M | re.I)
SUBJ_RE = re.compile(rb"^Subject:\s*(.*)$", re.M | re.I)


def fetch_headers(conn: imaplib.IMAP4_SSL, uids: list[bytes]) -> list[tuple[str, str, str]]:
    """Return [(uid, from, subject)] for given UIDs."""
    results: list[tuple[str, str, str]] = []
    BATCH = 200
    for i in range(0, len(uids), BATCH):
        chunk = uids[i:i + BATCH]
        uid_set = b",".join(chunk)
        status, data = conn.uid("fetch", uid_set, "(BODY.PEEK[HEADER.FIELDS (FROM SUBJECT)])")
        if status != "OK" or not data:
            continue
        for item in data:
            if isinstance(item, tuple) and len(item) >= 2:
                meta = item[0] if isinstance(item[0], (bytes, bytearray)) else b""
                body = item[1] if isinstance(item[1], (bytes, bytearray)) else b""
                m_uid = UID_RE.search(meta)
                m_from = FROM_RE.search(body)
                m_subj = SUBJ_RE.search(body)
                if m_uid:
                    uid = m_uid.group(1).decode()
                    frm = m_from.group(1).decode("utf-8", errors="replace").strip() if m_from else ""
                    sub = m_subj.group(1).decode("utf-8", errors="replace").strip() if m_subj else ""
                    results.append((uid, frm, sub))
    return results


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="Actually set \\Seen flag (default: dry-run)")
    ap.add_argument("--limit", type=int, default=0, help="Cap how many UNSEEN UIDs to inspect (0 = all)")
    args = ap.parse_args()

    print(f"[{'APPLY' if args.apply else 'DRY-RUN'}] connecting to {IMAP_SERVER}:{IMAP_PORT}")
    conn = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT, timeout=60)
    conn.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
    conn.select("INBOX")
    status, data = conn.uid("search", None, "UNSEEN")
    if status != "OK" or not data or not data[0]:
        print("No UNSEEN emails. Nothing to do.")
        conn.logout()
        return 0
    unseen = data[0].split()
    if args.limit:
        unseen = unseen[-args.limit:]
    print(f"UNSEEN UIDs to inspect: {len(unseen)}")

    headers = fetch_headers(conn, unseen)
    matched: list[tuple[str, str, str, str]] = []  # uid, from, subj, reason
    customer_kept = 0
    other_kept = 0
    for uid, frm, sub in headers:
        noise, reason = is_noise(frm, sub)
        if noise:
            matched.append((uid, frm, sub, reason))
        else:
            # quick classification for kept count
            if any(cp.search(sub) for cp in CUSTOMER_SUBJECT_PATTERNS):
                customer_kept += 1
            else:
                other_kept += 1

    print()
    print(f"=== Summary ===")
    print(f"Inspected: {len(headers)}")
    print(f"Noise to mark Seen: {len(matched)}")
    print(f"Customer signal kept unread: {customer_kept}")
    print(f"Other kept unread (manual review): {other_kept}")
    print()
    if matched:
        print("=== Sample of NOISE matches (first 25) ===")
        for uid, frm, sub, reason in matched[:25]:
            print(f"  UID={uid:>5} | {frm[:35]:35} | {sub[:50]:50} | {reason}")
        if len(matched) > 25:
            print(f"  ... +{len(matched) - 25} more")
    print()

    if not args.apply:
        print("Dry-run only. Re-run with --apply to mark Seen.")
        conn.logout()
        return 0

    if not matched:
        print("Nothing to mark.")
        conn.logout()
        return 0

    # Apply \Seen flag in batches
    BATCH = 200
    marked = 0
    uid_list = [m[0].encode() for m in matched]
    for i in range(0, len(uid_list), BATCH):
        chunk = uid_list[i:i + BATCH]
        uid_set = b",".join(chunk)
        s, _ = conn.uid("store", uid_set, "+FLAGS", "(\\Seen)")
        if s == "OK":
            marked += len(chunk)
        else:
            print(f"Batch {i // BATCH} failed (status={s})")
    print(f"Marked {marked} emails as Seen.")
    conn.logout()
    return 0


if __name__ == "__main__":
    sys.exit(main())
