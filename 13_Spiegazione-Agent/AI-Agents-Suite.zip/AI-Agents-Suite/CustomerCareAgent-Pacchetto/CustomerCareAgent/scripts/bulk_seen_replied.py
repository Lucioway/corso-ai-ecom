"""
Mark UNSEEN INBOX emails as Seen if they were already replied to.

Reuses the resolution passes from `unflag_resolved.py` but targets
UNSEEN (not FLAGGED) and sets \\Seen (not removes \\Flagged). Use when
the team replied via Hostinger webmail / Outlook / another client and
the tool's auto-Seen-mark didn't fire.

Detection passes:
  A. Strict threading: Sent In-Reply-To / References matches INBOX
     Message-ID
  B. Loose threading: same (customer addr, normalized subject), with
     Sent Date >= INBOX Date
  C. Optional (--loose): any Sent to the same customer with Date >=
     INBOX Date — catches threads where the operator changed the
     subject in the reply

Usage:
    python scripts/bulk_seen_replied.py            # dry-run, A+B
    python scripts/bulk_seen_replied.py --apply    # actually mark Seen
    python scripts/bulk_seen_replied.py --strict   # only RFC threading
    python scripts/bulk_seen_replied.py --loose    # also enable Pass C
"""
import argparse
import imaplib
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from config import EMAIL_ADDRESS, EMAIL_PASSWORD, IMAP_SERVER, IMAP_PORT
from unflag_resolved import (
    fetch_headers,
    extract_msg_ids,
    norm_addr,
    norm_subject,
    parse_date,
)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="Actually mark Seen (default: dry-run)")
    ap.add_argument("--strict", action="store_true", help="Only Pass A (RFC threading)")
    ap.add_argument("--loose", action="store_true", help="Also Pass C: any Sent to customer after inbox date")
    args = ap.parse_args()

    print(f"[{'APPLY' if args.apply else 'DRY-RUN'}] connecting to {IMAP_SERVER}:{IMAP_PORT}")
    conn = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT, timeout=120)
    conn.login(EMAIL_ADDRESS, EMAIL_PASSWORD)

    # 1. INBOX UNSEEN UIDs + headers
    print("Selecting INBOX...")
    conn.select("INBOX", readonly=not args.apply)
    s, d = conn.uid("search", None, "UNSEEN")
    if s != "OK" or not d or not d[0]:
        print("No UNSEEN UIDs.")
        conn.logout()
        return 0
    unseen_uids = d[0].split()
    print(f"  {len(unseen_uids)} UNSEEN UIDs")

    print("Fetching headers from UNSEEN inbox mails...")
    inbox_hdrs = fetch_headers(conn, unseen_uids, "MESSAGE-ID SUBJECT FROM DATE")
    msgid_to_uid: dict[str, str] = {}
    addr_subj_to_uids: dict[tuple[str, str], list[tuple[str, float]]] = {}
    addr_to_uids: dict[str, list[tuple[str, float]]] = {}
    missing_msgid = 0
    for uid_str, h in inbox_hdrs.items():
        mid_ids = extract_msg_ids(h.get("message-id", ""))
        if not mid_ids:
            missing_msgid += 1
        for i in mid_ids:
            msgid_to_uid[i] = uid_str
        addr = norm_addr(h.get("from", ""))
        subj = norm_subject(h.get("subject", ""))
        ts = parse_date(h.get("date", ""))
        if addr and subj:
            addr_subj_to_uids.setdefault((addr, subj), []).append((uid_str, ts))
        if addr:
            addr_to_uids.setdefault(addr, []).append((uid_str, ts))
    print(
        f"  {len(msgid_to_uid)} Message-IDs ({missing_msgid} missing) | "
        f"{len(addr_subj_to_uids)} (from, subject) keys | "
        f"{len(addr_to_uids)} distinct senders"
    )

    # 2. Sent folder
    print("Selecting INBOX.Sent...")
    s, d = conn.select("INBOX.Sent", readonly=True)
    if s != "OK":
        print("Cannot select INBOX.Sent")
        conn.logout()
        return 1
    s, d = conn.uid("search", None, "ALL")
    if s != "OK" or not d or not d[0]:
        print("Sent empty.")
        conn.logout()
        return 0
    sent_uids = d[0].split()
    print(f"  {len(sent_uids)} sent UIDs")

    print("Fetching headers from Sent...")
    sent_hdrs = fetch_headers(conn, sent_uids, "IN-REPLY-TO REFERENCES TO SUBJECT DATE")
    replied_msgids: set[str] = set()
    sent_addr_subj: dict[tuple[str, str], float] = {}
    sent_addr_max: dict[str, float] = {}
    for h in sent_hdrs.values():
        replied_msgids |= extract_msg_ids(h.get("in-reply-to", ""))
        replied_msgids |= extract_msg_ids(h.get("references", ""))
        to_addr = norm_addr(h.get("to", ""))
        subj = norm_subject(h.get("subject", ""))
        ts = parse_date(h.get("date", ""))
        if to_addr and subj:
            key = (to_addr, subj)
            if ts > sent_addr_subj.get(key, 0.0):
                sent_addr_subj[key] = ts
        if to_addr:
            if ts > sent_addr_max.get(to_addr, 0.0):
                sent_addr_max[to_addr] = ts
    print(
        f"  {len(replied_msgids)} threaded refs | "
        f"{len(sent_addr_subj)} (to, subject) keys | "
        f"{len(sent_addr_max)} distinct recipients"
    )

    # 3. Pass A — RFC threading
    resolved_a = {uid for mid, uid in msgid_to_uid.items() if mid in replied_msgids}
    print(f"\nPass A (RFC threading):     {len(resolved_a)} resolved")

    # 4. Pass B — (addr, subject) match
    resolved_b: set[str] = set()
    if not args.strict:
        for (addr, subj), inbox_list in addr_subj_to_uids.items():
            sent_ts = sent_addr_subj.get((addr, subj))
            if sent_ts is None:
                continue
            for uid_str, inbox_ts in inbox_list:
                if sent_ts + 60 >= inbox_ts:
                    resolved_b.add(uid_str)
        resolved_b -= resolved_a
        print(f"Pass B (addr+subject):      {len(resolved_b)} resolved")

    # 5. Pass C — any Sent to customer after inbox date
    resolved_c: set[str] = set()
    if args.loose:
        for addr, inbox_list in addr_to_uids.items():
            sent_ts = sent_addr_max.get(addr)
            if sent_ts is None:
                continue
            for uid_str, inbox_ts in inbox_list:
                if uid_str in resolved_a or uid_str in resolved_b:
                    continue
                if sent_ts + 60 >= inbox_ts:
                    resolved_c.add(uid_str)
        print(f"Pass C (any sent to addr):  {len(resolved_c)} resolved")

    resolved_all = resolved_a | resolved_b | resolved_c
    print(f"\nTotal resolved: {len(resolved_all)} / {len(unseen_uids)} UNSEEN")

    if not resolved_all:
        conn.logout()
        return 0

    # Sample print (mix passes)
    print("\n=== Sample of resolved UIDs (first 15) ===")
    for uid_str in sorted(resolved_all, key=lambda u: int(u))[-15:]:
        h = inbox_hdrs.get(uid_str, {})
        passes = []
        if uid_str in resolved_a:
            passes.append("A")
        if uid_str in resolved_b:
            passes.append("B")
        if uid_str in resolved_c:
            passes.append("C")
        print(
            f"  UID={uid_str:>5} [{','.join(passes)}] | "
            f"{h.get('from', '')[:35]:35} | {h.get('subject', '')[:55]}"
        )

    if not args.apply:
        print("\nDry-run only. Re-run with --apply to mark Seen.")
        conn.logout()
        return 0

    # Re-select INBOX writable
    conn.select("INBOX")
    BATCH = 200
    uid_list = sorted(resolved_all, key=lambda u: int(u))
    marked = 0
    for i in range(0, len(uid_list), BATCH):
        chunk = uid_list[i:i + BATCH]
        uid_set = ",".join(chunk).encode()
        s, _ = conn.uid("store", uid_set, "+FLAGS", "(\\Seen)")
        if s == "OK":
            marked += len(chunk)
        else:
            print(f"Batch {i // BATCH} failed (status={s})")
    print(f"Marked {marked} emails as Seen.")
    conn.logout()
    return 0


if __name__ == "__main__":
    sys.exit(main())
