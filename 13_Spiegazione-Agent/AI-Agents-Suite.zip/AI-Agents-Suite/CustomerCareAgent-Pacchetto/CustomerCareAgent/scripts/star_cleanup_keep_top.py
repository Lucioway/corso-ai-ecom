"""
Star cleanup — keep only top-N most-recent pending, unflag the rest.

"Pending" = no reply detected in Sent via:
  Pass A: RFC threading (In-Reply-To / References match)
  Pass B: same (from_addr, normalized_subject) with Sent >= inbox date
  Pass C: any Sent to the same address with date >= inbox date

Default --keep 60 matches operator's mental model of ~50 actionable stars.

Usage:
    python scripts/star_cleanup_keep_top.py                 # dry-run, keep 60
    python scripts/star_cleanup_keep_top.py --keep 50       # keep top 50
    python scripts/star_cleanup_keep_top.py --apply         # apply
"""
import argparse
import imaplib
import sys
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import EMAIL_ADDRESS, EMAIL_PASSWORD, IMAP_SERVER, IMAP_PORT
from scripts.unflag_resolved import (
    fetch_headers, extract_msg_ids, norm_addr, norm_subject, parse_date,
)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--keep", type=int, default=60, help="How many recent pending stars to keep")
    ap.add_argument("--apply", action="store_true", help="Actually unflag on IMAP")
    args = ap.parse_args()

    c = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT)
    c.login(EMAIL_ADDRESS, EMAIL_PASSWORD)

    # INBOX flagged
    c.select("INBOX", readonly=not args.apply)
    s, d = c.uid("search", None, "FLAGGED")
    flagged = d[0].split() if s == "OK" and d and d[0] else []
    print(f"INBOX flagged: {len(flagged)}")
    if not flagged:
        c.logout()
        return 0
    inbox_hdrs = fetch_headers(c, flagged, "MESSAGE-ID SUBJECT FROM DATE")

    # Sent refs
    c.select("INBOX.Sent", readonly=True)
    s, d = c.uid("search", None, "ALL")
    sent_uids = d[0].split() if s == "OK" and d and d[0] else []
    print(f"Sent total:    {len(sent_uids)}")
    sent_hdrs = fetch_headers(c, sent_uids, "IN-REPLY-TO REFERENCES TO SUBJECT DATE")

    replied_msgids: set[str] = set()
    sent_addr_subj: dict[tuple[str, str], float] = {}
    sent_addr_max: dict[str, float] = {}
    for h in sent_hdrs.values():
        replied_msgids |= extract_msg_ids(h.get("in-reply-to", ""))
        replied_msgids |= extract_msg_ids(h.get("references", ""))
        to_addr = norm_addr(h.get("to", ""))
        subj = norm_subject(h.get("subject", ""))
        ts = parse_date(h.get("date", ""))
        if to_addr and subj:
            key = (to_addr, subj)
            if ts > sent_addr_subj.get(key, 0.0):
                sent_addr_subj[key] = ts
        if to_addr and ts > sent_addr_max.get(to_addr, 0.0):
            sent_addr_max[to_addr] = ts

    # Classify each flagged as resolved / pending
    resolved_uids: set[str] = set()
    pending: list[tuple[float, str]] = []  # (date_ts, uid_str)
    for uid_str, h in inbox_hdrs.items():
        mid = next(iter(extract_msg_ids(h.get("message-id", ""))), None)
        addr = norm_addr(h.get("from", ""))
        subj_n = norm_subject(h.get("subject", ""))
        ts = parse_date(h.get("date", ""))

        is_resolved = False
        if mid and mid in replied_msgids:
            is_resolved = True
        elif addr and subj_n and sent_addr_subj.get((addr, subj_n), 0.0) + 60 >= ts:
            is_resolved = True
        elif addr and sent_addr_max.get(addr, 0.0) + 60 >= ts:
            is_resolved = True

        if is_resolved:
            resolved_uids.add(uid_str)
        else:
            pending.append((ts, uid_str))

    pending.sort(reverse=True)
    keep_set = {uid for _, uid in pending[:args.keep]}
    unflag_pending_old = {uid for _, uid in pending[args.keep:]}
    unflag_total = resolved_uids | unflag_pending_old

    print(f"\nResolved (any reply in Sent):         {len(resolved_uids)}")
    print(f"Pending total:                        {len(pending)}")
    print(f"Keep (top {args.keep} most recent pending): {len(keep_set)}")
    print(f"Unflag pending (older than top {args.keep}):{len(unflag_pending_old)}")
    print(f"Unflag total:                         {len(unflag_total)}")

    if keep_set and pending:
        oldest_kept_ts = min(ts for ts, uid in pending[:args.keep])
        if oldest_kept_ts:
            print(f"Oldest kept star dated:               "
                  f"{datetime.fromtimestamp(oldest_kept_ts).strftime('%Y-%m-%d %H:%M')}")

    if not args.apply:
        print("\nDry-run. Re-run with --apply to unflag on IMAP.")
        c.logout()
        return 0

    # Apply
    print("\nApplying: removing \\Flagged from non-kept UIDs in INBOX...")
    c.select("INBOX")
    BATCH = 100
    unflag_list = sorted(unflag_total, key=lambda x: int(x))
    failed = 0
    for i in range(0, len(unflag_list), BATCH):
        chunk = unflag_list[i:i + BATCH]
        uid_set = ",".join(chunk).encode()
        s, _ = c.uid("store", uid_set, "-FLAGS", "(\\Flagged)")
        if s != "OK":
            failed += len(chunk)
            print(f"  Batch {i}-{i+len(chunk)} FAILED: {s}")
        else:
            print(f"  Batch {i}-{i+len(chunk)}: OK ({len(chunk)} UIDs)")

    s, d = c.uid("search", None, "FLAGGED")
    new_count = len(d[0].split()) if s == "OK" and d and d[0] else -1
    print(f"\nIMAP flagged count: {new_count} (was {len(flagged)})")
    if failed:
        print(f"Failed: {failed} UIDs")
    c.logout()
    return 0


if __name__ == "__main__":
    sys.exit(main())
