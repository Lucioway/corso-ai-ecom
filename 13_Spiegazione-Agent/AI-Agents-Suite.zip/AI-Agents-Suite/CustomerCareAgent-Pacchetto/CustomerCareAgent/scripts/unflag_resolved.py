"""
Selective star cleanup: unflag INBOX emails that already got a reply in Sent.

Detection passes (any match -> resolved):
  A. Strict threading: Sent In-Reply-To / References matches INBOX Message-ID
  B. Loose threading: same customer address + same normalized subject,
     where Sent Date >= INBOX Date (operator composed a fresh reply).

Usage:
    python scripts/unflag_resolved.py              # dry-run (default)
    python scripts/unflag_resolved.py --apply      # actually unflag
    python scripts/unflag_resolved.py --strict     # only pass A (threading)
"""
import argparse
import email.utils
import imaplib
import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import EMAIL_ADDRESS, EMAIL_PASSWORD, IMAP_SERVER, IMAP_PORT


MSG_ID_RE = re.compile(r"<([^>]+)>")
ADDR_RE = re.compile(r"<([^>]+)>|([\w.+-]+@[\w.-]+)")
SUBJ_PREFIX_RE = re.compile(r"^\s*(re|fwd?|r|aw|sv|rif|tr|антв)\s*:\s*", re.IGNORECASE)


def norm_subject(s: str) -> str:
    s = s or ""
    # Strip all leading Re:/Fwd: prefixes (possibly nested)
    prev = None
    while prev != s:
        prev = s
        s = SUBJ_PREFIX_RE.sub("", s).strip()
    return s.lower().strip()


def norm_addr(value: str) -> str:
    if not value:
        return ""
    m = ADDR_RE.search(value)
    if not m:
        return value.strip().lower()
    return (m.group(1) or m.group(2) or "").strip().lower()


def parse_date(v: str) -> float:
    try:
        dt = email.utils.parsedate_to_datetime(v)
        return dt.timestamp() if dt else 0.0
    except Exception:
        return 0.0


def fetch_headers(conn: imaplib.IMAP4_SSL, uids: list[bytes],
                  fields: str) -> dict[str, dict[str, str]]:
    """Fetch specified headers for a batch of UIDs. Returns {uid: {header: value}}."""
    result: dict[str, dict[str, str]] = {}
    BATCH = 100
    for i in range(0, len(uids), BATCH):
        chunk = uids[i:i + BATCH]
        uid_set = b",".join(chunk)
        status, data = conn.uid("fetch", uid_set, f"(BODY.PEEK[HEADER.FIELDS ({fields})])")
        if status != "OK" or not data:
            continue
        current_uid = None
        for item in data:
            if isinstance(item, tuple) and len(item) == 2:
                header_raw = item[0].decode("utf-8", errors="ignore") if isinstance(item[0], bytes) else str(item[0])
                m_uid = re.search(r"UID (\d+)", header_raw)
                if m_uid:
                    current_uid = m_uid.group(1)
                body = item[1].decode("utf-8", errors="ignore") if isinstance(item[1], bytes) else str(item[1])
                headers: dict[str, str] = {}
                # Simple header parse (multiline values unfolded)
                cur_key = None
                for line in body.split("\r\n"):
                    if line.startswith((" ", "\t")) and cur_key:
                        headers[cur_key] += " " + line.strip()
                    elif ":" in line:
                        k, v = line.split(":", 1)
                        cur_key = k.strip().lower()
                        headers[cur_key] = v.strip()
                if current_uid:
                    result[current_uid] = headers
    return result


def extract_msg_ids(value: str) -> set[str]:
    """Extract all <msg-id> tokens from a header value."""
    if not value:
        return set()
    return {m.group(1).strip() for m in MSG_ID_RE.finditer(value)}


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--apply", action="store_true", help="Actually unflag (default: dry-run)")
    ap.add_argument("--strict", action="store_true", help="Only use RFC threading (no subject/address fallback)")
    ap.add_argument("--loose", action="store_true", help="Also add Pass C: any Sent to customer after inbox date")
    args = ap.parse_args()

    conn = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT)
    conn.login(EMAIL_ADDRESS, EMAIL_PASSWORD)

    # 1. INBOX flagged UIDs + key headers
    print("Selecting INBOX...")
    conn.select("INBOX", readonly=not args.apply)
    s, d = conn.uid("search", None, "FLAGGED")
    if s != "OK" or not d or not d[0]:
        print("No flagged UIDs.")
        return 0
    flagged_uids = d[0].split()
    print(f"  {len(flagged_uids)} flagged UIDs")

    print("Fetching headers from flagged inbox mails...")
    inbox_hdrs = fetch_headers(conn, flagged_uids, "MESSAGE-ID SUBJECT FROM DATE")
    # map: msg_id -> uid ; (addr, norm_subject) -> [(uid, date_ts), ...]
    msgid_to_uid: dict[str, str] = {}
    addr_subj_to_uids: dict[tuple[str, str], list[tuple[str, float]]] = {}
    missing_msgid = 0
    for uid_str, h in inbox_hdrs.items():
        mid_ids = extract_msg_ids(h.get("message-id", ""))
        if not mid_ids:
            missing_msgid += 1
        for i in mid_ids:
            msgid_to_uid[i] = uid_str
        addr = norm_addr(h.get("from", ""))
        subj = norm_subject(h.get("subject", ""))
        ts = parse_date(h.get("date", ""))
        if addr and subj:
            addr_subj_to_uids.setdefault((addr, subj), []).append((uid_str, ts))
    print(f"  {len(msgid_to_uid)} Message-IDs ({missing_msgid} missing) | "
          f"{len(addr_subj_to_uids)} (from, subject) keys")

    # 2. Sent: threading refs + (to, subject, date)
    print("Selecting INBOX.Sent...")
    s, d = conn.select("INBOX.Sent", readonly=True)
    if s != "OK":
        print("Cannot select INBOX.Sent")
        return 1
    s, d = conn.uid("search", None, "ALL")
    if s != "OK" or not d or not d[0]:
        print("Sent empty.")
        return 0
    sent_uids = d[0].split()
    print(f"  {len(sent_uids)} sent UIDs")

    print("Fetching headers from Sent...")
    sent_hdrs = fetch_headers(conn, sent_uids, "IN-REPLY-TO REFERENCES TO SUBJECT DATE")
    replied_msgids: set[str] = set()
    # (to_addr, norm_subject) -> max date_ts
    sent_addr_subj: dict[tuple[str, str], float] = {}
    # to_addr -> max date_ts  (for Pass C)
    sent_addr_max: dict[str, float] = {}
    for h in sent_hdrs.values():
        replied_msgids |= extract_msg_ids(h.get("in-reply-to", ""))
        replied_msgids |= extract_msg_ids(h.get("references", ""))
        to_addr = norm_addr(h.get("to", ""))
        subj = norm_subject(h.get("subject", ""))
        ts = parse_date(h.get("date", ""))
        if to_addr and subj:
            key = (to_addr, subj)
            if ts > sent_addr_subj.get(key, 0.0):
                sent_addr_subj[key] = ts
        if to_addr:
            if ts > sent_addr_max.get(to_addr, 0.0):
                sent_addr_max[to_addr] = ts
    print(f"  {len(replied_msgids)} threaded refs | {len(sent_addr_subj)} (to, subject) keys | "
          f"{len(sent_addr_max)} distinct recipients")

    # 3. Pass A — RFC threading
    resolved_a = {uid for mid, uid in msgid_to_uid.items() if mid in replied_msgids}
    print(f"\nPass A (RFC threading):     {len(resolved_a)} resolved")

    # 4. Pass B — same (customer, subject), Sent Date >= INBOX Date
    resolved_b: set[str] = set()
    if not args.strict:
        for (addr, subj), inbox_list in addr_subj_to_uids.items():
            sent_ts = sent_addr_subj.get((addr, subj))
            if sent_ts is None:
                continue
            for uid_str, inbox_ts in inbox_list:
                # Allow small clock skew (60s)
                if sent_ts + 60 >= inbox_ts:
                    resolved_b.add(uid_str)
        resolved_b -= resolved_a
        print(f"Pass B (addr+subject):      {len(resolved_b)} resolved")

    # 5. Pass C — any Sent to the customer with date >= inbox date
    resolved_c: set[str] = set()
    if args.loose:
        for uid_str, h in inbox_hdrs.items():
            if uid_str in resolved_a or uid_str in resolved_b:
                continue
            addr = norm_addr(h.get("from", ""))
            if not addr:
                continue
            inbox_ts = parse_date(h.get("date", ""))
            sent_ts = sent_addr_max.get(addr)
            if sent_ts is not None and sent_ts + 60 >= inbox_ts:
                resolved_c.add(uid_str)
        print(f"Pass C (any reply to addr): {len(resolved_c)} resolved")

    resolved_uids = resolved_a | resolved_b | resolved_c
    print(f"\nRESOLVED (total):              {len(resolved_uids)}")
    print(f"UNRESOLVED (no reply yet):     {len(flagged_uids) - len(resolved_uids)}")

    if not args.apply:
        print("\nDry-run. Sample of 10 that would be unflagged:")
        for uid in list(resolved_uids)[:10]:
            print(f"  uid={uid}")
        print("\nRe-run with --apply to unflag these on IMAP.")
        return 0

    # 4. Apply: unflag on INBOX
    print("\nApplying: removing \\Flagged from resolved UIDs in INBOX...")
    conn.select("INBOX")  # writable
    BATCH = 100
    resolved_list = sorted(resolved_uids, key=lambda x: int(x))
    failed = 0
    for i in range(0, len(resolved_list), BATCH):
        chunk = resolved_list[i:i + BATCH]
        uid_set = ",".join(chunk).encode()
        s, _ = conn.uid("store", uid_set, "-FLAGS", "(\\Flagged)")
        if s != "OK":
            failed += len(chunk)
            print(f"  Batch {i}-{i+len(chunk)} FAILED: {s}")
        else:
            print(f"  Batch {i}-{i+len(chunk)}: OK ({len(chunk)} UIDs)")

    # Verify
    s, d = conn.uid("search", None, "FLAGGED")
    new_count = len(d[0].split()) if s == "OK" and d and d[0] else -1
    print(f"\nIMAP flagged count now: {new_count} (was {len(flagged_uids)})")
    print(f"Unflagged: {len(flagged_uids) - new_count if new_count >= 0 else '?'}")
    if failed:
        print(f"Failed batches: {failed} UIDs")

    conn.logout()
    return 0


if __name__ == "__main__":
    sys.exit(main())
