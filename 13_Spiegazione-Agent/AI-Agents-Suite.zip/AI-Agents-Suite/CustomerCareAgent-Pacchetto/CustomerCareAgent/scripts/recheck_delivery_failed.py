"""One-shot recheck of a "Delivery Failed" batch against ParcelPanel real status.

Usage:
    python scripts/recheck_delivery_failed.py <input.xls> [output.xlsx]

Input  (.xls): the carrier/3PL "Delivery Failed Order Details" export.
Output (.xlsx): a colour-coded recheck workbook (defaults next to the input).

Both paths are arguments — nothing is hardcoded.
"""
from __future__ import annotations

import sys
import time
from pathlib import Path

import xlrd
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from connectors.parcelpanel_connector import ParcelPanelClient
from config import ORDER_ID_PREFIX

# Resolved at runtime from CLI args (see main()).
SRC: Path = Path()
DST: Path = Path()


def load_input() -> list[dict]:
    book = xlrd.open_workbook(str(SRC))
    sh = book.sheet_by_index(0)
    rows = []
    for r in range(1, sh.nrows):
        rows.append({
            "tracking": str(sh.cell_value(r, 0)).strip(),
            "local_tracking": str(sh.cell_value(r, 1)).strip(),
            "order_number": str(sh.cell_value(r, 2)).strip(),
            "reported_status": str(sh.cell_value(r, 3)).strip(),
            "reported_detail": str(sh.cell_value(r, 4)).strip(),
        })
    return rows


def classify(pp_status: str, delivery_date: str | None) -> str:
    s = (pp_status or "").upper()
    if s == "DELIVERED" or delivery_date:
        return "RESOLVED_DELIVERED"
    if s in ("IN_TRANSIT", "OUT_FOR_DELIVERY"):
        return "RECOVERED_IN_TRANSIT"
    if s in ("AVAILABLE_FOR_PICKUP", "READY_FOR_PICKUP"):
        return "AWAITING_CUSTOMER_PICKUP"
    if s in ("FAILED_ATTEMPT", "EXCEPTION"):
        return "STILL_PROBLEMATIC"
    if s in ("RETURNED",):
        return "RETURNED_TO_SENDER"
    if s in ("PENDING", "INFO_RECEIVED"):
        return "NO_TRACKING_DATA"
    if s in ("EXPIRED",):
        return "EXPIRED_TRACKING"
    return f"UNKNOWN ({pp_status or 'empty'})"


def fetch_row(pp: ParcelPanelClient, row: dict) -> dict:
    on = row["order_number"]
    # Pre-filter: order numbers not matching our brand prefix (supplier/shipper internal IDs)
    if ORDER_ID_PREFIX and not on.upper().startswith(ORDER_ID_PREFIX.upper()):
        return {
            **row,
            "pp_status": "", "pp_status_label": "", "pp_substatus": "",
            "carrier": "", "last_mile_carrier": "", "delivery_date": "",
            "pickup_date": "", "fulfillment_date": "", "transit_days": "",
            "latest_checkpoint": "", "latest_checkpoint_time": "",
            "customer_name": "", "customer_email": "", "country": "", "city": "",
            "verdict": "NOT_OUR_ORDER",
            "note": f"Order ID does not start with '{ORDER_ID_PREFIX}' — not in our Shopify store",
        }
    res = pp.get_tracking(order_number=on)
    out = {
        **row,
        "pp_status": "",
        "pp_status_label": "",
        "pp_substatus": "",
        "carrier": "",
        "last_mile_carrier": "",
        "delivery_date": "",
        "pickup_date": "",
        "fulfillment_date": "",
        "transit_days": "",
        "latest_checkpoint": "",
        "latest_checkpoint_time": "",
        "customer_name": "",
        "customer_email": "",
        "country": "",
        "city": "",
        "verdict": "",
        "note": "",
    }
    if not res:
        out["verdict"] = "API_ERROR"
        return out
    data = res.get("data") or res
    order = data.get("order") or data
    customer = order.get("customer") or {}
    ship_addr = order.get("shipping_address") or {}
    out["customer_name"] = customer.get("name") or ""
    out["customer_email"] = customer.get("email") or ""
    out["country"] = ship_addr.get("country") or ""
    out["city"] = ship_addr.get("city") or ""

    shipments = order.get("shipments") or []
    if not shipments:
        out["verdict"] = "NO_SHIPMENT_ON_PP"
        return out

    # Pick shipment matching input tracking if possible, else first
    target = None
    for sh in shipments:
        if sh.get("tracking_number") == row["tracking"]:
            target = sh
            break
    if not target:
        target = shipments[0]

    out["pp_status"] = target.get("status", "")
    out["pp_status_label"] = target.get("status_label", "")
    out["pp_substatus"] = target.get("substatus_label", "")
    carrier = target.get("carrier") or {}
    out["carrier"] = carrier.get("name", "") if isinstance(carrier, dict) else str(carrier)
    lm = target.get("last_mile") or {}
    out["last_mile_carrier"] = lm.get("carrier_name", "") if isinstance(lm, dict) else ""
    out["delivery_date"] = target.get("delivery_date") or ""
    out["pickup_date"] = target.get("pickup_date") or ""
    out["fulfillment_date"] = target.get("fulfillment_date") or ""
    out["transit_days"] = target.get("transit_time") or ""

    # Latest checkpoint
    cps = target.get("checkpoints") or []
    if cps:
        last = cps[-1]
        out["latest_checkpoint"] = last.get("message", "")
        out["latest_checkpoint_time"] = last.get("checkpoint_time", "")

    out["verdict"] = classify(out["pp_status"], out["delivery_date"])
    return out


VERDICT_COLOR = {
    "RESOLVED_DELIVERED":       "C6EFCE",  # green
    "RECOVERED_IN_TRANSIT":     "DDEBF7",  # light blue
    "AWAITING_CUSTOMER_PICKUP": "BDD7EE",  # darker blue
    "STILL_PROBLEMATIC":        "FFC7CE",  # red
    "RETURNED_TO_SENDER":       "FCE4D6",  # orange
    "NO_TRACKING_DATA":         "FFF2CC",  # yellow
    "EXPIRED_TRACKING":         "D9D9D9",  # gray
    "API_ERROR":                "FFC7CE",
    "NO_SHIPMENT_ON_PP":        "FFF2CC",
    "NOT_OUR_ORDER":            "D9D9D9",
}


def write_output(rows: list[dict]) -> None:
    wb = Workbook()
    ws = wb.active
    ws.title = "Recheck"

    cols = [
        ("order_number", "Order #", 12),
        ("verdict", "Verdict", 24),
        ("pp_status_label", "PP Status", 18),
        ("pp_substatus", "Substatus", 22),
        ("delivery_date", "Delivery Date", 20),
        ("customer_name", "Customer", 22),
        ("customer_email", "Email", 28),
        ("country", "Country", 12),
        ("city", "City", 16),
        ("carrier", "Carrier", 14),
        ("last_mile_carrier", "Last Mile", 14),
        ("tracking", "Tracking #", 22),
        ("local_tracking", "Local Tracking", 20),
        ("latest_checkpoint", "Latest Checkpoint", 50),
        ("latest_checkpoint_time", "Checkpoint Time", 20),
        ("transit_days", "Transit d", 10),
        ("pickup_date", "Pickup", 20),
        ("fulfillment_date", "Fulfilled", 20),
        ("reported_status", "Reported", 16),
    ]

    header_font = Font(bold=True, color="FFFFFF")
    header_fill = PatternFill("solid", fgColor="305496")
    for i, (_, label, width) in enumerate(cols, 1):
        c = ws.cell(row=1, column=i, value=label)
        c.font = header_font
        c.fill = header_fill
        c.alignment = Alignment(horizontal="center")
        ws.column_dimensions[get_column_letter(i)].width = width

    for r_idx, row in enumerate(rows, start=2):
        verdict = row.get("verdict", "")
        fill_hex = VERDICT_COLOR.get(verdict)
        fill = PatternFill("solid", fgColor=fill_hex) if fill_hex else None
        for c_idx, (key, _, _) in enumerate(cols, 1):
            c = ws.cell(row=r_idx, column=c_idx, value=row.get(key, ""))
            if fill:
                c.fill = fill
            c.alignment = Alignment(vertical="top", wrap_text=(key == "latest_checkpoint"))

    ws.freeze_panes = "A2"
    ws.auto_filter.ref = ws.dimensions

    # Summary sheet
    summary = wb.create_sheet("Summary")
    counts: dict[str, int] = {}
    for row in rows:
        counts[row["verdict"]] = counts.get(row["verdict"], 0) + 1
    summary.append(["Verdict", "Count", "% of total"])
    for c in summary[1]:
        c.font = Font(bold=True)
    total = len(rows) or 1
    for verdict, count in sorted(counts.items(), key=lambda x: -x[1]):
        summary.append([verdict, count, f"{count/total*100:.1f}%"])
        fill_hex = VERDICT_COLOR.get(verdict)
        if fill_hex:
            for c in summary[summary.max_row]:
                c.fill = PatternFill("solid", fgColor=fill_hex)
    summary.append([])
    summary.append(["TOTAL", total, "100.0%"])
    for col in range(1, 4):
        summary.column_dimensions[get_column_letter(col)].width = 26

    wb.save(str(DST))


def main() -> None:
    global SRC, DST
    if len(sys.argv) < 2:
        print(__doc__)
        print("error: missing input .xls path", file=sys.stderr)
        sys.exit(1)
    SRC = Path(sys.argv[1]).expanduser()
    if len(sys.argv) >= 3:
        DST = Path(sys.argv[2]).expanduser()
    else:
        DST = SRC.with_name(SRC.stem + "_recheck.xlsx")
    if not SRC.exists():
        print(f"error: input not found: {SRC}", file=sys.stderr)
        sys.exit(1)

    rows_in = load_input()
    print(f"Input rows: {len(rows_in)}")
    pp = ParcelPanelClient()
    out_rows = []
    t0 = time.time()
    for i, row in enumerate(rows_in, 1):
        r = fetch_row(pp, row)
        out_rows.append(r)
        if i % 10 == 0 or i == len(rows_in):
            elapsed = time.time() - t0
            print(f"[{i}/{len(rows_in)}] {r['order_number']} -> {r['verdict']}  ({elapsed:.1f}s)")
    write_output(out_rows)
    print(f"Written: {DST}")

    # Quick summary to stdout
    from collections import Counter
    c = Counter(r["verdict"] for r in out_rows)
    print("\n=== SUMMARY ===")
    for k, v in c.most_common():
        print(f"  {k}: {v}")


if __name__ == "__main__":
    main()
