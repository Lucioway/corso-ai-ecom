"""
List the most recent starred INBOX emails that still have no reply in Sent.
These are the likely "pending action" stars the operator cares about.

Usage:
    python scripts/list_pending_stars.py            # top 60 pending
    python scripts/list_pending_stars.py --limit 100
"""
import argparse
import imaplib
import re
import sys
from email.utils import parsedate_to_datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
from config import EMAIL_ADDRESS, EMAIL_PASSWORD, IMAP_SERVER, IMAP_PORT
from scripts.unflag_resolved import (
    fetch_headers, extract_msg_ids, norm_addr, norm_subject, parse_date,
)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--limit", type=int, default=60, help="How many most-recent pending to show")
    args = ap.parse_args()

    c = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT)
    c.login(EMAIL_ADDRESS, EMAIL_PASSWORD)

    # Gather inbox flagged
    c.select("INBOX", readonly=True)
    s, d = c.uid("search", None, "FLAGGED")
    flagged = d[0].split() if s == "OK" and d and d[0] else []
    inbox_hdrs = fetch_headers(c, flagged, "MESSAGE-ID SUBJECT FROM DATE")

    # Sent refs
    c.select("INBOX.Sent", readonly=True)
    s, d = c.uid("search", None, "ALL")
    sent_uids = d[0].split() if s == "OK" and d and d[0] else []
    sent_hdrs = fetch_headers(c, sent_uids, "IN-REPLY-TO REFERENCES TO SUBJECT DATE")

    replied_msgids: set[str] = set()
    sent_addr_subj: dict[tuple[str, str], float] = {}
    sent_addr_max: dict[str, float] = {}
    for h in sent_hdrs.values():
        replied_msgids |= extract_msg_ids(h.get("in-reply-to", ""))
        replied_msgids |= extract_msg_ids(h.get("references", ""))
        to_addr = norm_addr(h.get("to", ""))
        subj = norm_subject(h.get("subject", ""))
        ts = parse_date(h.get("date", ""))
        if to_addr and subj:
            key = (to_addr, subj)
            if ts > sent_addr_subj.get(key, 0.0):
                sent_addr_subj[key] = ts
        if to_addr and ts > sent_addr_max.get(to_addr, 0.0):
            sent_addr_max[to_addr] = ts

    # Build list of pending
    pending = []
    for uid_str, h in inbox_hdrs.items():
        mid = next(iter(extract_msg_ids(h.get("message-id", ""))), None)
        addr = norm_addr(h.get("from", ""))
        subj_raw = h.get("subject", "")
        subj_n = norm_subject(subj_raw)
        ts = parse_date(h.get("date", ""))

        replied = False
        if mid and mid in replied_msgids:
            replied = True
        elif addr and subj_n and sent_addr_subj.get((addr, subj_n), 0.0) + 60 >= ts:
            replied = True
        elif addr and sent_addr_max.get(addr, 0.0) + 60 >= ts:
            replied = True
        if replied:
            continue
        pending.append((ts, uid_str, addr, subj_raw[:70]))

    pending.sort(reverse=True)
    print(f"\n{len(pending)} pending stars (no reply in Sent). Top {args.limit} most recent:\n")
    print(f"{'Date':<20} {'UID':<6} {'From':<40} Subject")
    print("-" * 120)
    for ts, uid, addr, subj in pending[:args.limit]:
        from datetime import datetime
        dt = datetime.fromtimestamp(ts).strftime("%Y-%m-%d %H:%M") if ts else "?"
        print(f"{dt:<20} {uid:<6} {addr[:40]:<40} {subj}")

    c.logout()
    return 0


if __name__ == "__main__":
    sys.exit(main())
