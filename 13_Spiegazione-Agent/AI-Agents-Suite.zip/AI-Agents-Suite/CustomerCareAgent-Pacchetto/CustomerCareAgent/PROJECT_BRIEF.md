# PROJECT BRIEF — CustomerCareAgent

## Visione
Automatizzare il customer care per `${SUPPORT_EMAIL}`: leggere le email dei clienti, analizzarle con Claude AI, cercare ordini e tracking su Shopify/ParcelPanel, e preparare bozze di risposta intelligenti. L'agent NON invia mai automaticamente — salva tutto in bozze per revisione del team.

## Requisiti
1. **Email IMAP**: Lettura email da `${SUPPORT_EMAIL}` via Hostinger IMAP
2. **Email SMTP/IMAP APPEND**: Salvataggio bozze risposte nella cartella Drafts
3. **Shopify API**: Lookup ordini, clienti, prodotti, fulfillment per contesto
4. **Claude API**: Ragionamento sulle risposte basato su policy, template e contesto ordine
5. **ParcelPanel API**: Tracking spedizioni per ordini in transito
6. **Screenshot tracking**: Cattura screenshot delle pagine di tracking
7. **Knowledge base**: Policy store, brand context, template risposte come riferimento
8. **Filtro spam**: Escludere richieste spam, partnership, collaborazioni
9. **Scheduling**: Polling ogni 10 minuti

## Vincoli
- MAI inviare email automaticamente — solo bozze
- Documentazione in italiano
- Credenziali via .env (riusa quelle esistenti dagli altri agent)
- Test iniziale con 10 email
- Usato dal team (non solo founder)

## Criteri di Successo (Phase 1)
- [x] Tutte le 8 connessioni verificate con `--check`
- [x] Fetch di 10 email con `--dry-run`
- [x] Ogni connettore ha `test_connection() -> bool`

## Milestone
- **Phase 1**: Connessioni e setup (questo milestone)
- **Phase 2**: Logica di classificazione, lookup e draft risposte (da definire)
