"""
Screenshot di pagine tracking via Selenium Chrome headless.
Cattura screenshot PNG delle pagine di tracking pubbliche.
"""

import logging
import time
from datetime import datetime
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import CHROME_BIN, CHROMEDRIVER_PATH, SCREENSHOTS_DIR

logger = logging.getLogger(__name__)


class TrackingScreenshotter:
    """Cattura screenshot di pagine tracking via Chrome headless."""

    def __init__(self) -> None:
        self.driver = None

    def _get_driver(self):
        """Crea driver Chrome headless se non esiste."""
        if self.driver:
            return self.driver

        from selenium import webdriver
        from selenium.webdriver.chrome.service import Service
        from selenium.webdriver.chrome.options import Options

        options = Options()
        options.binary_location = CHROME_BIN
        options.add_argument("--headless=new")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--window-size=1920,1080")
        options.add_argument("--disable-gpu")
        options.add_argument("--lang=it-IT")

        service = Service(executable_path=CHROMEDRIVER_PATH) if CHROMEDRIVER_PATH else Service()
        self.driver = webdriver.Chrome(service=service, options=options)
        self.driver.set_page_load_timeout(30)
        return self.driver

    def test_browser(self) -> tuple[bool, str]:
        """
        Testa che Chrome headless funzioni.
        Ritorna (success, messaggio).
        """
        try:
            driver = self._get_driver()
            driver.get("about:blank")
            version = driver.capabilities.get("browserVersion", "?")
            self.close()
            return True, f"Chrome headless funzionante (v{version})"
        except FileNotFoundError:
            return False, f"Chrome o chromedriver non trovato (chrome={CHROME_BIN}, driver={CHROMEDRIVER_PATH})"
        except Exception as e:
            self.close()
            return False, f"Chrome headless fallito: {e}"

    def take_screenshot(self, url: str, filename: str | None = None) -> Path | None:
        """
        Naviga a un URL e cattura screenshot.
        Ritorna il Path del file PNG o None se fallisce.
        """
        try:
            driver = self._get_driver()
            logger.info("Screenshot: navigando a %s", url)
            driver.get(url)
            time.sleep(5)  # Attendi caricamento pagina tracking

            if not filename:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                filename = f"tracking_{timestamp}.png"

            SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)
            filepath = SCREENSHOTS_DIR / filename
            driver.save_screenshot(str(filepath))
            logger.info("Screenshot salvato: %s", filepath)
            return filepath

        except Exception as e:
            logger.error("Screenshot fallito per %s: %s", url, e)
            return None

    def close(self) -> None:
        """Chiudi il browser."""
        if self.driver:
            try:
                self.driver.quit()
            except Exception:
                pass
            self.driver = None
