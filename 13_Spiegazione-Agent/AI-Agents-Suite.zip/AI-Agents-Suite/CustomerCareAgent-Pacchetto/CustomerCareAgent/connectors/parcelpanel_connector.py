"""
Connettore ParcelPanel (ParcelWILL) API v2.
Tracking spedizioni per ordini Shopify.
"""

import logging
import time

import requests

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import PARCELPANEL_API_KEY, PARCELPANEL_BASE_URL

logger = logging.getLogger(__name__)

# Rate limit: 120 req/min = 1 ogni 0.5s
_MIN_REQUEST_INTERVAL = 0.5


class ParcelPanelClient:
    """Client per ParcelPanel API v2."""

    def __init__(self) -> None:
        self.base_url = PARCELPANEL_BASE_URL
        self.headers = {
            "x-parcelpanel-api-key": PARCELPANEL_API_KEY,
            "Content-Type": "application/json",
        }
        self._last_request_time: float = 0

    def _throttle(self) -> None:
        elapsed = time.time() - self._last_request_time
        if elapsed < _MIN_REQUEST_INTERVAL:
            time.sleep(_MIN_REQUEST_INTERVAL - elapsed)

    def _get(self, endpoint: str, params: dict | None = None) -> dict | None:
        """GET request con rate limiting."""
        self._throttle()
        url = f"{self.base_url}{endpoint}"
        try:
            resp = requests.get(url, headers=self.headers, params=params, timeout=15)
            self._last_request_time = time.time()
            if resp.ok:
                return resp.json()
            logger.error("ParcelPanel %s errore %d: %s", endpoint, resp.status_code, resp.text[:200])
            return None
        except requests.RequestException as e:
            logger.error("ParcelPanel request fallita: %s", e)
            return None

    def test_connection(self) -> tuple[bool, str]:
        """
        Testa la connessione ParcelPanel API.
        Ritorna (success, messaggio).
        """
        if not PARCELPANEL_API_KEY:
            return False, "PARCELPANEL_API_KEY non configurata — genera da Shopify Admin > Apps > ParcelPanel > Settings > API & Webhook"

        # Prova un endpoint con un ordine fittizio — ci aspettiamo 200 con data vuota o 404
        try:
            self._throttle()
            url = f"{self.base_url}/api/v2/tracking/order"
            resp = requests.get(
                url,
                headers=self.headers,
                params={"order_number": "__test__"},
                timeout=15,
            )
            self._last_request_time = time.time()

            # Se riceviamo 401/403 l'API key e` sbagliata
            if resp.status_code in (401, 403):
                return False, f"API key non valida (HTTP {resp.status_code})"

            # Qualsiasi altro codice (200, 404, 422) = API raggiungibile
            return True, f"Connesso — API v2 raggiungibile (HTTP {resp.status_code})"

        except requests.RequestException as e:
            return False, f"Connessione fallita: {e}"

    def get_tracking(self, order_number: str | None = None, order_id: str | None = None) -> dict | None:
        """
        Fetch tracking info per un ordine.
        Usa order_number (es. '#1234') o order_id (Shopify ID numerico).
        """
        params: dict[str, str] = {}
        if order_number:
            params["order_number"] = order_number
        elif order_id:
            params["order_id"] = order_id
        else:
            logger.error("Serve order_number o order_id")
            return None

        return self._get("/api/v2/tracking/order", params=params)

    def get_tracking_status(self, order_number: str) -> list[dict]:
        """
        Ritorna lista di shipment con status e checkpoints per un ordine.
        Formato semplificato per il customer care.
        """
        data = self.get_tracking(order_number=order_number)
        if not data:
            return []

        shipments = []
        for shipment in data.get("data", {}).get("shipments", []):
            checkpoints = shipment.get("checkpoints", [])
            latest = checkpoints[-1] if checkpoints else {}
            shipments.append({
                "tracking_number": shipment.get("tracking_number", ""),
                "carrier": shipment.get("carrier", ""),
                "status": shipment.get("status", ""),
                "latest_checkpoint": latest.get("message", ""),
                "latest_time": latest.get("checkpoint_time", ""),
                "tracking_link": shipment.get("tracking_link", ""),
            })

        return shipments
