"""
Connettore Shopify REST API.
Lookup ordini, clienti, prodotti e fulfillment per contesto customer care.
"""

import logging
import time
from typing import Any

import requests

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import SHOPIFY_STORE_URL, SHOPIFY_API_TOKEN, SHOPIFY_API_VERSION

logger = logging.getLogger(__name__)

# Rate limiting: Shopify consente 2 req/sec (bucket leaky)
_MIN_REQUEST_INTERVAL = 0.5  # secondi tra richieste


class ShopifyClient:
    """Client per Shopify Admin REST API."""

    def __init__(self) -> None:
        self.base_url = f"{SHOPIFY_STORE_URL}/admin/api/{SHOPIFY_API_VERSION}"
        self.headers = {
            "X-Shopify-Access-Token": SHOPIFY_API_TOKEN,
            "Content-Type": "application/json",
        }
        self._last_request_time: float = 0

    def _throttle(self) -> None:
        """Rate limiting semplice."""
        elapsed = time.time() - self._last_request_time
        if elapsed < _MIN_REQUEST_INTERVAL:
            time.sleep(_MIN_REQUEST_INTERVAL - elapsed)

    def _get(self, endpoint: str, params: dict | None = None) -> dict | None:
        """GET request con rate limiting e error handling."""
        self._throttle()
        url = f"{self.base_url}/{endpoint}"
        try:
            resp = requests.get(url, headers=self.headers, params=params, timeout=15)
            self._last_request_time = time.time()
            if resp.ok:
                return resp.json()
            logger.error("Shopify %s errore %d: %s", endpoint, resp.status_code, resp.text[:200])
            return None
        except requests.RequestException as e:
            logger.error("Shopify request fallita: %s", e)
            return None

    def _get_all(self, endpoint: str, params: dict | None = None, key: str = "") -> list[dict]:
        """GET con paginazione via Link header."""
        all_items: list[dict] = []
        url = f"{self.base_url}/{endpoint}"
        current_params = params

        while url:
            self._throttle()
            try:
                resp = requests.get(url, headers=self.headers, params=current_params, timeout=15)
                self._last_request_time = time.time()
                if not resp.ok:
                    logger.error("Shopify paginazione errore %d: %s", resp.status_code, resp.text[:200])
                    break

                data = resp.json()
                if key and key in data:
                    all_items.extend(data[key])
                else:
                    # Prendi il primo array trovato
                    for v in data.values():
                        if isinstance(v, list):
                            all_items.extend(v)
                            break

                # Pagina successiva
                url = self._get_next_page(resp.headers.get("Link", ""))
                current_params = None  # params solo per prima richiesta

            except requests.RequestException as e:
                logger.error("Shopify paginazione fallita: %s", e)
                break

        return all_items

    @staticmethod
    def _get_next_page(link_header: str) -> str | None:
        """Estrae URL della pagina successiva dal Link header."""
        if not link_header:
            return None
        for part in link_header.split(","):
            if 'rel="next"' in part:
                return part.split(";")[0].strip().strip("<>")
        return None

    # ── Test connessione ──

    def test_connection(self) -> tuple[bool, str]:
        """Verifica connessione Shopify API. Ritorna (success, messaggio)."""
        data = self._get("shop.json")
        if data and "shop" in data:
            name = data["shop"].get("name", "?")
            return True, f"Connesso — Store: {name}"
        return False, "Connessione Shopify fallita"

    # ── Ordini ──

    def get_order(self, order_id: str) -> dict | None:
        """Fetch un singolo ordine per ID."""
        data = self._get(f"orders/{order_id}.json")
        return data.get("order") if data else None

    def search_orders_by_email(self, customer_email: str, limit: int = 10) -> list[dict]:
        """Cerca ordini per email cliente via GraphQL Admin API.

        REST `orders.json?email=` non supporta filtro — ritorna tutto lo store.
        GraphQL `orders(query: "email:X")` filtra server-side e non richiede
        `read_customers` scope (per i campi ordine, non per customer object).
        """
        return self._graphql_orders_by_query(f"email:{customer_email}", limit=limit)

    def _graphql_orders_by_query(self, query: str, limit: int = 10) -> list[dict]:
        """Esegue query GraphQL orders + converte nella shape REST usata a valle."""
        self._throttle()
        url = f"{self.base_url}/graphql.json"
        gql = """
        query($q: String!, $n: Int!) {
          orders(first: $n, query: $q, sortKey: CREATED_AT, reverse: true) {
            edges { node {
              id name email createdAt
              displayFulfillmentStatus displayFinancialStatus
              paymentGatewayNames
              totalPriceSet { shopMoney { amount currencyCode } }
              shippingAddress { firstName lastName city country countryCode address1 zip }
              lineItems(first: 20) { edges { node { title variantTitle quantity } } }
            } }
          }
        }
        """
        try:
            resp = requests.post(
                url,
                headers={**self.headers, "Content-Type": "application/json"},
                json={"query": gql, "variables": {"q": query, "n": min(max(limit, 1), 100)}},
                timeout=15,
            )
            self._last_request_time = time.time()
            if not resp.ok:
                logger.error("Shopify GraphQL errore %d: %s", resp.status_code, resp.text[:200])
                return []
            payload = resp.json() or {}
            edges = ((payload.get("data") or {}).get("orders") or {}).get("edges") or []
            orders: list[dict] = []
            for e in edges:
                n = e.get("node") or {}
                price = (n.get("totalPriceSet") or {}).get("shopMoney") or {}
                addr = n.get("shippingAddress") or {}
                line_edges = ((n.get("lineItems") or {}).get("edges") or [])
                line_items = []
                for le in line_edges:
                    ln = le.get("node") or {}
                    line_items.append({
                        "title": ln.get("title") or "",
                        "variant_title": ln.get("variantTitle") or "",
                        "quantity": ln.get("quantity") or 1,
                    })
                # Shopify GID → numeric ID
                gid = n.get("id") or ""
                numeric_id = gid.rsplit("/", 1)[-1] if gid else ""
                orders.append({
                    "id": numeric_id,
                    "admin_graphql_api_id": gid,
                    "name": n.get("name") or "",
                    "email": n.get("email") or "",
                    "created_at": n.get("createdAt") or "",
                    "fulfillment_status": (n.get("displayFulfillmentStatus") or "").lower() or "unfulfilled",
                    "financial_status": (n.get("displayFinancialStatus") or "").lower(),
                    "payment_gateway_names": n.get("paymentGatewayNames") or [],
                    "total_price": price.get("amount") or "0",
                    "currency": price.get("currencyCode") or "",
                    "customer": {"email": n.get("email") or "",
                                 "first_name": addr.get("firstName") or "",
                                 "last_name": addr.get("lastName") or ""},
                    "shipping_address": {
                        "first_name": addr.get("firstName") or "",
                        "last_name": addr.get("lastName") or "",
                        "city": addr.get("city") or "",
                        "country": addr.get("country") or "",
                        "country_code": addr.get("countryCode") or "",
                        "address1": addr.get("address1") or "",
                        "zip": addr.get("zip") or "",
                    },
                    "line_items": line_items,
                })
            return orders
        except requests.RequestException as e:
            logger.error("Shopify GraphQL fallito: %s", e)
            return []

    def search_orders_by_name(self, order_name: str) -> list[dict]:
        """Cerca ordine per nome (es. '#1234')."""
        name = order_name if order_name.startswith("#") else f"#{order_name}"
        return self._get_all(
            "orders.json",
            params={"name": name, "status": "any"},
            key="orders",
        )

    # ── Clienti ──

    def search_customers(self, email_addr: str) -> list[dict]:
        """Cerca clienti per email. Ritorna [] silenziosamente se manca lo scope."""
        try:
            self._throttle()
            url = f"{self.base_url}/customers/search.json"
            resp = requests.get(url, headers=self.headers, params={"query": f"email:{email_addr}"}, timeout=15)
            self._last_request_time = time.time()
            if resp.status_code == 403:
                # Manca scope read_customers, skip silently
                return []
            if resp.ok:
                return resp.json().get("customers", [])
            return []
        except Exception:
            return []

    # ── Prodotti ──

    def get_products(self, limit: int = 250) -> list[dict]:
        """Fetch tutti i prodotti con varianti."""
        return self._get_all("products.json", params={"limit": limit}, key="products")

    # ── Fulfillment / Tracking ──

    def get_fulfillments(self, order_id: str) -> list[dict]:
        """Fetch fulfillment (tracking) per un ordine."""
        data = self._get(f"orders/{order_id}/fulfillments.json")
        return data.get("fulfillments", []) if data else []

    def get_tracking_info(self, order_id: str) -> list[dict[str, str]]:
        """
        Estrae info tracking da fulfillment.
        Ritorna lista di {tracking_number, tracking_url, tracking_company}.
        """
        fulfillments = self.get_fulfillments(order_id)
        tracking: list[dict[str, str]] = []
        for f in fulfillments:
            if f.get("tracking_number"):
                tracking.append({
                    "tracking_number": f.get("tracking_number", ""),
                    "tracking_url": f.get("tracking_url", ""),
                    "tracking_company": f.get("tracking_company", ""),
                    "status": f.get("status", ""),
                })
        return tracking
