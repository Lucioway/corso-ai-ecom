"""
Connettore Email — IMAP (lettura) + IMAP APPEND (salvataggio bozze).
Reads email from the configured SUPPORT_EMAIL via IMAP_SERVER (see .env).
Saves drafts in the Drafts folder via IMAP APPEND (never sends directly).
"""

import email
import email.message
import imaplib
import logging
import smtplib
from dataclasses import dataclass, field
from datetime import datetime
from email.header import decode_header
from email.mime.text import MIMEText
from email.utils import formatdate, make_msgid

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import (
    EMAIL_ADDRESS, EMAIL_PASSWORD, IMAP_SERVER, IMAP_PORT,
    SMTP_SERVER, SMTP_PORT, DRAFTS_FOLDER_NAMES,
)

logger = logging.getLogger(__name__)


@dataclass
class EmailMessage:
    """Una email estratta dalla casella."""
    from_addr: str
    to_addr: str
    subject: str
    body: str
    date: str
    message_id: str
    in_reply_to: str = ""
    references: str = ""
    html_body: str = ""
    direction: str = "ricevuta"
    uid: str = ""


def _decode_header_value(value: str) -> str:
    """Decodifica un header email che potrebbe essere encoded."""
    if not value:
        return ""
    decoded_parts = decode_header(value)
    result = []
    for part, charset in decoded_parts:
        if isinstance(part, bytes):
            result.append(part.decode(charset or "utf-8", errors="replace"))
        else:
            result.append(part)
    return " ".join(result)


def _extract_text_body(msg: email.message.Message) -> tuple[str, str]:
    """
    Estrae corpo text/plain e text/html da un email.message.
    Ritorna (plain_body, html_body).
    """
    plain = ""
    html = ""

    if msg.is_multipart():
        for part in msg.walk():
            content_type = part.get_content_type()
            try:
                charset = part.get_content_charset() or "utf-8"
                payload = part.get_payload(decode=True)
                if payload is None:
                    continue
                text = payload.decode(charset, errors="replace")
                if content_type == "text/plain" and not plain:
                    plain = text
                elif content_type == "text/html" and not html:
                    html = text
            except Exception as e:
                logger.debug("Errore decodifica parte email: %s", e)
    else:
        try:
            charset = msg.get_content_charset() or "utf-8"
            payload = msg.get_payload(decode=True)
            if payload:
                text = payload.decode(charset, errors="replace")
                if msg.get_content_type() == "text/html":
                    html = text
                else:
                    plain = text
        except Exception as e:
            logger.debug("Errore decodifica corpo email: %s", e)

    plain = plain[:5000] if plain else ""
    html = html[:10000] if html else ""
    return plain, html


# ──────────────────────────────────────────────
# IMAP — Lettura
# ──────────────────────────────────────────────

def connect_imap() -> imaplib.IMAP4_SSL:
    """Apre connessione IMAP e fa login. Ritorna la connessione."""
    conn = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT)
    conn.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
    return conn


def test_imap_connection() -> tuple[bool, str]:
    """
    Testa la connessione IMAP.
    Ritorna (success, messaggio).
    """
    try:
        conn = connect_imap()
        status, folders = conn.list()
        conn.select("INBOX", readonly=True)
        status, msgs = conn.search(None, "ALL")
        total = len(msgs[0].split()) if msgs[0] else 0
        conn.logout()
        return True, f"Connesso a {IMAP_SERVER} — {EMAIL_ADDRESS} (INBOX: {total} messaggi)"
    except imaplib.IMAP4.error as e:
        return False, f"Login IMAP fallito: {e}"
    except Exception as e:
        return False, f"Connessione IMAP fallita: {e}"


def fetch_recent_emails(limit: int = 10) -> list[EmailMessage]:
    """
    Fetch le N email piu` recenti dalla INBOX.
    Ritorna lista di EmailMessage ordinate dalla piu` recente.
    """
    emails: list[EmailMessage] = []
    try:
        conn = connect_imap()
        conn.select("INBOX", readonly=True)

        status, msgs = conn.search(None, "ALL")
        if status != "OK" or not msgs[0]:
            conn.logout()
            return []

        all_ids = msgs[0].split()
        # Prendi gli ultimi N (piu` recenti)
        recent_ids = all_ids[-limit:] if len(all_ids) > limit else all_ids
        recent_ids.reverse()  # Piu` recente prima

        for msg_id in recent_ids:
            try:
                status, msg_data = conn.fetch(msg_id, "(RFC822)")
                if status != "OK":
                    continue

                raw = msg_data[0][1]
                msg = email.message_from_bytes(raw)
                plain, html = _extract_text_body(msg)

                emails.append(EmailMessage(
                    from_addr=_decode_header_value(msg.get("From", "")),
                    to_addr=_decode_header_value(msg.get("To", "")),
                    subject=_decode_header_value(msg.get("Subject", "(nessun oggetto)")),
                    body=plain if plain else "(solo HTML)",
                    html_body=html,
                    date=msg.get("Date", ""),
                    message_id=msg.get("Message-ID", msg_id.decode()),
                    in_reply_to=msg.get("In-Reply-To", ""),
                    references=msg.get("References", ""),
                    direction="ricevuta",
                    uid=msg_id.decode() if isinstance(msg_id, bytes) else str(msg_id),
                ))
            except Exception as e:
                logger.error("Errore parsing email %s: %s", msg_id, e)

        conn.logout()

    except Exception as e:
        logger.error("Errore fetch email: %s", e)

    return emails


# ──────────────────────────────────────────────
# SMTP — Test connessione
# ──────────────────────────────────────────────

def test_smtp_connection() -> tuple[bool, str]:
    """
    Testa la connessione SMTP.
    Ritorna (success, messaggio).
    """
    try:
        conn = smtplib.SMTP_SSL(SMTP_SERVER, SMTP_PORT)
        conn.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
        conn.quit()
        return True, f"Connesso a {SMTP_SERVER}:{SMTP_PORT} — login OK"
    except smtplib.SMTPAuthenticationError as e:
        return False, f"Login SMTP fallito: {e}"
    except Exception as e:
        return False, f"Connessione SMTP fallita: {e}"



# NOTE: save_draft() rimossa — le bozze IMAP vengono create solo manualmente
# via POST /api/drafts nel web_server.py (bottone "Save draft" nella UI).
