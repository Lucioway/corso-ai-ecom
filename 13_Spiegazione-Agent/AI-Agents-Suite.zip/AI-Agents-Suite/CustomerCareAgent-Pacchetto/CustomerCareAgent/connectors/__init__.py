"""Connettori per servizi esterni."""
