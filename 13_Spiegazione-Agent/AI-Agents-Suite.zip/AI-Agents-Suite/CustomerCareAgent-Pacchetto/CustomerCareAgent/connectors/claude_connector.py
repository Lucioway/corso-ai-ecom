"""
Connettore Claude API via Anthropic SDK.
Wrapper per messaggi e test connessione.
"""

import logging

import anthropic

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import ANTHROPIC_API_KEY, CLAUDE_MODEL, CLAUDE_MAX_TOKENS

logger = logging.getLogger(__name__)


class ClaudeClient:
    """Client per Claude API via Anthropic SDK."""

    def __init__(
        self,
        api_key: str = ANTHROPIC_API_KEY,
        model: str = CLAUDE_MODEL,
        max_tokens: int = CLAUDE_MAX_TOKENS,
    ) -> None:
        self.client = anthropic.Anthropic(api_key=api_key)
        self.model = model
        self.max_tokens = max_tokens

    def test_connection(self) -> tuple[bool, str]:
        """
        Testa la connessione inviando un messaggio triviale.
        Ritorna (success, messaggio).
        """
        try:
            response = self.client.messages.create(
                model=self.model,
                max_tokens=50,
                messages=[{"role": "user", "content": "Rispondi solo: OK"}],
            )
            reply = response.content[0].text.strip()
            return True, f"Connesso — Model: {self.model} (risposta: {reply[:20]})"
        except anthropic.AuthenticationError as e:
            return False, f"API key non valida: {e}"
        except anthropic.APIError as e:
            return False, f"Errore API: {e}"
        except Exception as e:
            return False, f"Connessione fallita: {e}"

    def send_message(
        self,
        user_message: str,
        system_prompt: str = "",
        max_tokens: int | None = None,
    ) -> str:
        """
        Invia un messaggio a Claude e ritorna la risposta testuale.
        Solleva eccezione in caso di errore.
        """
        kwargs: dict = {
            "model": self.model,
            "max_tokens": max_tokens or self.max_tokens,
            "messages": [{"role": "user", "content": user_message}],
        }
        if system_prompt:
            kwargs["system"] = system_prompt

        response = self.client.messages.create(**kwargs)
        return response.content[0].text
