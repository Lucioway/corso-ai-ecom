"""
Optional bridge to an external Email_agent — reads its daily JSON reports
to enrich CustomerCareAgent context (volumes, recurring issues, refund causes,
known spam senders, frustration patterns, critical alerts).

DISABLED BY DEFAULT for tenants that do not have an Email_agent.
Enable by setting EMAIL_AGENT_REPORTS_DIR=/path/to/daily_reports/ in .env.
All public functions degrade gracefully (return None / empty / OK-skipped)
when the dir is unset or missing.
"""

import json
import logging
import os
from datetime import date, timedelta
from pathlib import Path
from typing import Any

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

_reports_env = os.getenv("EMAIL_AGENT_REPORTS_DIR", "")
EMAIL_AGENT_REPORTS_DIR: Path | None = Path(_reports_env) if _reports_env else None

logger = logging.getLogger(__name__)


def get_latest_report_path(target_date: date | None = None) -> Path | None:
    """
    Trova il report piu` recente (JSON).
    Se target_date e` specificata, cerca quello specifico.
    Altrimenti cerca il piu` recente disponibile (fino a 7 giorni indietro).
    """
    if EMAIL_AGENT_REPORTS_DIR is None or not EMAIL_AGENT_REPORTS_DIR.exists():
        # Bridge disabled / no reports configured — silent skip
        return None

    if target_date:
        path = EMAIL_AGENT_REPORTS_DIR / f"daily_{target_date.isoformat()}.json"
        return path if path.exists() else None

    # Cerca il report piu` recente (fino a 7 giorni indietro)
    for days_back in range(1, 8):
        d = date.today() - timedelta(days=days_back)
        path = EMAIL_AGENT_REPORTS_DIR / f"daily_{d.isoformat()}.json"
        if path.exists():
            return path

    return None


def load_daily_report(target_date: date | None = None) -> dict[str, Any] | None:
    """
    Carica il report JSON del giorno specificato (o il piu` recente).
    Ritorna il dict completo o None se non trovato.
    """
    path = get_latest_report_path(target_date)
    if not path:
        logger.warning("Nessun report giornaliero trovato")
        return None

    try:
        # Prova utf-8, fallback a latin-1 (i report possono contenere caratteri speciali)
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            text = path.read_text(encoding="latin-1")
        data = json.loads(text)
        logger.info("Report caricato: %s (%d email ricevute)", path.name, data.get("total_received", 0))
        return data
    except (json.JSONDecodeError, OSError) as e:
        logger.error("Errore caricamento report %s: %s", path, e)
        return None


def get_daily_context_summary(target_date: date | None = None) -> str:
    """
    Genera un riassunto testuale del report giornaliero da usare come contesto
    per Claude quando prepara le risposte. Include:
    - Volumi e allarmi
    - Top problemi critici
    - Pattern frustrazione
    - Raccomandazioni operative
    - Errori da evitare nelle risposte
    """
    report = load_daily_report(target_date)
    if not report:
        return ""

    lines: list[str] = []
    report_date = report.get("date", "?")
    lines.append(f"## Report Customer Care del {report_date}")
    lines.append(f"Email ricevute: {report.get('total_received', 0)} | Inviate: {report.get('total_sent', 0)}")
    lines.append("")

    # Volumi
    volumi = report.get("volumi", {})
    if volumi:
        lines.append(f"Clienti unici: {volumi.get('clienti_unici', '?')}")
        for allarme in volumi.get("allarmi", []):
            lines.append(f"  ALLARME: {allarme}")
        lines.append("")

    # Cause rimborsi
    cause = report.get("cause_rimborsi", {})
    if cause:
        lines.append(f"### Cause rimborsi ({cause.get('totale_richieste', 0)} richieste)")
        for cat in cause.get("top_3", []):
            lines.append(f"  - {cat.get('categoria', '?')}: {cat.get('conteggio', 0)} ({cat.get('percentuale', 0)}%)")
        lines.append("")

    # Top 5 problemi critici
    top_problems = report.get("top_5_problemi_critici", [])
    if top_problems:
        lines.append("### Problemi critici da gestire")
        for p in top_problems:
            lines.append(f"  - [{p.get('gravita', '?')}] {p.get('problema', '?')} ({p.get('clienti_coinvolti', '?')} clienti)")
        lines.append("")

    # Pattern frustrazione
    frustrazione = report.get("frustrazione", {})
    if frustrazione:
        lines.append("### Frustrazione clienti")
        lines.append(f"  Alta: {frustrazione.get('alta_pct', 0)}% | Media: {frustrazione.get('media_pct', 0)}% | Bassa: {frustrazione.get('bassa_pct', 0)}%")
        pattern = frustrazione.get("pattern_frustrazione", "")
        if pattern:
            lines.append(f"  Pattern: {pattern}")
        lines.append("")

    # Qualita` risposte ed errori da evitare
    qualita = report.get("qualita_risposte", {})
    if qualita:
        lines.append("### Errori da evitare nelle risposte")
        for errore in qualita.get("esempi_errori_policy", []):
            lines.append(f"  - {errore}")
        for allarme in qualita.get("allarmi", []):
            lines.append(f"  ALLARME: {allarme}")
        lines.append("")

    # Raccomandazioni operative
    insight = report.get("insight_qualitativi", {})
    if insight:
        raccs = insight.get("raccomandazioni_operative", [])
        if raccs:
            lines.append("### Raccomandazioni operative")
            for r in raccs:
                lines.append(f"  - {r.get('problema', '?')} -> {r.get('azione', '?')}")
            lines.append("")

        gap = insight.get("gap_marketing_esperienza", "")
        if gap:
            lines.append(f"### Gap marketing vs esperienza")
            lines.append(f"  {gap}")
            lines.append("")

    # Allarmi critici
    allarmi = report.get("allarmi_critici", [])
    if allarmi:
        lines.append("### ALLARMI CRITICI")
        for a in allarmi:
            lines.append(f"  {a}")
        lines.append("")

    # Email non customer care (per filtro spam)
    non_cc = report.get("email_non_customer_care", [])
    if non_cc:
        lines.append(f"### Email da ignorare (spam/partnership): {len(non_cc)} identificate ieri")
        lines.append("")

    return "\n".join(lines)


def get_known_problem_emails(target_date: date | None = None) -> list[dict]:
    """
    Estrae le email problematiche dal report — utile per dare priorita`
    o per sapere se un cliente ha gia` un problema noto.
    """
    report = load_daily_report(target_date)
    if not report:
        return []

    emails: list[dict] = []
    for problem in report.get("top_5_problemi_critici", []):
        for ref in problem.get("reference_email", []):
            emails.append({
                "from": ref.get("da", ""),
                "subject": ref.get("oggetto", ""),
                "problem": problem.get("problema", ""),
                "severity": problem.get("gravita", ""),
            })
    return emails


def get_spam_senders(target_date: date | None = None) -> set[str]:
    """
    Estrae i mittenti identificati come spam/partnership dal report.
    Utile per il filtro automatico.
    """
    report = load_daily_report(target_date)
    if not report:
        return set()

    senders: set[str] = set()
    for entry in report.get("email_non_customer_care", []):
        mittente = entry.get("mittente", "")
        if mittente:
            senders.add(mittente.lower())
    return senders


def test_bridge_connection() -> tuple[bool, str]:
    """
    Verifica che il collegamento con Email_agent funzioni.
    Ritorna (success, messaggio).
    """
    if EMAIL_AGENT_REPORTS_DIR is None:
        return True, "(disabled — EMAIL_AGENT_REPORTS_DIR not set)"
    if not EMAIL_AGENT_REPORTS_DIR.exists():
        return False, f"Directory non trovata: {EMAIL_AGENT_REPORTS_DIR}"

    # Conta report disponibili
    reports = list(EMAIL_AGENT_REPORTS_DIR.glob("daily_*.json"))
    if not reports:
        return False, "Nessun report JSON trovato"

    # Carica il piu` recente
    path = get_latest_report_path()
    if not path:
        return False, "Nessun report recente (ultimi 7 giorni)"

    report = load_daily_report()
    if not report:
        return False, "Report non leggibile"

    report_date = report.get("date", "?")
    total = report.get("total_received", 0)
    return True, f"{len(reports)} report disponibili — ultimo: {report_date} ({total} email)"
