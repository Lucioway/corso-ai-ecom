"""
CustomerCareAgent — Email Processor Pipeline.
Fetch -> Context Enrichment -> Classify -> Draft -> Save.
"""

import json
import logging
import re
import time
from dataclasses import dataclass, asdict
from datetime import datetime
from pathlib import Path
from typing import Any

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import (
    PROJECT_ROOT, DRAFTS_DIR, PROCESSED_DIR,
    ANTHROPIC_API_KEY, CLAUDE_MODEL, CLAUDE_OPUS_MODEL, CLAUDE_MAX_TOKENS,
)
from connectors.imap_connector import EmailMessage, fetch_recent_emails
from connectors.shopify_connector import ShopifyClient
from connectors.parcelpanel_connector import ParcelPanelClient
from connectors.claude_connector import ClaudeClient
from connectors.email_agent_bridge import get_daily_context_summary
from learning_db import save_ai_draft

logger = logging.getLogger(__name__)

PROMPTS_DIR = PROJECT_ROOT / "prompts"


# ──────────────────────────────────────────────
# Data models
# ──────────────────────────────────────────────

@dataclass
class Classification:
    category: str
    confidence: float
    language: str
    order_id_detected: str | None
    sentiment: str
    urgency: str
    summary: str


@dataclass
class ProcessedEmail:
    uid: str
    from_addr: str
    subject: str
    classification: Classification
    context: str  # enriched context block
    draft_body: str  # generated response
    draft_saved: bool
    processed_at: str
    error: str | None = None


# ──────────────────────────────────────────────
# State tracking: which emails already processed
# ──────────────────────────────────────────────

def _processed_ids_path() -> Path:
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    return PROCESSED_DIR / "processed_uids.json"


def load_processed_ids() -> set[str]:
    path = _processed_ids_path()
    if path.exists():
        try:
            return set(json.loads(path.read_text(encoding="utf-8")))
        except Exception:
            return set()
    return set()


def save_processed_id(uid: str) -> None:
    ids = load_processed_ids()
    ids.add(uid)
    _processed_ids_path().write_text(
        json.dumps(sorted(ids)), encoding="utf-8"
    )


# ──────────────────────────────────────────────
# Step 1: Context Enrichment
# ──────────────────────────────────────────────

def extract_order_id(text: str) -> str | None:
    """
    Extract order ID from text.
    If ORDER_ID_PREFIX is set (e.g. "LS"), matches "#LS12345" / "LS12345".
    Otherwise matches Shopify-style "#1001" / "1001".
    """
    from config import ORDER_ID_PREFIX
    if ORDER_ID_PREFIX:
        pattern = r"#?(" + re.escape(ORDER_ID_PREFIX) + r"\d{3,8})"
        match = re.search(pattern, text, re.IGNORECASE)
        return match.group(1).upper() if match else None
    # No prefix: match Shopify default "#1001"
    match = re.search(r"#(\d{4,8})\b", text)
    return match.group(1) if match else None


def extract_email_from_header(from_addr: str) -> str:
    """Extract clean email from 'Name <email>' format."""
    match = re.search(r"<([^>]+)>", from_addr)
    if match:
        return match.group(1).lower()
    if "@" in from_addr:
        return from_addr.strip().lower()
    return ""


def detect_payment_method(order: dict) -> str:
    """Detect payment method from Shopify order."""
    gateways = order.get("payment_gateway_names", [])
    if not gateways:
        # Empty gateway = likely Klarna (external payment app)
        if order.get("financial_status") in ("paid", "partially_refunded", "refunded"):
            return "Klarna"
        return "Unknown"
    gw = gateways[0].lower()
    if "paypal" in gw:
        return "PayPal"
    if "shopify_payments" in gw or "stripe" in gw:
        return "Carta"
    if "klarna" in gw:
        return "Klarna"
    return gateways[0]


def enrich_context(email: EmailMessage, shopify: ShopifyClient, parcelpanel: ParcelPanelClient) -> str:
    """
    Build context block from Shopify + ParcelPanel + email report.
    This runs BEFORE Claude sees the email.
    """
    blocks: list[str] = []
    customer_email = extract_email_from_header(email.from_addr)
    order_id_text = extract_order_id(f"{email.subject} {email.body[:500]}")

    # ── Shopify: Order lookup ──
    orders = []
    if order_id_text:
        # Search by order name
        orders = shopify.search_orders_by_name(order_id_text)

    if not orders and customer_email:
        # Fallback: search by customer email
        orders = shopify.search_orders_by_email(customer_email, limit=5)

    if orders:
        for order in orders[:3]:  # Max 3 orders
            order_name = order.get("name", "?")
            created = order.get("created_at", "")[:10]
            financial = order.get("financial_status", "?")
            fulfillment = order.get("fulfillment_status", "") or "unfulfilled"
            total = order.get("total_price", "?")
            currency = order.get("currency", "")

            # Line items
            items = order.get("line_items", [])
            items_str = ", ".join(
                f"{it.get('title', '?')} ({it.get('variant_title', '')})"
                for it in items[:5]
            )

            payment = detect_payment_method(order)
            block = f"ORDER {order_name}: placed {created}, {financial}, {fulfillment}, total {total} {currency}\n"
            block += f"  Payment: {payment}\n"
            block += f"  Items: {items_str}\n"

            # Shipping address
            shipping = order.get("shipping_address", {})
            if shipping:
                country = shipping.get("country", "")
                city = shipping.get("city", "")
                block += f"  Ship to: {city}, {country}\n"

            # Fulfillment / tracking
            order_id = str(order.get("id", ""))
            fulfillments = shopify.get_fulfillments(order_id) if order_id else []
            for f in fulfillments:
                tracking_num = f.get("tracking_number", "")
                tracking_url = f.get("tracking_url", "")
                tracking_co = f.get("tracking_company", "")
                f_status = f.get("status", "")
                if tracking_num:
                    # NOTE: f_status is the Shopify FULFILLMENT label status
                    # (success = label created, NOT delivered to customer).
                    # Real delivery status comes from ParcelPanel block below.
                    block += f"  Shipping label: {tracking_co} {tracking_num} (label_status: {f_status} — label only, not delivery status)\n"
                    if tracking_url:
                        block += f"  Tracking URL: {tracking_url}\n"

            # Customer note
            note = order.get("note", "")
            if note:
                block += f"  Customer note: {note}\n"

            blocks.append(block)

            # ── ParcelPanel: detailed tracking ──
            if order_name:
                pp_data = parcelpanel.get_tracking_status(order_name.lstrip("#"))
                if pp_data:
                    for shipment in pp_data:
                        blocks.append(
                            f"  PARCEL TRACKING: {shipment['carrier']} {shipment['tracking_number']}\n"
                            f"    Status: {shipment['status']}\n"
                            f"    Last update: {shipment['latest_checkpoint']} ({shipment['latest_time']})\n"
                            f"    Link: {shipment.get('tracking_link', 'N/A')}"
                        )
                else:
                    # Explicit marker so the prompt enters WISMO State W0 / W6
                    # instead of hallucinating "in transit" / "delivered" status.
                    has_shopify_tracking = any(f.get("tracking_number") for f in fulfillments)
                    if has_shopify_tracking:
                        blocks.append(
                            "  PARCEL TRACKING: no tracking data\n"
                            "    Note: Shopify shipping label exists but ParcelPanel has no checkpoints yet.\n"
                            "    → Use WISMO State W6 (pending / no scans).\n"
                            "    Do NOT claim the parcel is in transit or delivered."
                        )
                    else:
                        blocks.append(
                            "  PARCEL TRACKING: no tracking data\n"
                            "    Note: no shipment information available from courier.\n"
                            "    → Use WISMO State W0 (no tracking).\n"
                            "    Do NOT invent tracking numbers, URLs, carriers, or ETA."
                        )
    else:
        blocks.append("NO ORDER FOUND for this customer in Shopify.")

    # ── Customer history (from Shopify) ──
    if customer_email:
        customers = shopify.search_customers(customer_email)
        if customers:
            cust = customers[0]
            orders_count = cust.get("orders_count", 0)
            total_spent = cust.get("total_spent", "0")
            blocks.append(
                f"CUSTOMER: {cust.get('first_name', '')} {cust.get('last_name', '')}, "
                f"{orders_count} orders, total spent: {total_spent} {cust.get('currency', '')}"
            )

    # ── Daily report context ──
    daily = get_daily_context_summary()
    if daily:
        # Only include the critical issues section, not the full report
        lines = daily.split("\n")
        critical = [l for l in lines if "ALLARME" in l or "CRITICO" in l]
        if critical:
            blocks.append("KNOWN ISSUES TODAY:\n" + "\n".join(critical[:3]))

    context = "\n\n".join(blocks) if blocks else "No additional context available."
    logger.info("Context enriched for %s: %d blocks", email.from_addr, len(blocks))
    return context


# ──────────────────────────────────────────────
# Step 2: Classification
# ──────────────────────────────────────────────

def classify_email(email: EmailMessage, claude: ClaudeClient) -> Classification:
    """Classify email using Claude. Returns structured Classification."""
    from config import render_template
    prompt_template = (PROMPTS_DIR / "classify.md").read_text(encoding="utf-8")
    prompt_template = render_template(prompt_template)

    # Clean body for classification (first 1000 chars)
    body_clean = email.body[:1000] if email.body else "(HTML-only email)"

    prompt = prompt_template.replace("{{from}}", email.from_addr)
    prompt = prompt.replace("{{subject}}", email.subject)
    prompt = prompt.replace("{{body}}", body_clean)

    try:
        response = claude.send_message(prompt, max_tokens=500)

        # Extract JSON from response
        json_match = re.search(r"\{[^}]+\}", response, re.DOTALL)
        if json_match:
            data = json.loads(json_match.group())
        else:
            data = json.loads(response)

        return Classification(
            category=data.get("category", "other"),
            confidence=float(data.get("confidence", 0.5)),
            language=data.get("language", "en"),
            order_id_detected=data.get("order_id_detected"),
            sentiment=data.get("sentiment", "neutral"),
            urgency=data.get("urgency", "medium"),
            summary=data.get("summary", ""),
        )

    except (json.JSONDecodeError, KeyError) as e:
        logger.error("Classification parse error: %s — response: %s", e, response[:200])
        return Classification(
            category="other", confidence=0.0, language="en",
            order_id_detected=None, sentiment="neutral",
            urgency="medium", summary=f"Classification failed: {e}",
        )
    except Exception as e:
        logger.error("Classification error: %s", e)
        return Classification(
            category="other", confidence=0.0, language="en",
            order_id_detected=None, sentiment="neutral",
            urgency="medium", summary=f"Classification error: {e}",
        )


# ──────────────────────────────────────────────
# Step 3: Draft Generation
# ──────────────────────────────────────────────

def _build_examples_block(category: str, language: str, limit: int = 3) -> str:
    """
    Load past sent responses from learning_db as few-shot examples.
    Returns a ready-to-inject markdown block, or empty string if no examples available.
    """
    try:
        from learning_db import get_training_examples
        examples = get_training_examples(category=category, language=language, limit=limit)
    except Exception as e:
        logger.error("Examples retrieval error: %s", e)
        return ""

    if not examples:
        return ""

    lines = [
        "## Past successful responses to similar emails (learned from history)",
        "These are REAL examples of how a human operator has replied to emails in the same category.",
        "Match the tone, structure, length and phrasing of these examples — they reflect what actually works.",
        "Examples where was_modified=1 are corrections the human made to previous AI drafts — learn from them.",
        "",
    ]
    for i, ex in enumerate(examples, 1):
        cust = (ex.get("customer_body") or "").strip()[:1500]
        resp = (ex.get("final_response") or "").strip()[:2000]
        was_mod = ex.get("was_modified", 0)
        lang = ex.get("language") or "?"
        lines.append(f"### Example {i} (lang={lang}, {'CORRECTED BY HUMAN' if was_mod else 'AI draft sent as-is'})")
        lines.append("**Customer wrote:**")
        lines.append("```")
        lines.append(cust)
        lines.append("```")
        lines.append("**Human sent back:**")
        lines.append("```")
        lines.append(resp)
        lines.append("```")
        lines.append("")
    lines.append("---")
    lines.append("")
    return "\n".join(lines)


def generate_draft(
    email: EmailMessage,
    classification: Classification,
    context: str,
    claude: ClaudeClient,
    thread_history: str = "",
    operator_hint: str = "",
) -> str:
    """Generate response draft using Claude with enriched context + full thread history + few-shot examples + operator instructions."""
    prompt_template = (PROMPTS_DIR / "draft_response.md").read_text(encoding="utf-8")

    body_clean = email.body[:2000] if email.body else "(HTML-only email)"
    history_block = thread_history.strip() if thread_history else "(no prior messages - this is the first email in the conversation)"

    # Few-shot examples from learning_db: past sent responses in same category (preferring human corrections)
    examples_block = _build_examples_block(classification.category, classification.language, limit=3)
    if examples_block:
        logger.info("  Loaded %d training examples from learning_db (category=%s, lang=%s)",
                    examples_block.count("### Example"), classification.category, classification.language)

    # Load brand-specific context + reply templates from knowledge/ + templates/
    from config import (
        render_template,
        BRAND_CONTEXT_PATH, BRAND_CONTEXT_FULL_PATH, TEMPLATES_DIR,
    )
    brand_ctx_parts: list[str] = []
    if BRAND_CONTEXT_PATH.exists():
        brand_ctx_parts.append(BRAND_CONTEXT_PATH.read_text(encoding="utf-8"))
    if BRAND_CONTEXT_FULL_PATH.exists():
        brand_ctx_parts.append(BRAND_CONTEXT_FULL_PATH.read_text(encoding="utf-8"))
    brand_context_block = "\n\n".join(brand_ctx_parts) if brand_ctx_parts else "(no brand context configured — see knowledge/brand_context.md)"

    response_templates_block = ""
    templates_md = TEMPLATES_DIR / "customer_care_templates.md"
    if templates_md.exists():
        response_templates_block = templates_md.read_text(encoding="utf-8")
    else:
        response_templates_block = "(no reply templates configured — see templates/customer_care_templates.md)"

    # Render brand placeholders ({{BRAND_NAME}} etc) first, then runtime fields
    prompt = render_template(prompt_template)
    prompt = prompt.replace("{{from}}", email.from_addr)
    prompt = prompt.replace("{{subject}}", email.subject)
    prompt = prompt.replace("{{body}}", body_clean)
    prompt = prompt.replace("{{category}}", classification.category)
    prompt = prompt.replace("{{sentiment}}", classification.sentiment)
    prompt = prompt.replace("{{urgency}}", classification.urgency)
    prompt = prompt.replace("{{language}}", classification.language)
    prompt = prompt.replace("{{context}}", context)
    prompt = prompt.replace("{{thread_history}}", history_block)
    prompt = prompt.replace("{{operator_instructions}}", operator_hint.strip() if operator_hint else "(no additional instructions)")
    prompt = prompt.replace("{{brand_context}}", brand_context_block)
    prompt = prompt.replace("{{response_templates}}", response_templates_block)

    # Prepend examples block just before the template sections (if any)
    if examples_block:
        prompt = examples_block + "\n" + prompt

    try:
        # Use Opus for draft generation (smarter, more nuanced responses)
        opus_client = ClaudeClient(model=CLAUDE_OPUS_MODEL)
        response = opus_client.send_message(prompt, max_tokens=1500)
        return response.strip()
    except Exception as e:
        logger.error("Draft generation error: %s", e)
        return f"[DRAFT GENERATION FAILED: {e}]"


# ──────────────────────────────────────────────
# Main Pipeline
# ──────────────────────────────────────────────

SKIP_CATEGORIES = {"spam"}


def process_single_email(
    email: EmailMessage,
    claude: ClaudeClient,
    shopify: ShopifyClient,
    parcelpanel: ParcelPanelClient,
    thread_history: str = "",
    force: bool = False,
    operator_hint: str = "",
) -> ProcessedEmail:
    """Process a single email through the full pipeline.

    thread_history: optional pre-formatted conversation history (oldest first). When provided,
    the AI draft is generated with full awareness of prior exchanges.
    force: if True, generate a draft even for categories in SKIP_CATEGORIES (manual UI action).
    """
    logger.info("Processing: [%s] %s — %s", email.uid, email.from_addr, email.subject[:50])

    # Step 1: Classify
    classification = classify_email(email, claude)
    logger.info("  Classified: %s (%.0f%%) sentiment=%s urgency=%s",
                classification.category, classification.confidence * 100,
                classification.sentiment, classification.urgency)

    is_skip = classification.category in SKIP_CATEGORIES

    # Skip spam (unless forced by manual UI action)
    if is_skip and not force:
        logger.info("  Skipped (spam)")
        return ProcessedEmail(
            uid=email.uid if hasattr(email, 'uid') else email.message_id,
            from_addr=email.from_addr,
            subject=email.subject,
            classification=classification,
            context="",
            draft_body="",
            draft_saved=False,
            processed_at=datetime.now().isoformat(),
        )

    if is_skip and force:
        logger.info("  Forced draft on spam/auto-reply category")

    # Step 2: Context enrichment
    context = enrich_context(email, shopify, parcelpanel)
    logger.info("  Context enriched (%d chars)", len(context))

    # Step 3: Generate draft (with full thread history if available)
    draft_body = generate_draft(email, classification, context, claude, thread_history=thread_history, operator_hint=operator_hint)
    logger.info("  Draft generated (%d chars, thread=%d chars)", len(draft_body), len(thread_history or ""))

    if is_skip and force:
        draft_body = (
            "⚠️ WARNING: this email was classified as spam/auto-reply (likely an "
            "out-of-office bot or non-customer message). Review carefully before sending.\n\n"
            "---\n\n" + draft_body
        )

    # Step 4: Save to learning DB
    try:
        save_ai_draft(
            uid=email.uid if hasattr(email, 'uid') else email.message_id,
            message_id=email.message_id,
            from_addr=email.from_addr,
            subject=email.subject,
            customer_body=email.body[:2000],
            category=classification.category,
            confidence=classification.confidence,
            language=classification.language,
            sentiment=classification.sentiment,
            urgency=classification.urgency,
            order_id=classification.order_id_detected,
            summary=classification.summary,
            context=context,
            ai_draft=draft_body,
        )
    except Exception as e:
        logger.error("  Learning DB save error: %s", e)

    return ProcessedEmail(
        uid=email.uid if hasattr(email, 'uid') else email.message_id,
        from_addr=email.from_addr,
        subject=email.subject,
        classification=classification,
        context=context,
        draft_body=draft_body,
        draft_saved=False,
        processed_at=datetime.now().isoformat(),
    )


def process_batch(
    limit: int = 10,
    dry_run: bool = False,
) -> list[ProcessedEmail]:
    """
    Process a batch of unread emails.
    Returns list of ProcessedEmail results.
    """
    logger.info("=== Starting batch processing (limit=%d, dry_run=%s) ===", limit, dry_run)

    # Init clients
    claude = ClaudeClient()
    shopify = ShopifyClient()
    parcelpanel = ParcelPanelClient()

    # Fetch recent emails
    emails = fetch_recent_emails(limit=limit)
    logger.info("Fetched %d emails", len(emails))

    # Filter already processed
    processed_ids = load_processed_ids()
    to_process = [e for e in emails if e.message_id not in processed_ids]
    logger.info("To process: %d (skipping %d already processed)", len(to_process), len(emails) - len(to_process))

    results: list[ProcessedEmail] = []

    for email in to_process:
        try:
            if dry_run:
                # Only classify, no draft
                classification = classify_email(email, claude)
                result = ProcessedEmail(
                    uid=getattr(email, 'uid', email.message_id),
                    from_addr=email.from_addr,
                    subject=email.subject,
                    classification=classification,
                    context="(dry-run)",
                    draft_body="(dry-run)",
                    draft_saved=False,
                    processed_at=datetime.now().isoformat(),
                )
            else:
                result = process_single_email(email, claude, shopify, parcelpanel)
                save_processed_id(email.message_id)

            results.append(result)

            # Rate limiting between emails
            time.sleep(1)

        except Exception as e:
            logger.error("Error processing %s: %s", email.subject[:40], e)
            results.append(ProcessedEmail(
                uid=getattr(email, 'uid', email.message_id),
                from_addr=email.from_addr,
                subject=email.subject,
                classification=Classification(
                    category="other", confidence=0, language="en",
                    order_id_detected=None, sentiment="neutral",
                    urgency="medium", summary=f"Error: {e}",
                ),
                context="",
                draft_body="",
                draft_saved=False,
                processed_at=datetime.now().isoformat(),
                error=str(e),
            ))

    logger.info("=== Batch complete: %d processed, %d drafts saved ===",
                len(results), sum(1 for r in results if r.draft_saved))

    # Save results log
    _save_results_log(results)

    return results


def _save_results_log(results: list[ProcessedEmail]) -> None:
    """Save processing results to a JSON log file."""
    PROCESSED_DIR.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    log_path = PROCESSED_DIR / f"batch_{timestamp}.json"

    data = []
    for r in results:
        d = {
            "uid": r.uid,
            "from": r.from_addr,
            "subject": r.subject,
            "category": r.classification.category,
            "confidence": r.classification.confidence,
            "language": r.classification.language,
            "sentiment": r.classification.sentiment,
            "urgency": r.classification.urgency,
            "order_id": r.classification.order_id_detected,
            "summary": r.classification.summary,
            "draft_saved": r.draft_saved,
            "draft_length": len(r.draft_body),
            "processed_at": r.processed_at,
            "error": r.error,
        }
        data.append(d)

    log_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")
    logger.info("Results saved to %s", log_path.name)
