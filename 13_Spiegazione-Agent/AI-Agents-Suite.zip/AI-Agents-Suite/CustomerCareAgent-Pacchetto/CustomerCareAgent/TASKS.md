# TASKS — CustomerCareAgent (Phase 1: Connessioni)

## Batch 1: Fondamenta
- [x] T1: Creare PROJECT_BRIEF.md + SPEC.md + CLAUDE.md + TASKS.md
- [x] T2: Creare config.py + .env + .gitignore + requirements.txt

## Batch 2: Connettori Core
- [x] T3: Creare connectors/imap_connector.py (IMAP read + SMTP draft)
- [x] T4: Creare connectors/shopify_connector.py (Shopify REST API)
- [x] T5: Creare connectors/claude_connector.py (Anthropic SDK)

## Batch 3: Connettori Secondari
- [x] T6: Creare connectors/parcelpanel_connector.py (ParcelPanel API v2)
- [x] T7: Creare connectors/tracking_screenshot.py (Selenium screenshot)

## Batch 4: Knowledge + Entry Point
- [x] T8: Creare knowledge/knowledge_loader.py
- [x] T9: Creare main.py (CLI con --check, --dry-run, --once, --schedule)
- [x] T10: Creare .claude/skills/customer-care.md

## Batch 5: Verifica
- [x] T11: Eseguire --check → 6/8 connessioni OK (ParcelPanel API key mancante — da generare)
- [x] T12: Eseguire --dry-run → 10 email fetchate con successo
