"""
CustomerCareAgent — Entry Point.
Brand-agnostic customer-care automation. Configure via .env (see .env.example).

Comandi:
    python main.py --check              # Verifica tutte le connessioni
    python main.py --dry-run            # Fetch email senza azioni
    python main.py --dry-run --limit 5  # Fetch 5 email
    python main.py --once               # Singola esecuzione
    python main.py --schedule           # Polling ogni 10 minuti
"""

import argparse
import io
import logging
import sys
from datetime import datetime
from pathlib import Path

# Fix encoding Windows console
if sys.stdout.encoding != "utf-8":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# Aggiungi project root al path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import (
    ensure_dirs, validate_env, TEST_EMAIL_LIMIT,
    POLL_INTERVAL_MINUTES, TIMEZONE, LOG_LEVEL,
    LOGS_DIR,
)

# ──────────────────────────────────────────────
# Logging
# ──────────────────────────────────────────────

def setup_logging() -> None:
    """Configura logging su console + file rotante."""
    ensure_dirs()
    log_file = LOGS_DIR / f"customer_care_{datetime.now().strftime('%Y%m%d')}.log"

    handlers = [
        logging.StreamHandler(sys.stdout),
        logging.FileHandler(log_file, encoding="utf-8"),
    ]

    logging.basicConfig(
        level=getattr(logging, LOG_LEVEL.upper(), logging.INFO),
        format="%(asctime)s [%(levelname)s] %(name)s — %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S",
        handlers=handlers,
    )


# ──────────────────────────────────────────────
# --check: Verifica connessioni
# ──────────────────────────────────────────────

def check_all_connections() -> bool:
    """Verifica tutte le connessioni. Ritorna True se tutte OK."""
    print("\n  CustomerCareAgent — Verifica Connessioni\n")

    checks: list[tuple[str, bool, str]] = []
    passed = 0
    total = 0

    # 1. Variabili .env
    total += 1
    env_checks = validate_env()
    missing = [k for k, v in env_checks.items() if not v]
    if not missing:
        checks.append((".env", True, "Tutte le variabili presenti"))
        passed += 1
    else:
        checks.append((".env", False, f"Mancanti: {', '.join(missing)}"))

    # 2. IMAP (lettura)
    total += 1
    from connectors.imap_connector import test_imap_connection
    ok, msg = test_imap_connection()
    checks.append(("IMAP (lettura)", ok, msg))
    if ok:
        passed += 1

    # 3. SMTP (bozze)
    total += 1
    from connectors.imap_connector import test_smtp_connection
    ok, msg = test_smtp_connection()
    checks.append(("SMTP (bozze)", ok, msg))
    if ok:
        passed += 1

    # 4. Shopify API
    total += 1
    from connectors.shopify_connector import ShopifyClient
    shopify = ShopifyClient()
    ok, msg = shopify.test_connection()
    checks.append(("Shopify API", ok, msg))
    if ok:
        passed += 1

    # 5. Claude API
    total += 1
    from connectors.claude_connector import ClaudeClient
    claude = ClaudeClient()
    ok, msg = claude.test_connection()
    checks.append(("Claude API", ok, msg))
    if ok:
        passed += 1

    # 6. ParcelPanel API
    total += 1
    from connectors.parcelpanel_connector import ParcelPanelClient
    pp = ParcelPanelClient()
    ok, msg = pp.test_connection()
    checks.append(("ParcelPanel API", ok, msg))
    if ok:
        passed += 1

    # 7. Chrome/Selenium
    total += 1
    from connectors.tracking_screenshot import TrackingScreenshotter
    screenshotter = TrackingScreenshotter()
    ok, msg = screenshotter.test_browser()
    checks.append(("Chrome/Selenium", ok, msg))
    if ok:
        passed += 1

    # 8. Knowledge base
    total += 1
    from knowledge.knowledge_loader import test_knowledge_access
    ok, msg = test_knowledge_access()
    checks.append(("Knowledge base", ok, msg))
    if ok:
        passed += 1

    # 9. Email_agent bridge (daily reports)
    total += 1
    from connectors.email_agent_bridge import test_bridge_connection
    ok, msg = test_bridge_connection()
    checks.append(("Email_agent bridge", ok, msg))
    if ok:
        passed += 1

    # Stampa risultati
    for i, (name, ok, msg) in enumerate(checks, 1):
        icon = "v" if ok else "x"
        print(f"  {i}. {name:<20} [{icon}] {msg}")

    print(f"\n  Risultato: {passed}/{total} connessioni OK\n")
    return passed == total


# ──────────────────────────────────────────────
# --dry-run: Fetch email senza azioni
# ──────────────────────────────────────────────

def dry_run(limit: int) -> None:
    """Fetch N email recenti e mostra soggetti + contesto dal report Email_agent."""
    print(f"\n  CustomerCareAgent — Dry Run (limit={limit})\n")

    # Carica contesto dal report giornaliero Email_agent
    from connectors.email_agent_bridge import get_daily_context_summary, get_spam_senders
    context = get_daily_context_summary()
    if context:
        print("  === Contesto dal report Email_agent ===")
        for line in context.split("\n")[:20]:  # Prime 20 righe
            print(f"  {line}")
        print("  === Fine contesto ===\n")
    else:
        print("  (Nessun report Email_agent recente trovato)\n")

    # Mittenti spam noti
    spam_senders = get_spam_senders()
    if spam_senders:
        print(f"  Mittenti spam/partnership noti: {len(spam_senders)}\n")

    from connectors.imap_connector import fetch_recent_emails
    emails = fetch_recent_emails(limit=limit)

    if not emails:
        print("  Nessuna email trovata.\n")
        return

    print(f"  {len(emails)} email trovate:\n")
    for i, em in enumerate(emails, 1):
        # Tronca campi lunghi
        subj = em.subject[:60] + ("..." if len(em.subject) > 60 else "")
        from_addr = em.from_addr[:40] + ("..." if len(em.from_addr) > 40 else "")
        print(f"  {i:3d}. [{em.date[:16]}] {from_addr}")
        print(f"       Oggetto: {subj}")
        if em.in_reply_to:
            print(f"       (risposta a thread)")
        print()

    print(f"  Totale: {len(emails)} email. Nessuna azione eseguita (dry-run).\n")


# ──────────────────────────────────────────────
# --once: Singola esecuzione
# ──────────────────────────────────────────────

def run_once(limit: int) -> None:
    """
    Singola esecuzione del ciclo customer care.
    Phase 1: solo fetch email e log.
    Phase 2 aggiungerà: classifica, lookup Shopify, tracking, draft risposta.
    """
    logger = logging.getLogger("main")
    logger.info("=== Ciclo customer care iniziato ===")

    from connectors.imap_connector import fetch_recent_emails
    emails = fetch_recent_emails(limit=limit)
    logger.info("Email recuperate: %d", len(emails))

    for em in emails:
        logger.info("Email da %s — Oggetto: %s", em.from_addr, em.subject[:80])

    logger.info("=== Ciclo customer care completato (Phase 1 — solo fetch) ===")


# ──────────────────────────────────────────────
# --schedule: Polling periodico
# ──────────────────────────────────────────────

def run_schedule(limit: int) -> None:
    """Avvia scheduler con polling ogni N minuti."""
    from apscheduler.schedulers.blocking import BlockingScheduler
    from apscheduler.triggers.interval import IntervalTrigger

    scheduler = BlockingScheduler(timezone=TIMEZONE)
    scheduler.add_job(
        run_once,
        trigger=IntervalTrigger(minutes=POLL_INTERVAL_MINUTES),
        args=[limit],
        id="customer_care_cycle",
        name=f"Customer Care ogni {POLL_INTERVAL_MINUTES} min",
        next_run_time=datetime.now(),  # Esegui subito la prima volta
    )

    print(f"\n  CustomerCareAgent — Scheduler avviato")
    print(f"  Polling ogni {POLL_INTERVAL_MINUTES} minuti ({TIMEZONE})")
    print(f"  Premi Ctrl+C per fermare.\n")

    try:
        scheduler.start()
    except (KeyboardInterrupt, SystemExit):
        print("\n  Scheduler fermato.\n")
        scheduler.shutdown()


# ──────────────────────────────────────────────
# CLI
# ──────────────────────────────────────────────

def main() -> None:
    parser = argparse.ArgumentParser(
        description="CustomerCareAgent — Brand-agnostic customer-care automation"
    )
    parser.add_argument("--check", action="store_true", help="Verifica tutte le connessioni")
    parser.add_argument("--dry-run", action="store_true", help="Fetch email senza azioni")
    parser.add_argument("--once", action="store_true", help="Singola esecuzione")
    parser.add_argument("--schedule", action="store_true", help="Polling ogni 10 minuti")
    parser.add_argument("--limit", type=int, default=TEST_EMAIL_LIMIT,
                        help=f"Limite email da processare (default: {TEST_EMAIL_LIMIT})")

    args = parser.parse_args()
    setup_logging()
    ensure_dirs()

    if args.check:
        success = check_all_connections()
        sys.exit(0 if success else 1)
    elif args.dry_run:
        dry_run(limit=args.limit)
    elif args.once:
        run_once(limit=args.limit)
    elif args.schedule:
        run_schedule(limit=args.limit)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
