"""
CustomerCareAgent — Learning Database.
Traccia il ciclo: email_in -> draft_ai -> risposta_finale -> diff.
Ogni modifica umana diventa training data per migliorare i prompt.
"""

import json
import sqlite3
import logging
from datetime import datetime
from difflib import unified_diff, SequenceMatcher
from pathlib import Path
from typing import Any

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import DATA_DIR

logger = logging.getLogger(__name__)

DB_PATH = DATA_DIR / "learning.db"


def _get_conn() -> sqlite3.Connection:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(DB_PATH))
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA journal_mode=WAL")
    return conn


def init_db() -> None:
    """Create tables if they don't exist."""
    conn = _get_conn()
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS drafts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            uid TEXT NOT NULL,
            message_id TEXT,
            from_addr TEXT,
            subject TEXT,
            customer_body TEXT,
            category TEXT,
            confidence REAL,
            language TEXT,
            sentiment TEXT,
            urgency TEXT,
            order_id TEXT,
            summary TEXT,
            context TEXT,
            ai_draft TEXT NOT NULL,
            final_response TEXT,
            diff_text TEXT,
            similarity REAL,
            was_modified INTEGER DEFAULT 0,
            was_sent INTEGER DEFAULT 0,
            was_discarded INTEGER DEFAULT 0,
            created_at TEXT NOT NULL,
            sent_at TEXT,
            notes TEXT
        );

        CREATE TABLE IF NOT EXISTS stats (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            category TEXT NOT NULL,
            total INTEGER DEFAULT 0,
            sent_unmodified INTEGER DEFAULT 0,
            sent_modified INTEGER DEFAULT 0,
            discarded INTEGER DEFAULT 0,
            avg_similarity REAL DEFAULT 0,
            UNIQUE(date, category)
        );

        CREATE INDEX IF NOT EXISTS idx_drafts_uid ON drafts(uid);
        CREATE INDEX IF NOT EXISTS idx_drafts_category ON drafts(category);
        CREATE INDEX IF NOT EXISTS idx_drafts_created ON drafts(created_at);
        CREATE INDEX IF NOT EXISTS idx_drafts_sent ON drafts(was_sent);
    """)
    conn.commit()
    conn.close()
    logger.info("Learning DB initialized: %s", DB_PATH)


# ──────────────────────────────────────────────
# Save AI draft
# ──────────────────────────────────────────────

def save_ai_draft(
    uid: str,
    message_id: str,
    from_addr: str,
    subject: str,
    customer_body: str,
    category: str,
    confidence: float,
    language: str,
    sentiment: str,
    urgency: str,
    order_id: str | None,
    summary: str,
    context: str,
    ai_draft: str,
) -> int:
    """Save an AI-generated draft. Returns the row ID."""
    conn = _get_conn()
    cur = conn.execute("""
        INSERT INTO drafts (
            uid, message_id, from_addr, subject, customer_body,
            category, confidence, language, sentiment, urgency,
            order_id, summary, context, ai_draft, created_at
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (
        uid, message_id, from_addr, subject, customer_body[:3000],
        category, confidence, language, sentiment, urgency,
        order_id, summary, context[:5000], ai_draft,
        datetime.now().isoformat(),
    ))
    conn.commit()
    row_id = cur.lastrowid
    conn.close()
    logger.info("Draft saved to DB: id=%d uid=%s category=%s", row_id, uid, category)
    return row_id


# ──────────────────────────────────────────────
# Record human action on draft
# ──────────────────────────────────────────────

def _compute_diff(ai_draft: str, final: str) -> tuple[str, float]:
    """Compute unified diff and similarity ratio."""
    ai_lines = ai_draft.splitlines(keepends=True)
    final_lines = final.splitlines(keepends=True)
    diff = "".join(unified_diff(ai_lines, final_lines, fromfile="ai_draft", tofile="final"))
    similarity = SequenceMatcher(None, ai_draft, final).ratio()
    return diff, similarity


def record_sent(uid: str, final_response: str) -> dict:
    """
    Record that a draft was sent (possibly modified).
    Computes diff between AI draft and final human response.
    Returns stats about the modification.
    """
    conn = _get_conn()

    # Find the latest draft for this UID
    row = conn.execute(
        "SELECT id, ai_draft FROM drafts WHERE uid = ? ORDER BY created_at DESC LIMIT 1",
        (uid,)
    ).fetchone()

    if not row:
        conn.close()
        return {"error": "No draft found for this UID"}

    ai_draft = row["ai_draft"]
    diff_text, similarity = _compute_diff(ai_draft, final_response)
    was_modified = 1 if similarity < 0.95 else 0

    conn.execute("""
        UPDATE drafts SET
            final_response = ?,
            diff_text = ?,
            similarity = ?,
            was_modified = ?,
            was_sent = 1,
            sent_at = ?
        WHERE id = ?
    """, (final_response, diff_text, similarity, was_modified, datetime.now().isoformat(), row["id"]))
    conn.commit()
    conn.close()

    result = {
        "draft_id": row["id"],
        "similarity": round(similarity * 100, 1),
        "was_modified": bool(was_modified),
        "diff_lines": len(diff_text.splitlines()),
    }
    logger.info("Draft sent: id=%d similarity=%.1f%% modified=%s", row["id"], similarity * 100, was_modified)
    return result


def record_discarded(uid: str, notes: str = "") -> dict:
    """Record that a draft was discarded (not used)."""
    conn = _get_conn()
    row = conn.execute(
        "SELECT id FROM drafts WHERE uid = ? ORDER BY created_at DESC LIMIT 1",
        (uid,)
    ).fetchone()

    if not row:
        conn.close()
        return {"error": "No draft found"}

    conn.execute(
        "UPDATE drafts SET was_discarded = 1, notes = ? WHERE id = ?",
        (notes, row["id"])
    )
    conn.commit()
    conn.close()
    return {"draft_id": row["id"], "discarded": True}


# ──────────────────────────────────────────────
# Analytics / Stats
# ──────────────────────────────────────────────

def get_category_stats() -> list[dict]:
    """Stats per category: how often AI drafts are used vs modified vs discarded."""
    conn = _get_conn()
    rows = conn.execute("""
        SELECT
            category,
            COUNT(*) as total,
            SUM(CASE WHEN was_sent = 1 AND was_modified = 0 THEN 1 ELSE 0 END) as sent_unmodified,
            SUM(CASE WHEN was_sent = 1 AND was_modified = 1 THEN 1 ELSE 0 END) as sent_modified,
            SUM(was_discarded) as discarded,
            AVG(CASE WHEN similarity IS NOT NULL THEN similarity ELSE NULL END) as avg_similarity
        FROM drafts
        GROUP BY category
        ORDER BY total DESC
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_learning_insights() -> dict:
    """
    High-level insights for prompt improvement:
    - Which categories have lowest similarity (most human edits)
    - Most common modification patterns
    - Categories ready for auto-send (high similarity)
    """
    conn = _get_conn()

    # Overall stats
    overall = conn.execute("""
        SELECT
            COUNT(*) as total_drafts,
            SUM(was_sent) as total_sent,
            SUM(was_discarded) as total_discarded,
            AVG(CASE WHEN similarity IS NOT NULL THEN similarity END) as avg_similarity,
            SUM(CASE WHEN was_sent = 1 AND was_modified = 0 THEN 1 ELSE 0 END) as perfect_drafts
        FROM drafts
    """).fetchone()

    # Categories ready for auto-send (avg similarity > 95%)
    auto_ready = conn.execute("""
        SELECT category, COUNT(*) as count, AVG(similarity) as avg_sim
        FROM drafts
        WHERE was_sent = 1 AND similarity IS NOT NULL
        GROUP BY category
        HAVING AVG(similarity) > 0.95 AND COUNT(*) >= 5
        ORDER BY avg_sim DESC
    """).fetchall()

    # Categories needing improvement (avg similarity < 80%)
    needs_work = conn.execute("""
        SELECT category, COUNT(*) as count, AVG(similarity) as avg_sim
        FROM drafts
        WHERE was_sent = 1 AND similarity IS NOT NULL
        GROUP BY category
        HAVING AVG(similarity) < 0.80 AND COUNT(*) >= 3
        ORDER BY avg_sim ASC
    """).fetchall()

    # Recent diffs (last 10 modified drafts) for analysis
    recent_diffs = conn.execute("""
        SELECT category, subject, similarity, diff_text
        FROM drafts
        WHERE was_modified = 1 AND diff_text IS NOT NULL
        ORDER BY sent_at DESC LIMIT 10
    """).fetchall()

    conn.close()

    return {
        "total_drafts": overall["total_drafts"],
        "total_sent": overall["total_sent"],
        "total_discarded": overall["total_discarded"],
        "avg_similarity": round((overall["avg_similarity"] or 0) * 100, 1),
        "perfect_drafts": overall["perfect_drafts"],
        "auto_ready_categories": [dict(r) for r in auto_ready],
        "needs_improvement": [dict(r) for r in needs_work],
        "recent_modifications": [
            {"category": r["category"], "subject": r["subject"][:50],
             "similarity": round(r["similarity"] * 100, 1)}
            for r in recent_diffs
        ],
    }


def get_recent_drafts(limit: int = 20) -> list[dict]:
    """Get recent drafts with their status."""
    conn = _get_conn()
    rows = conn.execute("""
        SELECT id, uid, from_addr, subject, category, sentiment, urgency,
               similarity, was_modified, was_sent, was_discarded, created_at, sent_at
        FROM drafts
        ORDER BY created_at DESC
        LIMIT ?
    """, (limit,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_draft_detail(draft_id: int) -> dict | None:
    """Get full draft detail including diff."""
    conn = _get_conn()
    row = conn.execute("SELECT * FROM drafts WHERE id = ?", (draft_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def delete_draft(draft_id: int) -> bool:
    """Delete a draft from the learning DB."""
    conn = _get_conn()
    cur = conn.execute("DELETE FROM drafts WHERE id = ?", (draft_id,))
    conn.commit()
    deleted = cur.rowcount > 0
    conn.close()
    return deleted


def delete_draft_by_uid(uid: str) -> bool:
    """Delete the latest draft for a given email UID."""
    conn = _get_conn()
    cur = conn.execute("DELETE FROM drafts WHERE uid = ?", (uid,))
    conn.commit()
    deleted = cur.rowcount > 0
    conn.close()
    return deleted


def get_training_examples(category: str, language: str = "", limit: int = 3) -> list[dict]:
    """
    Retrieve past sent responses to use as few-shot training examples.
    Prefers modified drafts (human corrections) over identical ones, and matching language.
    """
    if not DB_PATH.exists():
        return []
    try:
        conn = _get_conn()
        # Prefer same language + modified (real human corrections), fallback to any sent
        # Ordering: was_modified DESC (corrections first), sent_at DESC (freshest first)
        rows = conn.execute(
            """
            SELECT customer_body, final_response, was_modified, similarity, language, sent_at, subject
            FROM drafts
            WHERE was_sent = 1
              AND final_response IS NOT NULL
              AND LENGTH(final_response) > 30
              AND category = ?
              AND (? = '' OR language = ?)
            ORDER BY was_modified DESC, sent_at DESC
            LIMIT ?
            """,
            (category, language, language, limit),
        ).fetchall()

        # If not enough same-language examples, fall back to any language
        if len(rows) < limit and language:
            existing_ids = set()  # no id selected, skip dedup by content
            need = limit - len(rows)
            extra = conn.execute(
                """
                SELECT customer_body, final_response, was_modified, similarity, language, sent_at, subject
                FROM drafts
                WHERE was_sent = 1
                  AND final_response IS NOT NULL
                  AND LENGTH(final_response) > 30
                  AND category = ?
                  AND language != ?
                ORDER BY was_modified DESC, sent_at DESC
                LIMIT ?
                """,
                (category, language, need),
            ).fetchall()
            rows = list(rows) + list(extra)

        conn.close()
        return [dict(r) for r in rows]
    except Exception as e:
        logger.error("get_training_examples error: %s", e)
        return []


# Init on import
init_db()
