"""
Priority Scorer — assigns priority to each email based on:
1. Optional Email_agent daily report (critical issues, known senders) — disabled by default
2. Keyword patterns (chargeback, legal, dispute, etc.)
3. Sender domain / history

Categories: critical, high, medium, low
"""

import json
import logging
import os
import re
from datetime import date, timedelta
from email.utils import parseaddr
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent))

logger = logging.getLogger(__name__)

# Optional external Email_agent reports dir (set via EMAIL_AGENT_REPORTS_DIR env);
# if not set or path missing, the priority scorer skips report-based signals.
_reports_env = os.getenv("EMAIL_AGENT_REPORTS_DIR", "")
EMAIL_AGENT_REPORTS_DIR: Path | None = Path(_reports_env) if _reports_env else None


# ──────────────────────────────────────────────
# Keyword patterns (priority signals)
# ──────────────────────────────────────────────

CRITICAL_KEYWORDS = [
    # Legal threats
    "chargeback", "dispute", "lawsuit", "legal action", "lawyer", "attorney",
    "consumer protection", "complaint to", "small claims", "court",
    "azione legale", "avvocato", "denuncia", "tribunale",
    "anwalt", "rechtsanwalt", "klage",
    # Fraud
    "fraud", "scam", "stolen", "frodato", "truffato",
    # Repeated contact / escalation
    "third time", "fourth time", "fifth time", "many times",
    "still no response", "still waiting", "no reply",
    "ancora senza risposta", "non risponde nessuno",
    # Money critical
    "paypal dispute", "stripe dispute", "bank reversal",
    "refund not received", "rimborso non ricevuto",
    "money never arrived", "nothing arrived",
]

HIGH_KEYWORDS = [
    # Strong negative sentiment
    "terrible", "horrible", "worst", "disgusting", "awful", "ridiculous",
    "very disappointed", "extremely disappointed",
    "pessimo", "terribile", "vergognoso", "delusa", "delusissim",
    "schrecklich", "furchtbar",
    # Damaged / quality
    "damaged", "broken", "defective", "ripped", "torn", "hole",
    "danneggiato", "rotto", "difettoso", "strappato", "buco",
    # Lost / missing
    "lost package", "package lost", "missing package", "never received",
    "pacco perso", "non ho ricevuto nulla",
    # Urgent
    "urgent", "asap", "immediately", "right now",
    "urgente", "subito", "immediatamente",
]

LOW_KEYWORDS = [
    # Positive feedback
    "thank you so much", "amazing", "love it", "perfect", "great quality",
    "grazie mille", "fantastico", "perfetto", "ottimo",
    # Pre-sale / info
    "do you ship to", "size guide", "in stock?", "available?",
    "spedite in", "guida taglie",
    # Newsletter / generic
    "newsletter", "marketing", "promo",
]


# ──────────────────────────────────────────────
# Daily report cache
# ──────────────────────────────────────────────

_report_cache: dict | None = None
_report_cache_date: str | None = None


def _load_latest_report() -> dict | None:
    """Carica il report piu` recente dell'Email_agent."""
    global _report_cache, _report_cache_date

    if EMAIL_AGENT_REPORTS_DIR is None or not EMAIL_AGENT_REPORTS_DIR.exists():
        return None

    # Find most recent report (last 7 days)
    for days_back in range(0, 8):
        d = date.today() - timedelta(days=days_back)
        path = EMAIL_AGENT_REPORTS_DIR / f"daily_{d.isoformat()}.json"
        if path.exists():
            # Cache hit
            if _report_cache_date == path.name:
                return _report_cache
            try:
                try:
                    text = path.read_text(encoding="utf-8")
                except UnicodeDecodeError:
                    text = path.read_text(encoding="latin-1")
                _report_cache = json.loads(text)
                _report_cache_date = path.name
                logger.info("Priority scorer: loaded report %s", path.name)
                return _report_cache
            except Exception as e:
                logger.error("Error loading report: %s", e)
                continue
    return None


def get_known_critical_senders() -> set[str]:
    """Estrae i mittenti delle email problematiche dal report."""
    report = _load_latest_report()
    if not report:
        return set()

    senders: set[str] = set()
    for problem in report.get("top_5_problemi_critici", []):
        for ref in problem.get("reference_email", []):
            sender = ref.get("da", "")
            _, clean = parseaddr(sender)
            if clean:
                senders.add(clean.lower())
            elif "@" in sender:
                senders.add(sender.lower().strip())
    return senders


def get_critical_subjects() -> set[str]:
    """Estrae i subject critici dal report."""
    report = _load_latest_report()
    if not report:
        return set()

    subjects: set[str] = set()
    for problem in report.get("top_5_problemi_critici", []):
        for ref in problem.get("reference_email", []):
            subj = (ref.get("oggetto", "") or "").lower().strip()
            if subj:
                # Normalize: rimuovi Re:, Fwd:
                subj = re.sub(r"^(re|fwd|fw)\s*:\s*", "", subj).strip()
                if len(subj) > 5:
                    subjects.add(subj)
    return subjects


# ──────────────────────────────────────────────
# Scoring function
# ──────────────────────────────────────────────

def score_email(
    from_addr: str,
    subject: str,
    body: str,
    is_starred: bool = False,
    is_spam: bool = False,
    auto_category: str = "",
) -> tuple[str, list[str]]:
    """
    Ritorna (priority, reasons) dove priority in {critical, high, medium, low}
    e reasons e` la lista dei motivi che hanno determinato il punteggio.
    """
    if is_spam:
        return "low", ["spam"]

    text = f"{subject} {body[:1000]}".lower()
    reasons: list[str] = []
    score = 0  # 0 = low, 1 = medium, 2 = high, 3 = critical

    # Extract clean sender email
    _, clean_from = parseaddr(from_addr or "")
    clean_from = clean_from.lower() if clean_from else ""

    # ── 1. Daily report signals (highest weight) ──
    critical_senders = get_known_critical_senders()
    if clean_from and clean_from in critical_senders:
        score = max(score, 3)
        reasons.append("known critical sender from daily report")

    critical_subjects = get_critical_subjects()
    norm_subj = re.sub(r"^(re|fwd|fw)\s*:\s*", "", subject.lower()).strip()
    for cs in critical_subjects:
        if cs in norm_subj or norm_subj in cs:
            score = max(score, 3)
            reasons.append(f"matches critical subject from report")
            break

    # ── 2. Critical keywords (legal, fraud, escalation) ──
    for kw in CRITICAL_KEYWORDS:
        if kw in text:
            score = max(score, 3)
            reasons.append(f"critical keyword: {kw}")
            break

    # ── 3. High keywords ──
    if score < 3:
        for kw in HIGH_KEYWORDS:
            if kw in text:
                score = max(score, 2)
                reasons.append(f"high keyword: {kw}")
                break

    # ── 4. Low keywords (positive/info) ──
    if score == 0:
        for kw in LOW_KEYWORDS:
            if kw in text:
                reasons.append(f"low keyword: {kw}")
                # Stay at 0 (low)
                break
        else:
            # No low signal → at least medium for legitimate customer
            score = 1
            reasons.append("default medium")

    # ── 5. Category-based adjustments ──
    if auto_category in ("complaint", "damaged_item", "payment_issue"):
        score = max(score, 2)
        reasons.append(f"category {auto_category}")
    elif auto_category in ("return_request", "where_is_my_order", "size_exchange",
                            "color_exchange", "address_change", "cancellation"):
        score = max(score, 1)
    elif auto_category in ("pre_sale_question",):
        # Stay low if no other signal
        pass

    # ── 6. Starred = boost (user marked as important) ──
    if is_starred:
        score = max(score, 2)
        reasons.append("starred")

    priority_map = {0: "low", 1: "medium", 2: "high", 3: "critical"}
    return priority_map[score], reasons


def reload_report_cache() -> None:
    """Force reload del report (chiamato ad ogni refresh cache)."""
    global _report_cache, _report_cache_date
    _report_cache = None
    _report_cache_date = None
    _load_latest_report()
