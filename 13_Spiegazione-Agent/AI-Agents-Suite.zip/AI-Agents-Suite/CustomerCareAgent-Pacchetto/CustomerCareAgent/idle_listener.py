"""
IMAP IDLE Listener — Real-time email detection.

Mantiene una connessione IMAP persistente con il comando IDLE.
Quando arriva una nuova email, Hostinger invia un EXISTS untagged response
e il listener triggera il processing immediato.

Re-auth ogni 29 min per evitare timeout server (limite IMAP RFC 2177).
"""

import imaplib
import logging
import socket
import threading
import time
from datetime import datetime
from typing import Callable

import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parent))

from config import EMAIL_ADDRESS, EMAIL_PASSWORD, IMAP_SERVER, IMAP_PORT

logger = logging.getLogger(__name__)

# IDLE re-issue interval (RFC says max 29 min)
IDLE_TIMEOUT_SECONDS = 28 * 60  # 28 min for safety


class IMAPIdleListener:
    """Background listener that uses IMAP IDLE for real-time email detection."""

    def __init__(self, on_new_email: Callable[[int], None]) -> None:
        """
        Args:
            on_new_email: callback called with the new EXISTS count
                          when a new email is detected
        """
        self.on_new_email = on_new_email
        self.conn: imaplib.IMAP4_SSL | None = None
        self.last_exists: int = 0
        self.running = False
        self.thread: threading.Thread | None = None

    def _connect(self) -> bool:
        """Connect to IMAP and select INBOX."""
        try:
            self.conn = imaplib.IMAP4_SSL(IMAP_SERVER, IMAP_PORT)
            self.conn.login(EMAIL_ADDRESS, EMAIL_PASSWORD)
            status, data = self.conn.select("INBOX")
            if status != "OK":
                logger.error("IDLE: select INBOX fallito: %s", status)
                return False
            self.last_exists = int(data[0]) if data and data[0] else 0
            logger.info("IDLE: connesso, INBOX ha %d messaggi", self.last_exists)
            return True
        except Exception as e:
            logger.error("IDLE: connessione fallita: %s", e)
            return False

    def _disconnect(self) -> None:
        """Close IMAP connection."""
        if self.conn:
            try:
                self.conn.logout()
            except Exception:
                pass
            self.conn = None

    def _send_idle(self) -> bool:
        """Send IDLE command. Returns True if accepted by server."""
        try:
            tag = self.conn._new_tag()
            self.conn.send(b"%s IDLE\r\n" % tag)
            # Wait for "+ idling" response
            resp = self.conn.readline()
            if b"+" in resp or b"idling" in resp.lower():
                logger.debug("IDLE: comando accettato, in ascolto...")
                return True
            logger.warning("IDLE: risposta inattesa: %s", resp)
            return False
        except Exception as e:
            logger.error("IDLE: errore invio comando: %s", e)
            return False

    def _send_done(self) -> None:
        """Send DONE to exit IDLE state."""
        try:
            self.conn.send(b"DONE\r\n")
            # Read until tagged response
            for _ in range(10):
                line = self.conn.readline()
                if not line or line.startswith(b"A"):
                    break
        except Exception as e:
            logger.debug("IDLE: errore DONE: %s", e)

    def _wait_for_event(self, timeout: float) -> str | None:
        """
        Wait for an untagged response (EXISTS, EXPUNGE, etc.) or timeout.
        Returns the event type or None if timeout.
        """
        try:
            self.conn.sock.settimeout(timeout)
            line = self.conn.readline()
            if not line:
                return None
            line_str = line.decode("utf-8", errors="replace").strip()
            logger.debug("IDLE event: %s", line_str)

            if "EXISTS" in line_str:
                # Parse: "* 123 EXISTS"
                parts = line_str.split()
                if len(parts) >= 3 and parts[0] == "*":
                    try:
                        new_count = int(parts[1])
                        return f"EXISTS:{new_count}"
                    except ValueError:
                        pass
            elif "EXPUNGE" in line_str:
                return "EXPUNGE"
            return "OTHER"
        except (socket.timeout, TimeoutError):
            return None
        except Exception as e:
            logger.error("IDLE: errore lettura: %s", e)
            return "ERROR"

    def _idle_loop(self) -> None:
        """Main IDLE loop. Reconnects on errors."""
        while self.running:
            if not self.conn:
                if not self._connect():
                    logger.warning("IDLE: retry connessione tra 30s...")
                    time.sleep(30)
                    continue

            # Send IDLE
            if not self._send_idle():
                self._disconnect()
                time.sleep(10)
                continue

            # Wait for events or timeout
            start = time.time()
            while self.running and (time.time() - start) < IDLE_TIMEOUT_SECONDS:
                event = self._wait_for_event(timeout=60)  # Check every 60s

                if event is None:
                    # Timeout normale, continua ad attendere
                    continue

                if event == "ERROR":
                    logger.warning("IDLE: errore evento, reconnect")
                    break

                if event.startswith("EXISTS:"):
                    new_count = int(event.split(":")[1])
                    if new_count > self.last_exists:
                        diff = new_count - self.last_exists
                        logger.info("IDLE: %d nuove email rilevate (totale: %d)", diff, new_count)
                        self.last_exists = new_count
                        # Exit IDLE per processare
                        self._send_done()
                        # Trigger processing in separate thread
                        try:
                            t = threading.Thread(
                                target=self.on_new_email,
                                args=(diff,),
                                daemon=True,
                            )
                            t.start()
                        except Exception as e:
                            logger.error("IDLE: errore callback: %s", e)
                        # Re-enter IDLE after processing trigger
                        if not self._send_idle():
                            break
                        start = time.time()  # Reset timeout

            # Re-auth periodica
            if self.running:
                logger.info("IDLE: re-auth dopo %d minuti", IDLE_TIMEOUT_SECONDS // 60)
                self._send_done()
                self._disconnect()

    def start(self) -> None:
        """Start the IDLE listener in a background thread."""
        if self.running:
            return
        self.running = True
        self.thread = threading.Thread(target=self._idle_loop, daemon=True)
        self.thread.start()
        logger.info("IDLE listener avviato")

    def stop(self) -> None:
        """Stop the listener."""
        self.running = False
        self._send_done()
        self._disconnect()
        logger.info("IDLE listener fermato")
