/**
 * CustomerCareAgent — Frontend Gmail-like
 * SPA con hash routing, fetch API, DOM rendering
 */

// ── State ──
const state = {
    currentFolder: 'inbox',
    currentQA: '',       // quick action filter
    currentCat: '',      // category filter
    currentPay: '',      // payment method filter
    currentPrio: '',     // priority filter
    emails: [],
    total: 0,
    page: 1,
    pages: 1,
    limit: 50,
    search: '',
    selectedEmail: null, // uid dell'email aperta
    lastThread: [],       // last thread loaded
    currentDraft: null,  // full draft detail when a draft is open (ground truth for edit/send/delete)
    folders: {},
    quickActions: {},
};

// ── DOM refs ──
const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

const dom = {
    emailList: () => $('#emailList'),
    emailDetail: () => $('#emailDetail'),
    toolbar: () => $('#toolbar'),
    searchInput: () => $('#searchInput'),
    currentFolder: () => $('#currentFolder'),
    emailCount: () => $('#emailCount'),
    pageInfo: () => $('#pageInfo'),
    inboxBadge: () => $('#inboxBadge'),
    draftsBadge: () => $('#draftsBadge'),
    sentBadge: () => $('#sentBadge'),
    spamBadge: () => $('#spamBadge'),
    starredBadge: () => $('#starredBadge'),
    contextMini: () => $('#contextMini'),
    refreshInfo: () => $('#refreshInfo'),
    composeOverlay: () => $('#composeOverlay'),
};

// ── Category labels ──
const QA_LABELS = {
    cambio_indirizzo: 'Address Change',
    cambio_taglia: 'Size Exchange',
    cambio_colore: 'Color Exchange',
    cancellazione: 'Cancellation',
    modifica_ordine: 'Order Modification',
};

const CATEGORY_LABELS = {
    where_is_my_order: 'Where is my order',
    size_exchange: 'Size exchange',
    color_exchange: 'Color exchange',
    return_request: 'Return/Refund',
    damaged_item: 'Damaged item',
    cancellation: 'Cancellation',
    address_change: 'Address change',
    customs_issue: 'Customs',
    pre_sale_question: 'Pre-sale',
    complaint: 'Complaint',
    payment_issue: 'Payment',
    where_is_my_order_klarna: 'Klarna order',
    refund_status: 'Refund status',
    duplicate_charge: 'Duplicate charge',
    other: 'Other',
};

// ── Instant UI refresh: read from server in-memory cache (already updated by mutation handler) ──
// No IMAP round-trip — the handlers for DELETE/send/read/star update store cache synchronously.
async function quickRefresh(_folder) {
    await Promise.all([loadAndRender(), fetchFolders()]);
}

// ── Toast notifications ──
function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);
    requestAnimationFrame(() => toast.classList.add('toast-visible'));
    setTimeout(() => {
        toast.classList.remove('toast-visible');
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}

// ── API calls ──
async function api(endpoint, options = {}) {
    try {
        const resp = await fetch(endpoint, options);
        if (!resp.ok) {
            // Try to propagate FastAPI error detail if present
            try {
                const errBody = await resp.json();
                return { error: true, status: resp.status, detail: errBody.detail || `HTTP ${resp.status}` };
            } catch (_) {
                return { error: true, status: resp.status, detail: `HTTP ${resp.status}` };
            }
        }
        return await resp.json();
    } catch (e) {
        console.error('API error:', endpoint, e);
        return null;
    }
}

async function fetchEmails() {
    let folder = state.currentFolder;
    if (state.currentQA) folder = 'inbox';

    // Trash: use dedicated endpoint (not cached)
    if (folder === 'trash') {
        const data = await api('/api/trash-list');
        if (!data || !data.emails) return;
        state.emails = data.emails;
        state.total = data.total;
        state.pages = 1;
        return;
    }

    const isAllQA = state.currentQA === '__all_qa__';
    const params = new URLSearchParams({
        folder,
        page: isAllQA ? 1 : state.page,
        limit: isAllQA ? 200 : state.limit,
        search: state.search,
        category: state.currentCat || '',
    });
    if (state.currentQA && !isAllQA) {
        params.set('quick_action', state.currentQA);
    }
    if (state.currentPay) {
        params.set('payment', state.currentPay);
    }
    if (state.currentPrio) {
        params.set('priority', state.currentPrio);
    }
    const data = await api(`/api/emails?${params}`);
    if (!data) return;

    state.emails = data.emails;
    state.total = data.total;
    state.pages = data.pages;

    // Only client-side filter for __all_qa__ which combines all categories
    if (isAllQA) {
        state.emails = state.emails.filter(e => e.quick_action);
        state.total = state.emails.length;
    }
}

async function fetchFolders() {
    const data = await api('/api/folders');
    if (!data) return;
    state.folders = data;
    renderFolderCounts();
    renderCategorySidebar();
}

async function fetchQuickActions() {
    const data = await api('/api/quick-actions');
    if (!data) return;
    state.quickActions = data;
    renderQASubItems();
}

async function fetchContext() {
    const data = await api('/api/context');
    if (!data) return;
    renderContext(data);
}

async function fetchEmailDetail(uid) {
    const data = await api(`/api/emails/${uid}`);
    if (!data) return null;
    return data;
}

// ── Rendering ──

// Decrement all relevant badges when an email transitions from unread to read.
// Starred and drafts are NOT touched: they show totals, not unread counts.
function decrementBadgesForEmail(e) {
    const decEl = (el) => {
        if (!el) return;
        const cur = parseInt(el.textContent || '0', 10);
        el.textContent = cur > 1 ? String(cur - 1) : '';
    };
    // Inbox
    decEl(dom.inboxBadge());
    // Priority
    const prioMap = { critical: 'prioCriticalBadge', high: 'prioHighBadge', medium: 'prioMediumBadge', low: 'prioLowBadge' };
    const prio = e.priority || 'medium';
    decEl(document.getElementById(prioMap[prio]));
    // Payment
    const payMap = { Carta: 'payCartaBadge', Klarna: 'payKlarnaBadge', PayPal: 'payPayPalBadge' };
    if (e.payment_method && payMap[e.payment_method]) {
        decEl(document.getElementById(payMap[e.payment_method]));
    }
    // Categoria (sidebar dinamica)
    if (e.auto_category) {
        const catEl = document.querySelector(`.cat-nav-item[data-category="${e.auto_category}"] .badge`);
        decEl(catEl);
    }
    // Keep state.folders in sync so the next render doesn't flash stale values
    if (state.folders) {
        if (typeof state.folders.inbox_unread === 'number') {
            state.folders.inbox_unread = Math.max(0, state.folders.inbox_unread - 1);
        }
        if (typeof state.folders.inbox === 'number') {
            state.folders.inbox = Math.max(0, state.folders.inbox - 1);
        }
        if (state.folders.priority_counts && typeof state.folders.priority_counts[prio] === 'number') {
            state.folders.priority_counts[prio] = Math.max(0, state.folders.priority_counts[prio] - 1);
        }
        if (e.auto_category && state.folders.category_counts && typeof state.folders.category_counts[e.auto_category] === 'number') {
            state.folders.category_counts[e.auto_category] = Math.max(0, state.folders.category_counts[e.auto_category] - 1);
        }
        if (e.payment_method && state.folders.payment_counts && typeof state.folders.payment_counts[e.payment_method] === 'number') {
            state.folders.payment_counts[e.payment_method] = Math.max(0, state.folders.payment_counts[e.payment_method] - 1);
        }
        if (e.quick_action && typeof state.folders.quick_actions === 'number') {
            state.folders.quick_actions = Math.max(0, state.folders.quick_actions - 1);
        }
    }
}

function renderFolderCounts() {
    const f = state.folders;
    dom.inboxBadge().textContent = f.inbox_unread || '';
    dom.draftsBadge().textContent = f.drafts || '';
    dom.sentBadge().textContent = f.sent || '';
    dom.spamBadge().textContent = f.spam || '';
    dom.starredBadge().textContent = f.starred || '';
    // Payment counts
    const pc = f.payment_counts || {};
    const $$pay = (id, key) => { const el = document.getElementById(id); if (el) el.textContent = pc[key] || ''; };
    $$pay('payCartaBadge', 'Carta');
    $$pay('payKlarnaBadge', 'Klarna');
    $$pay('payPayPalBadge', 'PayPal');
    // Priority counts
    const pcount = f.priority_counts || {};
    const setBadge = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v || ''; };
    setBadge('prioCriticalBadge', pcount.critical);
    setBadge('prioHighBadge', pcount.high);
    setBadge('prioMediumBadge', pcount.medium);
    setBadge('prioLowBadge', pcount.low);

    dom.refreshInfo().textContent = `Agg. ${f.last_refresh || ''}`;
}

function renderQASubItems() {
    const container = dom.qaSubItems();
    container.innerHTML = '';
    const icons = {
        cambio_indirizzo: '📍',
        cambio_taglia: '📏',
        cambio_colore: '🎨',
        cancellazione: '❌',
        modifica_ordine: '✏️',
    };
    for (const [catId, cat] of Object.entries(state.quickActions)) {
        if (cat.count === 0) continue;
        const a = document.createElement('a');
        a.className = 'nav-item';
        a.dataset.qa = catId;
        a.href = `#qa/${catId}`;
        a.innerHTML = `
            <span>${icons[catId] || '•'} ${cat.label}</span>
            <span class="badge">${cat.count}</span>
        `;
        container.appendChild(a);
    }
}

function renderContext(data) {
    const el = dom.contextMini();
    if (!data || !data.date) {
        el.innerHTML = '<em>No report available</em>';
        return;
    }
    const r = data.report;
    if (!r) return;

    const cause = r.cause_rimborsi?.top_3 || [];
    const causeHtml = cause.map(c => `${c.categoria}: <strong>${c.conteggio}</strong>`).join('<br>');

    el.innerHTML = `
        <strong>${data.date}</strong> — ${data.total_received} emails<br>
        ${r.volumi?.clienti_unici || '?'} unique customers<br>
        <br>
        <strong>Top issues:</strong><br>
        ${causeHtml}
        <br><br>
        <strong>Frustration:</strong> ${r.frustrazione?.alta_pct || 0}% high
    `;
}

// ── Email row HTML generation (reusable) ──
function emailRowHTML(e) {
    const unread = !e.is_read ? 'unread' : '';
    const starred = e.is_starred ? 'starred' : '';
    const qaHighlight = e.quick_action ? 'qa-highlight' : '';
    const qaTag = e.quick_action
        ? `<span class="email-qa-tag">${(QA_LABELS[e.quick_action] || e.quick_action.replace('_', ' '))}</span>`
        : '';

    return `
    <div class="email-row ${unread} ${qaHighlight}" data-uid="${e.uid}" data-priority="${e.priority || 'medium'}">
        <div class="email-check"><input type="checkbox" data-uid="${e.uid}"></div>
        <span class="email-unread-dot ${e.is_read ? 'read' : ''}"></span>
        <button class="email-star ${starred}" data-uid="${e.uid}">${e.is_starred ? '&#9733;' : '&#9734;'}</button>
        <div class="email-from" title="${esc(state.currentFolder === 'drafts' || state.currentFolder === 'sent' ? 'To: ' + e.to_addr : e.from_addr)}">${
            state.currentFolder === 'drafts' || state.currentFolder === 'sent'
                ? '<span class="to-prefix">To:</span> ' + esc(extractName(e.to_addr) || '(no recipient)')
                : (isFromUs(e.from_addr) ? '<span class="us-badge">US</span> ' : '') + esc(e.from_name || e.from_addr)
        }</div>
        <div class="email-content">
            <span class="email-subject">${esc(e.subject)}</span>
            <span class="email-separator"> — </span>
            <span class="email-preview">${esc(e.preview)}</span>
        </div>
        ${qaTag}
        ${e.auto_category && e.auto_category !== 'other' && !e.quick_action ? '<span class="email-cat-tag">' + (CATEGORY_LABELS[e.auto_category] || e.auto_category).substring(0, 12) + '</span>' : ''}
        ${e.priority === 'critical' ? '<span class="email-prio-badge critical">CRITICAL</span>' : ''}
        ${e.priority === 'high' ? '<span class="email-prio-badge high">HIGH</span>' : ''}
        ${e.has_draft ? '<span class="email-draft-badge">Draft</span>' : ''}
        ${e.is_ai_generated ? '<span class="ai-generated-tag">AI</span>' : ''}
        ${e.payment_method ? '<span class="ai-tag payment-' + e.payment_method.toLowerCase() + '" style="font-size:9px;padding:1px 6px;">' + e.payment_method + '</span>' : ''}
        ${e._was_sent === 1 ? '<span class="ai-status-tag sent">Sent</span>' : ''}
        ${e._was_sent === 0 && e._draft_id ? '<span class="ai-status-tag pending">To send</span>' : ''}
        <div class="email-date">${formatEmailDate(e.date_display)}</div>
    </div>`;
}

// ── Update list header (folder label, count, pagination) ──
function updateListHeader() {
    const folderLabels = {
        inbox: 'Inbox', sent: 'Sent', drafts: 'Drafts',
        spam: 'Spam', starred: 'Starred', all: 'All emails',
    };
    let folderLabel = folderLabels[state.currentFolder] || state.currentFolder;
    if (state.currentPrio) {
        folderLabel = 'Priority: ' + state.currentPrio.charAt(0).toUpperCase() + state.currentPrio.slice(1);
    } else if (state.currentPay) {
        folderLabel = 'Payment ' + state.currentPay;
    } else if (state.currentCat && CATEGORY_LABELS[state.currentCat]) {
        folderLabel = CATEGORY_LABELS[state.currentCat];
    } else if (state.currentQA && state.quickActions[state.currentQA]) {
        folderLabel = state.quickActions[state.currentQA].label;
    }
    dom.currentFolder().textContent = folderLabel;
    dom.emailCount().textContent = `(${state.total})`;
    dom.pageInfo().textContent = state.pages > 1 ? `${state.page}/${state.pages}` : '';
}

// ── Detect if an email row needs DOM update ──
function emailChanged(a, b) {
    return a.is_read !== b.is_read
        || a.is_starred !== b.is_starred
        || a.preview !== b.preview
        || a.has_draft !== b.has_draft
        || a.priority !== b.priority
        || a.is_ai_generated !== b.is_ai_generated
        || a._was_sent !== b._was_sent;
}

// ── Update a single row in-place without replacing it ──
function updateRowInPlace(row, email) {
    row.classList.toggle('unread', !email.is_read);
    const dot = row.querySelector('.email-unread-dot');
    if (dot) dot.classList.toggle('read', email.is_read);
    const star = row.querySelector('.email-star');
    if (star) {
        star.classList.toggle('starred', email.is_starred);
        star.innerHTML = email.is_starred ? '&#9733;' : '&#9734;';
    }
    row.dataset.priority = email.priority || 'medium';
    // Priority badges
    const existingPrio = row.querySelector('.email-prio-badge');
    if (email.priority === 'critical' && !existingPrio) {
        row.querySelector('.email-date').insertAdjacentHTML('beforebegin', '<span class="email-prio-badge critical">CRITICAL</span>');
    } else if (email.priority === 'high' && !existingPrio) {
        row.querySelector('.email-date').insertAdjacentHTML('beforebegin', '<span class="email-prio-badge high">HIGH</span>');
    } else if (existingPrio && email.priority !== 'critical' && email.priority !== 'high') {
        existingPrio.remove();
    }
    // Draft badge
    const draftBadge = row.querySelector('.email-draft-badge');
    if (email.has_draft && !draftBadge) {
        row.querySelector('.email-date').insertAdjacentHTML('beforebegin', '<span class="email-draft-badge">Draft</span>');
    } else if (!email.has_draft && draftBadge) {
        draftBadge.remove();
    }
}

// ── Incremental patch: only update changed rows ──
function patchEmailList(oldEmails, newEmails) {
    const container = dom.emailList();
    const oldMap = new Map(oldEmails.map(e => [e.uid, e]));
    const newMap = new Map(newEmails.map(e => [e.uid, e]));

    updateListHeader();

    if (newEmails.length === 0) {
        container.innerHTML = '<div class="empty-state">No emails</div>';
        return;
    }

    // Remove rows not in new set (with animation)
    container.querySelectorAll('.email-row').forEach(row => {
        if (!newMap.has(row.dataset.uid)) {
            row.classList.add('email-row-removing');
            setTimeout(() => row.remove(), 200);
        }
    });

    // Build ordered list of new UIDs
    const newUids = newEmails.map(e => e.uid);

    // Update existing or insert new rows
    let prevElement = container.querySelector('.qa-section-header') || null;
    for (const uid of newUids) {
        const existingRow = container.querySelector(`.email-row[data-uid="${uid}"]`);
        const newEmail = newMap.get(uid);
        const oldEmail = oldMap.get(uid);

        if (existingRow) {
            if (!oldEmail || emailChanged(oldEmail, newEmail)) {
                updateRowInPlace(existingRow, newEmail);
            }
            // Ensure order: move row after prevElement if not already there
            const expectedNext = prevElement ? prevElement.nextElementSibling : container.firstElementChild;
            if (existingRow !== expectedNext) {
                if (prevElement) {
                    prevElement.after(existingRow);
                } else {
                    container.prepend(existingRow);
                }
            }
            prevElement = existingRow;
        } else {
            // New email — create and insert with animation
            const temp = document.createElement('div');
            temp.innerHTML = emailRowHTML(newEmail);
            const newRow = temp.firstElementChild;
            newRow.classList.add('email-row-entering');
            if (prevElement) {
                prevElement.after(newRow);
            } else {
                container.prepend(newRow);
            }
            prevElement = newRow;
            requestAnimationFrame(() => {
                requestAnimationFrame(() => newRow.classList.remove('email-row-entering'));
            });
        }
    }
}

// ── Full render (used on first load and navigation changes) ──
function renderEmailList() {
    const container = dom.emailList();
    const emails = state.emails;

    updateListHeader();

    if (emails.length === 0) {
        container.innerHTML = '<div class="empty-state">No emails</div>';
        return;
    }

    let html = '';
    if (state.currentQA) {
        const qa = state.quickActions[state.currentQA];
        html += `<div class="qa-section-header">
            <span class="qa-dot ${state.currentQA}"></span>
            ${qa?.label || state.currentQA} — ${emails.length} email
        </div>`;
    }
    for (const e of emails) {
        html += emailRowHTML(e);
    }
    container.innerHTML = html;

    // Checkbox change handlers
    container.querySelectorAll('.email-check input').forEach(cb => {
        cb.addEventListener('change', () => updateToolbarActions());
    });

    // Click handlers
    container.querySelectorAll('.email-row').forEach(row => {
        row.addEventListener('click', (ev) => {
            if (ev.target.closest('.email-check')) return;
            if (ev.target.closest('.email-star')) {
                toggleStar(ev.target.closest('.email-star'));
                return;
            }
            openEmail(row.dataset.uid);
        });
    });
}



function formatEmailDate(dateDisplay) {
    if (!dateDisplay) return '';
    // Format from backend: "Gio 10/04 16:30"
    const parts = dateDisplay.trim().split(' ');
    if (parts.length >= 3) {
        const day = parts[0];
        const date = parts[1];
        const time = parts[2];
        return `<span class="email-date-small">${day} ${date}</span><span class="email-date-time">${time}</span>`;
    }
    return `<span class="email-date-time">${dateDisplay}</span>`;
}


function extractName(addr) {
    if (!addr) return '';
    // "Name <email>" → "Name"
    const m = addr.match(/^([^<]+?)\s*<([^>]+)>/);
    if (m) {
        const name = m[1].trim().replace(/^["']|["']$/g, '');
        return name || m[2].split('@')[0];
    }
    // Just "email" → before @
    if (addr.includes('@')) return addr.split('@')[0];
    return addr;
}

// Helper: detect if email is from us (own brand domain)
function isFromUs(addr) {
    if (!addr) return false;
    const a = addr.toLowerCase();
    const domain = (window.BRAND && window.BRAND.domain ? window.BRAND.domain : '').toLowerCase();
    const support = (window.BRAND && window.BRAND.support_email ? window.BRAND.support_email : '').toLowerCase();
    if (domain && a.includes(domain)) return true;
    if (support && a.includes(support)) return true;
    return false;
}

// Colori avatar per thread (rotazione)
const AVATAR_COLORS = ['#1a73e8', '#188038', '#e37400', '#d93025', '#9334e6', '#1967d2', '#137333', '#b06000'];

function avatarColor(name) {
    let hash = 0;
    for (let i = 0; i < name.length; i++) hash = name.charCodeAt(i) + ((hash << 5) - hash);
    return AVATAR_COLORS[Math.abs(hash) % AVATAR_COLORS.length];
}


async function openAIDraft(draftId) {
    const draft = await api(`/api/ai-drafts/${draftId}`);
    if (!draft) return;

    // Hide list, show detail
    dom.emailList().style.display = 'none';
    dom.toolbar().style.display = 'none';
    dom.emailDetail().style.display = 'block';

    // Set subject
    $('#detailSubject').textContent = draft.subject || '(no subject)';
    $('#threadCount').textContent = '';

    // Build a thread-like view: customer email + AI draft
    const container = $('#threadContainer');
    const fromName = draft.from_addr ? draft.from_addr.split('@')[0].split('<').pop() : '?';
    const initial = fromName[0]?.toUpperCase() || '?';
    const color = avatarColor(fromName);

    // Customer email block
    const customerBody = cleanPlainText(draft.customer_body || '');

    // AI draft block (formatted)
    const aiDraftBody = cleanPlainText(draft.ai_draft || '');
    const ctxBody = (draft.context || '').replace(/</g, '&lt;').replace(/>/g, '&gt;');

    // Status
    const statusBadge = draft.was_sent
        ? '<span class="ai-status-tag sent">Sent</span>'
        : (draft.was_discarded ? '<span class="ai-status-tag pending">Discarded</span>' : '<span class="ai-status-tag pending">To send</span>');

    container.innerHTML = `
        <div class="thread-msg expanded">
            <div class="thread-msg-header">
                <div class="thread-avatar" style="background:${color}">${initial}</div>
                <div class="thread-meta">
                    <div class="thread-from">${esc(draft.from_addr)}</div>
                    <div class="thread-preview">Email originale del cliente</div>
                </div>
                <div class="thread-date">${(draft.created_at || '').substring(0, 16)}</div>
            </div>
            <div class="thread-body plain-text">${customerBody}</div>
        </div>

        <div class="ai-panel" style="display:block; margin: 16px 24px;">
            <div class="ai-panel-header">
                <span class="ai-label">AI Draft</span>
                <div class="ai-tags">
                    <span class="ai-tag category">${(draft.category || '').replace(/_/g, ' ')}</span>
                    <span class="ai-tag sentiment-${draft.sentiment}">${draft.sentiment || ''}</span>
                    <span class="ai-tag urgency-${draft.urgency}">urgency: ${draft.urgency || ''}</span>
                    <span class="ai-tag language">${draft.language || ''}</span>
                    <span class="ai-tag confidence">${Math.round((draft.confidence || 0) * 100)}%</span>
                    ${draft.order_id ? '<span class="ai-tag category">' + draft.order_id + '</span>' : ''}
                    ${statusBadge}
                </div>
            </div>
            ${draft.summary ? '<div style="font-size:12px;color:#5f6368;margin-bottom:12px;"><strong>Riassunto:</strong> ' + esc(draft.summary) + '</div>' : ''}
            <details style="margin-bottom:12px;">
                <summary style="cursor:pointer;font-size:12px;color:#1a73e8;">Mostra contesto Shopify/tracking</summary>
                <div class="ai-context" style="display:block;margin-top:8px;">${ctxBody}</div>
            </details>
            <div class="ai-draft-body">${aiDraftBody}</div>
            <div class="ai-actions">
                <button class="ai-use-btn" onclick="useAIDraftFromView('${draft.from_addr.replace(/'/g, '&apos;')}', '${(draft.subject || '').replace(/'/g, '&apos;')}', \`${draft.ai_draft.replace(/`/g, '\`').replace(/\$/g, '\$')}\`, '${draft.message_id || ''}')">Use as reply</button>
                <button class="ai-toggle-ctx" onclick="copyDraftToClipboard()" id="copyDraftBtn">Copia testo</button>
            </div>
        </div>
    `;

    // Store for the copy/use buttons
    window._currentDraft = draft;

    // Update reply data
    $('#composeReplyTo').value = draft.message_id || '';
    $('#composeReferences').value = draft.message_id || '';
}

function useAIDraftFromView(toAddr, subject, body, messageId) {
    const draft = window._currentDraft;
    if (!draft) return;
    // Extract clean email
    const emailMatch = (toAddr || '').match(/<([^>]+)>/);
    const cleanEmail = emailMatch ? emailMatch[1] : (toAddr || '').replace(/[<>]/g, '');
    const re = subject.startsWith('Re:') ? subject : 'Re: ' + subject;
    openCompose({
        from_addr: cleanEmail,
        subject: subject,
        message_id: messageId || '',
        references: messageId || '',
    });
    $('#composeBody').value = draft.ai_draft;
}

function copyDraftToClipboard() {
    const draft = window._currentDraft;
    if (!draft) return;
    navigator.clipboard.writeText(draft.ai_draft).then(() => {
        const btn = document.getElementById('copyDraftBtn');
        if (btn) {
            btn.textContent = 'Copied!';
            setTimeout(() => { btn.textContent = 'Copy text'; }, 2000);
        }
    });
}

async function openEmail(uid) {
    state.selectedEmail = uid;
    state.lastThread = [];  // reset to prevent stale reply data
    state.currentDraft = null;  // reset draft context

    // If opening a draft, pre-load its full detail so Edit/Send/Delete have ground truth data
    if (state.currentFolder === 'drafts') {
        const detail = await fetchEmailDetail(uid);
        if (detail) {
            state.currentDraft = detail;
        }
    }

    // Special handling for AI drafts folder
    if (state.currentFolder === 'ai-drafts') {
        const emailInList = state.emails.find(e => e.uid === uid);
        if (emailInList && emailInList._draft_id) {
            await openAIDraft(emailInList._draft_id);
            return;
        }
    }

    // Mark as read
    api(`/api/read/${uid}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ folder: state.currentFolder, read: true }),
    }).then(() => fetchFolders());

    // Optimistic update: mark as read locally before server confirms
    const emailInList = state.emails.find(e => e.uid === uid);
    if (emailInList && !emailInList.is_read) {
        emailInList.is_read = true;
        decrementBadgesForEmail(emailInList);
    }

    // Hide list, show detail
    dom.emailList().style.display = 'none';
    dom.toolbar().style.display = 'none';
    dom.emailDetail().style.display = 'block';

    // Fetch thread
    const threadData = await api(`/api/thread/${uid}`);
    const thread = threadData?.thread || [];

    if (thread.length === 0) {
        // Fallback: single message
        const detail = await fetchEmailDetail(uid);
        if (!detail) return;
        renderThread([detail], detail);
        return;
    }

    // The clicked email for the subject
    state.lastThread = thread;
    const clicked = thread.find(e => e.uid === uid) || thread[thread.length - 1];
    renderThread(thread, clicked);
}

// Customer info panel: fetch and render asynchronously
async function loadCustomerPanel(clicked, thread) {
    const panel = document.getElementById('gmCustomerPanel');
    if (!panel) return;
    // Determine customer email (first non-us message's from_addr)
    let customerEmail = '';
    for (const m of thread) {
        if (!isFromUs(m.from_addr)) {
            const match = (m.from_addr || '').match(/<([^>]+)>/);
            customerEmail = match ? match[1] : (m.from_addr || '').trim();
            if (customerEmail) break;
        }
    }
    if (!customerEmail) {
        const toRaw = clicked.to_addr || '';
        const match = toRaw.match(/<([^>]+)>/);
        customerEmail = match ? match[1] : toRaw.trim();
    }
    if (!customerEmail || isFromUs(customerEmail)) {
        panel.innerHTML = '';
        panel.style.display = 'none';
        return;
    }

    panel.style.display = 'block';
    panel.innerHTML = '<div class="gm-cust-loading">Loading customer info…</div>';

    // Collect body + subject from all customer messages in the thread (to find order IDs)
    let combinedBody = '';
    let combinedSubject = '';
    for (const m of thread) {
        if (!isFromUs(m.from_addr)) {
            combinedBody += (m.body || '') + '\n';
            combinedSubject += (m.subject || '') + ' ';
        }
    }
    // Always include clicked subject
    combinedSubject += ' ' + (clicked.subject || '');

    const data = await api('/api/customer-info', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            email: customerEmail,
            body: combinedBody.substring(0, 4000),
            subject: combinedSubject.substring(0, 500),
        }),
    });
    if (!data || data.error) {
        panel.innerHTML = `<div class="gm-cust-empty">No customer data for <strong>${esc(customerEmail)}</strong></div>`;
        return;
    }

    if (!data.found) {
        panel.innerHTML = `
            <div class="gm-cust-card gm-cust-new">
                <div class="gm-cust-avatar-big">${esc((customerEmail[0] || '?').toUpperCase())}</div>
                <div class="gm-cust-info">
                    <div class="gm-cust-name">New customer</div>
                    <div class="gm-cust-email">${esc(customerEmail)}</div>
                    <div class="gm-cust-stats">
                        <span class="gm-cust-stat"><strong>0</strong> orders</span>
                        <span class="gm-cust-sep">·</span>
                        <span class="gm-cust-new-badge">FIRST CONTACT</span>
                    </div>
                </div>
            </div>`;
        return;
    }

    const fullName = data.full_name || customerEmail.split('@')[0];
    const initial = (fullName[0] || '?').toUpperCase();
    const last = data.last_order;
    const prev = data.previous_orders || [];

    let itemsHtml = '';
    if (last && last.items && last.items.length) {
        itemsHtml = '<div class="gm-cust-items">' + last.items.slice(0, 5).map(it => {
            const variant = it.variant ? ' <span class="gm-cust-variant">' + esc(it.variant) + '</span>' : '';
            const qty = it.qty > 1 ? ' <span class="gm-cust-qty">×' + it.qty + '</span>' : '';
            return '<div class="gm-cust-item">• ' + esc(it.title) + variant + qty + '</div>';
        }).join('') + '</div>';
    }

    let prevHtml = '';
    if (prev.length > 0) {
        prevHtml = '<div class="gm-cust-prev">Previous: ' + prev.map(p => {
            const st = p.fulfillment_status === 'fulfilled' ? '✓' : '…';
            return `<span class="gm-cust-prev-order" title="${esc(p.date)} · ${p.total} ${esc(p.currency)}">${esc(p.name)} ${st}</span>`;
        }).join(' ') + '</div>';
    }

    const lastSourceBadge = last && last.source === 'body' ? '<span class="gm-cust-src-body" title="Order ID found in email body">🔍 from body</span>' : '';
    const lastOrderLine = last ? `
        <div class="gm-cust-last-order">
            <div class="gm-cust-last-head">
                <strong>${esc(last.name)}</strong>
                <span class="gm-cust-date">${esc(last.date)}</span>
                <span class="gm-cust-total">${last.total.toFixed(2)} ${esc(last.currency)}</span>
                ${last.payment ? `<span class="gm-cust-pay">${esc(last.payment)}</span>` : ''}
                <span class="gm-cust-fulfill gm-fulfill-${last.fulfillment_status}">${esc(last.fulfillment_status)}</span>
                ${lastSourceBadge}
            </div>
            ${itemsHtml}
        </div>` : '';

    // Email mismatch warning
    const mismatchWarn = data.email_mismatch ? `
        <div class="gm-cust-mismatch">
            ⚠️ Writes from <code>${esc(customerEmail)}</code> but orders are on <code>${esc(data.customer_email_on_record)}</code>
        </div>` : '';

    panel.innerHTML = `
        <div class="gm-cust-card">
            <div class="gm-cust-avatar-big">${esc(initial)}</div>
            <div class="gm-cust-info">
                <div class="gm-cust-name">${esc(fullName)}</div>
                <div class="gm-cust-email">${esc(customerEmail)}${data.city || data.country ? ' · ' + esc([data.city, data.country].filter(Boolean).join(', ')) : ''}</div>
                <div class="gm-cust-stats">
                    <span class="gm-cust-stat"><strong>${data.total_orders}</strong> order${data.total_orders > 1 ? 's' : ''}</span>
                    <span class="gm-cust-sep">·</span>
                    <span class="gm-cust-stat">LTV <strong>${data.total_spent.toFixed(2)} ${esc(data.currency)}</strong></span>
                    ${data.total_orders >= 3 ? '<span class="gm-cust-sep">·</span><span class="gm-cust-vip">REPEAT CUSTOMER</span>' : ''}
                </div>
                ${mismatchWarn}
                ${lastOrderLine}
                ${prevHtml}
            </div>
        </div>`;
}


function renderThread(thread, clicked) {
    // Strip Re:/Fwd: prefixes for clean subject display
    let subject = (clicked.subject || '').replace(/^(Re|Fwd|Fw|R|I)\s*:\s*/i, '').replace(/^(Re|Fwd|Fw|R|I)\s*:\s*/i, '').trim() || '(no subject)';
    $('#detailSubject').textContent = subject;
    const tc = $('#threadCount');
    if (tc) tc.textContent = thread.length > 1 ? `${thread.length}` : '';

    // Top badges (category, priority, order, payment)
    const topBadgesEl = $('#detailTopBadges');
    if (topBadgesEl) {
        const badges = [];
        const cat = clicked.auto_category || '';
        if (cat) {
            const label = CATEGORY_LABELS[cat] || cat;
            badges.push(`<span class="gm-label gm-label-cat">${esc(label)}</span>`);
        }
        const prio = clicked.priority || '';
        if (prio && prio !== 'medium') {
            badges.push(`<span class="gm-label gm-label-prio prio-${prio}">${esc(prio.toUpperCase())}</span>`);
        }
        const orderMatch = ((clicked.subject || '') + ' ' + (clicked.preview || '') + ' ' + (clicked.body || '').substring(0, 500)).match(/#?LS\d{4,6}/i);
        if (orderMatch) {
            badges.push(`<span class="gm-label gm-label-order">${esc(orderMatch[0])}</span>`);
        }
        const pay = clicked.payment_method || '';
        if (pay) {
            badges.push(`<span class="gm-label gm-label-pay pay-${pay.toLowerCase()}">${esc(pay)}</span>`);
        }
        topBadgesEl.innerHTML = badges.join(' ');
    }

    // Second row: thread metadata (participants + message count + date range)
    const summaryEl = $('#detailSummary');
    if (summaryEl) {
        const parts = [];
        // Message count
        if (thread.length > 1) {
            parts.push(`<span class="gm-summary-count"><strong>${thread.length}</strong> messages</span>`);
        }
        // Unique participants (non-us)
        const participants = new Set();
        thread.forEach(m => {
            if (!isFromUs(m.from_addr)) {
                const name = m.from_name || (m.from_addr || '').split('<')[0].trim() || m.from_addr;
                if (name) participants.add(name);
            }
        });
        if (participants.size > 0) {
            const pList = Array.from(participants).slice(0, 3).map(p => esc(p));
            if (participants.size > 3) pList.push(`+${participants.size - 3} more`);
            parts.push(`<span class="gm-summary-participants">with <strong>${pList.join(', ')}</strong></span>`);
        }
        // Date range
        const first = thread[0];
        const last = thread[thread.length - 1];
        if (thread.length > 1 && first.date_display && last.date_display && first.date_display !== last.date_display) {
            parts.push(`<span class="gm-summary-dates">${esc(first.date_display)} → ${esc(last.date_display)}</span>`);
        } else if (clicked.date_display) {
            parts.push(`<span class="gm-summary-dates">${esc(clicked.date_display)}</span>`);
        }
        // Unread state
        const unread = thread.filter(m => !m.is_read && m.folder === 'inbox').length;
        if (unread > 0) {
            parts.push(`<span class="gm-summary-unread">${unread} unread</span>`);
        }
        // Has attachments indicator
        const totalAttachments = thread.reduce((n, m) => n + (Array.isArray(m.attachments) ? m.attachments.length : 0), 0);
        if (totalAttachments > 0) {
            parts.push(`<span class="gm-summary-att">📎 ${totalAttachments} attachment${totalAttachments > 1 ? 's' : ''}</span>`);
        }
        summaryEl.innerHTML = parts.join(' <span class="gm-summary-sep">·</span> ');
    }

    const starBtn = $('#detailStarBtn');
    if (starBtn) {
        starBtn.dataset.uid = clicked.uid || '';
        if (clicked.is_starred) {
            starBtn.classList.add('starred');
            starBtn.innerHTML = '&#9733;';
        } else {
            starBtn.classList.remove('starred');
            starBtn.innerHTML = '&#9734;';
        }
    }

    // Load customer info panel asynchronously (Shopify lookup, TTL 10min cache)
    loadCustomerPanel(clicked, thread).catch(() => {});

    const container = $('#threadContainer');
    let html = '';

    thread.forEach((msg, idx) => {
        const isLast = idx === thread.length - 1;
        const isExpanded = isLast;  // Gmail: only last message expanded by default
        const isDraft = msg.folder === 'drafts';
        const isSent = msg.folder === 'sent' || isFromUs(msg.from_addr);

        // Sender info
        const fromName = msg.from_name || msg.from_addr?.split('<')[0]?.trim() || msg.from_addr || 'Unknown';
        const fromMatch = (msg.from_addr || '').match(/<([^>]+)>/);
        const fromEmailClean = fromMatch ? fromMatch[1] : (msg.from_addr || '');
        const initial = (fromName[0] || '?').toUpperCase();
        const color = avatarColor(fromName);

        // Recipient info (who this was sent TO)
        const toRaw = msg.to_addr || '';
        const toMatch = toRaw.match(/<([^>]+)>/);
        const toEmailClean = toMatch ? toMatch[1] : toRaw;
        const isToUs = isFromUs(toEmailClean) || !toEmailClean;
        const toDisplay = isToUs ? 'me' : esc(toEmailClean);

        // Badge label
        let badge = '';
        if (isDraft) badge = '<span class="msg-badge msg-badge-draft">Draft</span>';
        else if (isSent) badge = '<span class="msg-badge msg-badge-sent">You</span>';

        // Date: relative for today, full otherwise
        const fullDate = esc(msg.date_str || msg.date_display || '');
        const shortDate = esc(msg.date_display || msg.date_str?.substring(0, 16) || '');

        // Body
        let bodyContent, isPlain = false;
        if (msg.html_body) {
            bodyContent = msg.html_body;
        } else if (msg.body) {
            bodyContent = cleanPlainText(msg.body);
            isPlain = true;
        } else {
            bodyContent = '<em>No content</em>';
        }

        // Attachments (images + files)
        let attachmentsHtml = '';
        let headerAttBadge = '';
        const allAtts = Array.isArray(msg.attachments) ? msg.attachments.filter(a => a && a.data_url) : [];
        if (allAtts.length > 0) {
            headerAttBadge = `<span class="gm-att-badge">&#128206; ${allAtts.length}</span>`;
            attachmentsHtml = `<div class="gm-attachments-section"><div class="gm-att-title">${allAtts.length} attachment${allAtts.length > 1 ? 's' : ''}</div><div class="gm-att-gallery">`;
            allAtts.forEach(a => {
                const name = esc(a.filename || 'file');
                const sizeKB = a.size ? Math.round(a.size / 1024) : 0;
                const sizeLabel = sizeKB > 1024 ? (sizeKB / 1024).toFixed(1) + ' MB' : sizeKB + ' KB';
                const href = a.data_url || '#';
                const ct = (a.content_type || '').toLowerCase();
                let icon = '&#128196;'; // generic file
                if (ct.startsWith('image/')) icon = '&#128247;';
                else if (ct.includes('pdf')) icon = '&#128213;';
                else if (ct.includes('word') || ct.includes('doc')) icon = '&#128462;';
                else if (ct.includes('sheet') || ct.includes('excel') || ct.includes('csv')) icon = '&#128202;';
                else if (ct.includes('zip') || ct.includes('rar') || ct.includes('compressed')) icon = '&#128230;';
                attachmentsHtml += `
                    <a class="gm-att-card" href="${href}" target="_blank" rel="noopener" title="${name} (${sizeLabel})">
                        <div class="gm-att-info"><span>${icon} ${name}</span><span class="gm-att-size">${sizeLabel}</span><span class="gm-att-dl">&#8595;</span></div>
                    </a>`;
            });
            attachmentsHtml += '</div></div>';
        }

        // Collapsed preview (one-line)
        const collapsedPreview = esc((msg.preview || '').substring(0, 120));

        html += `
        <div class="gm-msg ${isDraft ? 'is-draft' : ''} ${isSent ? 'is-sent' : ''} ${isExpanded ? 'expanded' : 'collapsed'}" data-uid="${msg.uid}">
            <div class="gm-msg-header">
                <div class="gm-avatar" style="background:${color}">${initial}</div>
                <div class="gm-sender-block">
                    <div class="gm-sender-line">
                        <span class="gm-sender-name">${esc(fromName)}</span>
                        <span class="gm-sender-email">&lt;${esc(fromEmailClean)}&gt;</span>
                        ${badge}
                    </div>
                    <div class="gm-to-line gm-expanded-only">
                        to <span class="gm-to-target">${toDisplay}</span>
                        <button class="gm-details-toggle" type="button" title="Show details">&#9662;</button>
                    </div>
                    <div class="gm-preview gm-collapsed-only">${collapsedPreview}</div>
                </div>
                <div class="gm-meta">
                    ${headerAttBadge}
                    <div class="gm-date" title="${fullDate}">${shortDate}</div>
                </div>
            </div>

            <div class="gm-details-panel">
                <table class="gm-details-table">
                    <tr><td class="gm-details-key">from:</td><td><strong>${esc(fromName)}</strong> &lt;${esc(fromEmailClean)}&gt;</td></tr>
                    <tr><td class="gm-details-key">to:</td><td>${esc(toEmailClean || (window.BRAND && window.BRAND.support_email) || '')}</td></tr>
                    <tr><td class="gm-details-key">date:</td><td>${fullDate}</td></tr>
                    ${msg.auto_category ? `<tr><td class="gm-details-key">category:</td><td>${esc(CATEGORY_LABELS[msg.auto_category] || msg.auto_category)}</td></tr>` : ''}
                    ${msg.priority && msg.priority !== 'medium' ? `<tr><td class="gm-details-key">priority:</td><td class="prio-${msg.priority}">${esc(msg.priority)}</td></tr>` : ''}
                    ${msg.payment_method ? `<tr><td class="gm-details-key">payment:</td><td>${esc(msg.payment_method)}</td></tr>` : ''}
                    ${msg.is_ai_generated ? `<tr><td class="gm-details-key">source:</td><td>AI-generated draft</td></tr>` : ''}
                </table>
            </div>

            <div class="gm-body-wrapper" data-uid="${msg.uid}">
                <div class="gm-body ${isPlain ? 'plain-text' : ''}" data-original-html="1">${bodyContent}</div>
                <button class="gm-translate-btn" type="button" data-uid="${msg.uid}" data-plain="${isPlain ? '1' : '0'}" title="Translate to English">&#127760; Translate to English</button>
            </div>
            ${attachmentsHtml}
        </div>`;
    });

    container.innerHTML = html;

    // Click on collapsed header to expand; click on expanded header does nothing
    container.querySelectorAll('.gm-msg').forEach(msgEl => {
        const header = msgEl.querySelector('.gm-msg-header');
        if (header) {
            header.addEventListener('click', (ev) => {
                if (ev.target.closest('.gm-details-toggle')) return;  // handled separately
                if (msgEl.classList.contains('collapsed')) {
                    msgEl.classList.remove('collapsed');
                    msgEl.classList.add('expanded');
                } else if (msgEl.classList.contains('expanded') && !ev.target.closest('.gm-body') && !ev.target.closest('.gm-details-panel')) {
                    msgEl.classList.add('collapsed');
                    msgEl.classList.remove('expanded');
                }
            });
        }
        const detailsToggle = msgEl.querySelector('.gm-details-toggle');
        if (detailsToggle) {
            detailsToggle.addEventListener('click', (ev) => {
                ev.stopPropagation();
                msgEl.classList.toggle('show-details');
            });
        }

        // Translate button
        const translateBtn = msgEl.querySelector('.gm-translate-btn');
        if (translateBtn) {
            translateBtn.addEventListener('click', async (ev) => {
                ev.stopPropagation();
                await handleTranslateClick(translateBtn, msgEl);
            });
        }
    });

    // Reply data: last message of the thread
    const lastMsg = thread[thread.length - 1];
    $('#composeReplyTo').value = lastMsg.message_id || '';
    $('#composeReferences').value = [lastMsg.references, lastMsg.message_id].filter(Boolean).join(' ');

    // Show Send/Edit/Delete draft buttons only when viewing a draft.
    // Buttons read from state.currentDraft (set in openEmail when folder===drafts).
    const clickedIsDraft = (state.currentFolder === 'drafts') || (clicked.folder === 'drafts');
    const showDraftBtns = clickedIsDraft && state.currentDraft;
    const sendDraftBtn = document.getElementById('sendDraftDirectBtn');
    const editDraftBtn = document.getElementById('editDraftBtn');
    const deleteDraftBtn = document.getElementById('deleteDraftBtn');
    if (sendDraftBtn) sendDraftBtn.style.display = showDraftBtns ? 'inline-flex' : 'none';
    if (editDraftBtn) editDraftBtn.style.display = showDraftBtns ? 'inline-flex' : 'none';
    if (deleteDraftBtn) deleteDraftBtn.style.display = showDraftBtns ? 'inline-flex' : 'none';

    // Scroll to the last message
    const lastEl = container.querySelector('.thread-msg:last-child');
    if (lastEl) lastEl.scrollIntoView({ behavior: 'smooth', block: 'start' });

    // Auto-load existing AI draft if available
    loadExistingDraft(state.selectedEmail);
}

async function handleTranslateClick(btn, msgEl) {
    const bodyEl = msgEl.querySelector('.gm-body');
    if (!bodyEl) return;

    // Toggle back to original if already translated
    if (btn.dataset.translated === '1') {
        if (bodyEl.dataset.originalHtmlContent) {
            bodyEl.innerHTML = bodyEl.dataset.originalHtmlContent;
        }
        btn.innerHTML = '&#127760; Translate to English';
        btn.classList.remove('translated');
        btn.dataset.translated = '0';
        return;
    }

    // Extract text to translate (use innerText to strip HTML/styles from rich emails)
    let textToTranslate = (bodyEl.innerText || bodyEl.textContent || '').trim();
    if (!textToTranslate) return;
    // Normalize whitespace: trim each line, collapse 3+ blank lines to 1 blank line
    textToTranslate = textToTranslate
        .split('\n')
        .map(l => l.replace(/\s+$/g, '').replace(/^[ \t]+/g, ''))
        .join('\n')
        .replace(/\n{3,}/g, '\n\n');

    // Save original HTML for toggle-back
    if (!bodyEl.dataset.originalHtmlContent) {
        bodyEl.dataset.originalHtmlContent = bodyEl.innerHTML;
    }

    const originalLabel = btn.innerHTML;
    btn.disabled = true;
    btn.innerHTML = '&#8987; Translating…';

    try {
        const resp = await api('/api/translate', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ text: textToTranslate, target: 'English' }),
        });
        if (!resp || resp.error || !resp.translated) {
            throw new Error(resp?.error || 'No translation returned');
        }
        // Render translated text preserving line breaks (CSS white-space: pre-wrap handles \n)
        const cleaned = (resp.translated || '')
            .replace(/\r\n/g, '\n')
            .split('\n')
            .map(l => l.replace(/\s+$/g, ''))
            .join('\n')
            .replace(/\n{3,}/g, '\n\n')
            .trim();
        bodyEl.innerHTML = `<div class="gm-translated-block">${esc(cleaned)}</div>`;
        btn.innerHTML = '&#9664; Show original';
        btn.classList.add('translated');
        btn.dataset.translated = '1';
    } catch (e) {
        btn.innerHTML = '&#9888; Translation failed';
        setTimeout(() => { btn.innerHTML = originalLabel; }, 2500);
        console.error('Translate error:', e);
    } finally {
        btn.disabled = false;
    }
}

async function loadExistingDraft(uid) {
    // No-op: inline AI panel removed, drafts go into compose via AI Draft button
    return;
}

function closeEmail() {
    state.selectedEmail = null;
    dom.emailDetail().style.display = 'none';
    dom.emailList().style.display = 'block';
    dom.toolbar().style.display = 'flex';
    renderEmailList();
}

function openCompose(replyTo = null) {
    const overlay = dom.composeOverlay();
    overlay.style.display = 'block';
    overlay.dataset.draftUid = '';
    overlay.dataset.draftMode = '';

    // Hide delete button (only visible for draft edit mode)
    const delBtn = document.getElementById('composeDeleteBtn');
    if (delBtn) delBtn.style.display = 'none';

    // Reset header
    const header = document.querySelector('.compose-header span');
    if (header) header.textContent = replyTo ? 'Reply' : 'New message';

    // Reset all fields
    $('#composeReplyTo').value = '';
    $('#composeReferences').value = '';
    $('#composeCc').value = '';
    $('#composeBcc').value = '';
    $('#composeCc').style.display = 'none';
    $('#composeBcc').style.display = 'none';

    if (replyTo) {
        // Pre-fill reply
        const from = replyTo.from_addr || '';
        const subject = replyTo.subject || '';
        const re = subject.startsWith('Re:') ? subject : `Re: ${subject}`;
        $('#composeTo').value = from;
        $('#composeSubject').value = re;
        $('#composeBody').value = '';
        // Set reply references
        $('#composeReplyTo').value = replyTo.message_id || '';
        $('#composeReferences').value = [replyTo.references, replyTo.message_id].filter(Boolean).join(' ');
        $('#composeBody').focus();
    } else {
        $('#composeTo').value = '';
        $('#composeSubject').value = '';
        $('#composeBody').value = '';
        $('#composeTo').focus();
    }
    $('#composeStatus').textContent = '';
}

function closeCompose() {
    dom.composeOverlay().style.display = 'none';
    // Reset draft mode
    const overlay = document.getElementById('composeOverlay');
    overlay.dataset.draftUid = '';
    overlay.dataset.draftMode = '';
    overlay.dataset.draftMessageId = '';
    overlay.dataset.aiUid = '';
    // Hide AI refine row
    const refineRow = document.getElementById('composeAiRefineRow');
    if (refineRow) { refineRow.style.display = 'none'; }
    const hintInput = document.getElementById('composeAiHint');
    if (hintInput) { hintInput.value = ''; }
}

function openDraftCompose(draft) {
    const overlay = dom.composeOverlay();
    overlay.style.display = 'block';
    overlay.dataset.draftUid = draft.uid || '';
    overlay.dataset.draftMode = 'edit';

    // Clean recipient (extract email from "Name <email>")
    const toMatch = (draft.to_addr || '').match(/<([^>]+)>/);
    const cleanTo = toMatch ? toMatch[1] : (draft.to_addr || '').trim();

    document.getElementById('composeTo').value = cleanTo;
    document.getElementById('composeSubject').value = draft.subject || '';

    // Body: prefer plain text, fallback to stripped HTML
    let body = draft.body || '';
    if (!body && draft.html_body) {
        // Strip HTML tags
        const tmp = document.createElement('div');
        tmp.innerHTML = draft.html_body;
        body = tmp.textContent || tmp.innerText || '';
    }
    document.getElementById('composeBody').value = body.trim();

    document.getElementById('composeReplyTo').value = draft.in_reply_to || '';
    document.getElementById('composeReferences').value = draft.references || '';

    // Update header to show "Edit draft"
    const header = document.querySelector('.compose-header span');
    if (header) header.textContent = 'Edit draft';

    // Show delete button
    const delBtn = document.getElementById('composeDeleteBtn');
    if (delBtn) delBtn.style.display = 'inline-block';

    document.getElementById('composeStatus').textContent = '';
    document.getElementById('composeBody').focus();
}

async function saveDraft() {
    const data = {
        to: $('#composeTo').value,
        subject: $('#composeSubject').value,
        body: $('#composeBody').value,
        in_reply_to: $('#composeReplyTo').value,
        references: $('#composeReferences').value,
    };
    if (!data.to || !data.subject) {
        $('#composeStatus').textContent = 'Fill recipient and subject';
        return;
    }

    // Prevent double-click: disable button during save
    const saveBtn = $('#saveDraftBtn');
    if (saveBtn.disabled) return;
    saveBtn.disabled = true;

    $('#composeStatus').textContent = 'Saving...';
    // If we were editing an existing draft, delete the OLD version FIRST, then save the new one.
    // Doing it in this order avoids the case where save succeeds but delete fails → double drafts.
    const draftUid = document.getElementById('composeOverlay').dataset.draftUid;
    if (draftUid) {
        try {
            await api('/api/email/' + draftUid + '?folder=drafts', { method: 'DELETE' });
        } catch (_) { /* best-effort, continue to save */ }
    }

    const result = await api('/api/drafts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
    });

    saveBtn.disabled = false;

    if (result && result.status === 'ok') {
        if (result.uid) {
            document.getElementById('composeOverlay').dataset.draftUid = result.uid;
        }
        $('#composeStatus').textContent = '✓ Draft saved';
        setTimeout(() => {
            closeCompose();
            quickRefresh('drafts');
        }, 600);
    } else {
        $('#composeStatus').textContent = 'Save error: ' + (result?.detail || 'request failed');
    }
}

async function sendEmail() {
    const data = {
        to: $('#composeTo').value,
        subject: $('#composeSubject').value,
        body: $('#composeBody').value,
        cc: ($('#composeCc').value || '').trim(),
        bcc: ($('#composeBcc').value || '').trim(),
        in_reply_to: $('#composeReplyTo').value,
        references: $('#composeReferences').value,
    };
    if (!data.to || !data.subject) {
        $('#composeStatus').textContent = 'Fill recipient and subject';
        return;
    }
    if (!data.body.trim()) {
        $('#composeStatus').textContent = 'Write a message';
        return;
    }
    // SAFETY: prevent sending to ourselves
    if (isFromUs(data.to)) {
        $('#composeStatus').textContent = 'Error: recipient is our own support address (we are sending to ourselves)';
        $('#composeStatus').style.color = '#d93025';
        return;
    }

    $('#sendBtn').disabled = true;
    $('#composeStatus').textContent = 'Sending...';

    // Pass the draft's Message-ID so /api/send can reuse it (dedup by Message-ID)
    const overlayEl = document.getElementById('composeOverlay');
    if (overlayEl.dataset.draftMessageId) {
        data.reuse_message_id = overlayEl.dataset.draftMessageId;
    }

    const result = await api('/api/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
    });

    $('#sendBtn').disabled = false;

    if (result && result.status === 'ok') {
        const sentAppended = result.sent_appended !== false; // default true for backward compat
        if (!sentAppended) {
            $('#composeStatus').textContent = '✓ Sent, but copy in "Sent" folder failed. Draft kept as backup.';
            $('#composeStatus').style.color = '#e37400';
        } else {
            $('#composeStatus').textContent = '✓ Email sent successfully to ' + data.to;
            $('#composeStatus').style.color = '#188038';
        }
        // If we were editing a saved draft, delete it after sending.
        const draftUid = document.getElementById('composeOverlay').dataset.draftUid;
        if (draftUid && sentAppended) {
            try {
                await api('/api/email/' + draftUid + '?folder=drafts', { method: 'DELETE' });
            } catch (e) {
                console.warn('Failed to delete draft after send:', draftUid, e);
            }
        }
        // Record to learning DB if this was an AI-drafted response
        if (state.selectedEmail) {
            api('/api/learning/sent/' + state.selectedEmail, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ final_response: data.body }),
            }).catch(() => {});
        }
        // Clean orphan drafts (drafts matching sent emails) in background
        api('/api/drafts/clean-orphans', { method: 'POST' }).catch(() => {});
        setTimeout(() => {
            closeCompose();
            $('#composeStatus').style.color = '';
            // Force reload of current folder so sent (or inbox if user is there) updates now
            loadAndRender();
            fetchFolders();
        }, 1500);
    } else {
        $('#composeStatus').textContent = '✗ Send error: ' + (result?.detail || 'connection failed');
        $('#composeStatus').style.color = '#d93025';
    }
}


// ── Chat (agent) ──
let chatHistory = [];
let chatSending = false;

function appendChatMsg(role, text) {
    const box = $('#chatMessages');
    const div = document.createElement('div');
    div.className = 'chat-msg ' + (role === 'user' ? 'chat-msg-user' : 'chat-msg-bot');
    div.textContent = text;
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
    return div;
}

async function sendChatMessage() {
    if (chatSending) return;
    const input = $('#chatInput');
    const msg = input.value.trim();
    if (!msg) return;
    input.value = '';
    chatSending = true;
    appendChatMsg('user', msg);
    const thinking = appendChatMsg('bot', '…');
    try {
        const resp = await api('/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ message: msg, history: chatHistory }),
        });
        if (resp && resp.reply) {
            thinking.textContent = resp.reply;
            chatHistory.push({ role: 'user', content: msg });
            chatHistory.push({ role: 'assistant', content: resp.reply });
            if (chatHistory.length > 20) chatHistory = chatHistory.slice(-20);
        } else {
            thinking.textContent = '(error: no reply)';
        }
    } catch (e) {
        thinking.textContent = '(error: ' + e.message + ')';
    } finally {
        chatSending = false;
    }
}

async function toggleStar(btn) {
    const uid = btn.dataset.uid;
    if (!uid || btn.disabled) return;

    const email = state.emails.find(x => x.uid === uid);
    const wasStarred = email ? email.is_starred : btn.classList.contains('starred');
    const newStarred = !wasStarred;

    // OPTIMISTIC: update UI immediately
    btn.classList.toggle('starred', newStarred);
    btn.innerHTML = newStarred ? '&#9733;' : '&#9734;';
    if (email) email.is_starred = newStarred;

    // If in starred folder and unstarring, fade out row immediately
    if (state.currentFolder === 'starred' && !newStarred) {
        const row = btn.closest('.email-row');
        if (row) {
            row.classList.add('email-row-removing');
            setTimeout(() => {
                state.emails = state.emails.filter(x => x.uid !== uid);
                state.total = state.emails.length;
                row.remove();
                updateListHeader();
            }, 200);
        }
    }

    // Fire server call, revert on failure
    try {
        const result = await api(`/api/star/${uid}`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ folder: state.currentFolder }),
        });
        if (!result || result.status !== 'ok') throw new Error('star failed');
        fetchFolders();
    } catch {
        // REVERT on failure
        btn.classList.toggle('starred', wasStarred);
        btn.innerHTML = wasStarred ? '&#9733;' : '&#9734;';
        if (email) email.is_starred = wasStarred;
        showToast('Star update failed', 'error');
    }
}


function getSelectedUids() {
    const uids = [];
    document.querySelectorAll('.email-check input:checked').forEach(cb => {
        if (cb.dataset.uid) uids.push(cb.dataset.uid);
    });
    return uids;
}

function updateToolbarActions() {
    const selected = getSelectedUids();
    const actions = document.getElementById('toolbarActions');
    const count = document.getElementById('selectedCount');
    if (selected.length > 0) {
        actions.style.display = 'flex';
        count.textContent = selected.length + ' selected';
    } else {
        actions.style.display = 'none';
    }
}

async function bulkMarkRead(markRead) {
    const uids = getSelectedUids();
    if (uids.length === 0) return;

    await api('/api/read-bulk', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uids, read: markRead, folder: state.currentFolder }),
    });

    // Update local state
    for (const e of state.emails) {
        if (uids.includes(e.uid)) e.is_read = markRead;
    }

    // Uncheck all
    document.getElementById('selectAll').checked = false;
    updateToolbarActions();

    // Re-render
    renderEmailList();
    fetchFolders();
}

async function bulkDelete() {
    const uids = getSelectedUids();
    if (uids.length === 0) return;

    const folder = state.currentFolder;
    const label = folder === 'drafts' ? 'bozze' : (folder === 'sent' ? 'email inviate' : 'email');
    if (!confirm(`Eliminare ${uids.length} ${label}? L'operazione non è reversibile.`)) return;

    const btn = document.getElementById('bulkDeleteBtn');
    if (btn) { btn.disabled = true; btn.textContent = 'Eliminando…'; }

    // OPTIMISTIC: fade out rows immediately
    const deletedSet = new Set(uids);
    const removedEmails = state.emails.filter(e => deletedSet.has(e.uid));
    document.querySelectorAll('.email-row').forEach(row => {
        if (deletedSet.has(row.dataset.uid)) {
            row.classList.add('email-row-removing');
        }
    });
    state.emails = state.emails.filter(e => !deletedSet.has(e.uid));
    state.total = Math.max(0, state.total - uids.length);
    document.getElementById('selectAll').checked = false;
    updateToolbarActions();
    updateListHeader();
    setTimeout(() => {
        document.querySelectorAll('.email-row-removing').forEach(r => r.remove());
    }, 200);

    try {
        const result = await api('/api/delete-bulk', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ uids, folder }),
        });
        if (!result || result.status !== 'ok') throw new Error(result?.detail || 'unknown');
        fetchFolders();
    } catch (e) {
        // REVERT: re-add emails
        state.emails = [...removedEmails, ...state.emails].sort((a, b) => b.date_ts - a.date_ts);
        renderEmailList();
        showToast('Delete failed: ' + e.message, 'error');
    } finally {
        if (btn) { btn.disabled = false; btn.innerHTML = '&#128465; Delete'; }
    }
}

// ── AI Draft ──

async function generateAIDraft(uid) {
    const btn = $('#aiGenerateBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="ai-spinner"></span> Generando...';

    // Check if a draft already exists
    let draft = null;
    const existing = await api(`/api/draft-by-uid/${uid}`);
    if (existing && existing.draft) {
        draft = existing.draft;
    } else {
        // Generate new (no operator hint on first generation)
        const result = await api(`/api/process-single/${uid}`, { method: 'POST' });
        if (!result || result.status !== 'ok') {
            btn.disabled = false;
            btn.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M19 9l1.25-2.75L23 5l-2.75-1.25L19 1l-1.25 2.75L15 5l2.75 1.25L19 9zm-7.5.5L9 4 6.5 9.5 1 12l5.5 2.5L9 20l2.5-5.5L17 12l-5.5-2.5z"/></svg> Genera risposta';
            alert('Errore generazione risposta: ' + (result?.error || 'unknown error'));
            return;
        }
        // Re-fetch to get full draft from DB
        const fresh = await api(`/api/draft-by-uid/${uid}`);
        draft = fresh?.draft || result;
    }

    btn.disabled = false;
    btn.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M19 9l1.25-2.75L23 5l-2.75-1.25L19 1l-1.25 2.75L15 5l2.75 1.25L19 9zm-7.5.5L9 4 6.5 9.5 1 12l5.5 2.5L9 20l2.5-5.5L17 12l-5.5-2.5z"/></svg> Genera risposta';

    // Find the customer email for reply target
    let target = null;
    for (let i = state.lastThread.length - 1; i >= 0; i--) {
        if (!isFromUs(state.lastThread[i].from_addr)) {
            target = state.lastThread[i];
            break;
        }
    }
    if (!target && state.lastThread.length) target = state.lastThread[state.lastThread.length - 1];
    if (!target) {
        alert('Cannot determine recipient');
        return;
    }

    // Open compose with AI draft body pre-filled
    openCompose(target);
    document.getElementById('composeBody').value = draft.ai_draft || draft.draft_body || '';
    // Mark as AI generated for tag
    const header = document.querySelector('.compose-header span');
    if (header) header.innerHTML = 'Reply <span class="compose-ai-badge">✨ AI</span>';
    // Show the AI refine row for corrections
    const refineRow = document.getElementById('composeAiRefineRow');
    if (refineRow) refineRow.style.display = 'flex';
    // Store the UID for regeneration
    document.getElementById('composeOverlay').dataset.aiUid = uid;
    return;
    // unreachable: old panel code
    const panel = null;

    // Show panel
    panel.style.display = 'block';

    // Tags
    const tags = $('#aiTags');
    const catLabel = result.category.replace(/_/g, ' ');
    tags.innerHTML = `
        <span class="ai-tag category">${catLabel}</span>
        <span class="ai-tag sentiment-${result.sentiment}">${result.sentiment}</span>
        <span class="ai-tag urgency-${result.urgency}">urgency: ${result.urgency}</span>
        <span class="ai-tag language">${result.language}</span>
        <span class="ai-tag confidence">${Math.round(result.confidence * 100)}%</span>
        ${result.order_id ? '<span class="ai-tag category">' + result.order_id + '</span>' : ''}
        ${result.payment_method ? '<span class="ai-tag payment-' + result.payment_method.toLowerCase() + '">' + result.payment_method + '</span>' : ''}
    `;

    // Context
    $('#aiContext').textContent = result.context || 'No context';

    // Draft body
    $('#aiDraftBody').value = result.draft_body;

    // Store for use
    panel.dataset.draftBody = result.draft_body;
    panel.dataset.summary = result.summary || '';

    // Scroll to panel
    panel.scrollIntoView({ behavior: 'smooth', block: 'center' });
}

async function regenerateWithHint() {
    const hintInput = document.getElementById('composeAiHint');
    const hint = hintInput ? hintInput.value.trim() : '';
    if (!hint) { hintInput.focus(); return; }

    const currentBody = document.getElementById('composeBody').value.trim();
    if (!currentBody) { alert('Nessun testo da raffinare'); return; }

    const btn = document.getElementById('composeAiRegenBtn');
    btn.disabled = true;
    btn.innerHTML = '<span class="ai-spinner"></span> Rigenerando...';

    try {
        const result = await api('/api/refine-draft', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                body: currentBody,
                hint: hint,
                uid: document.getElementById('composeOverlay').dataset.aiUid || '',
            }),
        });
        if (result && result.status === 'ok' && result.body) {
            document.getElementById('composeBody').value = result.body;
            hintInput.value = '';
        } else {
            alert('Errore: ' + (result?.detail || 'risposta vuota'));
        }
    } catch (e) {
        alert('Errore: ' + e.message);
    }

    btn.disabled = false;
    btn.innerHTML = '<svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M19 9l1.25-2.75L23 5l-2.75-1.25L19 1l-1.25 2.75L15 5l2.75 1.25L19 9zm-7.5.5L9 4 6.5 9.5 1 12l5.5 2.5L9 20l2.5-5.5L17 12l-5.5-2.5z"/></svg> Rigenera';
}

function useAIDraft() {
    const draftBody = $('#aiDraftBody').value || '';
    if (!draftBody) return;

    if (state.lastThread.length) {
        // Find LAST CUSTOMER message (not from us), to get the right recipient
        let target = null;
        for (let i = state.lastThread.length - 1; i >= 0; i--) {
            if (!isFromUs(state.lastThread[i].from_addr)) {
                target = state.lastThread[i];
                break;
            }
        }
        if (!target) target = state.lastThread[state.lastThread.length - 1];
        openCompose(target);
        $('#composeBody').value = draftBody;
    }
}


// ── Category Sidebar ──

function renderCategorySidebar() {
    const container = document.getElementById('categorySidebar');
    if (!container) return;
    const counts = state.folders.category_counts || {};
    let html = '';
    for (const [catId, label] of Object.entries(CATEGORY_LABELS)) {
        const count = counts[catId] || 0;
        if (count === 0) continue;
        const active = state.currentCat === catId ? 'active' : '';
        html += `<a class="cat-nav-item ${active}" data-category="${catId}" href="#cat/${catId}">
            <span class="cat-dot ${catId}"></span>
            <span>${label}</span>
            <span class="badge">${count}</span>
        </a>`;
    }
    container.innerHTML = html;

    container.querySelectorAll('.cat-nav-item').forEach(el => {
        el.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.hash = `cat/${el.dataset.category}`;
        });
    });
}

// ── Navigation ──

function navigateToPriority(prio) {
    state.currentFolder = 'inbox';
    state.currentQA = '';
    state.currentCat = '';
    state.currentPay = '';
    state.currentPrio = prio;
    state.page = 1;
    state.selectedEmail = null;
    document.querySelectorAll('.nav-item, .cat-nav-item').forEach(el => el.classList.remove('active'));
    document.querySelector(`.cat-nav-item[data-priority="${prio}"]`)?.classList.add('active');
    closeEmail();
    loadAndRender();
}

function navigateToPay(pay) {
    state.currentFolder = 'inbox';
    state.currentQA = '';
    state.currentCat = '';
    state.currentPrio = '';
    state.currentPay = pay;
    state.page = 1;
    state.selectedEmail = null;
    $$('.nav-item, .cat-nav-item').forEach(el => el.classList.remove('active'));
    document.querySelector(`.cat-nav-item[data-payment="${pay}"]`)?.classList.add('active');
    closeEmail();
    loadAndRender();
}

function navigateTo(folder, qa = '', cat = '') {
    state.currentFolder = folder;
    state.currentQA = qa;
    state.currentCat = cat || '';
    state.currentPay = '';
    state.currentPrio = '';
    state.page = 1;
    state.selectedEmail = null;

    // Update active nav
    $$('.nav-item').forEach(el => el.classList.remove('active'));
    if (qa) {
        const qaEl = document.querySelector(`.nav-item[data-qa="${qa}"]`);
        if (qaEl) qaEl.classList.add('active');
        document.querySelector('.nav-item[data-folder="quick-actions"]')?.classList.add('active');
    } else {
        const el = document.querySelector(`.nav-item[data-folder="${folder}"]`);
        if (el) el.classList.add('active');
    }

    // Show list, hide detail
    closeEmail();
    loadAndRender();
}

let _lastEmailsJSON = '';
let _userHovering = false;

async function loadAndRender() {
    dom.emailList().innerHTML = '<div class="loading">Loading...</div>';
    await fetchEmails();
    _lastEmailsJSON = JSON.stringify(state.emails.map(e => e.uid + (e.is_read?'R':'') + (e.is_starred?'S':'')));
    renderEmailList();
}

// Silent refresh: only re-render if data actually changed AND user is not interacting
async function silentRefresh() {
    await fetchEmails();
    const newJSON = JSON.stringify(state.emails.map(e => e.uid + (e.is_read?'R':'') + (e.is_starred?'S':'')));
    if (newJSON !== _lastEmailsJSON && !_userHovering) {
        _lastEmailsJSON = newJSON;
        renderEmailList();
    }
}

// Track mouse hover on email list to prevent re-render during interaction
document.addEventListener('DOMContentLoaded', () => {
    const list = document.getElementById('emailList');
    if (list) {
        list.addEventListener('mouseenter', () => { _userHovering = true; });
        list.addEventListener('mouseleave', () => { _userHovering = false; });
    }
});

// ── Hash routing ──

function handleRoute() {
    const hash = window.location.hash.replace('#', '') || 'inbox';

    if (hash.startsWith('cat/')) {
        const cat = hash.split('/')[1];
        navigateTo('inbox', '', cat);
    } else if (hash.startsWith('pay/')) {
        const pay = hash.split('/')[1];
        navigateToPay(pay);
    } else if (hash.startsWith('prio/')) {
        const prio = hash.split('/')[1];
        navigateToPriority(prio);
    } else if (hash.startsWith('qa/')) {
        const qa = hash.split('/')[1];
        navigateTo('inbox', qa);
    } else if (hash === 'quick-actions') {
        // Mostra tutte le quick actions insieme
        navigateTo('inbox', '__all_qa__');
    } else if (['inbox', 'sent', 'drafts', 'all', 'spam', 'starred', 'trash'].includes(hash)) {
        navigateTo(hash);
    } else {
        navigateTo('inbox');
    }
}


// ── Helpers ──

function linkify(html) {
    // Convert URLs to clickable links (run AFTER esc() so we match escaped text)
    // Match http/https URLs
    html = html.replace(/(https?:\/\/[^\s<>"']+)/gi, '<a href="$1" target="_blank" rel="noopener" class="gm-link">$1</a>');
    // Match email addresses (not already in href)
    html = html.replace(/(?<!href="|>)([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})/g, '<a href="mailto:$1" class="gm-link">$1</a>');
    return html;
}

function cleanPlainText(text) {
    if (!text) return '';
    let cleaned = text.replace(/\r\n/g, '\n');
    cleaned = cleaned.replace(/\n{3,}/g, '\n\n');
    const lines = cleaned.split('\n');
    let result = [];
    let inQuote = false;
    let quoteLines = [];
    for (const line of lines) {
        if (line.startsWith('>')) {
            if (!inQuote) { inQuote = true; quoteLines = []; }
            quoteLines.push(esc(line.replace(/^>+\s?/, '')));
        } else {
            if (inQuote) {
                result.push('<div class="quoted-text">' + quoteLines.join('<br>') + '</div>');
                inQuote = false;
                quoteLines = [];
            }
            result.push(esc(line));
        }
    }
    if (inQuote) {
        result.push('<div class="quoted-text">' + quoteLines.join('<br>') + '</div>');
    }
    return linkify(result.join('<br>'));
}

function esc(str) {
    if (!str) return '';
    const div = document.createElement('div');
    div.textContent = str;
    return div.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#39;');
}

// ── Event Listeners ──

document.addEventListener('DOMContentLoaded', async () => {
    // Initial data load
    await Promise.all([
        fetchFolders(),
        fetchContext(),
    ]);
    renderCategorySidebar();
    handleRoute();

    // Auto-poll: refresh badges every 2s and email list every 4s when user NOT reading an email
    setInterval(() => {
        if (document.hidden) return;
        fetchFolders();
    }, 2000);

    setInterval(() => {
        if (document.hidden) return;
        if (state.selectedEmail) return; // don't interrupt the user while reading
        silentRefresh();
    }, 4000);

    // SSE disabled for stability — polling handles updates

    // Select all checkbox
    $('#selectAll').addEventListener('change', (e) => {
        const checked = e.target.checked;
        document.querySelectorAll('.email-check input').forEach(cb => {
            cb.checked = checked;
        });
        updateToolbarActions();
    });

    // Mark read/unread buttons
    $('#markReadBtn').addEventListener('click', () => bulkMarkRead(true));
    $('#markUnreadBtn').addEventListener('click', () => bulkMarkRead(false));

    // Bulk delete
    const bulkDelBtn = document.getElementById('bulkDeleteBtn');
    if (bulkDelBtn) bulkDelBtn.addEventListener('click', bulkDelete);


    // Search
    let searchTimeout;
    dom.searchInput().addEventListener('input', (e) => {
        clearTimeout(searchTimeout);
        searchTimeout = setTimeout(() => {
            state.search = e.target.value;
            state.page = 1;
            loadAndRender();
        }, 300);
    });

    // AI Auto-Processor toggle
    async function updateAIToggleUI() {
        const data = await api('/api/auto-processor');
        if (!data) return;
        const btn = document.getElementById('aiToggleSwitch');
        const state = document.getElementById('aiToggleState');
        if (data.enabled) {
            btn.classList.add('on');
            state.textContent = 'ON';
        } else {
            btn.classList.remove('on');
            state.textContent = 'OFF';
        }
    }
    updateAIToggleUI();
    document.getElementById('aiToggleSwitch').addEventListener('click', async () => {
        const btn = document.getElementById('aiToggleSwitch');
        const cur = btn.classList.contains('on');
        const newState = !cur;
        const msg = newState
            ? 'Enable automatic AI draft generation?'
            : 'Disable automatic AI draft generation?';
        if (!confirm(msg)) return;
        await api('/api/auto-processor', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ enabled: newState }),
        });
        updateAIToggleUI();
    });

    // Refresh
    $('#refreshBtn').addEventListener('click', async () => {
        $('#refreshBtn').disabled = true;
        await api('/api/refresh', { method: 'POST' });
        await Promise.all([fetchFolders()]);
        loadAndRender();
        $('#refreshBtn').disabled = false;
    });

    // Pagination
    $('#prevPage').addEventListener('click', () => {
        if (state.page > 1) { state.page--; loadAndRender(); }
    });
    $('#nextPage').addEventListener('click', () => {
        if (state.page < state.pages) { state.page++; loadAndRender(); }
    });

    // Back to list
    $('#backToList').addEventListener('click', closeEmail);

    // Star/unstar from detail view
    $('#detailStarBtn').addEventListener('click', async () => {
        const btn = $('#detailStarBtn');
        const uid = btn.dataset.uid;
        if (!uid) return;
        // Also sync state.emails since detail view email might not be found by toggleStar
        const emailInList = state.emails.find(x => x.uid === uid);
        await toggleStar(btn);
        // After toggle, sync the list row if it exists
        const listStar = document.querySelector(`.email-row[data-uid="${uid}"] .email-star`);
        if (listStar) {
            const isNowStarred = btn.classList.contains('starred');
            listStar.classList.toggle('starred', isNowStarred);
            listStar.innerHTML = isNowStarred ? '&#9733;' : '&#9734;';
        }
    });

    // Chat panel
    const openChat = () => {
        $('#chatPanel').style.display = 'flex';
        setTimeout(() => $('#chatInput').focus(), 50);
    };
    const closeChat = () => { $('#chatPanel').style.display = 'none'; };
    $('#chatFabBtn').addEventListener('click', openChat);
    $('#chatOpenBtn').addEventListener('click', openChat);
    $('#chatCloseBtn').addEventListener('click', closeChat);
    $('#chatClearBtn').addEventListener('click', () => {
        chatHistory = [];
        $('#chatMessages').innerHTML = '<div class="chat-msg chat-msg-bot">Conversation cleared. What do you want to know?</div>';
    });
    $('#chatSendBtn').addEventListener('click', sendChatMessage);
    $('#chatInput').addEventListener('keydown', (ev) => {
        if (ev.key === 'Enter' && !ev.shiftKey) {
            ev.preventDefault();
            sendChatMessage();
        }
    });

    // Archive
    $('#archiveBtn').addEventListener('click', async () => {
        if (!state.selectedEmail) return;
        $('#archiveBtn').disabled = true;
        const result = await api(`/api/archive/${state.selectedEmail}`, { method: 'POST' });
        $('#archiveBtn').disabled = false;
        if (result && result.status === 'ok') {
            closeEmail();
            quickRefresh('inbox');
        } else {
            alert('Archive error: ' + (result?.detail || 'request failed'));
        }
    });

    // Delete (move to Trash) — permanent delete only from Trash folder view
    $('#deleteMsgBtn').addEventListener('click', async () => {
        if (!state.selectedEmail) return;
        const folder = state.currentFolder;
        $('#deleteMsgBtn').disabled = true;
        let result;
        if (folder === 'trash') {
            // From Trash: permanent delete
            result = await api(`/api/email/${state.selectedEmail}?folder=trash`, { method: 'DELETE' });
        } else {
            // From anywhere else: move to Trash (soft delete)
            result = await api(`/api/trash/${state.selectedEmail}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ folder }),
            });
        }
        $('#deleteMsgBtn').disabled = false;
        if (result && (result.status === 'ok')) {
            closeEmail();
            quickRefresh(folder);
        } else {
            alert('Delete error: ' + (result?.detail || 'request failed'));
        }
    });

    // Reply — use the thread already loaded in memory
    function _findReplyTarget() {
        if (state.lastThread.length) {
            let target = null;
            for (let i = state.lastThread.length - 1; i >= 0; i--) {
                if (!isFromUs(state.lastThread[i].from_addr)) {
                    target = state.lastThread[i];
                    break;
                }
            }
            return target || state.lastThread[state.lastThread.length - 1];
        }
        return null;
    }

    $('#replyBtn').addEventListener('click', async () => {
        if (!state.selectedEmail) return;
        const target = _findReplyTarget();
        if (target) {
            openCompose(target);
        } else {
            const detail = await fetchEmailDetail(state.selectedEmail);
            if (detail) openCompose(detail);
        }
    });

    // Reply All — reply + CC all other participants
    $('#replyAllBtn').addEventListener('click', async () => {
        if (!state.selectedEmail) return;
        const target = _findReplyTarget();
        if (!target) return;
        openCompose(target);
        // Collect all unique email addresses from the thread (excluding us and the To recipient)
        const toMatch = ($('#composeTo').value || '').match(/<([^>]+)>/);
        const toEmail = (toMatch ? toMatch[1] : $('#composeTo').value).toLowerCase().trim();
        const ccAddrs = new Set();
        for (const m of state.lastThread) {
            // From
            const fromMatch = (m.from_addr || '').match(/<([^>]+)>/);
            const fromEmail = (fromMatch ? fromMatch[1] : (m.from_addr || '')).toLowerCase().trim();
            if (fromEmail && !isFromUs(fromEmail) && fromEmail !== toEmail) ccAddrs.add(fromEmail);
            // To
            const mToMatch = (m.to_addr || '').match(/<([^>]+)>/);
            const mToEmail = (mToMatch ? mToMatch[1] : (m.to_addr || '')).toLowerCase().trim();
            if (mToEmail && !isFromUs(mToEmail) && mToEmail !== toEmail) ccAddrs.add(mToEmail);
        }
        if (ccAddrs.size > 0) {
            $('#composeCc').value = Array.from(ccAddrs).join(', ');
            $('#composeCc').style.display = 'block';
            $('#composeBcc').style.display = 'block';
        }
    });

    // Forward — open compose with Fwd: subject and original body quoted
    $('#forwardBtn').addEventListener('click', async () => {
        if (!state.selectedEmail) return;
        const target = _findReplyTarget();
        if (!target) return;
        const subj = (target.subject || '').startsWith('Fwd:') ? target.subject : 'Fwd: ' + target.subject;
        openCompose(null); // new compose, no reply-to
        $('#composeSubject').value = subj;
        // Build quoted body
        const fromName = target.from_name || target.from_addr || '';
        const date = target.date_display || target.date_str || '';
        const body = target.body || target.preview || '';
        $('#composeBody').value = '\n\n---------- Forwarded message ----------\nFrom: ' + fromName + '\nDate: ' + date + '\nSubject: ' + (target.subject || '') + '\n\n' + body;
        $('#composeTo').focus();
    });

    // ── Draft action buttons via document-level event delegation (always fires) ──

    document.addEventListener('click', async (ev) => {
        const target = ev.target;
        if (!target || !target.closest) return;

        // SEND DRAFT
        if (target.closest('#sendDraftDirectBtn')) {
            ev.stopPropagation();
            fetch('/api/debug/ping?source=sendDraftBtn&uid=' + encodeURIComponent(state.selectedEmail || 'NULL')).catch(() => {});
            const draft = state.currentDraft;
            if (!draft || !state.selectedEmail) {
                alert('No draft loaded (state.currentDraft=' + JSON.stringify(draft) + ')');
                return;
            }
            const toRaw = draft.to_addr || '';
            const toMatch = toRaw.match(/<([^>]+)>/);
            const cleanTo = toMatch ? toMatch[1] : toRaw.trim();
            const subject = draft.subject || '';
            const body = (draft.body || '').trim() || (draft.html_body || '').trim();
            if (!cleanTo || !subject || !body) {
                alert('Incomplete draft: to=' + cleanTo + ' subject=' + subject + ' body_len=' + body.length);
                return;
            }
            if (isFromUs(cleanTo)) {
                alert('Error: recipient is ourselves');
                return;
            }
            const btn = document.getElementById('sendDraftDirectBtn');
            btn.disabled = true;
            const origHtml = btn.innerHTML;
            btn.textContent = 'Sending…';
            try {
                const result = await api('/api/send', {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({
                        to: cleanTo, subject, body,
                        in_reply_to: draft.in_reply_to || '',
                        references: draft.references || '',
                    }),
                });
                if (result && result.status === 'ok') {
                    await api('/api/email/' + state.selectedEmail + '?folder=drafts', { method: 'DELETE' });
                    closeEmail();
                    quickRefresh('drafts');
                    fetchFolders();
                } else {
                    alert('Send error: ' + (result?.detail || 'request failed'));
                }
            } finally {
                btn.disabled = false;
                btn.innerHTML = origHtml;
            }
            return;
        }

        // EDIT DRAFT
        if (target.closest('#editDraftBtn')) {
            ev.stopPropagation();
            fetch('/api/debug/ping?source=editDraftBtn&uid=' + encodeURIComponent(state.selectedEmail || 'NULL')).catch(() => {});
            if (!state.currentDraft) {
                alert('No draft loaded');
                return;
            }
            openDraftCompose(state.currentDraft);
            return;
        }

        // DELETE DRAFT (from thread view) — no confirm, click = action
        if (target.closest('#deleteDraftBtn')) {
            ev.stopPropagation();
            fetch('/api/debug/ping?source=deleteDraftBtn&uid=' + encodeURIComponent(state.selectedEmail || 'NULL')).catch(() => {});
            const draftUid = state.selectedEmail;
            if (!draftUid) {
                alert('No draft selected');
                return;
            }
            const btn = document.getElementById('deleteDraftBtn');
            btn.disabled = true;
            btn.textContent = 'Deleting…';
            try {
                const result = await api('/api/email/' + draftUid + '?folder=drafts', { method: 'DELETE' });
                if (result && result.status === 'ok') {
                    closeEmail();
                    quickRefresh('drafts');
                } else {
                    alert('Delete error: ' + (result?.detail || 'request failed'));
                }
            } finally {
                btn.disabled = false;
                btn.innerHTML = '<svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M6 19c0 1.1.9 2 2 2h8c1.1 0 2-.9 2-2V7H6v12zM19 4h-3.5l-1-1h-5l-1 1H5v2h14V4z"/></svg> Delete draft';
            }
            return;
        }

        // DELETE DRAFT (from compose modal) — no confirm, click = action
        if (target.closest('#composeDeleteBtn')) {
            ev.stopPropagation();
            fetch('/api/debug/ping?source=composeDeleteBtn&uid=' + encodeURIComponent(state.selectedEmail || 'NULL')).catch(() => {});
            const overlay = document.getElementById('composeOverlay');
            const draftUid = overlay.dataset.draftUid || state.selectedEmail;
            if (!draftUid) {
                alert('No draft to delete');
                return;
            }
            const btn = document.getElementById('composeDeleteBtn');
            btn.disabled = true;
            const orig = btn.textContent;
            btn.textContent = 'Deleting…';
            try {
                const result = await api('/api/email/' + draftUid + '?folder=drafts', { method: 'DELETE' });
                if (result && result.status === 'ok') {
                    closeCompose();
                    quickRefresh('drafts');
                } else {
                    alert('Delete error: ' + (result?.detail || 'request failed'));
                }
            } finally {
                btn.disabled = false;
                btn.textContent = orig;
            }
            return;
        }
    });

    // AI Draft
    // Payment filter clicks
    document.querySelectorAll('.cat-nav-item[data-payment]').forEach(el => {
        el.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.hash = 'pay/' + el.dataset.payment;
        });
    });

    // Priority filter clicks
    document.querySelectorAll('.cat-nav-item[data-priority]').forEach(el => {
        el.addEventListener('click', (e) => {
            e.preventDefault();
            window.location.hash = 'prio/' + el.dataset.priority;
        });
    });

    $('#aiGenerateBtn').addEventListener('click', () => {
        if (state.selectedEmail) generateAIDraft(state.selectedEmail);
    });
    const detailAiBtnEl = $('#detailAiBtn');
    if (detailAiBtnEl) {
        detailAiBtnEl.addEventListener('click', () => {
            if (state.selectedEmail) generateAIDraft(state.selectedEmail);
        });
    }


    // Compose
    $('#composeBtn').addEventListener('click', () => openCompose());
    $('#composeClose').addEventListener('click', closeCompose);
    // CC/BCC toggle
    $('#ccBccToggle').addEventListener('click', () => {
        const cc = $('#composeCc');
        const bcc = $('#composeBcc');
        const show = cc.style.display === 'none';
        cc.style.display = show ? 'block' : 'none';
        bcc.style.display = show ? 'block' : 'none';
        if (show) cc.focus();
    });
    $('#sendBtn').addEventListener('click', sendEmail);
    // Note: composeDeleteBtn handled via document-level delegation above
    $('#saveDraftBtn').addEventListener('click', saveDraft);
    $('#composeAiRegenBtn').addEventListener('click', regenerateWithHint);
    // Enter key in hint input triggers regeneration
    $('#composeAiHint').addEventListener('keydown', (e) => {
        if (e.key === 'Enter') { e.preventDefault(); regenerateWithHint(); }
    });

    // Sidebar toggle
    $('#toggleSidebar').addEventListener('click', () => {
        $('#sidebar').classList.toggle('collapsed');
    });

    // Hash routing
    window.addEventListener('hashchange', handleRoute);

    // Keyboard shortcuts
    document.addEventListener('keydown', (e) => {
        if (e.target.tagName === 'INPUT' || e.target.tagName === 'TEXTAREA') return;
        if (e.key === 'Escape') {
            if (dom.composeOverlay().style.display !== 'none') closeCompose();
            else if (state.selectedEmail) closeEmail();
        }
        if (e.key === 'r' && state.selectedEmail) {
            e.preventDefault();
            $('#replyBtn').click();
        }
    });
});
