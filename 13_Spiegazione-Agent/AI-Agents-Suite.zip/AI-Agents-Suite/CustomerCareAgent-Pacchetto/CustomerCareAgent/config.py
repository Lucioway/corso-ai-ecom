"""
Configurazione centralizzata per CustomerCareAgent (multi-tenant template).
Carica .env e espone costanti per tutti i moduli.

TUTTO è brand-agnostic: passa BRAND_* env vars per personalizzare il client.
Vedi .env.example per la lista completa.
"""

import os
import platform
import sys
from pathlib import Path
from dotenv import load_dotenv


def _default_chrome_bin() -> str:
    system = platform.system()
    if system == "Darwin":
        return "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    if system == "Linux":
        return "/usr/bin/google-chrome"
    return r"C:\Program Files\Google\Chrome\Application\chrome.exe"


def _default_chromedriver() -> str:
    return ""


# ──────────────────────────────────────────────
# Paths
# ──────────────────────────────────────────────
PROJECT_ROOT: Path = Path(__file__).resolve().parent

load_dotenv(PROJECT_ROOT / ".env")

# Sottodirectory dati
DATA_DIR: Path = PROJECT_ROOT / "data"
DRAFTS_DIR: Path = DATA_DIR / "drafts"
SCREENSHOTS_DIR: Path = DATA_DIR / "screenshots"
PROCESSED_DIR: Path = DATA_DIR / "processed"
TEMPLATES_DIR: Path = PROJECT_ROOT / "templates"
POLICIES_DIR: Path = PROJECT_ROOT / "policies"
LOGS_DIR: Path = PROJECT_ROOT / "logs"
KNOWLEDGE_DIR: Path = PROJECT_ROOT / "knowledge"

# Knowledge base — tenant-specific in knowledge/ folder
BRAND_CONTEXT_PATH: Path = KNOWLEDGE_DIR / "brand_context.md"
BRAND_CONTEXT_FULL_PATH: Path = KNOWLEDGE_DIR / "brand_context_full.md"

# ──────────────────────────────────────────────
# Brand identity (mandatory — passed via .env)
# ──────────────────────────────────────────────
BRAND_NAME: str = os.getenv("BRAND_NAME", "Brand")
BRAND_NAME_LOWER: str = BRAND_NAME.lower()
BRAND_DOMAIN: str = os.getenv("BRAND_DOMAIN", "example.com")  # e.g. "yourstore.com"
BRAND_PRODUCTS_DESC: str = os.getenv(
    "BRAND_PRODUCTS_DESC",
    "premium e-commerce products"
)  # e.g. "your product category"
BRAND_LANGUAGE: str = os.getenv("BRAND_LANGUAGE", "english")  # english | italian | arabic | …
BRAND_TIMEZONE: str = os.getenv("BRAND_TIMEZONE", "Europe/Rome")
BRAND_RETURNS_URL: str = os.getenv(
    "BRAND_RETURNS_URL", f"https://{BRAND_DOMAIN}/policies/refund-policy"
)
BRAND_SHIPPING_URL: str = os.getenv(
    "BRAND_SHIPPING_URL", f"https://{BRAND_DOMAIN}/policies/shipping-policy"
)
BRAND_SIGN_OFF: str = os.getenv("BRAND_SIGN_OFF", f"{BRAND_NAME} Customer Care Team")
ORDER_ID_PREFIX: str = os.getenv("ORDER_ID_PREFIX", "")  # e.g. "LS", "KG" — leave blank for digits-only

# ──────────────────────────────────────────────
# Claude API
# ──────────────────────────────────────────────
ANTHROPIC_API_KEY: str = os.getenv("ANTHROPIC_API_KEY", "")
CLAUDE_MODEL: str = os.getenv("CLAUDE_MODEL", "claude-sonnet-4-20250514")
CLAUDE_OPUS_MODEL: str = os.getenv("CLAUDE_OPUS_MODEL", "claude-opus-4-20250514")
CLAUDE_MAX_TOKENS: int = int(os.getenv("CLAUDE_MAX_TOKENS", "4096"))

# ──────────────────────────────────────────────
# Email IMAP/SMTP — tenant-configurable provider
# ──────────────────────────────────────────────
EMAIL_ADDRESS: str = os.getenv("SUPPORT_EMAIL", f"info@{BRAND_DOMAIN}")
EMAIL_PASSWORD: str = os.getenv("MAIL_PASSWORD", "")
IMAP_SERVER: str = os.getenv("IMAP_SERVER", "imap.hostinger.com")
IMAP_PORT: int = int(os.getenv("IMAP_PORT", "993"))
SMTP_SERVER: str = os.getenv("SMTP_SERVER", "smtp.hostinger.com")
SMTP_PORT: int = int(os.getenv("SMTP_PORT", "465"))

# Nomi cartella Drafts da provare (covers most providers IT/EN/AR)
DRAFTS_FOLDER_NAMES: list[str] = [
    "Drafts",
    "INBOX.Drafts",
    "Bozze",
    "INBOX.Bozze",
    "[Gmail]/Drafts",
    "Brouillons",
    "Borradores",
    "Entwürfe",
]

# ──────────────────────────────────────────────
# Shopify API
# ──────────────────────────────────────────────
SHOPIFY_STORE_URL: str = os.getenv("SHOPIFY_STORE_URL", "").rstrip("/")
SHOPIFY_API_TOKEN: str = os.getenv("SHOPIFY_API_TOKEN", "")
SHOPIFY_API_VERSION: str = os.getenv("SHOPIFY_API_VERSION", "2024-01")

# ──────────────────────────────────────────────
# ParcelPanel API v2 (optional)
# ──────────────────────────────────────────────
PARCELPANEL_API_KEY: str = os.getenv("PARCELPANEL_API_KEY", "")
PARCELPANEL_BASE_URL: str = os.getenv("PARCELPANEL_BASE_URL", "https://open.parcelwill.com")

# ──────────────────────────────────────────────
# Selenium / Chrome
# ──────────────────────────────────────────────
CHROME_BIN: str = os.getenv("CHROME_BIN") or _default_chrome_bin()
CHROMEDRIVER_PATH: str = os.getenv("CHROMEDRIVER_PATH") or _default_chromedriver()

# ──────────────────────────────────────────────
# Telegram (opzionale)
# ──────────────────────────────────────────────
TELEGRAM_BOT_TOKEN: str = os.getenv("TELEGRAM_BOT_TOKEN", "")
TELEGRAM_CHAT_ID: str = os.getenv("TELEGRAM_CHAT_ID", "")

# ──────────────────────────────────────────────
# Web server / Auth / Tunnel
# ──────────────────────────────────────────────
WEB_PORT: int = int(os.getenv("WEB_PORT", "8899"))
WEB_AUTH_USERNAME: str = os.getenv("WEB_AUTH_USERNAME", BRAND_NAME_LOWER)
WEB_AUTH_PASSWORD: str = os.getenv("WEB_AUTH_PASSWORD", "")
TUNNEL_NAME: str = os.getenv("CLOUDFLARE_TUNNEL_NAME", f"{BRAND_NAME_LOWER}-care")
PUBLIC_URL: str = os.getenv("CLOUDFLARE_PUBLIC_URL", "")  # e.g. "https://care.brand.com"

# ──────────────────────────────────────────────
# Scheduling
# ──────────────────────────────────────────────
POLL_INTERVAL_MINUTES: int = int(os.getenv("POLL_INTERVAL_MINUTES", "10"))
TIMEZONE: str = BRAND_TIMEZONE

# ──────────────────────────────────────────────
# Test / log
# ──────────────────────────────────────────────
TEST_EMAIL_LIMIT: int = int(os.getenv("TEST_EMAIL_LIMIT", "10"))
LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")

# ──────────────────────────────────────────────
# Categorie Email
# ──────────────────────────────────────────────
EMAIL_CATEGORIES: dict[str, str] = {
    "RESO_RIMBORSO": "Richiesta reso o rimborso",
    "ORDINE_NON_ARRIVATO": "Ordine non ricevuto / tracking",
    "TAGLIA_COLORE": "Domanda su taglia o colore",
    "PRODOTTO_DIFETTOSO": "Prodotto danneggiato o difettoso",
    "INFO_PRODOTTO": "Informazioni su prodotti",
    "MODIFICA_ORDINE": "Modifica o cancellazione ordine",
    "PAGAMENTO": "Problema pagamento",
    "FEEDBACK_POSITIVO": "Complimento o recensione positiva",
    "FEEDBACK_NEGATIVO": "Reclamo o recensione negativa",
    "PARTNERSHIP": "Proposta partnership o collaborazione",
    "FORNITORE": "Comunicazione fornitore",
    "SPAM_MARKETING": "Spam o newsletter non richiesta",
    "ALTRO": "Altro non classificabile",
}

# Categorie da ignorare (no risposta)
SKIP_CATEGORIES: set[str] = {"PARTNERSHIP", "FORNITORE", "SPAM_MARKETING"}


# ──────────────────────────────────────────────
# Brand context dict for prompt rendering
# ──────────────────────────────────────────────
def get_brand_vars() -> dict[str, str]:
    """Variables exposed to prompt templates via {{VAR}} substitution."""
    return {
        "BRAND_NAME": BRAND_NAME,
        "BRAND_NAME_LOWER": BRAND_NAME_LOWER,
        "BRAND_DOMAIN": BRAND_DOMAIN,
        "BRAND_PRODUCTS_DESC": BRAND_PRODUCTS_DESC,
        "BRAND_LANGUAGE": BRAND_LANGUAGE,
        "BRAND_RETURNS_URL": BRAND_RETURNS_URL,
        "BRAND_SHIPPING_URL": BRAND_SHIPPING_URL,
        "BRAND_SIGN_OFF": BRAND_SIGN_OFF,
        "SUPPORT_EMAIL": EMAIL_ADDRESS,
        "ORDER_ID_PREFIX": ORDER_ID_PREFIX,
    }


def render_template(text: str) -> str:
    """Render {{VAR}} placeholders with brand vars."""
    out = text
    for k, v in get_brand_vars().items():
        out = out.replace("{{" + k + "}}", v)
    return out


def ensure_dirs() -> None:
    """Crea tutte le directory necessarie."""
    for d in [DATA_DIR, DRAFTS_DIR, SCREENSHOTS_DIR, PROCESSED_DIR,
              TEMPLATES_DIR, POLICIES_DIR, LOGS_DIR, KNOWLEDGE_DIR]:
        d.mkdir(parents=True, exist_ok=True)


def validate_env() -> dict[str, bool]:
    """Verifica che le variabili d'ambiente critiche siano presenti."""
    checks = {
        "BRAND_NAME": BRAND_NAME != "Brand",
        "BRAND_DOMAIN": BRAND_DOMAIN != "example.com",
        "ANTHROPIC_API_KEY": bool(ANTHROPIC_API_KEY),
        "MAIL_PASSWORD": bool(EMAIL_PASSWORD),
        "SUPPORT_EMAIL": bool(EMAIL_ADDRESS) and "@" in EMAIL_ADDRESS,
        "SHOPIFY_STORE_URL": bool(SHOPIFY_STORE_URL),
        "SHOPIFY_API_TOKEN": bool(SHOPIFY_API_TOKEN),
        "WEB_AUTH_PASSWORD": bool(WEB_AUTH_PASSWORD),
    }
    return checks
