---
name: customer-care
description: "Operate the CustomerCareAgent — verify connections, fetch email, manage draft replies. Brand-agnostic: uses values from .env (BRAND_NAME, SUPPORT_EMAIL, SHOPIFY_STORE_URL)."
allowed-tools: ["bash", "read_file", "write_file"]
---

# Customer Care Agent Skill

## Goal
Operate the brand-agnostic customer care agent that reads email from `SUPPORT_EMAIL`,
looks up orders on Shopify, verifies tracking on ParcelPanel, and drafts replies
via Claude. Never auto-sends — drafts always wait for human review.

## Setup (once per brand)
```bash
./setup.sh                         # Interactive wizard → .env + brand_context.md
pip install -r requirements.txt
python main.py --check
```

## Main commands
```bash
python main.py --check              # Verify all connections
python main.py --dry-run            # Fetch recent emails (default 10)
python main.py --dry-run --limit 5  # Fetch 5
python main.py --once               # Single cycle
python main.py --schedule           # Poll every POLL_INTERVAL_MINUTES
python web_server.py                # Dashboard at WEB_PORT (basic auth)
```

## SDD Commands
- `/plan` — regenerate spec and tasks
- `/build` — run next task batch
- `/verify` — verify current milestone
- `/status` — show task state

## Troubleshooting
1. **IMAP login fails** — check `MAIL_PASSWORD`, `IMAP_SERVER`, `SUPPORT_EMAIL` in .env
2. **Shopify 401** — check `SHOPIFY_API_TOKEN` and scopes (read_orders, read_customers, read_products)
3. **ParcelPanel skipped** — set `PARCELPANEL_API_KEY` (or leave empty to disable)
4. **Chrome not found** — check `CHROME_BIN` and `CHROMEDRIVER_PATH` in .env
5. **Knowledge base empty** — edit `knowledge/brand_context.md` (created by setup.sh)
6. **Email_agent bridge** — disabled by default; set `EMAIL_AGENT_REPORTS_DIR` only if you have an external Email_agent producing daily JSON reports

## Connections (all env-driven)
- Email: `IMAP_SERVER:IMAP_PORT` / `SMTP_SERVER:SMTP_PORT` for `SUPPORT_EMAIL`
- Shopify: `SHOPIFY_STORE_URL` (API `SHOPIFY_API_VERSION`)
- Claude: model defaults to claude-sonnet-4-5
- ParcelPanel: open.parcelwill.com/api/v2 (optional)
- Chrome: headless for tracking screenshots