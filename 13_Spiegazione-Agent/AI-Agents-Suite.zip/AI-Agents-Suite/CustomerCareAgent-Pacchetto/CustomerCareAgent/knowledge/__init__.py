"""Knowledge base loader."""
