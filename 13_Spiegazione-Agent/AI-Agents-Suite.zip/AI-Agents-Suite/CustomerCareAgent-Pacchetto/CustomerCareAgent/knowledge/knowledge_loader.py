"""
Knowledge Base Loader.
Loads brand context, policy store, reply templates, and email categories
from tenant-local knowledge/ and templates/ directories.
"""

import logging
from pathlib import Path

import sys
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from config import (
    BRAND_CONTEXT_PATH, BRAND_CONTEXT_FULL_PATH,
    TEMPLATES_DIR, POLICIES_DIR, EMAIL_CATEGORIES,
)

logger = logging.getLogger(__name__)


def load_brand_context() -> str:
    """
    Carica il brand context base da shared/brand_context.md.
    Ritorna il contenuto o stringa vuota se non trovato.
    """
    if BRAND_CONTEXT_PATH.exists():
        text = BRAND_CONTEXT_PATH.read_text(encoding="utf-8")
        logger.info("Brand context caricato: %s (%d chars)", BRAND_CONTEXT_PATH.name, len(text))
        return text
    logger.warning("Brand context non trovato: %s", BRAND_CONTEXT_PATH)
    return ""


def load_brand_context_full() -> str:
    """
    Carica il brand context completo da Marketing_KB.
    Ritorna il contenuto o stringa vuota se non trovato.
    """
    if BRAND_CONTEXT_FULL_PATH.exists():
        text = BRAND_CONTEXT_FULL_PATH.read_text(encoding="utf-8")
        logger.info("Brand context completo caricato: %s (%d chars)", BRAND_CONTEXT_FULL_PATH.name, len(text))
        return text
    logger.warning("Brand context completo non trovato: %s", BRAND_CONTEXT_FULL_PATH)
    return ""


def load_templates() -> dict[str, str]:
    """
    Carica tutti i template risposte dalla directory templates/.
    Ritorna dict {nome_file: contenuto}.
    """
    templates: dict[str, str] = {}
    if not TEMPLATES_DIR.exists():
        return templates

    for f in TEMPLATES_DIR.glob("*.md"):
        try:
            templates[f.stem] = f.read_text(encoding="utf-8")
        except Exception as e:
            logger.error("Errore caricamento template %s: %s", f.name, e)

    if templates:
        logger.info("Template caricati: %d file", len(templates))
    return templates


def load_policies() -> dict[str, str]:
    """
    Carica policy store dalla directory policies/.
    Ritorna dict {nome_file: contenuto}.
    """
    policies: dict[str, str] = {}
    if not POLICIES_DIR.exists():
        return policies

    for f in POLICIES_DIR.glob("*.md"):
        try:
            policies[f.stem] = f.read_text(encoding="utf-8")
        except Exception as e:
            logger.error("Errore caricamento policy %s: %s", f.name, e)

    if policies:
        logger.info("Policy caricate: %d file", len(policies))
    return policies


def get_email_categories() -> dict[str, str]:
    """Ritorna le categorie email per la classificazione."""
    return EMAIL_CATEGORIES


def test_knowledge_access() -> tuple[bool, str]:
    """
    Verifica che i file knowledge base siano accessibili.
    Ritorna (success, messaggio).
    """
    results: list[str] = []
    all_ok = True

    # Brand context base
    if BRAND_CONTEXT_PATH.exists():
        size = BRAND_CONTEXT_PATH.stat().st_size
        results.append(f"brand_context.md ({size / 1024:.1f} KB)")
    else:
        results.append("brand_context.md MANCANTE")
        all_ok = False

    # Brand context completo
    if BRAND_CONTEXT_FULL_PATH.exists():
        size = BRAND_CONTEXT_FULL_PATH.stat().st_size
        results.append(f"brand_context_completo.md ({size / 1024:.1f} KB)")
    else:
        results.append("brand_context_completo.md MANCANTE")

    # Template
    template_count = len(list(TEMPLATES_DIR.glob("*.md"))) if TEMPLATES_DIR.exists() else 0
    results.append(f"{template_count} template")

    # Policy
    policy_count = len(list(POLICIES_DIR.glob("*.md"))) if POLICIES_DIR.exists() else 0
    results.append(f"{policy_count} policy")

    msg = " | ".join(results)
    return all_ok, msg
