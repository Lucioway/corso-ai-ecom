#!/usr/bin/env bash
# CustomerCareAgent — macOS launcher (web server + optional tunnel)

set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

VENV_PY="$DIR/.venv/bin/python"
if [ ! -x "$VENV_PY" ]; then
  echo "venv missing at $VENV_PY — run: python3 -m venv .venv && .venv/bin/pip install -r requirements.txt"
  exit 1
fi

LOG_DIR="$DIR/logs"
mkdir -p "$LOG_DIR"

echo "Starting web_server.py..."
nohup "$VENV_PY" web_server.py > "$LOG_DIR/web_server.out" 2>&1 &
WEB_PID=$!
echo "web_server PID=$WEB_PID"

if command -v cloudflared >/dev/null 2>&1; then
  sleep 5
  echo "Starting tunnel_manager.py..."
  nohup "$VENV_PY" tunnel_manager.py > "$LOG_DIR/tunnel_manager.out" 2>&1 &
  TUN_PID=$!
  echo "tunnel_manager PID=$TUN_PID"
else
  echo "cloudflared not installed — skipping tunnel. Install: brew install cloudflared"
fi

echo "Done. Tail logs: tail -f $LOG_DIR/web_server.out"
