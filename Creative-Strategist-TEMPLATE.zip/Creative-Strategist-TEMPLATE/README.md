# Creative Strategist Agent — Replication Template

A teaching template for building a **Creative Strategist + Direct-Response Copywriter** AI agent.
Clone this folder, rename `_brand_/` to your brand, fill the placeholders, and you have a
working creative agent grounded in a marketing knowledge base.

This template contains **pure information only** — generic marketing frameworks, no proprietary
names, no brand-specific data. Everything here is meant to be copied and adapted.

---

## What this agent does

Given a brand and a brief, it produces production-ready creative output:
hooks, ad copy, landing-page sections, full product pages, emails, VSL scripts, angle research.

Every output is **grounded** in two things:
1. The **brand truth** (voice, audience, product facts, forbidden words) — `memory/brand.md`
2. The **marketing canon** (frameworks for desire, awareness, offers, copy) — `knowledge/`

It never invents brand facts. If a fact is missing, it asks. It learns over time through a
feedback loop (`winners.md` / `losers.md` / `hypotheses.md`).

---

## The 3-layer architecture

```
LAYER 1 — THE AGENT (how it works)
  agent/creative-strategist.md      the role, the workflow, the hard rules

LAYER 2 — THE BRAND VAULT (what it knows)
  _brand_/CLAUDE.md                 per-brand config + routing
  _brand_/memory/                   brand truth + feedback loop
  _brand_/knowledge/                the marketing frameworks (read-only)
  _brand_/wiki/                     distilled index linking concepts to sources
  _brand_/outputs/                  saved deliverables

LAYER 3 — THE GRAPH (how it navigates) — optional, generated
  graphify-out/                     auto-built knowledge graph over the vault
```

You can run the agent with **just Layer 1 + 2**. Layer 3 (the graph) is an optional power-up
for large knowledge bases — skip it until your vault is big enough to need it.

---

## Folder map

```
Creative-Strategist-TEMPLATE/
├── README.md                         ← this guide
├── agent/
│   └── creative-strategist.md        ← the agent definition (the brain)
└── _brand_/                          ← rename to your brand (e.g. acme/)
    ├── CLAUDE.md                     ← brand config: routing + output rules
    ├── memory/
    │   ├── brand.md                  ← single source of truth (voice/audience/product)
    │   ├── winners.md                ← creatives that worked (append-only)
    │   ├── losers.md                 ← creatives that failed + why (append-only)
    │   ├── hypotheses.md             ← open bets to test
    │   └── log.md                    ← chronological brief → output log
    ├── knowledge/                    ← the marketing frameworks (read-only)
    │   ├── Angle-Identifier.md           distributable — pure info
    │   ├── Copywriting-Fundamentals.md   distributable — pure info
    │   ├── Printing-Ecom-System.md       distributable — pure info
    │   ├── 100M-Leads_Hormozi.md         private book reference
    │   ├── Breakthrough-Advertising_Schwartz.md   private book reference
    │   ├── _neutral-summaries/           short framework digests (quick reference)
    │   └── _reference-private/           your private sources — do NOT distribute
    ├── wiki/
    │   └── index.md                  ← distilled concept index
    └── outputs/
        └── .gitkeep
```

---

## How to replicate (step by step)

### Step 1 — Copy the skeleton
Copy the whole template. Rename `_brand_/` to your brand slug (lowercase, e.g. `acme/`).

### Step 2 — Install the agent
Put `agent/creative-strategist.md` where your AI tool reads agent definitions
(e.g. `.claude/agents/` for Claude Code, or as a system prompt for any LLM).
If you run multiple brands, the agent stays shared — only the brand vault changes.

### Step 3 — Fill the brand truth
Open `memory/brand.md` and replace every `TBD`. This is the most important file.
The agent is only as good as this file. Be specific: real voice, real audience, real product
facts, the words you forbid. If you don't know something yet, leave `TBD` — the agent will ask
rather than invent.

### Step 4 — Keep the knowledge as-is (or extend it)
The `knowledge/` files are marketing frameworks — reusable across any brand. They are **read-only**.
The top-level pure-info files are safe to distribute/teach; anything under `_reference-private/` is
your own private source material — keep it out of anything you hand out. Add your own source files
if you want, but never edit a framework in a way that loses the principle.

### Step 5 — Run a brief
Give the agent a brief: `brand` + `what to write` + `deliverable format`.
It loads brand truth, pulls the relevant framework from `knowledge/`, composes, and saves to
`outputs/` with a date prefix.

### Step 6 — Close the loop
When a creative wins, append it to `winners.md`. When one fails, append it to `losers.md` with
the reason. The agent reads both before composing similar briefs, so it stops repeating losers
and reuses winners. This is what makes it improve over time.

### Step 7 (optional) — Build the graph
Once the vault has many files, build a knowledge graph over it so the agent can discover which
framework governs a brief and trace why past winners worked. Until then, simple file reads are
enough — don't add this complexity early.

---

## The feedback loop (the part most people skip)

```
brief ──▶ agent composes ──▶ output saved ──▶ human verdict
                                                 │
              ┌──────────────────────────────────┤
              ▼                  ▼                ▼
          winners.md         losers.md       brand.md patch
        (reuse pattern)   (avoid pattern)   (fix the voice)
              └──────────────┬───────────────────┘
                             ▼
                  next brief is smarter
```

The agent does **not** manage this loop itself. A human (or an orchestrator) records the verdict.
Every brief and output is appended to `log.md` regardless of outcome.

---

## Teaching notes

- **Start small.** A working agent needs only `creative-strategist.md` + `brand.md` +
  the 6 knowledge files. Everything else is progressive enhancement.
- **The brand truth is the lever.** 80% of output quality comes from `brand.md`. Spend the time there.
- **Knowledge is reusable, brand truth is not.** The frameworks are universal. The voice is sacred to one brand.
- **Read-only knowledge prevents drift.** If the agent could edit its own frameworks, it would
  slowly rewrite them into mush. Lock them.
- **Citations prove grounding.** Requiring the agent to point at the framework it applied is how
  you catch hallucination — if it can't cite the principle, it made the move up.
```
