---
name: _brand_ Creative Wiki — Index
type: index
last_verified: TBD
sources: [Breakthrough-Advertising_Schwartz.md, 100M-Leads_Hormozi.md, Copywriting-Fundamentals.md, Angle-Identifier.md, Printing-Ecom-System.md]
---

# _brand_ Creative Wiki

A distilled index over the `knowledge/` source documents. Each concept links to the file that
defines it, so the agent can jump straight to the principle a brief needs. Populate concept pages
over time as the brand's own application of each idea takes shape.

Source-file shorthand used below: Schwartz = `Breakthrough-Advertising_Schwartz.md`,
Hormozi = `100M-Leads_Hormozi.md`, Bible = `Copywriting-Fundamentals.md`,
Angle = `Angle-Identifier.md`, Printing = `Printing-Ecom-System.md`.

## Concepts

### Awareness + sophistication
- [[awareness-stages]] — five stages, unaware → most aware → Schwartz
- [[sophistication-levels]] — claim → mechanism → identity → Schwartz
- [[depositioning]] — reframe the obvious alternative as the problem → Schwartz

### Desire + emotion
- [[mass-desire]] — channel a pre-existing want, don't manufacture one → Schwartz
- [[emotional-drivers]] — fear, aspiration, belonging, pride → Schwartz
- [[emotion-then-logic]] — feel first, justify second → Schwartz

### Offer + value
- [[value-equation]] — dream × likelihood ÷ time × effort → Hormozi
- [[offer-stack]] — core + bonus + guarantee + scarcity → Hormozi
- [[risk-reversal]] — transfer the buyer's risk to the seller → Hormozi
- [[lead-magnets]] — solve a narrow problem to earn the next step → Hormozi

### Hooks + copy
- [[hook-patterns]] — curiosity, pattern-interrupt, contrarian, demo → Bible
- [[fascination-bullets]] — benefit + curiosity, sell the unseen → Bible
- [[proof-hierarchy]] — demonstration > specifics > third-party > reason-why → Bible
- [[clarity-over-clever]] — confused readers don't buy → Bible

### Angle + sub-avatar
- [[what-is-an-angle]] — the reason-to-buy, from the customer's view → Angle
- [[sub-avatar-mapping]] — same product, different people, different angles → Angle
- [[isolate-the-variable]] — change one thing per test → Angle

### Funnel + landing
- [[message-match]] — the page must continue the ad → Printing
- [[landing-section-order]] — mobile-first DR page sequence → Printing
- [[friction-removal]] — every step leaks conversions → Printing

## Patterns (cross-framework)

- [[awareness-to-hook]] — map awareness stage → the right opening move
- [[claim-mechanism-identity]] — escalate as the market gets sophisticated
- [[before-after-bridge]] — pain → desired state → product as bridge
- [[problem-agitate-solution]] — the recurring direct-response spine

---

## Population status
- [ ] concepts/ — 0 populated (create a page per concept as the brand applies it)
- [ ] patterns/ — 0 populated

Populate with the brand's own examples. Every page links back to its source knowledge file.
