---
name: _brand_ Brand Truth
type: memory
status: draft
last_verified: TBD
---

# _brand_ — Brand Truth

> Single source of truth for voice, audience, products, USP. Read by the Creative Strategist
> before every output. Update only when verified. The agent treats this file as fact — keep it true.

## Mission
TBD — one sentence: what the brand exists to do for the customer.

## Brand voice
- Language: TBD (primary market language)
- Reading grade: TBD (e.g. grade 6 — plain and direct)
- Tone: TBD (warm / direct / aspirational / clinical / playful)
- Point of view: TBD (you-focused / we-focused)
- Read-aloud test: if you wouldn't say it naturally out loud, rewrite it.

## Markets and channels
- Domains: TBD
- Markets: TBD
- Ads: TBD (which platforms / formats)

## Positioning
- Category: TBD
- Core promise / USP: TBD
- What we deposition against (the status quo or the obvious alternative): TBD

## Target KPIs
- Primary metric: TBD
- Definition of a winning creative: TBD
- Goal: TBD

---

## Products

### HERO — [product name]
- What it is: TBD
- Mechanism (why it works — must be true, not invented): TBD
- Proof points: TBD
- Formats / prices: TBD

### Other products
- [ ] add on demand

---

## Audience

### Avatar 1 — [name]
- Age: TBD
- Income band: TBD
- Dominant pain: TBD
- Dominant desire: TBD
- Awareness stage: TBD (see knowledge/01)
- Sophistication level: TBD (see knowledge/01)
- Identity / self-image: TBD
- Where they spend attention (channels): TBD

### Sub-avatars
[Per product, list specific sub-avatars with their distinct angle. Fill in over time. See knowledge/05.]

---

## Forbidden words / phrases
- TBD — populate as the voice sharpens (claims you legally can't make, off-brand words)

## Preferred words / phrases
- TBD — populate from winners

---

## Operating notes
- Voice rule: read-aloud test on every line.
- Claims rule: every product claim must be true and substantiable. Unverified → mark `[VERIFY]`.
- Source authority: only `knowledge/` frameworks + this file + verified customer voice. No external.
