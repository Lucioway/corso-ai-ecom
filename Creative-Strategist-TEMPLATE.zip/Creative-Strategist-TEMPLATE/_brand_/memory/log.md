# _brand_ — Creative Log

> Chronological brief → output log. Every brief gets an entry, regardless of outcome.
> The agent appends one line per delivery.

## Format
```
## [YYYY-MM-DD HH:MM] <brief-type> | <one-line summary> → outputs/<file>.md
```

---

<!-- Newest at the bottom. -->
