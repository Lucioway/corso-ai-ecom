---
name: _brand_ Losers
type: memory
append_only: true
---

# _brand_ — Losers

> Creatives that failed, with the reason. Append-only. The agent reads this before composing to
> avoid repeating mistakes. The reason matters more than the creative — capture *why* it failed.

## Template for each entry
```
## [YYYY-MM-DD] <creative type> — <one-line label>
- What it was: <the creative>
- Why it failed: <metric or signal + the likely cause>
- Lesson: <what to avoid next time, stated generally>
```

---

<!-- Append losses below. Newest at the bottom. -->
