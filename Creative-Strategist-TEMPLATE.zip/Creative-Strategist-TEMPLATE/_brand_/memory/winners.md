---
name: _brand_ Winners
type: memory
append_only: true
---

# _brand_ — Winners

> Creatives that proved they work. Append-only. The agent reads this before composing similar
> briefs to reuse what's validated. One entry per win.

## Template for each entry
```
## [YYYY-MM-DD] <creative type> — <one-line label>
- What it was: <hook / headline / section text>
- Why it won: <metric or signal — be concrete>
- Framework behind it: <which principle, from which knowledge file>
- Reusable pattern: <the transferable lesson, stated generally>
```

---

<!-- Append wins below. Newest at the bottom. -->
