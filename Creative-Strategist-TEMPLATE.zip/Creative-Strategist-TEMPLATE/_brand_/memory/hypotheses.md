---
name: _brand_ Hypotheses
type: memory
---

# _brand_ — Open Hypotheses

> Bets the brand wants to test. Each one is a falsifiable claim about what will work and why.
> When a test resolves, move the result to winners.md or losers.md and close the hypothesis here.

## Template for each hypothesis
```
## H<N> — <one-line claim>
- Belief: <what we think will work>
- Reason: <why — which audience insight or framework supports it>
- Test: <how we'll know — the creative + the metric that settles it>
- Status: open / testing / resolved → <winner|loser>
```

---

<!-- Append hypotheses below. -->
