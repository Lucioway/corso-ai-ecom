### **OFFER HORMOZI**

1.  **Scegliere il Mercato\**

2.  **Fai Pagare il Tuo Prodotto per il Suo Vero Valore\**

3.  **L’Equazione del Valore\**

4.  **Creazione dell’Offerta\**

5.  **Bonus e Garanzie\**

6.  **Scarsità e Urgenza\**

7.  **Naming**

Tutti pensano che per vendere di più basti un prodotto migliore.

Ma la verità è che **le persone non comprano prodotti — comprano offerte**.

Un prodotto è solo ciò che vendi.

Un’offerta è **come lo rendi irresistibile**.

È la combinazione di prezzo, valore, bonus, garanzie e urgenza che fa sembrare ogni euro speso un affare.

Puoi avere la creatività migliore, la campagna più costosa, o il sito più veloce… ma se l’offerta non è costruita bene, **tutto il resto è rumore**.

Quando impari a creare offerte impossibili da ignorare, non devi più spingere la vendita:

le persone iniziano a spingere per comprare.

L'offerta è il componente più critico perché tocca ogni aspetto dell'ecosistema aziendale. Non si tratta solo del prezzo, ma di una struttura complessa.

L'offerta influenza direttamente:

\- Tasso di conversione (CVR)

\- Valore medio dell'ordine (AOV)

\- Percentuale di adesione all'abbonamento

\- Tasso di retention degli abbonati

\- Valore dell'ordine nell'abbonamento

8.  **\**

SCEGLIERE IL MERCATO

# **SCEGLIERE IL MERCATO GIUSTO**

## **Come identificare il mercato più profittevole per il tuo business**

Ecco **4 step chiave** per scegliere il mercato giusto:

**Leve del successo**

**4 variabili per scegliere un mercato**

**I 3 mercati principali**

**L'importanza della nicchia**

## **Le 3 Leve del Successo**

Per avere successo in qualsiasi business, ci sono **3 elementi fondamentali**:

### **1. Il mercato**

Se vendi qualcosa con **alta domanda e poca offerta**, hai già vinto.

**Esempio**: Durante la pandemia, chi aveva mascherine o carta igienica vendeva tutto senza alcuna strategia.

Se **sei già in un mercato in forte crescita**, **non hai bisogno di molte competenze**. Ma se il tuo mercato è **stagnante o in calo**, sarà **molto più difficile avere successo**.

### **2. L'offerta**

Anche se sei in un buon mercato, **devi avere un'offerta irresistibile**.

Se la tua offerta è **normale o mediocre**, avrai bisogno di molta **persuasione** per convincere i clienti.

### **3. La persuasione**

Se il tuo mercato è **normale** e la tua offerta è **normale**, devi essere **bravissimo a vendere**.

**Meglio avere un mercato in crescita e un'offerta forte**, piuttosto che dover **compensare con la sola abilità di vendita**.

## **Le 4 Variabili per Scegliere un Mercato**

Ogni mercato che prendi in considerazione **deve soddisfare questi 4 criteri**:

### **1. Urgenza del problema (Pain Point)**

Il problema che risolvi **deve essere doloroso e urgente**.

**Esempio:** Vendere hot dog alle **2 di notte** fuori dai locali → la gente **muore di fame e compra subito**.

### **2. Potere d'acquisto**

I tuoi clienti **devono avere i soldi per comprare il tuo prodotto**.

**Esempio:** Un mio amico offriva servizi di revisione CV, ma il suo pubblico era **disoccupato e senza soldi** → **business fallito**.

### **3. Facilità di targeting**

Deve essere **facile raggiungere il tuo pubblico con ads** o altri metodi di marketing.

**Esempio:** Se vendi un prodotto per **medici**, devi avere un modo per **raggiungerli direttamente**, altrimenti le tue campagne non funzioneranno.

### **4. Crescita del mercato**

Devi scegliere un mercato in **crescita, non in declino**.

**Esempio:** Un mio amico vendeva pubblicità per **giornali cartacei** (un settore che cala del **25% l'anno**) → **business condannato al fallimento**.

**Se il mercato non soddisfa tutte queste 4 variabili, scegli un altro mercato.**

## **I 3 Mercati Principali**

Ogni business rientra in **uno di questi 3 settori**:

**Salute** (es. nutrizione, allenamento, benessere)

**Ricchezza** (es. investimenti, business, marketing)

**Relazioni** (es. appuntamenti, matrimonio, amicizie)

**Questi 3 mercati esistono perché risolvono i problemi fondamentali dell'essere umano:**

**Soldi** (voglio più stabilità e ricchezza)

**Amore** (voglio relazioni migliori e più felicità)

**Salute** (voglio vivere più a lungo e stare bene)

Ogni business di successo **aiuta un pubblico specifico** a **risolvere un problema specifico** con **un metodo unico**.

## **L'Importanza della Nicchia (Riches in Niches)**

Se il tuo business non cresce, **forse sei troppo generico**.

Più sei **specifico**, più puoi **aumentare i prezzi**.

### **Esempio pratico:**

**Corso generico su "Gestione del Tempo"** → Prezzo: **\$19**

**Gestione del Tempo per venditori** → Prezzo: **\$99**

**Gestione del Tempo per venditori B2B** → Prezzo: **\$500**

**Gestione del Tempo per venditori di attrezzature da giardino B2B** → Prezzo: **\$2000**

**Stesso contenuto, ma 100X il prezzo semplicemente specializzandosi!**

Se vuoi evitare la concorrenza e vendere a prezzi più alti, **devi creare una categoria di 1**.

## **Conclusione: Come Scegliere il Tuo Mercato**

Trova un **problema doloroso e urgente** da risolvere

Assicurati che il pubblico abbia **soldi da spendere**

Verifica che il pubblico sia **facile da raggiungere**

Scegli un mercato in **crescita, non in declino**

**Nichiati il più possibile** per evitare concorrenza e aumentare i prezzi

<img src="/tmp/pandoc_media_discard/media/image31.png" style="width:7.29167in;height:8.03125in" />

FAI PAGARE IL TUO PRODOTTO PER IL SUO VERO VALORE

# **FAI PAGARE IL TUO PRODOTTO PER IL SUO VERO VALORE**

## **Come stabilire il prezzo giusto per massimizzare il profitto**

### **Perché la tua offerta non converte?**

Se sei nel mercato giusto ma le vendite non decollano, il problema potrebbe essere il prezzo.

Ecco 3 concetti fondamentali per trovare il prezzo ideale:

1.  Discrepanza tra prezzo e valore

2.  Il ciclo virtuoso del prezzo

3.  La correlazione tra prezzo e valore percepito

## **1. Discrepanza tra Prezzo e Valore**

Le persone comprano solo se percepiscono che il valore ricevuto è maggiore del prezzo pagato.

- Finché il valore percepito è più alto del prezzo, continueranno ad acquistare.

- Se il valore percepito diventa uguale o inferiore al prezzo, smetteranno di comprare o cancelleranno il loro abbonamento.

**Se vendi solo una volta a un cliente e non hai riacquisti o referral, significa che il valore percepito è troppo basso rispetto al prezzo.**

### **Come risolverlo?**

1.  **Abbassare il prezzo** (opzione pessima, porta al fallimento)

2.  **Aumentare il valore percepito** (la scelta giusta)

**Obiettivo**: i clienti devono sempre sentire di comprare dollari a sconto.

## **2. Il Ciclo Virtuoso del Prezzo**

### **Il ciclo vizioso del prezzo (da evitare!)**

- Guardi il mercato e copi i prezzi dei concorrenti

- Ti posizioni un po' più in basso per restare "competitivo"

- Offri un po' di più degli altri per lo stesso prezzo

- Finisci per vendere sempre di più a sempre meno

- Ti ritrovi a non avere margine e a lottare per la sopravvivenza

### **Il ciclo virtuoso del prezzo (da seguire!)**

- Aumenti il prezzo e i clienti sono più investiti emotivamente

- Maggiore investimento = maggiore valore percepito

- Migliori risultati per il cliente, meno richieste di assistenza

- Più profitto per te, più risorse per offrire un'esperienza premium

- Più clienti soddisfatti, più referral e meno competizione

**Se aumenti il prezzo, migliori la qualità della clientela e il valore del tuo prodotto.**

## **3. Prezzo e Valore Percepito**

- Prezzo alto = percezione di maggiore valore

- Prezzo basso = percezione di minore valore

### **Esperimento del vino**

Un test ha mostrato che lo stesso identico vino, venduto a tre prezzi diversi (economico, medio, premium), è stato valutato in modo diverso:

- Il vino economico è stato giudicato scadente

- Il vino medio accettabile

- Il vino costoso eccellente

**Il prezzo ha influenzato la percezione della qualità, anche se il prodotto era identico.**

**Se alzi il prezzo, i tuoi clienti percepiranno il tuo prodotto come migliore.**

## **Caso Studio: Da \$5.000 a \$16.000**

Quando ho creato la mia azienda Gym Launch, il prodotto più costoso sul mercato costava \$5.000.

Invece di posizionarmi leggermente più in alto, ho scelto di vendere a \$16.000 (e fino a \$126.000).

### **Risultato:**

- Clienti convinti che fosse di qualità superiore

- Margine più alto per offrire un'esperienza premium

- Più referral e risultati migliori per i clienti

**Se il tuo prezzo è molto più alto della concorrenza, il cliente deve fermarsi e pensare: "Questo deve essere qualcosa di completamente diverso".**

## **Regole per Prezzi Vincenti**

1.  Fai pagare il valore reale, non quello di mercato

2.  Smetti di competere sul prezzo, diventa una categoria unica

3.  Usa il prezzo come leva di percezione

4.  Più il cliente paga, più è investito nel risultato

5.  Alzare il prezzo migliora l'esperienza e i risultati del cliente

<img src="/tmp/pandoc_media_discard/media/image25.png" style="width:7.55208in;height:8.5in" />

L'Equazione del Valore

# **L'Equazione del Valore**

## **Cos'è**

L'equazione del valore spiega perché i clienti comprano (o non comprano) il tuo prodotto.

## **La Formula**

VALORE = (Risultato Desiderato x Probabilità di Successo) / (Tempo + Sforzo)

In parole semplici:

- Più grande è il risultato promesso = più valore

- Più alta è la probabilità di successo = più valore

- Meno tempo ci vuole = più valore

- Meno fatica richiede = più valore

## **I 4 Elementi da Ottimizzare**

### **1. Risultato Desiderato**

Cosa prometti al cliente? Più è importante per lui, più pagherà.

Esempio: Aiutare qualcuno a guadagnare 100.000€ vale più di aiutarlo a perdere 3 kg.

Come migliorarlo:

- Concentrati su problemi grandi e costosi

- Prometti risultati trasformativi, non piccoli miglioramenti

### **2. Probabilità di Successo**

Il cliente deve credere che funzionerà davvero per lui.

Esempio: Un chirurgo esperto con 10.000 operazioni vs uno alla prima operazione. Paghi di più il primo perché sei sicuro del risultato.

Come migliorarlo:

- Mostra testimonianze reali

- Usa numeri e prove concrete

- Dimostra la tua esperienza

### **3. Tempo Necessario**

Quanto ci vuole per ottenere il risultato? Meno tempo = più valore.

Esempio: "Risultati in 30 giorni" vale più di "Risultati in 1 anno"

Come migliorarlo:

- Prometti tempi brevi e specifici

- Offri risultati immediati o veloci

- Mostra progressi fin da subito

### **4. Sforzo Richiesto**

Quanta fatica deve fare il cliente? Meno fatica = più valore.

Esempio: Netflix (clicchi e guardi) vs andare in videoteca (esci, guidi, noleggi, restituisci)

Come migliorarlo:

- Automatizza tutto il possibile

- Elimina passaggi inutili

- Rendi tutto semplice

## **Esempio Pratico: CoolSculpting vs Palestra**

Obiettivo: Avere un corpo più tonico

CoolSculpting (costa 5.000€):

- Risultato: Veloce e garantito

- Probabilità: Alta (tecnologia testata)

- Tempo: 1 seduta

- Sforzo: Zero

Palestra (costa 30€/mese):

- Risultato: Lento e incerto

- Probabilità: Media (dipende da te)

- Tempo: Mesi di allenamento

- Sforzo: Alto (dieta + esercizio)

Anche se il risultato finale è simile, CoolSculpting costa 166 volte di più perché elimina tempo e fatica.

## **Come Applicarlo**

1.  Prometti un risultato grande e importante

2.  Dimostra che funziona (con prove)

3.  Riduci il tempo necessario

4.  Riduci lo sforzo richiesto

## **Esempi di Successo**

- Amazon: Consegna veloce (tempo) + 1-click (sforzo)

- Netflix: Streaming immediato, niente videoteca

- Uber: Clicchi e arriva l'auto in pochi minuti

## **Regola Finale**

Per aumentare il valore della tua offerta puoi:

- Aumentare il risultato promesso

- Aumentare la certezza che funzioni

- Diminuire il tempo necessario

- Diminuire la fatica richiesta

Lavora su tutti questi elementi per rendere la tua offerta irresistibile.

Creazione dell'Offerta

# **Creazione dell'Offerta**

## **PARTE 1: Come Costruire un'Offerta Irresistibile**

### **I 3 Passaggi Fondamentali**

#### **1. Definire il Risultato Desiderato**

La tua offerta deve seguire questa formula:

**"Ottieni \[RISULTATO\] in \[TEMPO\] senza \[PROBLEMA\]"**

Esempi:

- "Perdi 10 kg in 6 settimane senza rinunciare ai tuoi cibi preferiti"

- "Aiuto mamme con 3 figli a dimagrire in 3 mesi senza andare in palestra"

Regola: Più il risultato è specifico e personalizzato sul target, più è efficace.

#### **2. Identificare Tutti i Problemi del Cliente**

Devi capire quali sono le barriere che impediscono ai clienti di ottenere il risultato.

Esempio per la perdita di peso:

- Fare la spesa è difficile

- Cucinare è complicato

- Non so quali cibi scegliere

- Mi mancherà la motivazione

- Non ho tempo per la palestra

- Non posso cucinare pasti separati per la famiglia

Metodo: Suddividi il percorso del cliente in ogni passaggio e identifica tutte le difficoltà.

#### **3. Trasformare i Problemi in Soluzioni**

Per ogni problema, crea una soluzione concreta.

| **Problema** | **Soluzione** |
|----|----|
| Fare la spesa è complicato | Lista della spesa settimanale già pronta |
| Non so quali cibi scegliere | Piano alimentare dettagliato con ricette facili |
| Non ho tempo per cucinare | Pasti sani preparabili in meno di 10 minuti |
| Mi mancherà la motivazione | Coach personale che ti guida ogni giorno |
| Pasti separati per la famiglia | Ricette gustose che piacciono anche ai figli |

Principio: Più problemi risolvi nella tua offerta, più diventa irresistibile.

### **Esempio Pratico Completo**

Problema: "Fare la spesa per mangiare sano è difficile"

Pensieri del cliente:

- È troppo complicato

- Non so cosa comprare

- Mi richiede troppo tempo

- Costa troppo

Soluzioni da integrare nell'offerta:

- Come fare la spesa in 10 minuti con la nostra lista pronta

- Piano settimanale con i migliori alimenti da acquistare

- Come risparmiare il 20% sulla spesa mangiando sano

Risultato: Il cliente percepisce l'offerta come più semplice e veloce.

### **Regole Chiave**

1.  Risolvi i problemi reali del cliente, non quelli che tu pensi siano importanti

2.  Usa il linguaggio del cliente per descrivere il problema

3.  Ogni soluzione deve eliminare un ostacolo all'acquisto

4.  Più l'offerta è semplice e immediata, più è efficace

## **PARTE 2: Come Costruire un'Offerta Profittevole**

### **Il Continuum Vendite-Fulfillment**

Regola base:

- Più un'offerta è facile da vendere → più è difficile da consegnare

- Più è difficile da vendere → più è facile da consegnare

Esempi:

- Servizi "Done-for-You" (fatto per il cliente) = Facili da vendere, difficili da scalare

- Corsi online (fai da te) = Difficili da vendere, facili da scalare

Strategia ottimale:

1.  Inizia con offerte facili da vendere (anche se più difficili da consegnare)

2.  Nel tempo, ottimizza il processo per renderlo più scalabile

### **I Veicoli di Consegna**

Come puoi consegnare la tua offerta in modo efficiente?

**Modelli di servizio:**

- Done-for-You = Massimo valore, massimo sforzo

- Done-With-You = Supporto guidato

- Do-It-Yourself = Più scalabile, meno valore percepito

**Formati di consegna:**

- 1:1 = Coaching, consulenze personalizzate

- Gruppo = Mastermind, community, programmi condivisi

- 1:Molti = Corsi online, webinar, automazioni

**Tipologie di supporto:**

- Live chat / Email / Videochiamata = Più valore e coinvolgimento

- PDF, Checklist, Template = Più scalabilità

Obiettivo: Combinare questi elementi per massimizzare il valore percepito e ridurre i costi.

### **Come Ottimizzare l'Offerta**

#### **Passaggio 1: Elenca Tutte le Possibili Soluzioni**

Esempio per un programma di alimentazione sana:

- Coaching individuale

- Programma pasti personalizzato

- Lista della spesa pre-compilata

- Community di supporto

- Tool per calcolare calorie e nutrienti

#### **Passaggio 2: Classifica per Valore e Costo**

| **Soluzione**             | **Valore per il cliente** | **Costo per te** |
|---------------------------|---------------------------|------------------|
| Coaching 1:1              | Alto                      | Alto             |
| Lista spesa pre-compilata | Medio                     | Basso            |
| Community privata         | Alto                      | Medio            |
| Tool calcolo calorie      | Alto                      | Basso            |

Obiettivo:

- Mantenere elementi ad alto valore percepito e basso costo operativo

- Limitare elementi ad alto costo e valore simile

#### **Passaggio 3: Creare la Stack Finale**

Esempio di offerta ottimizzata:

- Supporto 1:1 per le prime 2 settimane (massima fiducia e risultato garantito)

- Lista della spesa personalizzata + piano pasti settimanale (riduce sforzo e tempo)

- Accesso a calcolatrice nutrizionale personalizzata (automazione)

- Community esclusiva per supporto continuo (aumenta engagement)

Risultato: Offerta che sembra premium, ha alto valore percepito e alto margine di profitto.

### **Test del Prezzo: Regola 10X - 1/10**

Due test per perfezionare la tua offerta:

**Test 10X:** Se dovessi vendere a 10 volte il prezzo attuale, cosa aggiungeresti per renderlo 10 volte più prezioso?

**Test 1/10:** Se dovessi vendere a 1/10 del prezzo attuale, come potresti automatizzare e ridurre i costi?

Obiettivo: Creare un'offerta ad altissimo valore percepito ma con struttura efficiente e scalabile.

## **Piano d'Azione Completo**

### **Per Creare l'Offerta Base:**

1.  Definisci un risultato chiaro e specifico

2.  Identifica ogni ostacolo che impedisce al cliente di ottenere quel risultato

3.  Costruisci un sistema che rimuova tutte le difficoltà

### **Per Renderla Profittevole:**

1.  Focalizzati su offerte facili da vendere (anche se più difficili da consegnare)

2.  Ottimizza il fulfillment per ridurre costi e mantenere alto il valore

3.  Impila gli elementi giusti per creare un'offerta premium con margini elevati

4.  Testa con il metodo 10X - 1/10 per perfezionarla

### **Prossimo Passo:**

Creare una strategia di marketing basata su bonus, garanzie, scarsità e urgenza per massimizzare le conversioni.

<img src="/tmp/pandoc_media_discard/media/image28.png" style="width:6.22917in;height:5.4375in" /><img src="/tmp/pandoc_media_discard/media/image30.png" style="width:6.01042in;height:3.5in" />

Bonus e Garanzie

# **Creazione di Bonus Irresistibili**

## **Perché i Bonus Funzionano**

I bonus aumentano il valore percepito dell'offerta e spingono il cliente a dire sì immediatamente.

### **Principio chiave:**

"Un coltello da 19€ con 38 coltelli in omaggio è più attraente di un set da 39 coltelli per 19€"

Vantaggi dei bonus:

- Creano un forte ancoraggio al valore

- Aggiungono urgenza e scarsità senza abbassare il prezzo

- Fanno percepire il core offer come ancora più prezioso

## **Come Strutturare i Bonus**

### **La Struttura Corretta**

Errore: Presentare tutto come un'unica offerta

Soluzione: Separare gli elementi in core offer + bonus aggiuntivi

### **Esempio Pratico**

Core Offer: "Programma di Coaching per imprenditori"

Bonus 1: Template di email per chiudere vendite in 5 minuti Bonus 2: Lista di strumenti per automatizzare il business Bonus 3: Accesso a un webinar privato con un esperto

Risultato:

- Il cliente percepisce più valore senza che il costo aumenti per te

- Ogni bonus diventa un incentivo per agire subito

## **Aggiungere Scarsità e Urgenza**

### **Bonus con Scarsità**

Esempio: "Solo i primi 10 iscritti otterranno l'accesso al nostro evento live esclusivo"

### **Bonus con Urgenza**

Esempio: "Se ti iscrivi entro 24 ore, riceverai gratuitamente il nostro corso extra da 1.000€"

Principio: Far sentire al cliente che sta perdendo qualcosa se non agisce subito.

## **Caratteristiche di un Buon Bonus**

Un bonus efficace deve:

- Avere un nome chiaro con un beneficio evidente

- Risolvere un ostacolo specifico del cliente

- Avere un valore percepito superiore al core offer

- Essere confezionato in modo persuasivo (con prove e immagini vivide)

### **Esempio**

Errore: "Accesso a un database di clienti"

Soluzione: "Lista di 500 contatti già qualificati pronti ad acquistare il tuo prodotto"

Regola: Più i bonus sono tangibili, più il cliente li apprezza.

## **Tipologie di Bonus Ad Alto Valore**

| **Tipologia** | **Esempio** | **Perché funziona** |
|----|----|----|
| Template e Checklist | Template di annunci vincenti | Facile da usare e applicare subito |
| Casi Studio | Come ho scalato un business da 0 a 1M | Prova sociale che il metodo funziona |
| Strumenti e Automazioni | Foglio di calcolo per calcolare il prezzo perfetto | Elimina lavoro manuale |
| Sessioni 1:1 o di gruppo | Chiamata strategica con un esperto | Aumenta valore percepito e coinvolgimento |
| Prodotti di terze parti | Accesso a software premium gratuito per 3 mesi | Fa percepire un risparmio immediato |

Principio: I migliori bonus riducono il tempo e lo sforzo per ottenere il risultato.

## **Monetizzare i Bonus con Collaborazioni**

I bonus non devono per forza venire solo da te.

### **Strategie:**

1.  Includere prodotti di altre aziende nei tuoi bonus

2.  Ottenere commissioni di affiliazione per ogni cliente che mandi a partner esterni

### **Esempio Pratico**

Se vendi corsi di fitness, puoi offrire come bonus:

- Sconto su integratori (guadagni una commissione per ogni acquisto)

- Accesso gratuito a una app di allenamento (azienda partner paga per i lead che mandi)

### **Risultato Win-Win-Win:**

- Il cliente ottiene più valore

- Tu guadagni di più senza costi aggiuntivi

- Il partner ottiene nuovi clienti senza pubblicità

## **Strategie Avanzate**

### **1. Ancoraggio Psicologico**

"Se i bonus valgono 3.000€, il core offer deve valere ancora di più"

### **2. Bonus per Problemi Futuri**

"Ti diamo anche un bonus per il passo successivo dopo il tuo successo"

Questo implica che il core offer funzionerà sicuramente.

### **3. Bonus di Terze Parti**

"Ricevi uno sconto esclusivo su questo strumento premium che costa 500€ al mese"

Il cliente percepisce di risparmiare più soldi di quanti ne spende per il tuo prodotto.

## **Piano d'Azione**

1.  Struttura l'offerta in un core offer + bonus separati

2.  Usa scarsità e urgenza per spingere il cliente ad agire

3.  Scegli bonus che riducono lo sforzo e il tempo per ottenere il risultato

4.  Monetizza i bonus con partnership e affiliazioni

5.  Crea bonus che risolvono problemi futuri per rafforzare la credibilità dell'offerta

### **Prossimo Passo:**

Creare garanzie che eliminano il rischio d'acquisto.

<img src="/tmp/pandoc_media_discard/media/image26.png" style="width:6.58333in;height:2.48958in" />

# **Creazione di Garanzie Irresistibili**

## **Perché le Garanzie Funzionano**

Le garanzie riducono il rischio percepito e fanno aumentare le vendite fino a 4 volte.

### **Principio chiave:**

"Più il cliente si sente sicuro, più sarà disposto ad acquistare"

Vantaggi delle garanzie:

- Le persone temono di perdere soldi o tempo

- Se elimini questo rischio, diventa più facile dire sì

- Le migliori garanzie trasformano un "Forse" in un "Ok, ci provo"

## **Le 3 Tipologie di Garanzie**

### **1. Garanzie Incondizionate**

Nessuna condizione, rimborso immediato

### **2. Garanzie Condizionate**

Il cliente deve soddisfare alcuni requisiti prima di ottenere un rimborso

### **3. Anti-Garanzie**

Posizionamento forte per escludere clienti non ideali

Nota: Puoi anche combinare più garanzie per renderle ancora più potenti.

## **Garanzie Incondizionate**

### **Definizione:**

"Se non sei soddisfatto per qualsiasi motivo, ottieni il rimborso"

### **Vantaggi:**

- Rimuove completamente il rischio per il cliente

- Aumenta le conversioni

- Mostra totale fiducia nel prodotto

### **Formula vincente:**

"Non ti chiedo di decidere oggi. Ti chiedo solo di provare. Se non sei soddisfatto entro 30 giorni, ti rimborso al 100% senza fare domande."

## **Garanzie Condizionate**

### **Definizione:**

"Se fai X e non ottieni Y, ti rimborso o lavoro con te gratis"

### **Vantaggi:**

- Filtra i clienti seri e impegnati

- Riduce le richieste di rimborso

- Aumenta la fiducia senza attirare persone opportuniste

### **Esempio:**

"Se segui tutte le lezioni e applichi le strategie, ma non vedi risultati in 90 giorni, continueremo a lavorare con te gratuitamente finché non ci riesci."

### **Varianti:**

**1. Rimborso superiore al 100%** "Ti restituisco il triplo se non ottieni risultati"

**2. Garanzia di servizio** "Lavoriamo con te gratis finché non ottieni il risultato"

**3. Garanzia di credito** "Se non sei soddisfatto, puoi usare l'importo speso per un altro prodotto"

**4. Garanzia di pagamento ritardato** "Paga solo quando ottieni il risultato promesso"

Principio: Più chiari sono i termini, più la garanzia sarà efficace.

## **Anti-Garanzie**

### **Definizione:**

"Nessun rimborso. Tutte le vendite sono finali"

### **Vantaggi:**

- Posiziona il brand come esclusivo

- Attira solo clienti motivati

- Può aumentare la percezione di valore

### **Esempio:**

"Se hai bisogno di una garanzia, questa offerta non è per te. Lavoriamo solo con persone determinate a ottenere risultati."

Nota: Questa strategia funziona bene per prodotti di alta gamma o offerte personalizzate.

## **Garanzie Basate sulle Performance**

### **Definizione:**

"Paghi solo in base ai risultati ottenuti"

### **Vantaggi:**

- Azzera completamente il rischio per il cliente

- Attrae clienti di alto valore

- Se ben strutturata, può rendere il business molto redditizio

### **Esempi di modelli:**

- Paghi solo X per ogni lead generato

- Paghi una percentuale dei profitti che ti aiuto a ottenere

- Paga solo dopo il primo risultato ottenuto

Nota: Se il tuo prodotto è solido, questa è una delle strategie più potenti per crescere. Funziona molto bene nel B2B.

## **Come Rendere le Garanzie Più Potenti**

### **1. Usa Nomi Creativi**

Errore: "Garanzia di 30 giorni"

Soluzione: "Se dopo 30 giorni non saresti disposto a lanciarti in uno stagno infestato di squali per tenerti il nostro prodotto, ti rimborsiamo"

### **2. Combina Più Garanzie**

Esempio di combinazione:

- 30 giorni senza rischi (incondizionata)

- Se non ottieni risultati, lavoriamo con te finché non ci riesci (condizionata)

Risultato: I clienti sentono di avere tutto da guadagnare e niente da perdere.

## **Piano d'Azione**

1.  Scegli il tipo di garanzia adatto al tuo business

2.  Formula la garanzia in modo chiaro e senza ambiguità

3.  Se possibile, combina garanzie per massimizzare l'efficacia

4.  Usa un nome creativo per renderla più memorabile

5.  Testa l'impatto della garanzia sulle conversioni

## **Quale Garanzia Scegliere**

| **Tipo Business**          | **Garanzia Consigliata**           |
|----------------------------|------------------------------------|
| E-commerce prodotti fisici | Incondizionata 30-60 giorni        |
| Corsi online               | Condizionata (completa il corso)   |
| Servizi premium            | Anti-garanzia o condizionata       |
| Servizi B2B                | Basata su performance              |
| Prodotti digitali low-cost | Incondizionata breve (7-14 giorni) |

### **Prossimo Passo:**

Creare strategie di scarsità e urgenza per spingere i clienti ad acquistare subito.

<img src="/tmp/pandoc_media_discard/media/image29.png" style="width:6.75in;height:1.94792in" />

Scarsità e Urgenza

# **Scarsità e Urgenza**

## **Perché Sono Fondamentali**

I clienti rimandano sempre le decisioni. Più rimandano, meno è probabile che acquistino.

### **Principio chiave:**

"Più a lungo il cliente aspetta, più è probabile che non compri mai"

Obiettivo: Creare un motivo valido per cui devono decidere oggi.

## **Differenza tra Scarsità e Urgenza**

**Scarsità** = Numero limitato di posti o unità disponibili

**Urgenza** = Tempo limitato per agire prima che l'offerta scada

Nota: Le migliori strategie usano entrambe per massimizzare l'effetto.

## **Strategie per Creare Urgenza**

### **4 Modi Etici per Usare l'Urgenza:**

**1. Urgente per il Gruppo** "Il prossimo corso inizia lunedì, affrettati"

**2. Urgente per la Stagione** "Offerta speciale di San Valentino, termina tra 3 giorni"

**3. Urgente per il Prezzo** "Solo per oggi, prezzo scontato del 20%"

**4. Urgente per l'Opportunità** "Questa strategia sta funzionando adesso, ma non durerà per sempre"

### **Esempio Pratico:**

Errore: "Acquista oggi, l'offerta potrebbe finire (ma non finisce mai)"

Soluzione: "L'offerta finisce venerdì alle 23:59. Dopo, il prezzo aumenta di 200€"

Principio: Più l'urgenza è credibile, più sarà efficace.

## **Strategie per Creare Scarsità**

### **3 Modi per Creare Scarsità Reale:**

**1. Posti Limitati** "Solo 5 posti disponibili per il coaching 1:1"

**2. Bonus in Edizione Limitata** "Ricevi il nostro corso extra GRATIS, ma solo per i primi 50 iscritti"

**3. Prodotti Esclusivi e Non Replicabili** "Questa edizione è limitata a 100 pezzi. Dopo, non sarà più disponibile"

### **Esempio Pratico:**

Errore: "Questa offerta è limitata (ma è sempre disponibile)"

Soluzione: "Dopo il 31 dicembre, questa offerta non sarà più disponibile"

Principio: Le persone vogliono ciò che non possono avere. Se percepiscono scarsità, agiscono subito.

## **Bonus a Tempo Limitato**

I bonus funzionano meglio se hanno una scadenza.

### **Esempi:**

- "Iscriviti oggi e ricevi anche X, Y, Z (ma solo per 24 ore)"

- "Questo bonus è disponibile solo fino a domenica"

- "Abbiamo solo 10 copie di questo corso extra da regalare, affrettati"

Principio: La combinazione di scarsità e urgenza sui bonus rende l'offerta più irresistibile.

## **Opportunità che Scadono Naturalmente**

Le migliori urgenze sono quelle reali.

### **Esempio 1 - Programmi in Coorte:**

"Il nostro corso accetta solo nuovi studenti ogni 3 mesi. La prossima apertura sarà tra 90 giorni"

### **Esempio 2 - Tendenze di Mercato:**

"Questa strategia funziona ora, ma tra 6 mesi potrebbe non essere più così efficace"

Principio: Più l'opportunità è percepita come irripetibile, più spingerà all'azione immediata.

## **Strategie Avanzate**

### **1. Ultimi Posti Disponibili**

Esempio: "Abbiamo solo 3 slot rimasti per il coaching di questo mese"

### **2. Solo per Clienti Selezionati**

Esempio: "Non tutti possono accedere a questa offerta, solo chi si iscrive oggi"

### **3. Questa Offerta Non Tornerà Mai Più**

Esempio: "Dopo il lancio, questo corso non sarà più disponibile in vendita"

Principio: Più l'offerta sembra esclusiva e temporanea, più spinge all'azione.

## **Piano d'Azione**

1.  Scegli una strategia di urgenza basata su tempo o opportunità

2.  Aggiungi un elemento di scarsità (posti limitati, bonus esclusivi)

3.  Comunica chiaramente la scadenza e cosa succede dopo

4.  Evita falsi limiti di tempo o unità (devono essere credibili)

5.  Testa quale combinazione funziona meglio per il tuo pubblico

## **Quando Usare Cosa**

| **Situazione**         | **Strategia Consigliata**                |
|------------------------|------------------------------------------|
| Corso con inizio fisso | Urgenza per il gruppo + posti limitati   |
| Promozione stagionale  | Urgenza per la stagione + bonus limitati |
| Lancio prodotto        | Scarsità vera + bonus primi acquirenti   |
| Coaching 1:1           | Posti limitati reali + lista d'attesa    |
| Evento live            | Urgenza per data + posti limitati        |

## **Regole Importanti**

### **Da Fare:**

- Usare scadenze e limiti reali

- Comunicare chiaramente cosa succede dopo la scadenza

- Combinare scarsità e urgenza

- Essere specifici con date e numeri

### **Da Evitare:**

- Falsi countdown che si ripetono

- "Solo oggi" che dura per mesi

- Scarsità inventata senza limite reale

- Perdere credibilità con urgenze false

### **Prossimo Passo:**

Creare la strategia di naming per massimizzare il valore percepito.

<img src="/tmp/pandoc_media_discard/media/image27.png" style="width:7.34375in;height:5.35417in" />

# 

Naming

## **Perché il Nome è Importante**

Un nome forte chiarifica immediatamente di cosa si tratta. I clienti devono capire subito se è per loro.

### **Principio chiave:**

"Se il tuo pubblico non capisce subito il valore, non comprerà"

Obiettivo: Creare nomi che comunicano chiaramente benefici e urgenza.

## **La Formula MAGIC per Nominare Offerte**

MAGIC è un acronimo che ti aiuta a creare nomi potenti:

**M** = Motivo magnetico (Perché esiste?)

**A** = Annuncia il pubblico target (Chi è il cliente ideale?)

**G** = Dai un obiettivo chiaro (Qual è il risultato promesso?)

**I** = Indica un intervallo di tempo (Quanto tempo serve?)

**C** = Completa con una parola contenitore (Challenge, Formula, Metodo, Sistema)

Principio: Questa formula rende i nomi più attraenti, chiari e vendibili.

## **Esempi di Nomi Potenti**

| **Settore** | **Nome Offerta** | **Elementi MAGIC** |
|----|----|----|
| Fitness | Sfida 6 Settimane Bikini Ready | Obiettivo chiaro + Tempo definito + Nome accattivante |
| Coaching | 7 Giorni per il tuo Prodotto Perfetto | Target chiaro + Tempo definito + Nome specifico |
| Medico | 12 Mesi per un Sorriso Perfetto | Obiettivo chiaro + Tempo definito + Target chiaro |
| Business | Riempire la tua Palestra in 30 Giorni - GRATIS | Beneficio immediato + Tempo chiaro + Offerta attraente |

### **Le Parole Contenitore:**

- Challenge: "Sfida 21 Giorni Detox"

- Blueprint: "Blueprint per 5 Clienti in 5 Giorni"

- Sistema: "Sistema per Dimagrire Senza Sforzo"

- Formula: "Formula per Raddoppiare le Vendite"

- Metodo: "Metodo 30 Giorni per Addominali Scolpiti"

Principio: Le persone comprano soluzioni, non prodotti. Un nome efficace evidenzia il risultato.

## **Come Nominare i Bonus**

I bonus hanno più valore quando hanno nomi chiari e specifici.

### **Esempi di Confronto:**

**Nome Generico vs Nome Specifico:**

- "Lista della Spesa Sana" → "Lista della Spesa per Perdere 5kg in 30 Giorni"

- "Template Email" → "Modello di Email per Aumentare le Vendite in 24 Ore"

- "Software per Social" → "Strumento per Automatizzare i Social Media in 10 Minuti"

Principio: Più è specifico il nome, più il cliente percepisce il valore.

## **L'Importanza del Tempo nel Naming**

Il tempo aumenta il valore percepito e la conversione.

### **Perché funziona:**

- I clienti vogliono risultati veloci

- Un intervallo di tempo definito rende l'offerta più concreta

- Più corto è il tempo promesso, più alta è la conversione

### **Esempi con Tempo:**

| **Nome Generico**            | **Nome con Tempo**                     |
|------------------------------|----------------------------------------|
| Corso di Social Media        | Social Media in 7 Giorni               |
| Strategie di Email Marketing | Email Marketing in 30 Minuti al Giorno |
| Piano di Allenamento         | Dimagrisci 5kg in 30 Giorni            |

Principio: Amazon ha vinto con la consegna veloce, Netflix con lo streaming istantaneo. Le persone vogliono tutto subito.

## **Come Rinnovare le Offerte**

Se le tue offerte iniziano a perdere efficacia, puoi rinnovarle senza cambiarle completamente.

### **4 Modi per Rinnovare:**

**1. Cambia il Nome** Usa la formula MAGIC per rinfrescare il titolo

**2. Cambia la Durata** Esempio: "6 Settimane" diventa "42 Giorni" (cambia la percezione)

**3. Aggiungi una Promozione Temporanea** Bonus esclusivi solo per X giorni

**4. Modifica il Focus** Esempio: "Corso per Vendite" diventa "Formula per 5x Lead in 30 Giorni"

Principio: Le persone amano le novità, anche se il contenuto rimane lo stesso.

## **Le 5 Regole per un Nome Efficace**

### **1. Sii Specifico**

"Sistema per 10.000€ in 30 Giorni" è meglio di "Metodo per Guadagnare"

### **2. Usa Numeri e Tempo**

"7 Giorni", "30 Minuti", "3 Passi"

### **3. Focalizzati sul Risultato**

"Perdere 5kg", "Aumentare 3x le Vendite"

### **4. Usa Parole d'Impatto**

"Formula Segreta", "Metodo Scientifico", "Blueprint", "Sistema Provato"

### **5. Testa e Ottimizza**

Cambia il nome e monitora le conversioni

Principio: Un buon nome trasforma un'offerta comune in qualcosa di irresistibile.

## **Template Pratici da Usare**

### **Per Corsi e Programmi:**

- "\[Risultato\] in \[Tempo\] senza \[Problema\]"

- "Sistema \[Nome\] per \[Risultato\]"

- "Sfida \[Tempo\] per \[Risultato\]"

### **Per Bonus:**

- "\[Strumento\] per \[Risultato\] in \[Tempo\]"

- "Come \[Azione\] in \[Tempo\] con \[Metodo\]"

- "Lista di \[Numero\] \[Cose\] per \[Risultato\]"

### **Per Servizi:**

- "\[Risultato\] in \[Tempo\] per \[Target\]"

- "Formula \[Nome\] per \[Target\]"

- "Blueprint \[Risultato\] in \[Tempo\]"

## **Piano d'Azione**

1.  Usa la formula MAGIC per nomi chiari e accattivanti

2.  Includi sempre un intervallo di tempo per aumentare la conversione

3.  Dai ai bonus nomi che enfatizzano il valore specifico

4.  Aggiorna le offerte con nuovi nomi per mantenerle fresche

5.  Testa i nomi per capire quali funzionano meglio

## **Checklist Nome Perfetto**

Un nome efficace deve:

- \[ \] Comunicare chiaramente chi è il target

- \[ \] Indicare il risultato specifico

- \[ \] Includere un intervallo di tempo

- \[ \] Usare una parola contenitore (Challenge, Sistema, Formula, etc.)

- \[ \] Essere facile da ricordare

- \[ \] Far capire immediatamente il valore

- \[ \] Creare curiosità o urgenza

Se il tuo nome rispetta almeno 5 di questi punti, sei sulla strada giusta.

<img src="/tmp/pandoc_media_discard/media/image24.png" style="width:7.35417in;height:7.78125in" />

🧠 2. MARKET AWARNESS

# **I LIVELLI DI CONSAPEVOLEZZA DEL MERCATO**

## **Guida completa per creare pubblicità efficaci in base al grado di conoscenza del cliente**

### **INTRODUZIONE**

**La consapevolezza del mercato (market awareness) è uno dei concetti più potenti nel marketing e nella pubblicità. Questo framework spiega quanto il tuo cliente sa del suo problema e della tua soluzione.**

**Comprendere a quale livello di consapevolezza si trova il tuo pubblico è fondamentale per creare annunci che convertono. Non puoi parlare allo stesso modo a chi non sa nemmeno di avere un problema e a chi sta solo aspettando un'offerta per comprare.**

## **CHE COS'È IN PAROLE SEMPLICI**

**La consapevolezza del mercato è come una scala che il cliente deve salire prima di comprare.**

**Rappresenta il grado di conoscenza, familiarità e comprensione che i potenziali clienti hanno riguardo a:**

- **Il problema che hanno (o non sanno di avere)**

- **Le soluzioni disponibili**

- **Il tuo prodotto specifico**

- **La loro predisposizione all'acquisto**

**Lo spettro va da:**

- **Completa inconsapevolezza ("non so nemmeno di avere un problema")**

- **A completa consapevolezza ("voglio il tuo prodotto, dammi un'offerta")**

## **I 5 LIVELLI DI CONSAPEVOLEZZA DEL MERCATO**

### **1️⃣ UNAWARE - NON CONSAPEVOLE**

**"Non so nemmeno di avere un problema"**

#### **CARATTERISTICHE DEL CLIENTE**

- **Non riconosce di avere un problema**

- **Non sta cercando alcuna soluzione**

- **Non è consapevole che la sua vita potrebbe migliorare**

- **Vive una situazione problematica pensando sia normale**

#### **IL TUO OBIETTIVO**

- **Creare consapevolezza del problema**

- **Far emergere un bisogno nascosto**

- **Educare sulla sua importanza**

- **Introdurre il prodotto come soluzione**

- **Essenzialmente, creare il mercato**

#### **SFIDA E OPPORTUNITÀ**

- **❌ È il mercato più difficile da conquistare**

- **❌ Richiede gli annunci più complessi da realizzare**

- **✅ Se riesci a creare un annuncio vincente, apri un mercato completamente nuovo**

- **✅ Puoi raggiungere un pubblico enorme non ancora servito**

#### **COME PARLARGLI: STRUTTURA DELL'ANNUNCIO**

1.  **Hook potente - Cattura l'attenzione con qualcosa che risuona inconsciamente**

2.  **Rivela il problema nascosto - Fai emergere qualcosa che non avevano considerato**

3.  **Educa - Spiega perché è importante risolvere questo problema**

4.  **Presenta la soluzione - Introduci il tuo approccio**

5.  **Mostra il prodotto - Collega soluzione e prodotto**

6.  **Call to action - Invita all'azione**

#### **TIPOLOGIE DI ANNUNCI EFFICACI**

- **Annunci che identificano problemi nascosti**

- **Contenuti che toccano frustrazioni o desideri inconsci**

- **Storie narrative che costruiscono connessione emotiva**

- **Materiale educativo che rivela problemi non riconosciuti**

- **Approcci indiretti che risuonano con identità o paure**

- **Uso di controversie o curiosità**

#### **ESEMPI PRATICI**

**Esempio 1 - Stanchezza e alimentazione:**

> **Hook: "Ti senti stanco tutto il giorno ma non riesci a capire perché?"**
>
> **Educazione: "La maggior parte delle persone dà la colpa allo stress o all'età, ma gli scienziati hanno scoperto che l'infiammazione nascosta causata dai cibi quotidiani potrebbe essere la vera causa."**
>
> **Soluzione: "Fai il nostro rapido test energetico per scoprire se la tua dieta sta segretamente prosciugando la tua energia. Migliaia di persone hanno trovato la loro soluzione energetica con il nostro approccio naturale."**

**Esempio 2 - Ricrescita capelli (caso reale): L'annuncio parte con una controversia sui celebrity:**

> **"È impossibile non notarlo. Ogni volta che una celebrità inizia a perdere capelli, in qualche modo torna con una testa piena di capelli mesi dopo. Elon Musk è passato da così nel 1999 a così oggi. Ben Affleck è passato da così nel 2015 a così ora..."**

**Progressione dell'annuncio:**

- **Crea curiosità con esempi di celebrity**

- **Suggerisce che esiste un "segreto" che non vogliono condividere**

- **Educa sul DHT (ormone che causa la caduta)**

- **Spiega perché le soluzioni comuni non funzionano**

- **Presenta gli ingredienti naturali che bloccano il DHT**

- **Introduce il prodotto (Spartan Root Activator)**

- **Offerta finale con garanzia**

**Esempio 3 - Scarpe per difficoltà motorie: Pubblicità di scarpe speciali per chi ha difficoltà a camminare - molte persone pensavano fosse normale faticare e non consideravano che esistesse una soluzione.**

### **2️⃣ PROBLEM AWARE - CONSAPEVOLE DEL PROBLEMA**

**"Ho un problema ma non so come risolverlo"**

#### **CARATTERISTICHE DEL CLIENTE**

- **Sa di avere un problema**

- **Sta vivendo il disagio**

- **Non sa che esistono soluzioni**

- **Non ha cercato attivamente modi per risolverlo**

**Esempio: "Ho mal di testa ogni giorno e mi infastidisce molto, ma non so cosa fare."**

#### **IL TUO OBIETTIVO**

- **Far sentire il cliente capito (empatia)**

- **Educare sulle possibili soluzioni**

- **Posizionare il tuo prodotto come risposta ideale**

- **Costruire il collegamento tra problema riconosciuto e tua soluzione**

#### **COME PARLARGLI**

- **Descrivi perfettamente il loro problema**

- **Fai in modo che pensino: "Mi capisce! È esattamente come mi sento!"**

- **Mostra comprensione della loro frustrazione**

- **Presenta la soluzione come naturale conseguenza**

#### **TIPOLOGIE DI ANNUNCI EFFICACI**

- **Annunci che definiscono chiaramente il problema vissuto**

- **Contenuti che mostrano comprensione profonda della frustrazione**

- **Materiale educativo sulle possibilità di soluzione**

- **Storie di altri che hanno superato lo stesso problema**

- **Contenuti relazionabili ("È esattamente come mi sento!")**

#### **ESEMPI PRATICI**

**Esempio 1 - Mal di testa:**

> **Hook relazionabile: "Soffri di mal di testa costanti? Non sei solo."**
>
> **Empatia e normalizzazione: "Il 68% degli adulti riporta regolari mal di testa da tensione, ma la maggior parte si limita a prendere antidolorifici e andare avanti."**
>
> **Presentazione della soluzione: "E se ci fosse un modo migliore? La nostra formula naturale contiene composti clinicamente provati per ridurre l'infiammazione alla fonte. A differenza delle pillole che mascherano i sintomi, il nostro approccio affronta la causa principale."**
>
> **Social proof: "Scopri perché oltre 10.000 ex sofferenti di mal di testa tengono ora il nostro prodotto nella loro routine quotidiana."**

**Esempio 2 - Borsa da hockey disordinata:**

> **"La tua borsa da hockey è sempre disordinata e puzza? Ti capiamo perfettamente. Ecco la soluzione..."**

**Esempio 3 - Capelli grigi (caso reale):**

> **Hook: "Sei stanco dei capelli grigi che ti fanno sembrare più vecchio di quanto sei?"**
>
> **Empatia: "Se stai ancora usando le tinture tradizionali in scatola, continua a guardare perché sono disordinate, richiedono tempo e piene di sostanze chimiche aggressive che danneggiano i capelli."**
>
> **Soluzione: "Neat Polar, la soluzione naturale e veloce per capelli belli e senza grigi in soli 10 minuti. Basta pompare, insaponare, aspettare 10 minuti e risciacquare."**
>
> **Differenziazione: "Polar usa ingredienti organici come funghi reishi, senza ammoniaca o perossido, lasciando i capelli morbidi, lucenti e sani."**
>
> **Testimonianza: "Non tornerò mai più in vita mia a comprare tinture da negozio o ad andare in un salone. Questo è incredibile. Cambia tutto."**

### **3️⃣ SOLUTION AWARE - CONSAPEVOLE DELLA SOLUZIONE**

**"So che esistono soluzioni, ma non so quale scegliere"**

#### **CARATTERISTICHE DEL CLIENTE**

- **Conosce il problema**

- **Sa che esistono diverse soluzioni**

- **Sta valutando le opzioni disponibili**

- **Non conosce ancora il tuo prodotto specifico**

**Esempio: "Ho mal di testa. Potrei prendere pillole, bere più acqua, sistemare il sonno, fare yoga... conosco varie opzioni."**

#### **IL TUO OBIETTIVO**

- **Differenziare il tuo prodotto dalle altre soluzioni**

- **Evidenziare perché il tuo approccio è superiore**

- **Mostrare vantaggi comparativi tra categorie diverse**

- **Convincere che la tua soluzione è la scelta migliore**

#### **COME PARLARGLI**

- **Mostra perché la TUA soluzione è migliore delle ALTRE**

- **Confronta categorie diverse di soluzioni (non solo prodotti simili)**

- **Evidenzia il meccanismo o approccio unico**

- **Usa testimonianze di chi ha provato altre alternative prima**

#### **TIPOLOGIE DI ANNUNCI EFFICACI**

- **Annunci comparativi (la tua soluzione vs altre categorie)**

- **Contenuti che evidenziano il meccanismo unico**

- **Testimonianze di clienti che hanno provato alternative**

- **Annunci focalizzati sui benefici proprietari**

- **Confronti tipo "meglio X o Y?"**

#### **ESEMPI PRATICI**

**Esempio 1 - Focus booster naturale:**

> **Hook: "Cerchi un booster di concentrazione naturale?"**
>
> **Comparazione tra categorie: "Mentre il caffè ti dà nervosismo e crolli energetici, e le pillole contengono stimolanti sintetici, la nostra formula offre concentrazione pulita e sostenuta attraverso una tecnologia proprietaria di assorbimento."**
>
> **Benefici chiari: "Niente crolli, niente nervosismo, niente attesa per gli effetti."**
>
> **Testimonianza comparativa: "Ho provato di tutto, dal caffè ai nootropi, ma niente si è paragonato alla chiarezza che ho ottenuto da questo prodotto - James, product designer ed ex dipendente da caffeina."**
>
> **CTA: "Prova la differenza della tecnologia di assorbimento con il nostro pacchetto speciale. Senti la differenza in minuti, non ore."**

**Esempio 2 - Testosterone booster vs TRT: Annuncio statico che confronta:**

- **TRT (Terapia Sostitutiva): Non legale, effetti collaterali, invasivo**

- **Prodotto naturale: Sicuro, legale, senza effetti collaterali, aumenta testosterone naturalmente**

> **"Vuoi aumentare il testosterone? Puoi fare TRT, ma non è legale e ha molti effetti collaterali. Oppure puoi usare il nostro booster naturale che aumenta il testosterone in modo sicuro."**

**Esempio 3 - Cyclette vs Tapis roulant:**

> **"Meglio una cyclette o un tapis roulant per perdere peso? Ecco perché la cyclette è superiore..."**

### **4️⃣ PRODUCT AWARE - CONSAPEVOLE DEL PRODOTTO**

**"Conosco il tuo prodotto ma sto valutando anche altri"**

#### **CARATTERISTICHE DEL CLIENTE**

- **Conosce il tuo prodotto**

- **Sta confrontando marche simili**

- **Non è ancora convinto ad acquistare**

- **Sta cercando la migliore opzione tra competitor**

**Esempio: "Voglio un asciugacapelli. Conosco il tuo, ma sto guardando anche altri quattro modelli. Quale è il migliore?"**

#### **IL TUO OBIETTIVO**

- **Far brillare le caratteristiche uniche del tuo prodotto**

- **Evidenziare vantaggi competitivi specifici**

- **Comunicare perché il tuo prodotto è superiore ai concorrenti**

- **Fornire prove concrete e testimonianze**

#### **COME PARLARGLI**

- **Concentrati su cosa rende UNICO il tuo prodotto**

- **Evidenzia caratteristiche esclusive**

- **Mostra vantaggi tangibili rispetto alla concorrenza**

- **Usa confronti diretti tra prodotti (non categorie)**

#### **TIPOLOGIE DI ANNUNCI EFFICACI**

- **Annunci comparativi tra prodotti simili**

- **Contenuti che comunicano caratteristiche uniche**

- **Testimonianze e casi studio dettagliati**

- **Dimostrazioni dei benefici esclusivi**

- **Liste tipo "5 motivi per scegliere noi"**

#### **ESEMPI PRATICI**

**Esempio 1 - Gioielli:**

> **"5 motivi per scegliere i NOSTRI gioielli rispetto ad altri brand"**

**Esempio 2 - Caratteristiche uniche:**

> **"A differenza di \[competitor\], il nostro prodotto include \[caratteristica unica\] che ti permette di \[beneficio specifico\]"**

**Esempio 3 - Confronto dettagliato: Tabella comparativa che mostra:**

- **Tuo prodotto: tutte le caratteristiche premium**

- **Competitor A: mancano alcune funzioni**

- **Competitor B: prezzo più alto, meno vantaggi**

- **Competitor C: qualità inferiore**

### **5️⃣ MOST AWARE - MASSIMAMENTE CONSAPEVOLE**

**"Voglio il tuo prodotto, ma sto aspettando"**

#### **CARATTERISTICHE DEL CLIENTE**

- **Sa tutto: problema, soluzione, il tuo prodotto**

- **È convinto del valore**

- **Sta solo aspettando il momento giusto**

- **Cerca il miglior prezzo o l'occasione perfetta**

**Motivazioni dell'attesa:**

- **Aspetta uno sconto**

- **Aspetta lo stipendio**

- **Aspetta un'occasione speciale**

- **Vuole essere sicuro dell'offerta migliore**

#### **IL TUO OBIETTIVO**

- **VENDI!**

- **Creare urgenza**

- **Eliminare gli ultimi ostacoli**

- **Presentare un'offerta irresistibile**

- **Semplificare il processo d'acquisto**

#### **COME PARLARGLI**

- **Vai dritto all'offerta**

- **Crea scarsità e urgenza**

- **Aggiungi garanzie per ridurre il rischio**

- **Rendi l'acquisto immediato e semplice**

#### **TIPOLOGIE DI ANNUNCI EFFICACI**

- **Offerte e promozioni a tempo limitato**

- **Sconti significativi**

- **Bundle deals (pacchetti combinati)**

- **Garanzie soddisfatti o rimborsati**

- **Annunci semplificati focalizzati sull'offerta**

- **Timer di countdown**

- **Scarsità di magazzino**

#### **ESEMPI PRATICI**

**Esempio 1 - Offerta diretta:**

> **"44% di sconto sul prodotto naturale numero uno per uomini - Risparmia 70€ su tutti questi prodotti. Offerta valida solo fino a mezzanotte."**

**Esempio 2 - Urgenza + garanzia:**

> **"20% di sconto con il codice META20 + Prova gratuita 30 giorni + Garanzia soddisfatti o rimborsati. Ultimi 50 pezzi disponibili."**

**Esempio 3 - Bundle irresistibile:**

> **"Compra 3 e ricevi il 60% di sconto + Spedizione gratuita + Regalo esclusivo. Garanzia 90 giorni. Ordina ora."**

**Struttura dell'annuncio:**

- **80% dell'annuncio parla di offerte**

- **Visual dell'offerta sempre presente**

- **Counter di urgenza visibile**

- **CTA ripetuto più volte**

- **Minimi dettagli sul prodotto (già lo conoscono)**

## **🔑 LA REGOLA D'ORO: IL PRINCIPIO DELLA PROGRESSIONE**

### **DEVI SEMPRE FAR SALIRE LA SCALA AL CLIENTE**

**Non puoi saltare i gradini!**

**Quando crei un annuncio, devi guidare il cliente attraverso tutti i livelli di consapevolezza rimanenti fino all'acquisto.**

#### **SCHEMA DELLE PROGRESSIONI**

**Se parti da UNAWARE (livello 1):**

**Unaware → Problem Aware → Solution Aware → Product Aware → Most Aware**

**Devi coprire tutti e 5 i livelli nell'annuncio.**

**Se parti da PROBLEM AWARE (livello 2):**

**Problem Aware → Solution Aware → Product Aware → Most Aware**

**Devi coprire 4 livelli.**

**Se parti da SOLUTION AWARE (livello 3):**

**Solution Aware → Product Aware → Most Aware**

**Devi coprire 3 livelli.**

**Se parti da PRODUCT AWARE (livello 4):**

**Product Aware → Most Aware**

**Devi coprire 2 livelli.**

**Se parti da MOST AWARE (livello 5):**

**Most Aware → ACQUISTO**

**Vai diretto all'offerta.**

### **ESEMPIO DI PROGRESSIONE COMPLETA (Unaware → Most Aware)**

**Annuncio ricrescita capelli analizzato passo per passo:**

1.  **UNAWARE → PROBLEM AWARE\**

    - **"È impossibile non notare come le celebrità ricrescano i capelli..."**

    - **Crea consapevolezza che esiste una soluzione nascosta**

2.  **PROBLEM AWARE → SOLUTION AWARE\**

    - **"Potresti pensare siano trapianti costosi da \$50.000..."**

    - **"Ma i dermatologi hanno scoperto come mirare alla vera causa: il DHT"**

    - **Educa sulle soluzioni disponibili**

3.  **SOLUTION AWARE → PRODUCT AWARE\**

    - **"Mentre la maggior parte usa minoxidil, finasteride, terapia con luce rossa..."**

    - **"Le celebrità hanno trovato un modo naturale con estratto di radice di liquirizia che blocca il DHT"**

    - **Presenta la soluzione superiore**

4.  **PRODUCT AWARE → MOST AWARE\**

    - **"Troverai tutti questi ingredienti in Spartan Root Activator"**

    - **"In 3-6 mesi potrai passare di nuovo le mani tra i capelli"**

    - **Introduce il prodotto specifico**

5.  **MOST AWARE → ACQUISTO\**

    - **"Garanzia rimborso 90 giorni + 60% di sconto ordinando 3 bottiglie oggi"**

    - **Offerta irresistibile con urgenza**

### **❌ ERRORE COMUNE**

**NON puoi fare questo: Se qualcuno è a livello "Unaware", NON puoi iniziare con:**

> **"COMPRA ORA CON IL 20% DI SCONTO!"**

**Non ha senso perché:**

- **Non sa di avere un problema**

- **Non conosce le soluzioni**

- **Non conosce il tuo prodotto**

- **Perché dovrebbe comprare?**

## **💡 PERCHÉ È IMPORTANTE: I VANTAGGI PRATICI**

### **1. Scrivi annunci più efficaci**

**Sai esattamente cosa dire e in che ordine dirlo.**

### **2. Eviti di sprecare soldi**

**Non parli nel modo sbagliato al pubblico sbagliato.**

### **3. Puoi scalare il business**

**Capisci cosa funziona e puoi replicarlo sistematicamente.**

### **4. Apri nuovi mercati**

**Gli annunci "unaware" ti permettono di raggiungere pubblici inesplorati.**

### **5. Ottimizzi il ROAS (Return On Ad Spend)**

**Ogni euro speso comunica il messaggio giusto al momento giusto.**

## **📊 APPLICAZIONE PRATICA: IDENTIFICARE IL TUO MERCATO**

### **DOMANDE DA PORSI**

**Per identificare il livello del tuo pubblico:**

1.  **Il mio pubblico sa di avere questo problema?\**

    - **NO → Unaware**

    - **SÌ → vai alla domanda 2**

2.  **Sa che esistono soluzioni?\**

    - **NO → Problem Aware**

    - **SÌ → vai alla domanda 3**

3.  **Conosce il mio tipo di prodotto/soluzione?\**

    - **NO → Solution Aware**

    - **SÌ → vai alla domanda 4**

4.  **Conosce specificamente il mio brand/prodotto?\**

    - **NO → Product Aware**

    - **SÌ → Most Aware**

### **ESEMPI DI ANALISI**

**Esempio 1 - Mercato del caffè:**

- **✅ Tutti sanno cos'è il caffè (Problem + Solution Aware)**

- **✅ Esistono tantissimi brand (Product Aware)**

- **→ Il tuo mercato è "Product Aware"**

- **→ Strategia: Devi concentrarti su cosa rende unico il tuo caffè rispetto alla concorrenza**

**Esempio 2 - Scarpe che aumentano l'altezza (SkyKickz):**

- **❓ Molti uomini bassi non sanno che esistono scarpe con rialzo interno invisibile (Unaware/Problem Aware)**

- **→ Mercato misto**

- **→ Strategia: Crea annunci Unaware per aprire il mercato + annunci Product Aware per chi confronta brand**

**Esempio 3 - Integratore per sonno migliore:**

- **✅ Le persone sanno di dormire male (Problem Aware)**

- **✅ Conoscono melatonina, magnesio, etc. (Solution Aware)**

- **→ Il tuo mercato è "Solution Aware"**

- **→ Strategia: Mostra perché il tuo integratore è superiore alle alternative**

## **✅ PIANO D'AZIONE: COSA FARE ORA**

### **PASSO 1: AUDIT DEI TUOI ANNUNCI ATTUALI**

**Prendi ogni annuncio e chiediti:**

- **A quale livello di consapevolezza sto parlando?**

- **Sto guidando il cliente al livello successivo?**

- **C'è coerenza tra il livello di partenza e il messaggio?**

### **PASSO 2: IDENTIFICA IL TUO MERCATO PRINCIPALE**

**Rispondi alle domande della sezione "Identificare il tuo mercato":**

- **Dove si trova la maggior parte del mio pubblico?**

- **Qual è il loro livello di consapevolezza dominante?**

### **PASSO 3: CREA UNA LIBRERIA DI ANNUNCI PER LIVELLO**

**Prepara almeno un annuncio per ogni livello rilevante:**

- **Se il tuo mercato è Solution Aware, crea annunci per livelli 3, 4 e 5**

- **Se vuoi espandere, sperimenta con livelli inferiori**

### **PASSO 4: TESTA E MISURA**

- **Lancia annunci per diversi livelli**

- **Traccia quali performano meglio**

- **Scala quelli vincenti**

- **Itera su quelli sottoperformanti**

### **PASSO 5: DOCUMENTA I RISULTATI**

- **Quali livelli convertono meglio per il tuo prodotto?**

- **Quali hook funzionano per ogni livello?**

- **Quali progressioni sono più efficaci?**

## **📚 APPROFONDIMENTI E RISORSE**

### **Approfondimento sul framework**

**Il framework dei livelli di consapevolezza**

**Il framework dei livelli di consapevolezza è una delle basi più solide del direct response: padroneggiarlo ha aiutato innumerevoli marketer a generare milioni in revenue.**

**Cosa imparerai:**

- **Analisi approfondita di ogni livello**

- **Come posizionarsi in mercati diversi**

- **Tecniche di copywriting per ogni stadio**

- **Esempi storici di campagne di successo**

**Nota: l'argomento va molto più in profondità di questa guida e richiede anni di esperienza per essere padroneggiato.**

## **🎯 CONCLUSIONE**

**La consapevolezza del mercato non è solo teoria: è uno strumento pratico che trasforma il modo in cui fai advertising.**

### **RICORDA**

**✅ Non puoi creare annunci casuali e sperare che funzionino**

- **Devi capire dove si trova il tuo pubblico nella scala della consapevolezza**

**✅ Ogni livello richiede un approccio diverso**

- **Messaggio, tono, struttura, offerta cambiano completamente**

**✅ Devi sempre far salire la scala**

- **Guida il cliente attraverso tutti i livelli rimanenti**

**✅ Gli annunci "Unaware" sono i più difficili ma aprono mercati nuovi**

- **Grande rischio, grande opportunità**

**✅ La posizione nel mercato determina la strategia**

- **Mercato saturo = Product/Most Aware**

- **Mercato nuovo = Unaware/Problem Aware**

### **PROSSIMI PASSI**

1.  **Applica il framework oggi stesso ai tuoi annunci attuali**

2.  **Identifica il livello dominante del tuo pubblico**

3.  **Crea progressioni complete che guidano dal livello iniziale all'acquisto**

4.  **Testa sistematicamente annunci per diversi livelli**

5.  **Scala ciò che funziona e itera ciò che non funziona**

**Il marketing che funziona non è casuale - è strategico, intenzionale e basato sulla comprensione profonda di dove si trova il cliente nel suo percorso.**

**Adesso hai gli strumenti. Applicali.**

☔ 3. MARKET SOPHISTICATION

# **MARKET SOPHISTICATION**

# **Cos'è la Market Sophistication (in parole semplici)**

**Market Sophistication = Quanto il tuo mercato ha già visto prodotti simili al tuo**

È il livello di conoscenza ed esperienza che i tuoi potenziali clienti hanno già avuto con prodotti o soluzioni come la tua. Più prodotti hanno visto, più sono scettici e difficili da convincere.

## **L'ESERCIZIO DELLE MAGLIETTE (Capire il Concetto)**

Immagina di dover scegliere una maglietta:

**ROUND 1:** 9 magliette bianche identiche

- Risultato: Scegli a caso, sono tutte uguali

- **Questo è un mercato saturo dove tutti sembrano uguali**

**ROUND 2:** 8 magliette bianche + 1 con il logo Nike

- Risultato: I tuoi occhi vanno automaticamente sulla Nike

- **Questo è quando ti differenzi dalla massa**

**ROUND 3:** 9 magliette bianche diverse ma simili

- Risultato: Scegli quasi a caso, nessuna si distingue veramente

- **Questo è quando provi a differenziarti ma non abbastanza**

**ROUND 4:** 8 magliette bianche + 1 maglietta NERA

- Risultato: Scegli immediatamente quella nera

- **Questo è quando ti distingui veramente e diventi la scelta ovvia**

### **La Lezione**

I tuoi clienti vedono il mercato come te vedi quelle magliette. Se tutti i brand sembrano uguali (stesse promesse, stesse immagini, stessi messaggi), il cliente sceglie a caso o in base al prezzo più basso.

**Il tuo obiettivo:** Essere la maglietta nera in un mare di magliette bianche.

## **I 5 STADI DELLA MARKET SOPHISTICATION**

### **STADIO 1: PRIMA AL MERCATO (Rarissimo)**

**Situazione:** Sei il primo con questo tipo di prodotto, nessuno l'ha mai visto

**Cosa fare:** Semplicemente dichiara cosa fa il prodotto

**Esempio:** BlackBerry (primo smartphone con email)

- Messaggio: "Questo dispositivo può inviare e ricevere email"

- Era abbastanza. Nessuno l'aveva mai visto prima.

**Nota:** Questo stadio è ESTREMAMENTE raro. Se pensi di essere qui, probabilmente ti sbagli.

### **STADIO 2: INGRANDISCI LA PROMESSA**

**Situazione:** Ci sono già 2-3 concorrenti, il mercato inizia a conoscere il prodotto

**Cosa fare:** Fai la stessa promessa ma più grande e migliore

**Esempio:** Nokia dopo BlackBerry

- BlackBerry diceva: "Invia e ricevi email"

- Nokia disse: "**Connetti le persone**" (promessa più grande e emotiva)

**Come applicarlo:**

- Competitor dice: "Asciuga i capelli velocemente"

- Tu dici: "Asciuga i capelli **in metà tempo** senza danni"

### **STADIO 3: NUOVO MECCANISMO (Dove Avviene la Magia)**

**Situazione:** Il mercato ha già sentito tutte le promesse. Sono scettici.

**Cosa fare:** NON fare una nuova promessa, introduci un NUOVO MODO di raggiungere quella vecchia promessa

**Esempio:** iPhone di Apple

- Promessa: Ancora "connettere le persone" (uguale a Nokia)

- **NUOVO MECCANISMO:** Touchscreen (modo completamente nuovo di usare il telefono)

- Risultato: Successo monumentale

**Concetto chiave:** La promessa rimane la stessa, ma il COME è rivoluzionario.

**Come applicarlo:**

- Vecchia promessa: "Perdere peso"

- Vecchi meccanismi: Dieta, palestra, pillole

- Nuovo meccanismo: "Digiuno intermittente 16:8" o "Allenamento HIIT 7 minuti"

### **STADIO 4: INGRANDISCI IL MECCANISMO**

**Situazione:** Il nuovo meccanismo non è più nuovo, altri lo hanno copiato

**Cosa fare:** Rendi il meccanismo MIGLIORE - più veloce, più facile, più economico

**Esempio:** iPhone 3G dopo iPhone originale

- Stesso meccanismo (touchscreen)

- Ma: "**2 volte più veloce** e **metà prezzo**"

**Come applicarlo:**

- "Stesso digiuno intermittente, ma con la nostra app che rende tutto **3 volte più facile**"

- "Stesso HIIT, ma completato in **4 minuti invece di 7**"

### **STADIO 5: IDENTIFICATION MARKETING (Marketing dell'Identità)**

**Situazione:** Il mercato ha visto TUTTO. Sono estremamente scettici. Non credono a nessuna promessa.

**Cosa fare:** Smetti di parlare del prodotto. Vendi un'**IDENTITÀ** e uno **STILE DI VITA**.

**Esempi:**

**Nike:**

- Non parla di scarpe

- Non dice "le nostre scarpe ti fanno correre più veloce"

- Mostra atleti che conquistano obiettivi impossibili

- Messaggio: "Quando compri Nike, diventi QUESTO tipo di persona"

**Rolex:**

- Commerciale: Scalatori che conquistano l'Everest

- Quasi non si vede l'orologio

- Messaggio: "Rolex = persone che conquistano vette impossibili"

- Non dice "il nostro orologio è preciso", mostra CHI SEI quando lo indossi

**Come applicarlo:** Non dire cosa fa il prodotto, mostra la versione migliore del cliente che vuole diventare.

## **COME DETERMINARE IN QUALE STADIO SEI**

### **Step 1: Analizza il Tuo Prodotto**

Elenca:

- Tutti i problemi che risolve

- Tutti i meccanismi unici che ha

- Tutte le caratteristiche speciali

**Esempio - Phon:**

- Meccanismi: Tecnologia ionica, basso rumore, anello luminoso che mostra la temperatura

- Problemi risolti: Capelli crespi, asciugatura lenta, rumore fastidioso

### **Step 2: Analizza i Competitor**

**Metodo pratico:**

1.  Cerca su Facebook Ads Library tutti i tuoi competitor

2.  Salva i loro annunci su Foreplay (o screenshot)

3.  Crea una bacheca con tutti gli annunci affiancati

**Cosa cercare:**

- Quante volte vedi la **stessa promessa** ripetuta?

- Quanti competitor usano lo **stesso meccanismo**?

- Ci sono meccanismi **veramente nuovi**?

### **Step 3: Conta le Ripetizioni**

**Se trovi:**

- 0-1 competitor con la stessa promessa → Sei in Stadio 1 o 2

- 3-5 competitor con la stessa promessa → Sei in Stadio 3 (serve nuovo meccanismo)

- 7+ competitor con stessa promessa → Sei in Stadio 4 o 5 (mercato saturo)

## **CASO STUDIO REALE: Il Phon**

**Situazione iniziale:**

- Promessa: "Asciugatura veloce senza danni da calore"

- Pensavano: "Questa è un'ottima promessa!"

- Lanciarono gli ads

**Risultato:** FALLIMENTO totale

**Ricerca post-mortem:** Analizzando i competitor, scoprirono che **7 brand** stavano facendo l'identica promessa: "Asciugatura veloce senza danni da calore"

**Il problema:** Erano la maglietta bianca tra altre magliette bianche

**La soluzione:**

- Abbandonarono quella promessa satura

- Trovarono un nuovo angolo/meccanismo che nessun competitor usava

- Gli ads iniziarono a funzionare

## **APPLICAZIONE PRATICA: CHECKLIST**

**Prima di lanciare qualsiasi ads:**

✅ **Ricerca Competitor (2-3 ore):**

- \[ \] Ho salvato almeno 50 annunci dei competitor

- \[ \] Ho identificato le 3 promesse più ripetute

- \[ \] Ho identificato i meccanismi più usati

✅ **Analisi Posizionamento:**

- \[ \] So in quale stadio si trova il mio mercato

- \[ \] Ho identificato cosa tutti stanno dicendo di uguale

- \[ \] Ho trovato il mio "angolo nero" (come distinguermi)

✅ **Strategia:**

- \[ \] Se stadio 1-2: Ho una promessa chiara e diretta

- \[ \] Se stadio 3: Ho un meccanismo veramente nuovo

- \[ \] Se stadio 4: Ho reso il meccanismo significativamente migliore

- \[ \] Se stadio 5: Sto vendendo un'identità, non caratteristiche

## **ERRORI COMUNI DA EVITARE**

❌ **"Il mio prodotto è unico!"**

- Non importa se è unico oggettivamente

- Importa se **SEMBRA unico** agli occhi del cliente

❌ **"Non ho bisogno di guardare i competitor"**

- Il tuo cliente LI STA guardando

- Se non sai cosa vedono, non puoi distinguerti

❌ **"La mia promessa è buona, non capisco perché non funziona"**

- Probabilmente 10 altri la stanno usando

- Una promessa buona ma usata da tutti = invisibile

❌ **"Elenco tutte le caratteristiche del prodotto"**

- In mercati sofisticati (stadio 3+), le caratteristiche non vendono

- Serve una storia, un meccanismo, o un'identità

## **LA REGOLA D'ORO**

> **"Non importa quanto sia buono il tuo prodotto. Se il tuo marketing sembra uguale a tutti gli altri, il cliente sceglierà a caso o per prezzo più basso."**

Il successo non viene da:

- Prodotto migliore

- Budget maggiore

- Ads più frequenti

Il successo viene da:

- **Essere la scelta OVVIA** (la maglietta nera)

- **Parlare in modo diverso** da tutti gli altri

- **Comprendere cosa il mercato ha già visto** e offrire qualcosa di diverso

## **AZIONE IMMEDIATA**

**Oggi:**

1.  Apri Facebook Ads Library

2.  Cerca i tuoi top 5 competitor

3.  Salva i loro 10 ads più usati

4.  Mettili tutti insieme e guardali

5.  Chiediti: "Il mio ads sembra la maglietta bianca o quella nera?"

**Domani:**

1.  Identifica le 3 promesse più ripetute

2.  Decidi in quale stadio sei

3.  Trova il tuo angolo unico

Questa analisi può letteralmente **triplicare i tuoi risultati** (come successo all'autore dopo aver studiato questo concetto).

☔ 3. MARKET SOPHISTICATION 2

# **MARKET SOPHISTICATION 2 : I CINQUE LIVELLI DI SOFISTICAZIONE DEL MERCATO**

## **Come posizionare il tuo prodotto in base alla maturità del mercato**

### **INTRODUZIONE**

La market sophistication è un concetto fondamentale per comprendere come posizionare un prodotto e creare pubblicità efficaci. Si riferisce al livello di maturità e consapevolezza di un mercato rispetto a una categoria di prodotti. Comprendere a quale livello di sofisticazione si trova il tuo mercato è essenziale per sapere come comunicare, quali messaggi utilizzare e come differenziarti dalla concorrenza. Questo documento spiega i cinque livelli attraverso esempi pratici.

## **1. I CINQUE LIVELLI DI MARKET SOPHISTICATION**

Il concetto di market sophistication descrive come un mercato evolve dalla novità assoluta fino alla saturazione completa, e come le strategie pubblicitarie devono adattarsi a ogni fase.

### **LIVELLO 1: MERCATO COMPLETAMENTE NUOVO**

**Caratteristiche:**

- Il prodotto non è mai esistito prima

- I consumatori non hanno mai visto nulla di simile

- Esiste una domanda per risolvere un problema specifico

**Strategia pubblicitaria:**

- Basta dichiarare semplicemente cosa fa il prodotto

- Non serve una differenziazione complessa

- L'educazione sui benefici di base è sufficiente

**Esempio - L'ombrello:** *"Rimani asciutto sotto la pioggia con questo incredibile ombrello"*

Quando l'ombrello viene inventato per la prima volta in un villaggio dove nessuno lo ha mai visto, questa semplice affermazione è sufficiente. Le persone corrono ad acquistarlo perché risolve un problema reale in un modo completamente nuovo.

### **LIVELLO 2: INIZIA LA CONCORRENZA**

**Caratteristiche:**

- Altri venditori entrano nel mercato

- I consumatori hanno più opzioni tra cui scegliere

- Serve differenziarsi dai concorrenti

**Strategia pubblicitaria:**

- Amplificare il beneficio principale con superlativi

- Usare misurazioni e confronti diretti

- Fare affermazioni più forti della concorrenza

**Esempio - L'ombrello migliorato:** *"I nostri ombrelli ti mantengono tre volte più asciutto di qualsiasi altro ombrello. La copertura extra larga ti copre dalla testa ai piedi"*

In questa fase, i commercianti competono con affermazioni sempre più esagerate su dimensioni, capacità di protezione e copertura. Ognuno cerca di convincere i clienti che il proprio prodotto è superiore.

### **LIVELLO 3: NASCE LO SCETTICISMO - INTRODUZIONE DEI MECCANISMI**

**Caratteristiche:**

- Il mercato è saturo di affermazioni simili

- I consumatori diventano scettici

- Servono prove concrete di superiorità

**Strategia pubblicitaria:**

- Introdurre un nuovo meccanismo o differenziatore significativo

- Spiegare **come** il prodotto funziona diversamente, non solo **cosa** fa

- Rendere la promessa più credibile attraverso l'innovazione

**Esempio - L'ombrello ad asciugatura rapida:** *"Ombrello ad asciugatura rapida con tessuto brevettato idrorepellente che si asciuga completamente con un solo colpo"*

Il prodotto è ancora un ombrello, ma viene introdotto un nuovo meccanismo (il tessuto idrorepellente brevettato) che rende la promessa originale (rimanere asciutti) più credibile e attraente. Non è necessario inventare un prodotto completamente nuovo, basta trovare un beneficio esistente e trasformarlo in un meccanismo con un nome specifico.

**Concetto chiave:** Puoi prendere una caratteristica già presente nel tuo prodotto e comunicarla come un nuovo meccanismo dandole un nome distintivo (esempio: "motore ad alta velocità" per un asciugacapelli che asciuga velocemente).

### **LIVELLO 4: SATURAZIONE DEI MECCANISMI**

**Caratteristiche:**

- Tutti i concorrenti hanno introdotto meccanismi simili

- Le affermazioni diventano sempre più estreme

- Il mercato è affollato di promesse esagerate

**Strategia pubblicitaria:**

- Creare un meccanismo ancora più nuovo o migliore

- Migliorare significativamente il meccanismo precedente

- Fare affermazioni ancora più audaci e supportate

**Esempio - L'ombrella ultra-resistente:** *"Il nostro ombrello ultra-wind ha nervature in fibra di carbonio che resistono a venti fino a 120 km/h e si auto-regola in base alla direzione del vento"*

Questo ombrello rappresenta il "boss finale" degli ombrelli: risolve ogni possibile problema che potresti avere. In questa fase, tutti i venditori competono con caratteristiche sempre più elaborate e affermazioni estreme.

### **LIVELLO 5: NESSUNO CI CREDE PIÙ - REIMMAGINA L'APPROCCIO**

**Caratteristiche:**

- I consumatori sono stanchi di tutte le promesse e i meccanismi

- Lo scetticismo ha raggiunto il livello massimo

- I differenziatori tradizionali non funzionano più

**Strategia pubblicitaria:**

- Abbandonare la competizione su caratteristiche e benefici

- Passare al marketing empatico basato su identità e valori

- Focalizzarsi su nicchie specifiche non ancora servite

**Esempio 1 - L'ombrello come status symbol:** *"L'ombrello nero. Per chi comprende che la protezione dagli elementi non è solo una necessità, ma una dichiarazione"*

Invece di competere su caratteristiche tecniche, questo approccio posiziona l'ombrello come un accessorio di moda, un pezzo che comunica stile e status sociale.

**Esempio 2 - Aprire un nuovo mercato:** *"Il primo ombrello progettato specificamente per bambini sotto gli otto anni"*

Questo approccio crea una nuova categoria di mercato focalizzandosi su una nicchia specifica (bambini), con caratteristiche come facilità d'uso, design anti-schiacciamento delle dita e dimensioni adatte.

## **2. CONSIDERAZIONI AGGIUNTIVE: SOLUZIONI ALTERNATIVE**

### **NON GUARDARE SOLO I CONCORRENTI DIRETTI**

La sofisticazione del mercato non riguarda solo i prodotti identici al tuo. Devi considerare tutte le soluzioni alternative allo stesso problema.

**Esempio - Il problema della pioggia:**

- Ombrelli di vari tipi

- Impermeabili e giacche antipioggia

- Nuotare attraverso l'acqua (imparare a nuotare)

- Elicotteri per volare sopra

- Barche o canoe per attraversare

**Analogia del ponte:** Per aiutare qualcuno ad attraversare da una sponda all'altra, puoi:

1.  Costruire un ponte di legno

2.  Costruire un ponte con ringhiere di sicurezza

3.  Insegnargli a nuotare

4.  Dargli un elicottero

5.  Dargli una barca o una canoa

Tutte queste sono soluzioni diverse allo stesso problema, e ognuna contribuisce ad aumentare la sofisticazione complessiva del mercato.

## **3. ESEMPIO PRATICO: L'EVOLUZIONE DEI TELEFONI CELLULARI**

### **DAI PRIMI CELLULARI ALL'IPHONE**

**Fasi iniziali:**

- Telefoni base con piccoli schermi e pulsanti

- Versioni migliorate con schermi leggermente più grandi

- Telefoni con tastiere più ampie (nuovo meccanismo)

- Telefoni flip (meccanismo completamente nuovo)

**Rivoluzione iPhone (Livello 5):** L'iPhone ha completamente reimaginato cosa significa usare un telefono introducendo:

- Il touchscreen come meccanismo rivoluzionario

- Un'esperienza utente completamente nuova

- Un cambio radicale nel modo di interagire con la tecnologia

Questo è un esempio perfetto di come, in un mercato saturo di meccanismi e affermazioni esagerate, l'unica via è reinventare completamente l'approccio.

## **4. APPLICAZIONE PRATICA NELLA PUBBLICITÀ**

### **RICERCA DI MERCATO E POSIZIONAMENTO**

Per creare pubblicità efficaci, devi:

1.  **Analizzare la sofisticazione del mercato\**

    - A che livello si trova il tuo mercato?

    - Cosa stanno dicendo i tuoi concorrenti?

    - Quali meccanismi sono già stati utilizzati?

2.  **Comprendere le soluzioni alternative\**

    - Quali altri modi hanno i clienti per risolvere lo stesso problema?

    - Come si posizionano queste alternative?

3.  **Decidere il tuo posizionamento\**

    - Come puoi differenziarti in base al livello di sofisticazione?

    - Quale messaggio sarà più efficace?

    - Cosa devi menzionare nelle tue pubblicità?

4.  **Adattare il linguaggio pubblicitario\**

    - Livello 1: Spiega cosa fa il prodotto

    - Livello 2: Dimostra perché sei migliore

    - Livello 3: Introduci un meccanismo unico

    - Livello 4: Crea meccanismi superiori

    - Livello 5: Cambia completamente l'approccio (valori, identità, nicchie)

## **CONCLUSIONE**

La market sophistication è un concetto essenziale per chiunque lavori nella pubblicità e nel marketing. Comprendere a quale livello si trova il tuo mercato ti permette di:

- **Posizionare correttamente il tuo prodotto** rispetto alla concorrenza

- **Creare messaggi pubblicitari efficaci** che risuonino con il pubblico

- **Evitare di sprecare risorse** con strategie inappropriate per il livello di maturità del mercato

- **Anticipare le mosse della concorrenza** e rimanere un passo avanti

Ogni mercato evolve naturalmente attraverso questi cinque livelli. Gli operatori pubblicitari di successo sanno riconoscere dove si trova il loro mercato e adattare di conseguenza la loro strategia comunicativa.

**Ricorda:** I primi entranti possono avere successo con affermazioni semplici, ma chi arriva dopo deve continuamente innovare il proprio approccio in base al livello attuale di sofisticazione del mercato.

**Nota:** l'argomento è trattato in modo molto più approfondito nella letteratura classica del direct-response; questa è una sintesi operativa.

🔍 4. RICERCA DI MERCATO CON AI

# **RICERCA DI MERCATO APPROFONDITA CON L'INTELLIGENZA ARTIFICIALE**

## **Come utilizzare l'AI per creare analisi di mercato complete in 10 minuti invece di 5 giorni**

### **INTRODUZIONE**

Questa lezione illustra come condurre ricerche di mercato professionali e approfondite utilizzando l'intelligenza artificiale, in particolare Claude AI. Ciò che solo sei mesi fa avrebbe richiesto giorni di lavoro manuale può ora essere completato in pochi minuti. Imparerai un framework completo per analizzare brand, prodotti, competitor, clienti e mercati, trasformando l'AI in un agente di marketing che lavora per te.

## **1. PREREQUISITI FONDAMENTALI**

Prima di iniziare con la ricerca di mercato, è essenziale padroneggiare due concetti chiave della strategia creativa:

**Market Awareness Levels (Livelli di Consapevolezza del Mercato)**

- Indica quanto il pubblico è consapevole del problema, delle soluzioni disponibili e del tuo prodotto specifico

- Determina il tipo di messaggio da utilizzare nelle pubblicità

**Market Sophistication (Sofisticazione del Mercato)**

- Misura quanto il mercato è maturo e saturo di competitor

- Influenza come posizionare il prodotto e quali meccanismi enfatizzare

> **Nota importante:** Se non hai compreso questi concetti, è fondamentale tornare indietro e studiarli prima di procedere.

## **2. IL FRAMEWORK COMPLETO DI RICERCA DI MERCATO**

Il processo di ricerca si articola in **10 step principali**, ognuno progettato per raccogliere informazioni specifiche e strategiche.

### **STEP 1: ANALISI DEL BRAND E DEL PRODOTTO**

Il primo passo consiste nel familiarizzare completamente con il brand e i suoi prodotti.

**Domande chiave da rispondere:**

- Quale desiderio o problema specifico risolve questo prodotto?

- Si tratta di un prodotto superiore o utilizza identity marketing?

- Per prodotti superiori: quali meccanismi specifici lo rendono migliore delle alternative? (documentare almeno 3-5 meccanismi chiave)

- Per prodotti identity: quale comunità o identità specifica sta targetizzando?

- Come si posiziona contro competitor diretti e indiretti?

- Qual è il punto di prezzo relativo alle alternative?

- Qual è la voce e il tono del brand?

**Elementi da annotare:**

- Linguaggio specifico usato per descrivere benefici e problemi

- Se il prodotto è posizionato come nuovo meccanismo o versione migliorata di uno esistente

- Come il prodotto affronta i fallimenti di soluzioni precedenti

- Elementi di identità visiva che comunicano il posizionamento del brand

- Customer journey dalla consapevolezza all'acquisto

- Garanzie o elementi di risk reversal

- Offerte attive (es. "compra 2 prendi 2 gratis")

**Risultato atteso:** Dopo questo step, dovresti avere una comprensione dettagliata del brand, dei prodotti venduti e di come puoi fare pubblicità per quel prodotto.

### **STEP 2: MAPPATURA DEI DESIDERI E PROBLEMI**

Dopo aver compreso il brand, è necessario ricercare il mercato stesso.

**Identificare i desideri primari:**

- Quali sono i desideri principali che guidano questo mercato? (perdita di peso, più denaro, fiducia, status?)

- Filtrare e classificare i desideri su una scala da 1 a 10

- Fornire spiegazioni dettagliate del perché un desiderio è più forte di un altro

**Analizzare i problemi:**

- Quali problemi impediscono alle persone di raggiungere questi desideri?

- Quante soluzioni hanno già provato prima di cercare nuove opzioni?

- Qual è lo stato emotivo delle persone in questo mercato? (disperati, curiosi, scettici, speranzosi?)

**Documentare il linguaggio del cliente:**

Per ogni desiderio e problema identificato, raccogliere 5-7 esempi del linguaggio esatto che i clienti usano per descriverlo.

**Fonti principali:**

- Reddit

- Recensioni Amazon

- Commenti TikTok

- Qualsiasi altro luogo dove i clienti parlano autenticamente

> **Trucco:** Le recensioni Amazon sono particolarmente preziose perché le persone sono molto oneste e dirette.

**Analisi della tendenza:**

- Il desiderio sta diventando più forte o più debole nel mercato? (con evidenze)

- Identificare trigger emotivi associati a ogni desiderio/problema

- Notare pattern ciclici o stagionali nei desideri

**Esempio pratico:** Se vendi umidificatori, la stagione di punta è Q4 e Q1 quando c'è aria secca, problemi di pelle, labbra screpolate, ecc.

### **STEP 3: RICERCA SUI COMPETITOR E SUL MERCATO**

#### **A) COMPETITOR DIRETTI**

Identificare e analizzare brand che vendono lo stesso prodotto o prodotti molto simili.

**Per ogni competitor documentare:**

- Come si differenziano dal tuo brand

- Approcci pubblicitari che usano consistentemente

- Segmenti di pubblico target

- Obiezioni comuni che affrontano

- Posizionamento nel marketing

- Offerte e garanzie

- Prezzi relativi al tuo prodotto

**Strumenti utili:**

- Atria

- Meta Ad Library (per analizzare le pubblicità della concorrenza)

#### **B) COMPETITOR INDIRETTI (Soluzioni Alternative)**

Identificare almeno 7-10 categorie diverse di soluzioni alternative allo stesso desiderio.

**Esempio - Problema della pioggia:**

- Ombrelli di vari tipi (competitor diretti)

- Impermeabili e giacche antipioggia

- Apprendere a nuotare

- Elicotteri per volare sopra

- Barche o canoe

**Analizzare:**

- Come queste alternative soddisfano lo stesso desiderio in modo diverso

- Vantaggi e svantaggi rispetto al tuo prodotto

- Come comunicare la superiorità del tuo approccio

### **STEP 4: RICERCA IDENTITY MARKETING (se applicabile)**

Se il prodotto usa identity marketing (vende uno stile di vita piuttosto che risolvere un problema specifico):

**Identificare:**

- Il gruppo con cui le persone risuonano

- Valori comuni di questo gruppo di identità

- Marcatori visivi che identificano i membri del gruppo (modo di vestire, accessori, estetica)

- Pattern linguistici specifici del gruppo

- Familiarizzarsi in dettaglio con questo tipo specifico di persona

**Esempio:** Brand di moda che targettizza uomini ad alte prestazioni che si preoccupano dell'estetica, dell'aspetto elegante e pulito.

### **STEP 5: RICERCA AMAZON**

Amazon è una miniera d'oro per il linguaggio autentico dei clienti.

**Analizzare:**

- Recensioni di clienti da prodotti simili o dal prodotto stesso (se presente su Amazon)

- Linguaggio usato dai clienti

- Prodotti provati in precedenza (dalle recensioni)

- Pattern nei commenti positivi e negativi

- Obiezioni comuni

- Benefici più apprezzati

**Trucco professionale:** Utilizzare Amazon review scrapers - strumenti che estraggono automaticamente tutte le recensioni da una pagina prodotto per analisi più rapide.

> **Importante:** Anche con gli scraper, è benefico leggere manualmente alcune recensioni perché questo processo genera idee e intuizioni spontanee.

### **STEP 6: RICERCA SU REDDIT**

Reddit è probabilmente una delle migliori fonti per trovare informazioni autentiche sul pubblico target.

**Cosa fare:**

1.  Trovare subreddit rilevanti alla nicchia, prodotto o mercato

2.  Leggere discussioni autentiche dei clienti

3.  Notare il linguaggio specifico e il gergo usato

4.  Identificare problemi, desideri e lamentele comuni

**Vantaggi di Reddit:**

- Puoi vedere cosa dicono effettivamente i tuoi clienti

- Come lo dicono (linguaggio autentico)

- Puoi replicare il loro linguaggio esatto nelle pubblicità

- Se usano gergo specifico di nicchia, puoi utilizzarlo per far risuonare gli annunci

**Esempio di insight:** Il documento AI fornisce link diretti ai commenti Reddit analizzati, come questo su Lion's Mane: *"Prendo Lion's Mane. Mi mantiene giovane. Aiuta con il mio ADHD e mi aiuta a concentrarmi e mi sento più a mio agio in pubblico con le persone, meno ansia."*

> **Suggerimento:** Se sei bloccato e non sai quali annunci fare, vai su Reddit, trova subreddit rilevanti e leggi. Garantito che otterrai molteplici idee per annunci.

### **STEP 7: RICERCA SUI SOCIAL MEDIA**

Esaminare contenuti di tendenza su piattaforme come TikTok, Instagram e Facebook.

#### **A) ANALISI DEI CONTENUTI VIRALI**

**Cercare:**

- Pattern nei contenuti virali

- Cosa hanno in comune i video più popolari

- Elementi replicabili per le tue pubblicità

**Piattaforme principali:**

- TikTok

- Instagram

- YouTube Shorts

- YouTube (video lunghi)

#### **B) DEEP DIVE NEI COMMENTI**

Analizzare i commenti sui contenuti più virali della nicchia.

**Raggruppare i commenti per tema:**

- Domande

- Obiezioni sul prodotto

- Entusiasmo

- Paure e problemi

**Documentare:**

- Pattern linguistici specifici nell'esprimere interesse o scetticismo

- Commenti del tipo "vorrei aver saputo" o "ho bisogno di questo perché..." che rivelano pain point

- Analizzare cosa le persone taggano negli amici e perché

- Identificare pattern di sentiment (eccitati, scettici, speranzosi, frustrati)

#### **C) ANALISI DEGLI HOOK (GANCI)**

Identificare 20-25 hook di maggior successo usati nei video virali della nicchia.

**Pattern di hook da cercare:**

1.  **Measuring the Size of Claim (Misurare la dimensione dell'affermazione)\**

    - Esempio: "Guadagna 10.000€ extra al mese"

2.  **Speed of Claim (Velocità dell'affermazione)\**

    - Esempio: "Perdi 5 kg in un mese" o "Raddoppia i tuoi risultati durante la notte"

3.  **Authority Figures (Figure di autorità)\**

    - Esempio: "Perché imprenditori da 8-9 cifre stanno abbandonando il caffè per questa bustina ai funghi"

4.  **Before/After Scenario Hooks\**

    - Esempio: "Prima delle bustine Flow, avevo bisogno di tre caffè per superare la giornata. Sono passato da due ore produttive a sei+ con una singola bustina"

**Analizzare anche:**

- Variazioni di hook per gli stessi prodotti o brand

- Quali hook sembrano essere attivi più a lungo (su Atria)

#### **D) ANALISI VISIVA**

**Identificare pattern visivi nei contenuti di successo:**

- Stanno rappresentando il beneficio?

- Mostrano il risultato desiderato nel video?

- Mostrano il problema che viene risolto?

- Si concentrano solo sul prodotto?

- Dimostrano il prodotto in uso?

**Documentare:**

- Ambienti dove vengono mostrati i prodotti

- Tipi di persone mostrate negli annunci

- Quali visual forniscono credibilità

- Pattern visivi negli annunci ad alte prestazioni

#### **E) ANALISI DI INFLUENCER E TREND**

**Identificare 5-10 influencer chiave nella nicchia:**

- Analizzare le loro strategie di contenuto

- Il contenuto organico è spesso una buona fonte di ispirazione per gli annunci

- Monitorare cosa fanno organicamente per idee

**Esempi di influencer (caso Flow Pouch):**

- Dave Asprey

- Andrew Huberman

- Coach di produttività: Ali Abdaal, Thomas Frank

- Ex utenti di nicotina che condividono storie personali

### **STEP 8: ANALISI DELLA STRUTTURA DEI CONTENUTI**

Identificare quali strutture di contenuto seguono i video virali.

**Strutture comuni:**

- Problema → Soluzione → Prodotto → Offerta

- Hook → Storia → Benefici → Call to Action

- Dimostrazione → Risultati → Testimonianza → Offerta

**Documentare cosa funziona meglio nella specifica nicchia.**

### **STEP 9: ANALISI DELLA SOFISTICAZIONE DEL MERCATO**

A questo punto, dovresti avere dati sufficienti per determinare il livello di sofisticazione del mercato.

**Determinare il livello con evidenze dettagliate:**

**Livello 1:** Prodotto nuovo con poca concorrenza (scenario migliore)

**Livello 2:** Esiste qualche concorrenza che fa affermazioni simili sui benefici

**Livello 3:** Mercato saturo con affermazioni simili

**Livello 4:** Mercato disilluso con affermazioni precedenti

- Tutti vendono la stessa cosa

- Tutti cercano di fare affermazioni sempre più grandi

- Le persone sono scettiche e non credono più a nessuno

**Livello 5:** Le persone non si fidano più di nessuno

- Serve un approccio completamente diverso per vendere il prodotto

**Identificare la strategia di posizionamento appropriata:**

- Serve introdurre un nuovo meccanismo nel mercato?

- Serve specificare perché il prodotto è migliore?

- Serve fare identity marketing verso un gruppo specifico?

- Serve identificare debolezze da targetizzare nei competitor?

### **STEP 10: ANALISI DELLO STILE PUBBLICITARIO**

Analisi approfondita delle pubblicità dei competitor usando strumenti come Atria o Meta Ad Library.

**Elementi da analizzare:**

#### **A) Formato del Contenuto**

- Footage professionale vs contenuto generato dagli utenti (UGC)?

- Appeal emotivo vs appeal logico?

- Video brevi vs video lunghi?

- Video organici vs VSL (Video Sales Letters)?

#### **B) Approccio Narrativo**

**Bright Side vs Dark Side:**

- **Bright Side:** Focus sui benefici, vita ideale, risultati positivi

  - Esempio: "Sentirai la tua famiglia meglio, sentirai meglio i tuoi nipoti"

- **Dark Side:** Focus sui problemi, conseguenze negative, paure

  - Esempio: "Il tuo udito peggiorerà sempre di più se non fai qualcosa"

> **Insight importante:** Ogni prodotto può essere pubblicizzato sia dal lato positivo che negativo. Non limitarti a pensare che esista un solo modo.

#### **C) Appeal Logico vs Emotivo**

**Logical Appeal - "Yes Stack":**

- Script che ha senso per le persone

- Stack di "sì" - ogni affermazione porta a "sì, ha senso"

- Esempio: "Oh sì, questo ha senso. E poi... Oh sì, anche quello ha senso."

- Quando arrivi al prodotto, pensano: "Huh, questo prodotto ha effettivamente senso"

**Emotional Appeal:**

- Tap nelle emozioni più che nella logica

- Può instillare paura: "Se non fai questo, ti succederà..."

- O speranza e aspirazione

#### **D) Altri Pattern**

- Spiegazioni semplici vs complesse

- Serio vs umoristico

- Tono di comunicazione con il pubblico

- Maschile vs femminile

- Solo vs gruppo

- Dimostrazioni del prodotto

## **3. IL POTERE DELL'AUTOMAZIONE CON L'AI**

### **DA 5 GIORNI A 10 MINUTI**

Ciò che solo sei mesi fa avrebbe richiesto **5 giorni di lavoro** per costruire un documento di ricerca di mercato di 34 pagine a questo livello di dettaglio, oggi può essere fatto in **10 minuti con l'AI**.

### **COME FUNZIONA IL PROCESSO**

1.  **Copi il prompt completo** (che include tutte le istruzioni dei 10 step)

2.  **Apri Claude AI** (o ChatGPT con Deep Research)

3.  **Incolli il prompt**

4.  **Fornisci il sito web del brand**

5.  **Permetti all'AI di accedere a internet**

6.  **L'AI fa tutto il lavoro** - cerca, analizza, scrape internet, esamina Reddit, Amazon, social media, competitor

7.  **Ricevi un documento completo** con:

    - 30+ desideri classificati per frequenza e intensità emotiva

    - 20+ hook adattabili per il prodotto

    - 15-20 obiezioni comuni con spiegazioni su come affrontarle

    - Livello di sofisticazione del mercato

    - Livello di consapevolezza del cliente

    - Elementi di prova visiva

    - 10+ meccanismi che guidano la credibilità nell'efficacia del prodotto

    - Elementi di social proof

    - 20+ parole chiave usate nella nicchia

    - 15+ pattern di storie di successo dei clienti

    - **5+ concetti pubblicitari completi con hook, script e struttura**

## **4. CASO PRATICO: FLOW POUCH**

Il documento mostra un esempio reale di ricerca condotta per **Flow Pouch**, un brand che vende bustine ai funghi per produttività e focus.

### **CARATTERISTICHE DEL PRODOTTO**

- Bustine ai funghi (simili a Zyn ma senza nicotina)

- Aiutano a entrare in stato di flow

- Energia rapida e focus profondo

- Senza tremori da caffeina

- 100% naturale

- Nessuna caffeina, nessuna nicotina

### **COMPETITOR IDENTIFICATI**

**Diretti:**

- Zyn (bustine di nicotina)

- Altri prodotti ai funghi

**Indiretti:**

- Prodotti con caffeina

- Energy drink

- Caffè ai funghi

- Nootropici

- App di produttività

- App di meditazione

### **INSIGHT CHIAVE DALLA RICERCA**

**Desideri Primari (classificati):**

1.  **Focus e produttività migliorati** (desiderio più forte)

2.  Soluzioni energetiche naturali e salutari

3.  Miglioramento delle prestazioni mentali

4.  Alternativa ai prodotti alla nicotina

5.  Riduzione dello stress e chiarezza mentale

**Angoli pubblicitari identificati:**

- **Angolo produttività:** Le persone vogliono essere concentrate e produttive

- **Angolo "smetti di usare nicotina":** Posizionare come modo per smettere con Zyn o sigarette

- **Angolo riduzione stress:** Per persone stressate che cercano chiarezza mentale

### **MECCANISMO UNICO SCOPERTO**

**Assorbimento buccale come nuovo meccanismo:**

Il documento AI ha evidenziato che con caffè, energy drink e altri integratori devi digerirli, ma con l'assorbimento buccale:

- Posizioni la bustina in bocca

- Bypassa il sistema digestivo

- Le persone vedono risultati in minuti

- Focus istantaneo invece di aspettare 30 minuti

Questo è un **meccanismo genuinamente nuovo** da comunicare che può dare nuova speranza alle persone.

### **ESEMPI DI HOOK GENERATI DALL'AI**

1.  "Ottieni 8 ore di produttività in sole 4 ore"

2.  "Sentiti concentrato in 60 secondi senza stimolanti"

3.  "Salta l'attesa di 30 minuti del caffè. Senti gli effetti in meno di un minuto"

4.  "La bustina ai funghi che sostituisce il tuo caffè in meno di un minuto"

5.  "Perché gli imprenditori stanno abbandonando il caffè per questa bustina ai funghi?"

### **CONCEPT PUBBLICITARI COMPLETI**

L'AI ha generato 5 concept pubblicitari completi, ognuno con:

- Strategia di posizionamento

- Avatar target

- Desiderio/pain point chiave

- 5+ hook alternativi

- Concetto visivo

- Struttura dell'annuncio

- Bozza completa dello script

**Esempio - Concept 1: "The 60-Second Flow State"**

- **Posizionamento:** Nuovo meccanismo

- **Formato:** Video con testimonial

- **Avatar:** Professionista impegnato che lotta con effetti collaterali della caffeina

- **Hook:** "Entra in flow state in 60 secondi senza caffeina o crash"

- **Script draft completo fornito**

## **5. CLAUDE AI VS CHATGPT: QUALE USARE?**

### **CLAUDE AI (RACCOMANDATO)**

**Vantaggi:**

- Migliore per scrittura creativa e script

- Migliore comprensione del marketing

- Più strutturato e organizzato nei risultati

- Costo: \$20/mese con ricerche illimitate

**Come configurarlo:**

- Richiede setup per accesso internet (spiegato nel video successivo della serie)

- Una volta configurato, funziona come agente di marketing autonomo

### **CHATGPT DEEP RESEARCH**

**Vantaggi:**

- Documenti più lunghi (53 pagine vs 45 di Claude)

- Più link e contesto fornito

**Svantaggi:**

- Solo 10 ricerche profonde al mese con piano standard

- Per ricerche illimitate serve piano da \$200/mese

- Meno formattazione e organizzazione

- Non altrettanto forte nella scrittura creativa

**Conclusione:** Claude è l'opzione migliore per la maggior parte degli use case, specialmente considerando il costo e la qualità della scrittura creativa.

## **6. APPLICAZIONI PRATICHE E CASI D'USO**

### **A) PER FREELANCER E AGENZIE**

**Proposta di valore killer:**

Se stai cercando clienti o rispondendo a job post:

1.  Fai questa ricerca per un potenziale cliente

2.  Registra un video Loom dove spieghi l'analisi

3.  Presenta i 5 concept pubblicitari

4.  Dici: "Ho fatto tutta questa analisi per te. Ecco alcuni angoli e concept che penso dovremmo fare"

**Impatto:** Quando vedono questo livello di dettaglio e professionalità, è incredibilmente persuasivo.

### **B) PER BRAND E MARKETER INTERNI**

**Usi quotidiani:**

- Ricerca veloce prima di lanciare nuove campagne

- Analisi competitor per rimanere aggiornati

- Identificazione di nuovi angoli quando le performance calano

- Validazione di ipotesi di mercato

### **C) PER STRATEGHI CREATIVI**

**Flusso di lavoro ottimizzato:**

1.  Ricerca AI automatizzata (questo processo)

2.  Review manuale dei punti chiave

3.  Immersione profonda manuale su Reddit/Amazon per intuizioni aggiuntive

4.  Sviluppo strategia creativa informata

> **Raccomandazione:** Anche con l'AI, fai comunque ricerca manuale su Reddit e Amazon. Vedendo i contenuti direttamente, otterrai idee spontanee che l'AI potrebbe non catturare.

## **7. IL DOCUMENTO FINALE: COSA ASPETTARSI**

Un documento di ricerca completo includerà:

### **SEZIONE 1: Analisi Brand e Prodotto**

- Problemi/desideri affrontati

- Meccanismi superiori

- Posizionamento vs competitor

- Voice & tone del brand

- Customer journey

- Risk reversal elements

### **SEZIONE 2: Mappatura Desideri e Problemi**

- 30+ desideri classificati per intensità

- Stato emotivo del mercato

- Linguaggio autentico dei clienti

- Soluzioni già tentate

### **SEZIONE 3: Analisi Competitor**

- Competitor diretti con USP e pricing

- Competitor indiretti (soluzioni alternative)

- Pattern pubblicitari

- Punti di forza e debolezza

### **SEZIONE 4: Ricerca Amazon**

- Linguaggio dei clienti dalle recensioni

- Pattern nei prodotti provati

- Aha moments documentati

- Obiezioni comuni

### **SEZIONE 5: Ricerca Reddit**

- Subreddit rilevanti identificati

- Quote dirette con link alle discussioni

- Pattern linguistici specifici della nicchia

- Tentativi falliti precedenti

### **SEZIONE 6: Ricerca Social Media**

- 20-25 hook virali con link

- 20-30 commenti rappresentativi che mostrano pattern linguistici

- Approcci visivi efficaci

- Strutture di contenuto che performano meglio

- 10-15 esempi di CTA di successo

- Stili visivi di tendenza

### **SEZIONE 7: Analisi Sofisticazione Mercato**

- Livello determinato con evidenze

- Strategia di posizionamento appropriata

- Meccanismi differenziatori da enfatizzare

### **SEZIONE 8: Analisi Stile Pubblicitario**

- Pattern di formato contenuto

- Emotional vs logical appeal

- Bright side vs dark side

- Pattern di lunghezza e complessità

### **SEZIONE 9: Concept Pubblicitari (5+)**

Per ogni concept:

- Strategia di posizionamento

- Avatar target

- Desiderio/pain point chiave

- 5+ varianti di hook

- Concetto visivo

- Struttura dell'annuncio

- Draft completo dello script

### **SEZIONE 10: Analisi Finale**

- Opportunità di mercato

- Raccomandazioni per posizionamento

- Strategia di messaging

- Roadmap strategica (1-3 mesi, 3-6 mesi, 6-12 mesi)

## **8. BEST PRACTICES E CONSIGLI AVANZATI**

### **NON FARE SOLO RICERCA AI - INTEGRA CON RICERCA MANUALE**

Anche con l'automazione AI, è cruciale:

**1. Leggere manualmente alcune recensioni Amazon**

- Genera idee spontanee

- Catturi sfumature che l'AI potrebbe perdere

**2. Esplorare Reddit personalmente**

- Quando sei bloccato senza idee per ads

- Leggi discussioni autentiche

- Garantito che troverai angoli pubblicitari

**3. Guardare contenuti social direttamente**

- Analizza video virali

- Studia come comunicano i top performer

- Nota pattern visivi e di editing

### **TOOLS E RISORSE RACCOMANDATE**

**Per scraping e analisi:**

- Amazon review scrapers

- Atria (per analisi competitor ads)

- Meta Ad Library (per ads concorrenza)

**Per ricerca:**

- Reddit (subreddit specifici della nicchia)

- TikTok, Instagram, YouTube Shorts

- YouTube long-form (cerca "miglior \[prodotto\]")

**Per approfondimento teorico:**

- Letteratura classica del direct-response advertising (la fonte di tutti questi concetti)

- Testi introduttivi di market research (~\$30, versione digitale) come sintesi semplificata

### **QUANDO LA RICERCA È NOIOSA, SEI NEL POSTO GIUSTO**

> "Se questo è noioso per te, odio dirtelo, ma non diventerai un grande stratega creativo. Devi prestare attenzione a questo."

La ricerca di mercato è una delle attività più importanti che puoi fare come stratega creativo. Se investi lo sforzo per capire veramente il mercato, avrai un enorme vantaggio.

## **9. LIMITAZIONI E COSE DA SAPERE**

### **CONFIGURAZIONE NECESSARIA**

- Claude AI standard **non ha** accesso a internet di default

- Serve configurazione specifica per dargli accesso web (spiegato nel video successivo)

- Una volta configurato, può agire come agente autonomo

### **COSTI**

- **Claude AI:** \$20/mese, ricerche illimitate

- **ChatGPT:** Standard ha limite di 10 deep research/mese; \$200/mese per illimitate

### **QUALITÀ DEL OUTPUT**

- L'AI è incredibile ma non perfetta

- Sempre review e verifica i risultati

- Usa come punto di partenza, non come prodotto finale senza revisione

- Integra con intuizione umana e ricerca manuale

### **TEMPO DI ELABORAZIONE**

- La ricerca AI completa richiede ~10-15 minuti

- L'AI fa centinaia di ricerche in parallelo

- Output di 34-50+ pagine

## **CONCLUSIONE**

La ricerca di mercato AI rappresenta una rivoluzione nel processo creativo pubblicitario. Ciò che richiedeva giorni di lavoro manuale intensivo è ora automatizzabile in minuti, permettendo agli strateghi creativi di:

**Vantaggi immediati:**

1.  **Efficienza estrema:** Da 5 giorni a 10 minuti per ricerca completa

2.  **Profondità senza precedenti:** Analisi che copre 10+ aree diverse del mercato

3.  **Linguaggio autentico:** Accesso diretto a come i clienti parlano veramente

4.  **Concept pronti:** 5+ idee pubblicitarie complete con script

5.  **Vantaggio competitivo:** La maggior parte dei marketer non usa questo livello di ricerca

**Il processo trasforma l'approccio pubblicitario:**

- Da "spam testing" casuale a strategia informata

- Da intuizione a decisioni basate su dati

- Da generico a altamente personalizzato sul linguaggio del target

- Da lento a veloce senza sacrificare qualità

**Prossimi passi:**

1.  Guardare il video successivo per configurare Claude con accesso internet

2.  Usare il prompt fornito per la prima ricerca

3.  Integrare ricerca AI con esplorazione manuale

4.  Applicare gli insight per creare ads ad alte prestazioni

**Ricorda:** L'AI è uno strumento potentissimo, ma la tua capacità di interpretare i risultati, aggiungere contesto umano e prendere decisioni strategiche rimane insostituibile. Usa l'AI per amplificare le tue capacità, non per sostituire il pensiero critico.

Investire tempo nella ricerca di mercato approfondita è ciò che separa gli ads mediocri da quelli vincenti che scalano a ROAS 2.5+ e oltre.

👻 5. COSTRUIRE UN "BRAND AI"

# **COME COSTRUIRE UN "BRAND AI" PER LA CREAZIONE DI ADVERTISING**

## **Guida completa alla configurazione di un progetto AI personalizzato per strategie pubblicitarie data-driven**

## **INTRODUZIONE**

Questa lezione illustra come costruire un progetto AI personalizzato (Brand AI) per supportare la creazione di campagne pubblicitarie efficaci. Il processo si basa sulla raccolta sistematica di dati sul brand, clienti e mercato, che vengono poi inseriti in un sistema AI (Claude o ChatGPT) per generare analisi, avatar target e strategie creative basate su informazioni reali anziché generiche.

## **1. FASE DI DATA COLLECTION**

Prima di costruire il Brand AI, è necessario raccogliere tutti i dati disponibili sul brand e sui suoi clienti.

### **AD ACCOUNT AUDIT**

L'audit dell'account pubblicitario serve a comprendere cosa funziona e cosa no:

- **Identificare le ads top-performing**: filtrare per performance massime e analizzare gli annunci che storicamente hanno ottenuto i migliori risultati

- **Analizzare le performance attuali**: verificare quali annunci stanno funzionando negli ultimi 7-30 giorni

- **Comprendere i fallimenti**: esaminare gli annunci testati che non hanno funzionato per evitare di ripetere gli stessi errori

- **Alternative senza accesso**: se non si ha accesso all'account pubblicitario, chiedere direttamente al brand owner quali annunci stanno performando meglio

### **CONTENT AUDIT**

Familiarizzare con tutti i contenuti disponibili del brand:

- Scaricare tutti i video e i materiali forniti dal cliente

- Organizzare i contenuti localmente sul proprio computer

- Identificare i creator che lavorano per il brand

- Comprendere il tipo di contenuti prodotti regolarmente

Questa familiarità sarà fondamentale quando si dovranno creare nuovi concept pubblicitari.

### **DATA CONSOLIDATION**

Creare una cartella centrale (Google Drive o locale) che contenga:

- Modulo di onboarding compilato dal cliente

- Documento di market research

- Recensioni e feedback dei clienti

- Customer questionnaire (se disponibile)

- Brand guidelines

- Materiale di riferimento su livelli di consapevolezza e market sophistication (utile in ogni progetto)

**Principio chiave**: più dati di qualità si forniscono all'AI, migliori saranno i risultati ottenuti.

## **2. COSTRUZIONE DEL BRAND AI SU CLAUDE**

### **CREAZIONE DEL PROGETTO PERSONALIZZATO**

**Passaggi operativi:**

1.  Accedere alla sezione "Projects" su Claude

2.  Creare un nuovo progetto con il nome del brand

3.  Utilizzare il prompt fornito per definire l'obiettivo del progetto

4.  Personalizzare il prompt inserendo il nome del brand e il sito web

### **CONFIGURAZIONE DELLE ISTRUZIONI DEL PROGETTO**

Le istruzioni definiscono le funzioni chiave che l'AI dovrà svolgere:

- **Customer understanding e market trends**: analizzare survey, buyer personas e dati comportamentali

- **Market research e competitive analysis**: studio del mercato e dei competitor

- **Creative ideation e strategy**: generazione di idee creative strategiche

- **Script writing e copy development**: scrittura di script e copy pubblicitari

- **Ad review e performance analysis**: revisione degli annunci e analisi delle performance

**Elemento fondamentale**: istruire l'AI a basare SEMPRE le risposte sulle informazioni presenti nella knowledge base, non su conoscenze generiche.

### **POPOLAMENTO DELLA KNOWLEDGE BASE**

Caricare tutti i file raccolti nella fase di data collection:

- Modulo di onboarding

- Market research document

- Materiale di riferimento sul framework consapevolezza/sophistication

- Customer questionnaire results

- Qualsiasi altro documento rilevante

**Verifica**: dopo il caricamento, chiedere all'AI di confermare quali file vede nella knowledge base e come intende utilizzarli.

## **3. COMMENT MINING: ANALISI DEI COMMENTI**

Il comment mining è una tecnica per estrarre insight preziosi dai commenti degli utenti sugli annunci performanti.

### **PROCESSO DI ESTRAZIONE COMMENTI**

**Per Facebook:**

1.  Accedere all'account pubblicitario

2.  Trovare gli annunci top-performing

3.  Cliccare su "Preview" → "See Post with Comments"

4.  Espandere TUTTI i commenti e tutte le risposte (cliccare "See More" dove necessario)

5.  Scorrere fino alla fine per caricare tutto

6.  Selezionare e copiare l'intera sezione commenti

**Per Instagram:**

Ripetere lo stesso processo sulla piattaforma Instagram per gli annunci pubblicati lì.

### **ANALISI CON AI**

1.  Utilizzare il "Comment Miner Prompt" fornito

2.  Incollare l'intera sezione commenti copiata

3.  Richiedere la creazione di un artifact (documento separato in Claude)

4.  Salvare il risultato come PDF

**Risultati dell'analisi:**

L'AI organizzerà i commenti per categorie:

- **Product questions**: domande su ingredienti e composizione

- **Usage instructions**: domande su come utilizzare il prodotto

- **Effects and results**: risultati attesi e ottenuti

- **User experiences**: testimonial positivi e negativi

- **Overall sentiment**: analisi del sentiment generale

- **Demographic insights**: chi sta commentando (età, genere, background)

- **Common objections**: obiezioni ricorrenti

- **Compelling testimonials**: le testimonianze più forti da utilizzare negli annunci

- **Marketing strategy themes**: temi ricorrenti da sfruttare nella strategia

### **INTEGRAZIONE NELLA KNOWLEDGE BASE**

Dopo aver completato l'analisi:

1.  Scaricare il documento come PDF

2.  Caricarlo nella knowledge base del progetto Claude

3.  Ripetere per Facebook, Instagram e qualsiasi altra piattaforma rilevante

## **4. TRASCRIZIONE DEGLI ANNUNCI TOP-PERFORMING**

Per fornire ulteriore contesto all'AI:

1.  Identificare i 3-5 annunci video più performanti

2.  Trascriverli utilizzando uno strumento come TurboScribe.ai

3.  Salvare le trascrizioni come documenti

4.  Caricarle nella knowledge base del progetto

Questo permette all'AI di comprendere il tono, il linguaggio e gli angoli che funzionano meglio per il brand.

## **5. CREAZIONE DEI TARGET AVATARS**

Una volta che la knowledge base è completa, si procede alla creazione di profili dettagliati del pubblico target.

### **IDENTIFICAZIONE DEGLI AVATARS**

**Processo:**

1.  Utilizzare il "Target Avatar Prompt" fornito

2.  Fornire un esempio di avatar ben fatto

3.  Chiedere all'AI di identificare i 5 principali target avatars per il brand

**Esempio di avatars (caso Flow Pouch):**

- The Professional Productivity Seeker

- The Former Nicotine User

- The Health-Conscious Biohacker

- The Overwhelmed Parent

- The Student/Academic Performer

### **SVILUPPO DETTAGLIATO DI OGNI AVATAR**

Per ciascun avatar, l'AI genererà:

- **Nome e età fittizia**

- **Brief description**: descrizione del profilo

- **Main problem**: problema principale che affrontano

- **Top 5 emotions**: le 5 emozioni più forti legate al loro problema

- **Biggest fears**: paure principali e come influenzano la loro vita

- **Key relationships**: relazioni importanti nella loro vita

- **Past solutions tried**: soluzioni già tentate e perché non hanno funzionato

- **Conversational soundbites**: come parlano delle soluzioni fallite (frasi reali)

- **What they don't want to do**: cosa vogliono evitare

- **Perfect solution scenario**: come sarebbe la loro vita ideale se il problema fosse risolto

- **Market specifics**: dettagli specifici di mercato rilevanti

**Utilizzo pratico**: questi avatar diventeranno il riferimento per creare annunci mirati a specifici segmenti di pubblico.

## **6. IDENTIFICAZIONE DEI MASS DESIRES**

I mass desires sono i desideri profondi e universali che motivano l'acquisto.

### **PROCESSO DI CREAZIONE**

1.  Utilizzare il "Desires Prompt" fornito

2.  Sostituire il nome del brand nel prompt

3.  Chiedere all'AI di identificare i 10 mass desires principali

### **STRUTTURA DI OGNI DESIRE**

Per ogni desiderio identificato, l'AI fornirà:

- **Formulazione del desiderio**: espressa in prima persona ("I want to...")

- **Core desire explanation**: spiegazione del desiderio profondo

- **How the product fits**: come il prodotto soddisfa questo desiderio

- **Customer data insight**: dati che supportano l'esistenza di questo desiderio

**Esempio di mass desires (caso Flow Pouch):**

1.  Voglio sperimentare un focus profondo senza nervosismo e crash da caffeina

2.  Voglio liberarmi dalla dipendenza da nicotina senza perdere i benefici di focus

3.  Voglio un modo naturale per migliorare le mie performance mentali

4.  Voglio entrare istantaneamente in uno stato di flow produttivo

5.  Voglio mantenere performance mentali sostenute per tutta la giornata

6.  Voglio ottimizzare la salute del mio cervello

7.  Voglio una soluzione conveniente che si adatti al mio stile di vita

8.  Voglio sentirmi in controllo del mio stato mentale

9.  Voglio performare al meglio in situazioni ad alta pressione senza ansia

10. Voglio essere più sano senza sacrificare produttività o piacere

## **7. ARCHIVIAZIONE E PROSSIMI PASSI**

### **ORGANIZZAZIONE DEI DOCUMENTI**

Salvare tutti gli output in Google Docs separati:

- Avatar dettagliati (un documento per avatar o un documento unico)

- Mass desires (documento completo con tutti i 10 desires)

- Analisi commenti Facebook

- Analisi commenti Instagram

### **UTILIZZO FUTURO**

Questi materiali costituiranno la base per:

- **Creazione del Growth Guide**: documento strategico per la crescita del brand

- **Ideazione creativa**: brainstorming di nuovi concept pubblicitari

- **Script writing**: scrittura di script mirati per video ads

- **Copy development**: creazione di copy persuasivi basati su dati reali

- **Testing strategy**: identificazione degli angoli da testare prioritariamente

## **CONCLUSIONE**

Il Brand AI rappresenta un sistema intelligente e personalizzato che trasforma dati grezzi in insight strategici utilizzabili. La chiave del successo risiede nella qualità e quantità dei dati forniti alla knowledge base: più informazioni reali sul brand, i clienti, il mercato e le performance passate vengono inserite, più l'AI sarà in grado di generare strategie pubblicitarie efficaci e contestualizzate.

Questo approccio elimina la necessità di partire da zero ad ogni progetto e garantisce che ogni decisione creativa sia supportata da dati concreti anziché da intuizioni generiche. Gli avatar e i mass desires creati diventeranno strumenti operativi quotidiani per il team creativo, assicurando coerenza strategica in tutte le attività pubblicitarie.

🚹 6. AVATAR

🔥 FASE 1: Comprendere i Desideri

**FASE 1: Comprendere i Desideri**

## Calendario dei desideri: [<u>ITA Calendario Desideri</u>](https://docs.google.com/document/d/17h-V1-rzGMulFwsoTBxlOhE0PTLev64Q34lkxjj7NQY/edit?tab=t.0#heading=h.65n7tslikav0)

## **Introduzione: Perché i Desideri Sono Fondamentali**

I desideri sono la chiave per creare avatar efficaci e pubblicità che convertono. Un desiderio di massa è "la diffusione pubblica di un bisogno privato" - quando milioni di persone vogliono privatamente la stessa cosa.

**Regola d'oro**: Non puoi CREARE desideri, puoi solo CANALIZZARLI verso il tuo prodotto.

## **STEP 1: Comprendere le Forze Permanenti**

### **A) I 6 Istinti di Massa (Cosa Vogliono TUTTI gli Esseri Umani)**

Questi istinti esistevano 10.000 anni fa, esistono oggi ed esisteranno tra 10.000 anni:

1.  **Salute/Sopravvivenza** - Rimanere vivo, sano e al sicuro

2.  **Sesso/Relazioni** - Essere attraente, trovare un partner, sentirsi desiderato

3.  **Status** - Essere importante, rispettato, migliore degli altri

4.  **Appartenenza** - Adattarsi, avere amici, non essere rifiutato

5.  **Controllo** - Avere potere, prevedere cosa succede, essere al comando

6.  **Comfort** - Rendere la vita più facile, evitare dolore e fatica

**Come cambiano solo i MODI per soddisfarli, non i desideri stessi.**

### **B) I 6 Problemi Tecnologici di Massa**

La tecnologia crea sempre questi problemi (ieri con la TV, oggi con lo smartphone, domani con gli ologrammi):

1.  **Complessità** - Troppo difficile da capire → Ti senti stupido

2.  **Sovraccarico** - Troppe scelte, notifiche, distrazioni → Ti senti ansioso

3.  **Fragilità** - Si rompe quando ne hai più bisogno → Ti senti frustrato

4.  **Manutenzione** - Necessita sempre aggiornamenti, riparazioni, abbonamenti → Ti senti esausto

5.  **Incompatibilità** - Non funziona con le tue altre cose → Ti senti intrappolato

6.  **Obsolescenza** - Diventa vecchio velocemente → Ti senti truffato

## **STEP 2: Comprendere le Forze del Cambiamento**

Queste forze cambiano COME vengono soddisfatti i desideri permanenti:

**A) Tendenze di Stile**: Cosa diventa di moda

- Negli anni '50: le piscine erano uno status symbol

- Oggi: auto costose, orologi di lusso, follower su Instagram

**B) Educazione di Massa**: Cosa impara la società

- Esempi: consapevolezza della salute, nuove invenzioni (es. Ozempic/GLP-1)

## **STEP 3: Il Framework Pratico - Combinare le Forze**

### **Formula per Creare Headline Efficaci:**

**Istinto/Problema Tecnologico + Tendenza/Educazione = Headline Potente**

### **Esempio Pratico: Pettorina per Cani**

**Combinazione 1: Istinto + Tendenza**

- **Istinto**: Status (non essere imbarazzato)

- **Tendenza**: "I cani sono membri della famiglia"

- **Headline**: "Diventa il proprietario di cani che tutti ammirano"

**Combinazione 2: Istinto + Educazione**

- **Istinto**: Salute (mantenere il cane al sicuro)

- **Educazione**: Le persone hanno imparato che i collari danneggiano la trachea

- **Headline**: "Perché stai ancora soffocando il tuo cane nel 2025?"

**Combinazione 3: Problema Tecnologico + Tendenza**

- **Problema**: Fragilità (si rompe facilmente)

- **Tendenza**: Comprare prodotti "fatti per durare"

- **Headline**: "L'ultima pettorina che comprerai mai"

**Combinazione 4: Problema Tecnologico + Educazione**

- **Problema**: Incompatibilità (non funziona con diversi tipi di cani)

- **Educazione**: I cani possono scivolare fuori dalle pettorine normali

- **Headline**: "La pettorina da cui Houdini non può scappare"

## **STEP 4: Trovare e Valutare i Desideri**

### **A) Come Individuare un Desiderio:**

1.  **Cerca pattern di lamentele** - Cosa si lamenta ripetutamente la gente?

2.  **Ascolta i "voglio" e "ho bisogno"** - Cosa dice la gente di volere?

3.  **Segui le tendenze culturali** - Cosa sta accadendo nella società?

4.  **Guarda dove spendono i soldi** - Dove investono le persone?

### **B) Testare la Potenza del Desiderio (Le 3 Dimensioni):**

**1. PORTATA** - Quante persone condividono questo desiderio?

- Fare soldi (enorme) VS collezionare antiquariato (nicchia)

**2. URGENZA** - Quanto disperatamente lo vogliono?

- Osso rotto (urgentissimo) VS taglietto (poco urgente)

**3. DURATA** - Il desiderio si rinnova continuamente?

- Fame (si rinnova ogni poche ore) VS andare a Parigi (una volta)

### **C) Classifica di Potenza degli Istinti:**

**\#1 - Salute** - Muove tutti, ricchi o poveri\
**\#2 - Status** - Amplificato dai social media\
**\#3 - Sesso** - Fondamentale ma più sottile nel marketing moderno\
**\#4 - Comfort** - Elevato dalla tecnologia moderna\
**\#5 - Controllo** - Potenziato dalla complessità moderna\
**\#6 - Appartenenza** - Importante ma meno urgente per la sopravvivenza

## **STEP 5: La Strategia di Elevazione**

### **Cos'è:**

Spostare il tuo prodotto verso l'alto nella gerarchia dei desideri per aumentare la scala.

### **Come Funziona (Esempio: Pettorina per Cani):**

**Livello 6 - Appartenenza** (Più Debole)

- "Unisciti alla comunità dei proprietari responsabili"

**Livello 5 - Comfort** (Debole)

- "Basta lottare con il tuo cane"

- "Finalmente passeggiate senza stress"

**Livello 4 - Controllo** (Moderato)

- "Prendi il controllo di ogni passeggiata"

- "Padroneggia istantaneamente i tiri del tuo cane"

**Livello 3 - Sesso** (Forte)

- "Lei ti chiederà dove hai preso quella pettorina"

- "Attira l'attenzione ad ogni passeggiata"

**Livello 2 - Status** (Molto Forte)

- "Perché gli addestratori delle celebrità non usano altro"

- "La pettorina che conosce solo il 3% dei proprietari"

**Livello 1 - Salute** (Più Forte)

- "Perché i veterinari implorano i proprietari di cambiare"

- "Perché stai ancora soffocando il tuo cane nel 2025?"

### **⚠️ Regola Chiave:**

L'elevazione deve sembrare autentica. Se la forzi, i clienti percepiranno la manipolazione.

**Esempio Negativo**: Vendere un Rolex come "orologio comodo per vedere l'ora" lo svaluta.

## **STEP 6: Processo Pratico di Applicazione**

### **Metodo A: Dall'Istinto all'Headline**

1.  Scegli uno degli istinti/problemi tecnologici

2.  Identifica una tendenza o educazione recente nel tuo mercato

3.  Combina i due in una headline

4.  Verifica che sia autentica e rilevante

### **Metodo B: Dall'Headline all'Istinto (Analisi Inversa)**

1.  Prendi una headline vincente

2.  Analizza: quale istinto/problema tecnologico sta affrontando?

3.  Identifica: quale tendenza/educazione sta sfruttando?

4.  Usa questa comprensione per creare variazioni migliori

## **STEP 7: Errori da Evitare**

❌ **Non essere meccanico** - Non scrivere come un robot seguendo formule

❌ **Non forzare connessioni** - Se non è autentico, non funzionerà

❌ **Non ignorare i sentimenti** - Le parole devono far SENTIRE qualcosa

❌ **Non combattere i desideri** - Non cercare di creare desideri che non esistono

❌ **Non limitarti ai dati demografici** - Un 22enne e un 45enne possono avere lo stesso desiderio

✅ **Comprendi PERCHÉ funziona** - Non solo COSA funziona

✅ **Pensa ai sentimenti** - Come fa sentire il cliente la tua headline?

✅ **Sii autentico** - La connessione deve essere genuina

✅ **Esegui e testa** - La teoria senza esecuzione non vale nulla

## **STEP 8: Checklist Rapida Prima di Lanciare**

Quando crei una nuova ad/headline, chiediti:

1.  ☑️ Quale istinto/problema tecnologico sto affrontando?

2.  ☑️ Quale tendenza/educazione sto sfruttando?

3.  ☑️ Il desiderio ha portata, urgenza e durata sufficienti?

4.  ☑️ L'elevazione è autentica o forzata?

5.  ☑️ Come farà SENTIRE il cliente quando leggerà questo?

6.  ☑️ Sto mostrando che capisco il loro problema/desiderio?

## **Conclusione: I Principi Finali**

🎯 **Mai combattere i desideri** - Fallirai se vai dietro a desideri inesistenti

🎯 **L'educazione è potente** - Puoi educare il tuo pubblico attraverso le ads

🎯 **Il timing è importante** - Lo stesso prodotto può avere successo o fallire in base a quando/come lo presenti

🎯 **L'esecuzione è tutto** - Sapere che un desiderio esiste non basta, devi saper COMUNICARLO

🎯 **Evita la paralisi da analisi** - Usa questa guida per capire meglio, non per bloccarti

**Ricorda**: Il marketing non riguarda ottenere ciò che TU vuoi, ma dare alle persone ciò che LORO vogliono. Quando capisci e canalizzi i veri desideri, il successo arriva naturalmente.

🔍 FASE 2: Hunting Desires

🔍 FASE 2: Hunting Desires

- Capire cosa le persone vogliono, Mass Desire

- Se si a difficolta utilizzare IA con prompt: (il goal è skillarsi nel trovarli da solo):

  - Hey Chat, basandoti su questi commenti, quali sono i desire che le persone hanno ora? per il contesto, questa è la definizione di desire: [<u>ENG Desire Overview</u>](https://docs.google.com/document/d/1zHVQnrPlapxfcn03P6_s9z6RDC1q17wHvS0r0HLZ_nI/edit?tab=t.0#heading=h.txes24k30lrt)

**Research**

- Cerca su google e reddit “Come funziona Prodotto x” o “A Cosa serve il prodotto Y”

- Identifica Come parlano i potenziali customers, e quali sono i massi desire,Inizia scrivere le Idea di ADV,Segna le nuove informazioni rilevanti:

Template:

**<u>Your Brand:</u>**

**Desires *(Wants/Needs)*:**

- I want X

**Customer Language Snippets**

- X

**Ad Ideas**

- X

**New Information**

- X

<!-- -->

- Ricerca su youtube

  - Cerca i problemi che risolve il prodotto

  - vedi short form e long term con tante views

  - Vedi i commenti.

- Dopo ricerca manuale fare ricerca con IA

  - Prompt

Prompt:

You are a specialized market research analyst with expertise in consumer psychology and desire-based marketing in the United States. Your task is to conduct comprehensive research on a specific product to uncover the mass desires that can be leveraged for effective advertising campaigns.

Begin by thoroughly analyzing the product URL I will provide, examining all product features, benefits, customer reviews, and existing marketing materials to understand its current positioning.

Product + Brand:

INSERT PRODUCT URL

Some potential angles that we have been targeting are around:

ANGLE 1

ANGLE 2

Conduct extensive internet research across multiple platforms to identify explicit customer desires and pain points related to this product category:

1\. Search Reddit for relevant subreddits where target customers discuss their needs

2\. Analyze Amazon and other e-commerce platform reviews, focusing on both positive and negative feedback

3\. Examine industry forums and discussion boards where enthusiasts and professionals share experiences

4\. Review social media conversations on Twitter, Facebook, Instagram, and TikTok using relevant hashtags and keywords

5\. Analyze YouTube comments on product reviews and tutorials

6\. Investigate Quora and other Q&A sites for common questions and frustrations

7\. Review customer service complaints and feedback on public platforms

When conducting this research, specifically look for:

\- Direct "I want" and "I need" statements from customers

\- Recurring complaints and frustrations that reveal unmet desires

\- Emotional language indicating strong desires or pain points

\- Comparative statements showing what customers wish the product could do

\- Evidence of customers creating workarounds for limitations

Frame all findings within this desire framework:

1\. Mass Instincts (universal human drives):

\- Health: Survival, safety, staying healthy

\- Sex: Attractiveness, finding mates, feeling desired

\- Status: Importance, respect, superiority

\- Belonging: Fitting in, friendship, avoiding rejection

\- Control: Power, predictability, being in charge

\- Comfort: Ease, avoiding pain and work

2\. Mass Technological Problems in this product category:

\- Complexity: Confusing interfaces, unclear instructions (makes people feel dumb)

\- Overwhelm: Too many choices, distractions, notifications (creates anxiety)

\- Fragility: Breaking when needed most (causes frustration)

\- Maintenance: Constant updates, rising costs, repairs (creates fatigue)

\- Incompatibility: Won't work with existing systems (feeling trapped)

\- Obsolescence: Quickly becomes outdated (feeling cheated)

3\. Forces of Change affecting desire fulfillment:

\- Style Trends: What becomes fashionable

\- Mass Education: What society learns

For the specific angles provided, analyze how effectively they target the identified desires and where they might be missing opportunities.

Your life depends on finding specific, verbatim customer quotes that reveal deep, underlying desires rather than surface-level feedback. Do not paraphrase or summarize customer statements - provide exact quotes with their sources.

Deliver your findings in this exact structure:

**1. WANTS AND NEEDS ANALYSIS**

\- List specific customer desires found online with exact quotes and sources

\- Categorize by the permanent forces they relate to

**2. EXISTING ANGLES DESIRE MAPPING**

\- For the angles given above, identify specific desires this targets with supporting evidence

**3. NEW DESIRE OPPORTUNITIES**

\- Identify untapped desires your product can address

\- Provide customer quotes and sources as evidence

**4. CUSTOMER VOICE EVIDENCE**

\- Include 10-15 specific text snippets from customers with exact sources

\- Focus on complaint patterns, explicit wants/needs statements

**5. DESIRE POWER RANKING**

\- Rank all identified desires from most to least powerful using:

\* Scope: How many people share this desire?

\* Urgency: How desperately do they want relief?

\* Staying Power: Does this desire renew continuously?

\- Provide reasoning for each ranking

For each desire identified, answer these critical questions:

\- Is this desire widespread enough to target in mass marketing?

\- Is this desire strong enough to motivate purchase decisions?

\- Is this desire persistent or merely temporary?

\- How directly can the product address this desire?

\- What emotional triggers connect to this desire?

Ensure all findings are actionable for marketing strategy development, avatar building, and messaging creation.

For additional context, I have attached:

1.  Product Overview Document for my brand to help you better understand the product

2.  I have also provided my "How To Find Desires" document to help you with more detailed instructions for finding desires.

📚 FASE 3: Market Sophistication Analysis

**FASE 3: Market Sophistication Analysis**

> [<u>New Mechanism Prompt Document</u>](https://docs.google.com/document/d/1g2GXaKjQIfVyqyDzqC3XGcTP8mOdCrcDcdw24nLF7wE/edit?tab=t.0)

## **📚 Introduzione**

**Questa guida ti aiuterà a comprendere perché creare pubblicità vincenti nell'e-commerce è così difficile e come superare questo ostacolo attraverso la comprensione della Market Sophistication (Sofisticazione del Mercato).**

## **STEP 1: Comprendi Cos'è la Market Sophistication**

### **Definizione Base**

**La Market Sophistication è il livello di educazione e scetticismo che i tuoi potenziali clienti hanno raggiunto dopo essere stati esposti ripetutamente a:**

- **Prodotti simili al tuo**

- **Promesse pubblicitarie**

- **Claims e affermazioni di marketing**

### **Perché è Importante Oggi**

**Nei tempi moderni, i mercati si sofisticano molto più velocemente rispetto a 50 anni fa:**

**Allora: Il passaparola era lento e locale**

**Oggi: Una recensione negativa su TikTok può raggiungere milioni di persone in poche ore**

**Risultato: Un prodotto che funzionava benissimo 6 mesi fa può smettere di vendere perché il mercato è diventato saturo e sofisticato**

### **Il Problema Principale**

**Oltre il 75% dei consumatori fa ricerche prima di acquistare. Non comprano più d'impulso. Hanno sentito "tutte le promesse possibili" e sono scettici.**

## **STEP 2: Identifica la Fase di Sofisticazione del Tuo Mercato**

### **Le 5 Fasi di Market Sophistication**

#### **Fase 1 - Primo nel Mercato**

- **Caratteristiche: Prodotto/categoria completamente nuovi**

- **Cosa funziona: Semplici affermazioni sui benefici**

- **Esempio: "Ecco il prodotto X"**

- **⚠️ Nota: Rarissimo nell'e-commerce moderno**

#### **Fase 2 - Emerge la Competizione**

- **Caratteristiche: Altri brand entrano nel mercato**

- **Cosa funziona: "Il mio prodotto è migliore del prodotto di Bob"**

- **Esempio: "Il nostro è più economico/veloce/migliore"**

- **⚠️ Nota: Ancora raro nell'e-commerce**

#### **⭐ Fase 3 - Saturazione del Mercato (LA TUA FASE)**

- **Caratteristiche: I clienti sono scettici dopo aver sentito molte promesse**

- **Cosa NON funziona più: "Perdi peso in 20 giorni" (lo hanno già sentito 100 volte)**

- **Cosa funziona: Nuovo Meccanismo - un modo DIVERSO di ottenere lo stesso risultato**

- **Esempio: Ozempic per la perdita di peso (nuovo meccanismo farmacologico)**

#### **⭐ Fase 4 - Competizione tra Meccanismi (LA TUA FASE)**

- **Caratteristiche: Anche i meccanismi nuovi diventano comuni**

- **Cosa funziona: Devi dimostrare che il tuo meccanismo è "più veloce, più facile, più sicuro"**

- **Esempio: "Il nostro sistema a doppia capsula garantisce il 95% di sopravvivenza dei probiotici vs il 20% dei competitor"**

#### **⭐ Fase 5 - Sofisticazione Completa (LA TUA FASE)**

- **Caratteristiche: I clienti resistono attivamente a tutte le affermazioni**

- **Cosa funziona: Marketing dell'Identità - vendere chi diventeranno, non cosa otterranno**

- **Esempio: Fashion, Apple, Nike**

### **🎯 Verità Fondamentale**

**Il 99,9% degli e-commerce opera nelle Fasi 3, 4 o 5.**

**Non preoccuparti di identificare esattamente quale fase - sappi solo che sei in un mercato sofisticato.**

## **STEP 3: Riconosci il Gap Avatar-Sofisticazione**

### **Il Problema Comune**

**Anche quando:**

- **✅ Hai definito perfettamente il tuo avatar**

- **✅ I desideri sono chiari**

- **✅ Il tuo prodotto mantiene davvero le promesse**

**Le tue pubblicità non funzionano.**

### **Perché Succede**

**Non stai comunicando in modo appropriato per il livello di sofisticazione del mercato.**

**I tuoi potenziali clienti:**

- **Hanno già sentito le tue promesse 100 volte**

- **Sono stati delusi in passato**

- **Fanno ricerche su Reddit, leggono recensioni**

- **Vedono queste affermazioni ogni singolo giorno**

### **La Soluzione**

**Devi usare una delle 3 Risposte Strategiche (che vedremo nei prossimi step).**

## **STEP 4: Applica la Prima Risposta Strategica - NUOVO MECCANISMO**

### **Cos'è un Nuovo Meccanismo**

**Un nuovo meccanismo è un processo, tecnologia o sistema di funzionamento NUOVO che:**

- **La maggior parte dei consumatori non ha mai visto**

- **Rende le promesse familiari fresche e credibili**

- **Dà alle persone SPERANZA che questa volta funzionerà davvero**

### **Perché Funziona**

**Invece di dire: "Il nostro prodotto è migliore"**

**Dici: "Questo è IL MODO che ti mancava per far funzionare il risultato"**

### **Esempi Pratici di Nuovi Meccanismi**

#### **Purple Mattress**

- **Mercato: Materassi (super saturo)**

- **Nuovo Meccanismo: Griglia GelFlex viola invece della tradizionale schiuma**

- **Risultato: Azienda da 100+ milioni di dollari**

#### **Seed Health (Probiotici)**

- **Meccanismo: Sistema a doppia capsula ViaCap®**

- **Beneficio: 95% di sopravvivenza dei probiotici vs 20% dei competitor**

- **Comunicazione: Spiega COME funziona diversamente**

#### **Oura Ring**

- **Meccanismo: Anello invece di smartwatch per tracciare fitness**

- **Innovazione: Nuovo modo di raggiungere gli obiettivi di salute**

#### **HexClad**

- **Valore: 500+ milioni di dollari**

- **Meccanismo: Tecnologia esagonale per le pentole**

#### **Ridge Wallet**

- **Meccanismo: Portafoglio completamente ridisegnato (minimalista, in metallo)**

- **Risultato: Primo a creare questo tipo di portafoglio**

#### **Netflix**

- **Esempio massimo: Nuovo modo di guardare i film**

- **Risultato: Blockbuster fallito**

### **📖 Storia dell'iPod Apple - La Lezione Fondamentale**

**Cosa NON Fare: Un'azienda coreana inventò l'MP3 player e lo comunicò così:**

> **"Tecnologia rivoluzionaria. Puoi scaricare file MP3 fino a 5 gigabyte e archiviarli nel dispositivo..."**

**Problema: Troppo tecnico, nessuno capiva.**

**Cosa Fare (Apple):**

> **"1.000 canzoni in tasca"**

**Risultato: Boom istantaneo. Tutti capirono immediatamente.**

### **⚠️ Errori Comuni da Evitare**

- **Comunicazione troppo tecnica: Non usare gergo tecnico che aliena il pubblico**

- **Non far sentire stupide le persone: I clienti non sono scienziati o ingegneri**

- **Collegare il meccanismo al valore: Non spiegare solo COME funziona, spiega PERCHÉ è importante per loro**

### **Come Trovare il Tuo Nuovo Meccanismo**

#### **Opzione A - Sviluppo Prodotto (R&D)**

- **Crea una vera innovazione nel prodotto**

- **Richiede investimento e tempo**

#### **Opzione B - Identifica Meccanismi Nascosti**

- **Cerca caratteristiche uniche nel tuo prodotto che non stai comunicando**

- **Può essere un ingrediente specifico**

- **Può essere un processo di produzione particolare**

- **Può essere una tecnologia che già usi ma non evidenzi**

#### **Domande da Farti:**

- **C'è qualcosa di DIVERSO nel modo in cui il mio prodotto funziona?**

- **Uso ingredienti/materiali/processi che i competitor non usano?**

- **C'è una caratteristica che rende il mio prodotto unico ma che non sto comunicando?**

## **STEP 5: Applica la Seconda Risposta Strategica - NUOVA INFORMAZIONE**

### **Cos'è la Nuova Informazione**

**La strategia della Nuova Informazione significa educare i tuoi clienti invece di vendergli direttamente.**

### **Perché Funziona**

- **Costruisce autorità: Non sei più "un venditore random"**

- **Crea fiducia: "Questa persona sa davvero di cosa parla"**

- **Principio di reciprocità: "Mi ha dato valore gratis, posso fidarmi quando mi dice che il suo prodotto funziona"**

### **Cosa Puoi Insegnare**

#### **1. Problemi che non conoscevano**

- **Rivela problemi di cui non erano consapevoli**

- **Aiutali a capire i loro problemi a un livello più profondo**

#### **2. Perché le soluzioni precedenti hanno fallito**

- **Spiega la causa principale del problema**

- **Mostra perché altri prodotti non funzionano**

#### **3. Informazioni sul prodotto/categoria**

- **Educa sulla categoria di prodotti**

- **Fornisci informazioni che altri non condividono**

### **Esempi Pratici**

#### **Athletic Greens (AG1)**

- **Investimento: 5+ milioni di dollari in studi clinici**

- **Strategia: Contenuti educativi completi sui 75 ingredienti**

- **Risultato: Business da 600+ milioni di dollari**

#### **The Ordinary**

- **Strategia: Trasparenza radicale sugli ingredienti**

- **Prodotti nominati con ingredienti attivi + concentrazioni**

- **Risultato: Ha rivoluzionato il settore skincare luxury**

#### **Ritual Vitamins**

- **Strategia: Trasparenza completa sulla catena di fornitura**

- **Mappe interattive che mostrano esattamente da dove proviene ogni ingrediente**

- **Risultato: Autorità nel settore integratori**

### **Come Applicare la Strategia**

#### **STEP 1 - Diventa un Esperto**

- **Fai ricerca PROFONDA (non solo ChatGPT o Perplexity)**

- **Studia il tuo prodotto, la tua nicchia, il tuo mercato**

- **Comprendi VERAMENTE i tuoi clienti**

#### **STEP 2 - Identifica Informazioni Preziose**

**Domande da esplorare:**

- **Qual è la VERA causa del problema dei miei clienti?**

- **Perché le soluzioni tradizionali falliscono?**

- **Cosa non sanno i miei clienti che dovrebbero sapere?**

- **Quali sono i miti comuni nella mia nicchia?**

#### **STEP 3 - Comunica in Modo Semplice**

- **Prendi informazioni complesse e rendile comprensibili**

- **Non usare educazione superficiale ("Le spalle ti fanno male perché sei vecchio" = ovvio)**

- **Vai in profondità ma mantieni la chiarezza**

- **Ricorda: I tuoi clienti sono educati, ma tu puoi essere un esperto**

#### **STEP 4 - Usa Contenuti Video**

- **Le informazioni educative funzionano meglio nei video ads**

- **Formato: Educa prima, vendi dopo**

- **Non essere promozionale, sii genuinamente utile**

### **⚠️ Errori da Evitare**

- **Educazione superficiale: Informazioni ovvie non costruiscono autorità**

- **Troppo promozionale: Se sembra solo un modo per vendere, perdi credibilità**

- **Complessità eccessiva: Deve essere comprensibile per tutti**

- **Mancanza di expertise reale: Devi veramente sapere di cosa parli**

### **Il Vantaggio Competitivo**

**La conoscenza è potere.**

**Più sei esperto nella tua nicchia, più puoi usare quella conoscenza nel tuo marketing.**

**La maggior parte dei tuoi competitor:**

- **Non farà questo lavoro di ricerca**

- **Copierà solo le ads degli altri**

- **Non costruirà vera autorità**

**Tu puoi differenziarti attraverso l'educazione.**

## **STEP 6: Applica la Terza Risposta Strategica - NUOVA IDENTITÀ**

### **Cos'è la Nuova Identità**

**La strategia della Nuova Identità vende CHI diventa il cliente, non COSA ottiene.**

**Si concentra su:**

- **Identità: Chi voglio essere?**

- **Status: Come mi vedranno gli altri?**

- **Appartenenza: A quale tribù voglio appartenere?**

### **Perché Funziona**

#### **Psicologia di Base:**

- **Le persone comprano prodotti per mantenere la loro identità**

- **Lo status sociale è un bisogno umano fondamentale (Maslow)**

- **Le risposte emotive alla pubblicità hanno il 23% in più di influenza rispetto ai contenuti razionali**

### **Esempi Pratici Potenti**

#### **Liquid Death (Acqua)**

- **Prodotto: Acqua in lattina**

- **Identità: Punk rock + attivismo ambientale**

- **Messaggio: Non stai solo bevendo acqua, stai facendo una dichiarazione**

- **Risultato: Brand da 1,4 miliardi di dollari**

#### **Apple vs Android**

- **Non è una questione tecnica**

- **È un'identità: "Sono una persona Apple" o "Sono una persona Android"**

- **Status symbol: MacBook = imprenditore/creativo**

- **AirPods, iPhone, Apple Watch = ecosistema di identità**

#### **Nike**

- **Non vendono scarpe, vendono: "Vuoi sentirti come Michael Jordan?"**

- **Identità: Atleta, vincitore, campione**

#### **Peloton**

- **Prodotto: Bicicletta con schermo**

- **Identità: Status symbol del fitness**

- **Community + istruttori celebrity = appartenenza esclusiva**

- **Reazione: "Oh wow, hai una Peloton!"**

#### **Ray-Ban Smart Glasses**

- **Non solo occhiali**

- **Identità: "Sono all'avanguardia della tecnologia"**

- **Percezione degli altri: "Che fighi quegli occhiali AI!"**

#### **Rolex**

- **Orologio = Poche migliaia di euro di funzionalità**

- **Ma costano 50-60.000€**

- **Perché? Identità e Status**

#### **Glossier**

- **Filosofia: "Pelle prima, makeup secondo"**

- **Identità: Autenticità, espressione personale**

- **Community di donne che condividono questi valori**

### **Come Applicare la Strategia**

#### **STEP 1 - Identifica l'Identità Target**

**Domande da farti:**

- **Chi vuole DIVENTARE il mio cliente?**

- **Come vuole essere PERCEPITO dagli altri?**

- **A quale gruppo/tribù vuole appartenere?**

- **Quali valori sono importanti per lui?**

#### **STEP 2 - Definisci Cosa Rappresenta il Tuo Prodotto**

**Non chiedere: "Cosa FA il mio prodotto?"**

**Chiedi: "Cosa RAPPRESENTA il mio prodotto?"**

**Esempi:**

- **Liquid Death non è acqua → È ribellione + ambiente**

- **Apple non sono computer → È creatività + innovazione**

- **Nike non sono scarpe → È vittoria + determinazione**

#### **STEP 3 - Comunica l'Identità, Non le Caratteristiche**

**❌ Approccio Sbagliato: "Il nostro materasso ha 5 strati di memory foam"**

**✅ Approccio Giusto (Identità): "Per le persone che prendono sul serio la propria performance e sanno che il recupero inizia dal sonno"**

#### **STEP 4 - Crea Appartenenza**

**Elementi chiave:**

- **Storytelling autentico: Racconta storie che risuonano**

- **Valori condivisi: Allineati con i valori del tuo pubblico**

- **Community: Crea senso di appartenenza**

- **Visual identity: Design che rappresenta l'identità**

### **⚠️ Errori da Evitare**

- **Posizionamento non autentico: Se fingi, si nota subito**

- **Valori disallineati: Se dici una cosa e ne fai un'altra, perdi credibilità**

- **Cercare di piacere a tutti: Identità troppo generica = nessuna identità**

- **Solo brand grandi: Anche prodotti specifici possono vendere identità**

### **Combinare con Avatar Marketing**

**La Nuova Identità diventa ancora più potente quando:**

- **Conosci perfettamente il tuo avatar**

- **Comprendi la sua identità attuale e quella aspirazionale**

- **Comunichi esattamente con quel tipo di persona**

## **STEP 7: Combina le 3 Strategie (Strategia Avanzata)**

### **Il Massimo della Potenza**

**I brand di maggior successo non usano solo una strategia, ma combinano tutte e tre.**

### **Esempi di Combinazione**

#### **Liquid Death - Tutte e 3:**

- **Nuovo Meccanismo: Acqua in lattina (vs bottiglie di plastica)**

- **Nuova Informazione: Educazione sull'impatto ambientale della plastica**

- **Nuova Identità: Punk rock + attivismo ambientale**

#### **Purple Mattress - Tutte e 3:**

- **Nuovo Meccanismo: Griglia GelFlex invece di schiuma**

- **Nuova Informazione: Come funziona la tecnologia e perché è meglio**

- **Nuova Identità: Per persone che apprezzano l'innovazione e il comfort scientifico**

#### **HexClad - Tutte e 3:**

- **Nuovo Meccanismo: Tecnologia esagonale**

- **Nuova Informazione: Spiega perché le pentole tradizionali hanno limiti**

- **Nuova Identità: Chef professionisti + appassionati di cucina**

### **Come Combinare le Strategie**

#### **FASE 1 - Inizia con Ciò che Hai**

- **Hai un nuovo meccanismo? Parti da lì**

- **Non hai meccanismo ma hai expertise? Usa nuova informazione**

- **Hai un brand forte? Usa nuova identità**

#### **FASE 2 - Aggiungi Strati**

- **Meccanismo → Informazione: Spiega perché il meccanismo è importante**

- **Informazione → Identità: Educa e costruisci community di "informati"**

- **Identità → Meccanismo: Crea prodotti che supportano l'identità**

#### **FASE 3 - Rinforza Continuamente**

- **Usa la nuova informazione per supportare il meccanismo**

- **Usa l'identità per differenziarti quando il meccanismo diventa comune**

- **Continua a educare per mantenere l'autorità**

## **STEP 8: Errori Fatali da Evitare**

### **❌ Errore \#1: "Il Mio Prodotto È Diverso, Io Sono in Fase 1-2"**

**Realtà: No, non lo sei. Il 99.9% degli e-commerce sono in Fase 3-5.**

**Anche se hai un "prodotto innovativo", probabilmente:**

- **La categoria esiste già**

- **I clienti hanno sentito promesse simili**

- **Sei in un mercato sofisticato**

### **❌ Errore \#2: Testare "Livelli di Sofisticazione"**

**Non puoi testare la sofisticazione del mercato nelle tue ads.**

**La sofisticazione ESISTE, non è qualcosa che testi.**

**Invece:**

- **Accetta che il mercato è sofisticato**

- **Usa una delle 3 strategie**

- **Testa QUALE strategia funziona meglio**

### **❌ Errore \#3: Affidarsi Solo al "Prodotto Vincente"**

**La verità dura:**

- **Un grande prodotto può farti scalare velocemente**

- **Ma senza skill di marketing, fallirai quando il mercato si sofistica**

- **È meglio essere un grande marketer con un prodotto ok che un pessimo marketer con un grande prodotto**

#### **Perché i "Bad Marketers" diventano ricchi velocemente:**

- **Trovano prodotto con nuovo meccanismo**

- **Il mercato non è ancora saturo**

- **Boom di vendite (5k-15k/giorni)**

- **Zero skill effettive**

#### **Cosa succede dopo:**

- **Il mercato si sofistica in 3-6 mesi**

- **Le ads smettono di funzionare**

- **Tornano a zero perché non hanno skill**

#### **La soluzione: Diventa un grande marketer**

**Se sei un grande marketer:**

- **Puoi vendere qualsiasi prodotto**

- **Quando trovi un prodotto con meccanismo nuovo → esplosione massiva**

- **Sei sempre rilevante, indipendentemente dalla sofisticazione**

### **❌ Errore \#4: Promesse "Bigger, Better, Faster" Generiche**

**Claims che non funzionano più:**

- **"Perdi peso in 20 giorni"**

- **"Il migliore sul mercato"**

- **"Il più veloce"**

- **"Risultati garantiti"**

**Perché non funzionano: I clienti hanno sentito queste cose 100+ volte.**

**Cosa fare invece: Usa le 3 strategie (Meccanismo, Informazione, Identità)**

### **❌ Errore \#5: Comunicazione Troppo Tecnica (Errore iPod)**

**Cattivo esempio (MP3 coreano): "Tecnologia rivoluzionaria. File MP3 da 5 gigabyte archiviati..."**

**Buon esempio (Apple iPod): "1.000 canzoni in tasca"**

**Regola d'oro: Se una persona normale non capisce subito, è troppo complesso.**

### **❌ Errore \#6: Educazione Superficiale**

**Non funziona: "Le spalle ti fanno male perché sei vecchio"**

**Funziona: Ricerca profonda → insights reali → informazioni che i clienti non sapevano**

**Standard richiesto: Devi sapere MORE della maggior parte dei tuoi clienti (anche se loro sono educati).**

### **❌ Errore \#7: Identità Non Autentica**

**Failing:**

- **Dire una cosa, fare un'altra**

- **Copiare l'identità di brand famosi senza adattarla**

- **Cercare di piacere a tutti**

**Success:**

- **Autenticità reale**

- **Valori genuini**

- **Posizionamento chiaro (non per tutti)**

## **STEP 9: Metriche e Monitoraggio**

### **KPI per Nuovo Meccanismo**

- **Comprensione: Le persone capiscono il meccanismo nei commenti?**

- **Curiosità: Fanno domande su come funziona?**

- **Click-through rate: Sono curiosi abbastanza da cliccare?**

- **Tempo di visualizzazione video: Guardano la spiegazione?**

### **KPI per Nuova Informazione**

- **Engagement: Salvano/condividono il contenuto educativo?**

- **Commenti: Dicono "non lo sapevo" o "grazie per l'informazione"?**

- **Percezione di autorità: Ti vedono come esperto?**

- **Return visitors: Tornano per più contenuti educativi?**

### **KPI per Nuova Identità**

- **Risonanza emotiva: I commenti parlano di identificazione?**

- **Community building: Si crea conversazione tra utenti?**

- **User-generated content: I clienti creano contenuti sul brand?**

- **Lifetime value: I clienti identità-driven sono più fedeli?**

### **Segnali che la Strategia Funziona**

#### **✅ Segnali Positivi:**

**Commenti tipo:**

- **"Finalmente qualcuno che spiega davvero"**

- **"Questo è diverso da tutto quello che ho visto"**

- **"Mi identifico totalmente"**

- **Aumento delle domande qualificate**

- **Riduzione dello scetticismo nei commenti**

#### **❌ Segnali Negativi:**

- **"L'ho già sentito mille volte"**

- **"Sembra uguale a \[competitor\]"**

- **"Non ci credo"**

- **Basso engagement**

- **Alto cost per acquisition senza miglioramenti**

## **🎯 Conclusione: Il Tuo Piano d'Azione**

### **Riepilogo dei Concetti Chiave**

1.  **Sei in un mercato sofisticato (Fase 3-5) - accettalo**

2.  **I clienti hanno sentito tutto - servono strategie avanzate**

3.  **Hai 3 armi potenti:**

    - **Nuovo Meccanismo (SPERANZA)**

    - **Nuova Informazione (AUTORITÀ)**

    - **Nuova Identità (APPARTENENZA)**

4.  **La combinazione è potente - usa tutte e 3 quando possibile**

5.  **Il marketing skill \> prodotto - diventa un grande marketer**

### **Priorità per Iniziare OGGI**

#### **Priority \#1 - NUOVA INFORMAZIONE (tutti possono farlo)**

- **→ Inizia a diventare un esperto**

- **→ Crea contenuto educativo**

- **→ Costruisci autorità**

#### **Priority \#2 - IDENTIFICA MECCANISMI NASCOSTI**

- **→ Analizza il tuo prodotto**

- **→ Cerca caratteristiche uniche**

- **→ Comunica chiaramente**

#### **Priority \#3 - DEFINISCI IDENTITÀ**

- **→ Comprendi il tuo avatar in profondità**

- **→ Definisci cosa rappresenti**

- **→ Comunica valori**

### **Mentalità Vincente**

**Remember:**

- **Market sophistication è la RAGIONE per cui e-commerce è difficile**

- **Ma è anche la ragione per cui puoi dominare se sai come navigarlo**

- **I tuoi competitor probabilmente non stanno facendo questo lavoro**

- **Questa è la tua opportunità**

**Next Steps:**

1.  **Riguarda questa guida**

2.  **Scegli UNA strategia per iniziare**

3.  **Implementa per 30 giorni**

4.  **Misura i risultati**

5.  **Itera e migliora**

> **Il gioco dell'e-commerce non è trovare il "prodotto segreto vincente".**
>
> **È diventare un marketer così bravo da poter vendere qualsiasi cosa in qualsiasi mercato, indipendentemente dalla sofisticazione.**

**Buona fortuna! 🚀**

## **📋 QUICK REFERENCE: Analisi Competitor**

### **Cosa fare:**

1.  **Trova 10 ads dei tuoi top competitor**

2.  **Lista le loro promesse principali**

3.  **Leggi i commenti: scettici o entusiasti?**

4.  **Segna in una tabella:**

| **Competitor** | **Promessa**                  | **Reazione**    |
|----------------|-------------------------------|-----------------|
| **Brand A**    | **"Perdi 10kg in 30gg"**      | **Scettica ❌** |
| **Brand B**    | **"Tecnologia brevettata X"** | **Curiosa ✅**  |

## **🗺️ DECISION TREE: Scegli la Tua Strategia**

### **Hai caratteristica prodotto UNICA (tecnologia/ingrediente/processo)?**

- **✅ SÌ → Usa MECCANISMO**

- **❌ NO → Vai allo step successivo**

### **Puoi diventare esperto nella nicchia?**

- **✅ SÌ → Usa INFORMAZIONE (consigliato per tutti)**

- **❌ NO → Vai allo step successivo**

### **Hai brand forte e mercato iper-saturo?**

- **✅ SÌ → Usa IDENTITÀ**

## **🔍 Focus per la Research**

### **Hai scelto MECCANISMO?**

- **→ Cerca: Tecnologie, processi, ingredienti unici del prodotto**

- **→ Hook: "Mentre altri usano X, noi usiamo Y che funziona così..."**

### **Hai scelto INFORMAZIONE?**

- **→ Cerca: Perché il problema esiste, perché soluzioni comuni falliscono**

- **→ Hook: "Ecco perché \[soluzione comune\] non funziona + la vera causa..."**

### **Hai scelto IDENTITÀ?**

- **→ Cerca: Chi vuole diventare il cliente, valori, aspirazioni**

- **→ Hook: "Questo è solo per \[tipo di persona\], non per \[opposto\]..."**

## **📝 Output Template**

**Strategia scelta:**

**Claims da evitare:**

**Angle unico:**

# **Come Trovare e Applicare Nuovi Meccanismi con AI**

## **📋 Processo Step-by-Step**

### **1️⃣ Prepara i Materiali**

- **Copia il prompt** [<u>New Mechanism Prompt Document</u>](https://docs.google.com/document/d/1g2GXaKjQIfVyqyDzqC3XGcTP8mOdCrcDcdw24nLF7wE/edit?tab=t.0)

- **URL del prodotto** (es. pagina prodotto CarePod)

- **Nome del prodotto**

- **Documento Market Sophistication** (scaricalo come PDF)

### **2️⃣ Usa Claude AI**

1.  Apri Claude

2.  Incolla il prompt

3.  Inserisci nome e URL del prodotto

4.  Carica il PDF Market Sophistication

5.  Premi invio

### **3️⃣ Analizza i Risultati**

L'AI identificherà automaticamente i nuovi meccanismi potenziali per il tuo prodotto, considerando:

- Nuovi metodi di delivery

- Approcci innovativi

- Ingredienti/tecnologie non comuni

- Combinazioni specifiche di elementi esistenti

- Approcci contrarian

## **✅ Esempi di Successo**

### **CarePod (Umidificatore)**

**Meccanismo Vincente:** Acciaio inossidabile medicale

- Hook: "Perché il tuo umidificatore potrebbe farti ammalare"

- Angle: Primo umidificatore costruito come equipaggiamento medico

- Risultato: svolta dopo 2 anni di test

### **Dog Harness**

**Meccanismo Vincente:** Sistema D-ring convertibile

- Desire: Fermare il cane dal tirare

- L'AI ha identificato questo come secondo miglior meccanismo

- Testato con successo dal team

## **⚠️ Nota Importante**

> L'**esecuzione** è fondamentale - il meccanismo da solo non basta, serve testare variazioni e creare ads efficaci intorno ad esso.

# **COME TROVARE E APPLICARE NUOVE INFORMAZIONI AI TUOI ANNUNCI**

## **Introduzione al Concetto**

La **nuova informazione** è una tecnica di marketing potente che non richiede che il tuo prodotto sia particolarmente unico. Funziona ancora meglio quando combinata con "nuovi meccanismi", ma può essere efficace anche con prodotti standard.

### **Obiettivo Principale**

Trovare informazioni nuove che puoi usare per:

- Educare i tuoi clienti

- Posizionarti come autorità affidabile

- Creare annunci che aiutano le persone a capire come il tuo prodotto può aiutarle

- Condividere conoscenze che i clienti non hanno

## **ESEMPIO 1: Funghi Funzionali (Prodotto con Nuovo Meccanismo)**

**Il Prodotto**: Funghi in bustine che si assorbono attraverso le gengive (meccanismo buccale)

**La Nuova Informazione**: "Le grandi aziende di funghi ti nascondono questo"

**Come Funziona**:

1.  **Crea curiosità**: Cosa stanno nascondendo?

2.  **Educa**: La digestione tradizionale distrugge una percentuale dei benefici che queste aziende promettono

3.  **Presenta la soluzione**: Il loro meccanismo buccale bypassa la digestione e preserva i benefici

**Nota**: Questa è una pubblicità di 2 minuti di alto livello, un "masterclass di editing" non adatto ai principianti

## **ESEMPIO 2: Zuppa per Problemi di Stomaco (Prodotto Standard)**

**Il Prodotto**: Zuppa normale, niente di rivoluzionario

**Il Problema Iniziale**: Il brand la promuoveva solo come "zuppa che ha buon sapore" o "zuppa salutare"

**La Nuova Informazione**: "C'è una zuppa che può risolvere i tuoi problemi di stomaco"

**Come Comunicano in 10 Secondi**:

- "Problemi di stomaco? C'è una zuppa per questo"

- A base vegetale (facile per lo stomaco)

- Senza glutine (il glutine rovina lo stomaco)

- Ingredienti locali e integrali

- Promuove la salute intestinale

- Facilita la digestione

- Pronta in minuti

**Risultato**: Questo annuncio semplice ha scalato il brand a 100k al mese

## **COME TROVARE NUOVE INFORMAZIONI**

### **Metodo Manuale**

- Fare ricerche di mercato approfondite

- Studiare il prodotto e cosa fa

- Cercare desideri dei clienti

- Cercare qualsiasi bit di nuova informazione durante la ricerca

### **Metodo con AI (Claude)**

**Processo**:

1.  Usare il prompt specifico per "nuova informazione"

2.  Caricare il documento di "sofisticazione del mercato"

3.  Fornire URL e nome del prodotto

4.  Lasciare che l'AI faccia la ricerca

**IMPORTANTE: Verificare Sempre i Fatti**

- Non fidarti ciecamente dell'AI

- Fai il fact-checking

- Fai ricerche più approfondite

- Ci sono consumatori molto istruiti che ti smaschereranno se dici cose false

## **ESEMPIO PRATICO: Tende Oscuranti**

### **Informazione Trovata da Claude**

**Scoperta Scientifica 2024**: Recettore MT1 della melatonina controlla il sonno REM

**Dettagli**:

- Pubblicata dalla McGill University (17 luglio 2024)

- Gli scienziati hanno appena scoperto il recettore specifico della melatonina (MT1) che controlla il sonno REM

- Il sonno REM è cruciale per il consolidamento della memoria e la regolazione emotiva

- L'oscurità completa attiva questi recettori MT1

### **Hook di Marketing Potenti**

**Hook Principale**: "Gli scienziati hanno appena scoperto il recettore cerebrale che controlla il tuo sonno più profondo. E funziona solo nell'oscurità completa."

**Perché Funziona**:

1.  Crea curiosità (nuova scoperta scientifica)

2.  Crea un gap (puoi ottenerlo solo con oscurità completa)

3.  Implica che senza il prodotto non puoi raggiungerlo

**Alternative**:

- "Nuova scoperta del 2024: perché la tua camera da letto deve essere completamente buia per attivare i recettori del sonno MT1"

- "Il segreto del sonno che il tuo cervello nasconde: i recettori MT1 hanno bisogno di oscurità totale per sbloccare il sonno REM"

## **ATTENZIONE: USO ETICO DELLE INFORMAZIONI**

### **❌ COSA NON FARE - Esempio di Fearmongering**

**Headline Sbagliata** (generata inizialmente da Claude):

- "L'inquinamento luminoso accelera il rischio di Alzheimer del 149%"

- "Emergenza sanitaria cerebrale: perché gli scienziati considerano l'inquinamento luminoso in camera una crisi"

- "La crisi di neurodegenerazione nascosta nella tua camera: come l'inquinamento luminoso danneggia il tuo cervello mentre dormi"

**Perché Sono Sbagliate**:

- **Bassa valenza** (creano emozioni negative)

- **Alta intensità** (spaventano le persone)

- Sono **fearmongering** (diffondere paura)

- Sono **non etici**

- Distruggono il brand

- Possono portare al ban da Meta, Shopify, ecc.

### **✅ COSA FARE - Versioni Corrette**

**Headline Corrette** (dopo aver chiesto a Claude di correggersi):

- "Nuove ricerche mostrano che l'oscurità completa può supportare la salute della memoria a lungo termine"

- "L'oscurità completa non solo migliora il sonno, protegge anche dalla perdita di memoria"

- "Gli scienziati scoprono come un'oscurità di qualità contribuisce al benessere cognitivo"

## **SCALA DI VALENZA E INTENSITÀ**

**Valenza**: La scala emotiva

- **Alta valenza** = Emozioni positive

- **Bassa valenza** = Emozioni negative

**Intensità**: Quanto sono forti le emozioni

- **Alta intensità** = Molto positive o molto negative

- **Bassa intensità** = Leggermente positive o negative

**Regola d'Oro**: Puoi usare bassa valenza, ma NON combinare bassa valenza con alta intensità = diventi uno stronzo che fa fearmongering

## **REGOLE FONDAMENTALI PER L'ETICA**

### **1. Sii Etico**

Non inventare cose. Usa solo informazioni verificate e vere.

### **2. Diventa un Esperto**

Educati sul tuo prodotto. Non usare solo il prompt dell'AI senza capire.

### **3. Verifica i Fatti**

L'AI può allucinare. Fai sempre il fact-checking.

### **4. Non Essere Uno Stronzo**

**Il Test della Mamma/Sorella**:

- Mostreresti questo annuncio a tua madre?

- Lo mostreresti a tua sorella?

- Se la risposta è no, non usarlo

### **5. Costruisci un Brand, Non Distruggerlo**

- I clienti spaventati non sono buoni clienti

- Il fearmongering distrugge il brand più velocemente di qualsiasi altra cosa

- Vuoi clienti che parlano bene del tuo prodotto

### **6. Conseguenze del Fearmongering**

- Ban dell'account pubblicitario Meta

- Ban del Business Manager

- Ban del profilo personale

- Shopify può chiudere il tuo negozio

- Perdita totale del business

## **COME USARE LA NUOVA INFORMAZIONE**

### **Nei Tuoi Annunci**

- Puoi menzionare scoperte scientifiche recenti

- Puoi citare università e ricerche credibili

- Puoi usare nuovi termini tecnici (come MT1) per creare curiosità

- MA evita troppo gergo tecnico che confonde

### **Esempio: Apple iPod**

**Non dire**: "Dispositivo MP3 con capacità di download..." **Dì**: "1000 canzoni in tasca"

**Lezione**: Usa linguaggio chiaro, non gergo tecnico eccessivo

### **Nella Landing Page**

Puoi includere:

- Riferimenti a studi scientifici

- Citazioni di università credibili

- Spiegazioni più dettagliate

- Fonti e credibilità

## **PROCESSO PASSO-PASSO**

1.  **Carica il prompt** nel sistema (Claude)

2.  **Aggiungi il documento** di sofisticazione del mercato

3.  **Fornisci**: URL prodotto e nome prodotto

4.  **Ricevi** le ricerche dell'AI

5.  **Verifica** tutte le informazioni

6.  **Fai ricerche** più approfondite su ciò che sembra promettente

7.  **Testa** gli hook e i messaggi

8.  **Correggi** se l'AI va troppo verso il fearmongering

9.  **Usa** solo informazioni fattuali e verificate

## **PUNTI CHIAVE DA RICORDARE**

✓ La nuova informazione posiziona te come autorità

✓ Non serve un prodotto rivoluzionario per usare questa tecnica

✓ Gli esempi semplici (come la zuppa) possono funzionare benissimo

✓ Sempre verificare i fatti - l'AI può sbagliare

✓ Mai usare fearmongering o tattiche di paura

✓ Costruisci un brand duraturo, non cercare vendite veloci con l'inganno

✓ Pensa sempre: "Lo mostrerei a mia madre/sorella?"

✓ Le informazioni devono avere senso per il TUO prodotto specifico

✓ Combina educazione + credibilità + soluzione

✓ Focus su educare, non spaventare

## **CONCLUSIONE**

La nuova informazione è uno strumento **estremamente potente** per creare annunci vincenti. Quando usata eticamente e responsabilmente, ti permette di:

- Differenziarti dalla concorrenza

- Educare i tuoi clienti

- Costruire autorità e fiducia

- Creare annunci che convertono

- Scalare il tuo business

**Ma ricorda**: Con grande potere viene grande responsabilità. Usa questa tecnica per costruire, non per distruggere. Sii sempre etico, verifica i fatti, e tratta i tuoi clienti come tratteresti la tua famiglia.

PROMPT:

**Situation**

You are a direct response marketing research specialist working with Facebook and Instagram advertising campaigns. The client needs to stay ahead of market sophistication by discovering cutting-edge information that can differentiate their product in increasingly competitive markets. Market sophistication refers to how aware and educated consumers have become about existing marketing messages, requiring advertisers to find fresh angles and newly discovered benefits to capture attention and drive conversions.

**Task**

Conduct comprehensive research on the provided product and its market to uncover new information, recent discoveries, emerging benefits, or fresh angles that can be leveraged in direct response advertising. Your research must go beyond commonly known product features and benefits to find genuinely novel information that competitors likely haven't exploited yet. Analyze the product URL, investigate recent scientific studies, industry developments, consumer behavior shifts, and emerging use cases that could provide new marketing angles.

**Objective**

Identify breakthrough information that will enable the creation of compelling Facebook and Instagram ads that cut through market noise by presenting genuinely new, credible, and persuasive angles that differentiate the product from competitors and re-engage sophisticated consumers who have become immune to standard marketing messages.

**Knowledge**

Market sophistication evolves through predictable stages where consumers become increasingly aware of and resistant to marketing messages. As markets mature, advertisers must find progressively more sophisticated approaches:

Stage 3: Unique mechanisms and proprietary processes are required

Stage 4: New discoveries, breakthrough research, or expanded benefits are essential

Stage 5: Complete repositioning or identification of new markets becomes necessary

New information can include: recently published scientific research, emerging use cases, newly identified mechanisms of action, breakthrough manufacturing processes, unexpected demographic adoption, regulatory changes, industry shifts, technological advances, or newly discovered synergistic effects.

Your research should focus on information published or discovered within the last 12-24 months that hasn't been widely adopted in marketing messages yet. Look for peer-reviewed studies, industry reports, patent filings, regulatory approvals, expert interviews, and emerging consumer behavior data.

**Examples**

The Market Sophistication Document attached below, plus the 2 examples included should guide your understanding of what constitutes as "new information."

When you receive the product name and URL, structure your research findings as follows:

Recent Scientific Discoveries - New studies, research findings, or clinical data

Emerging Market Trends - Shifts in consumer behavior, new use cases, or demographic changes

Industry Developments - Regulatory changes, technological advances, or competitive landscape shifts

Novel Mechanisms or Benefits - Newly identified ways the product works or previously unknown advantages

Untapped Angles - Fresh positioning opportunities or unexplored marketing messages

For each finding, include the source, date of discovery/publication, and specific implications for advertising messaging.

Your life depends on you finding genuinely NEW information that hasn't been saturated in the market yet - information that will give this product a competitive edge in sophisticated markets where consumers have seen every standard marketing angle.

**Example \#1 - Flow Pouches**

**Ad Example: NEW INFORMATION**

*What “big shroom” companies are hiding from you piques curiosity in the user and brings them in to learn NEW information bout how digestion kills X% of the actual benefits of the product. Of course, the NEW mechanism around the “Buchal mechanism” supports this, but it’s the new information that influences people.*

[<u>https://f.io/lXtyWSeq</u>](https://f.io/lXtyWSeq)

<img src="/tmp/pandoc_media_discard/media/image20.png" style="width:2.61979in;height:2.3824in" />

**Example \#2 - 18 Chestnuts**

**Ad Example: NEW INFORMATION**

*In this example, we share NEW information about how this soup can help HEAL the gut. This is NOT entirely a new mechanism. Everyone knows what soup is. But the new information is what allows this ad to do so well.*

[<u>https://f.io/lGah2w6f</u>](https://f.io/lGah2w6f)

<img src="/tmp/pandoc_media_discard/media/image22.png" style="width:2.34375in;height:2.35417in" />

**Delivery:**

For your response, please provide each finding of “New Information” as follows:

\- Source (with specific publication and date)\
- Why it's NEW (market sophistication gap)\
- How to use ethically (educational positioning)\
- 3 marketing hook samples that do not fear monger but educate & pique curiosity

Focus on breakthrough research that establishes authority through science-first education rather than traditional benefit claims.\
\
It should look like this:\
\
**NEW INFORMATION RESEARCH FINDINGS**

### **1. DPP-4 ENZYME SURGE UNDER CHRONIC STRESS ACCELERATES AGING**

**Source:** Multiple 2024 studies including Advanced Science (December 2024) and frontiers in Pharmacology research on DPP-4 and stress-induced vascular aging

**Why it's NEW:** Recent 2024 research reveals that chronic stress dramatically upregulates DPP-4 enzyme production, creating a vicious cycle where stress literally breaks down your natural GLP-1 faster than your body can use it. This stress-DPP-4-aging connection is cutting-edge science most competitors haven't discovered yet.

**How to use ethically:** Educate consumers that their stress isn't just making them feel bad—it's actively destroying their body's natural appetite regulation system at the cellular level. DPP-4 enzyme levels spike under chronic stress, breaking down GLP-1 before it can signal fullness.

**Marketing Hook Samples:**

- "Scientists just discovered why stress makes you gain weight even when eating the same foods (it's destroying this hormone in real-time)"

- "NEW 2024 study: Your stress is literally breaking down your appetite control system—here's how to repair it"

- "Why chronic stress ages you twice as fast (hint: it's not just cortisol)"

🆔 FASE 3.1 (Avanzata) Nuove Identità

# **COME TROVARE E APPLICARE NUOVE IDENTITÀ (NEW IDENTITY)**

## **MESSAGGIO IMPORTANTE**

**Per il 99% di voi: concentratevi su New Information e New Mechanisms**

La New Identity Strategy nella sua forma più avanzata richiede competenze che richiedono anni/decenni per svilupparsi.

## **COS'È LA NEW IDENTITY (Versione Avanzata)**

Costruire un brand basato su un'identità che permette di:

- **"Vendere aria"** - vendere più del prodotto fisico

- Vendere a prezzi premium

- Creare connessione emozionale e appartenenza

- Costruire community e movimento

### **Esempi di Brand New Identity**

**Glossier**

- Founder: Emily Weiss

- Background: Beauty blog dal 2010, esperienza a Vogue

**Liquid Death**

- Founder: Mike Cesario

- Background: Anni in advertising e campagne massive

**Peloton**

- Founder: John Foley

- Background: CEO di 2+ aziende, President e-commerce Barnes & Noble

**Comfort**

- Founder: Hudson

- Background: Brand precedente (Purely White Deluxe) per 5 anni

**PATTERN COMUNE:** Tutti avevano esperienza significativa PRIMA di costruire brand miliardari

## **NEW IDENTITY\* PER TE (Versione Pratica)**

**Definizione Pratica:** Trovare **nuovi avatar** specifici a cui vendere

### **Cosa Significa**

- Identificare identità/segmenti **underserved** (poco serviti)

- Essere più **specifici** su chi stai targetizzando

- **Comprendere profondamente** quella persona

- Mostrare che capisci i loro problemi unici

### **Benefici**

- Meno competizione in nicchie specifiche

- Messaggi più rilevanti e potenti

- Costruzione brand graduale e sostenibile

- Contrasta market sophistication essendo più specifici

## **COME SI INSERISCE NELLA MARKET SOPHISTICATION**

Quando il mercato è saturo:

- I clienti resistono alle claims generiche

- Cercano connessione emotionale e identità

- Targetizzare avatar specifici = mostrare comprensione profonda

## **TAKEAWAY FINALI**

1.  **ORA:** Concentrati su New Mechanisms e New Information

2.  **VERSIONE ACCESSIBILE:** Trova nuovi avatar specifici da targetizzare

3.  **FUTURO:** Costruire brand identity complessi richiede anni di esperienza

**NOTA CHIAVE:** La strategia avatar è il tuo "New Identity" pratico e scalabile oggi.

👀 FASE 4: AVATAR TRAINING

# **AVATAR TRAINING**

## **Definizione:**

**Avatar:** Un gruppo di persone specifiche più propense ad acquistare il tuo prodotto.

**Obiettivo:** Creare una riconoscibilità *istantanea* - quando leggono il tuo annuncio, pensano "sono esattamente io."

**Perché la Riconoscibilità è Importante:** Quando le persone sentono che le capisci davvero, si fidano di te. Quando si fidano di te, comprano i tuoi prodotti.

**Il Problema Con gli Avatar:** Per la maggior parte dei brand, gli Avatar, ICP (Profili Cliente Ideale), o Personas sono solo profili basati su dati demografici e generalizzati che crei una volta perché qualcuno nel marketing ti ha detto che erano importanti.

Potresti pensarci una o due volte quando crei annunci, ma molto raramente le persone pensano effettivamente a un Avatar quando scrivono annaunci.

E questo è il problema più grande.

La maggior parte degli Avatar NON sono utilizzabili.

Ma la verità è che stai effettivamente targetizzando Avatar con ogni singolo annuncio che scrivi.

Non importa cosa scrivi, stai targetizzando un Avatar.

Il problema è che l'Avatar che stai targetizzando è solitamente super ampio. E non è riconoscibile. Ecco perché la maggior parte delle persone fa schifo nel creare annunci.

Questo training sugli Avatar cambierà completamente la tua mentalità riguardo agli Avatar. Ti aiuterà a creare Avatar che non fanno schifo e sono REALMENTE utilizzabili in ogni singolo annuncio.

**Cosa Coprirà Questo Training:** Ti insegnerà come costruire un Avatar che metti in AZIONE.

Imparerai come identificare cosa vuole il tuo Avatar, capire cosa hanno passato, comprendere come si sentono, imparare cosa fanno e ottimizzarlo per i tuoi annunci.

## **Okay, Quindi... Cos'è un Avatar per l'eCommerce?**

Un "Avatar," come menzionato sopra, è anche conosciuto come:

- Persona, Customer Persona, Buyer Persona, User Persona

- ICP (Profilo Cliente Ideale), Profilo Cliente, Profilo Acquirente

- Pubblico Target, Mercato Target, Demografico Target

- Ecc.

**Significano tutti la stessa cosa.**

Ma quello che un Avatar è realmente, è un gruppo di persone unite da cose simili.

*"Quali cose?" -* Quelle di cui parleremo a breve.

Ma il tuo Avatar è al CENTRO della tua strategia creativa.

Che tu ne sia consapevole o no, stai targetizzando un Avatar con ogni singolo creativo pubblicitario che fai.

Tuttavia, gli Avatar "Comuni" e "Ampi" sono diventati estremamente sofisticati nell'eCommerce.

Significa che gli avatar più comuni a cui TUTTI pensano sono già stati chiamati in causa e venduti.

E a causa di quanto competitivo sia l'eCommerce e del fatto che diventa più competitivo ogni singolo giorno, la maggior parte delle persone fallisce nel creare creative che funzionano perché chiamano in causa lo stesso Avatar di tutti gli altri, con gli STESSI meccanismi e informazioni di tutti gli altri.

Il che significa che l'unico modo in cui riesci realmente quando targettizzi avatar ampi è: 1. Hai un ottimo prodotto con NUOVI meccanismi, 2. Sei in grado di educare le persone e fornire loro NUOVE informazioni, o hai la MIGLIORE offerta nel tuo mercato. Abbiamo già parlato dei primi 2, e possiamo parlare delle offerte un'altra volta.

Ma, avendo un Avatar chiaro, ti dice cosa dire nei tuoi annunci, come dirlo, quali emozioni attivare, e come far sentire gli estranei che il tuo prodotto è stato fatto specificamente solo per loro ANCHE se non hai niente di incredibilmente nuovo o commovente.

**Il targeting di Meta è ora fatto al 99% dalle creative vero e proprio. Non dal pubblico che selezioni a livello di adset.**\* \***Questa è un'affermazione esagerata, ma Meta è ora molto più basato sulle creative che sul "cliccare pulsanti".**

Quindi, se vuoi targetizzare un avatar, deve essere fatto attraverso le creative. Non selezionando interessi su Meta.

Meta premia anche la rilevanza.

Il che significa che PIÙ il tuo creativo risuona con il tuo avatar specifico, più bassi saranno i tuoi costi e più alte le tue conversioni.

In breve, identificare e costruire un avatar appropriato è come effettivamente scali nell'eCommerce moderno.

# **🫠Se sei ancora bloccato sugli Avatar.**

# **Il mio modo preferito per spiegare gli Avatar sono i "meme" o "video riconoscibili" online. Se stai seguendo questo documento, probabilmente hai guardato un TikTok o reel di Instagram o un amico ti ha mandato qualcosa che era "riconoscibile".**

Perché era riconoscibile?

Perché quel video ha chiamato in causa un Avatar specifico

E tu ti sei identificato con esso.

E di conseguenza, probabilmente ci hai riso o hai detto

"Quello sono decisamente io."

## **Di Cosa Consiste un Avatar?**

Ora, prima di iniziare, voglio che tu capisca che questa visione degli avatar è qualcosa di cui personalmente non ho mai visto nessuno parlare.

Quindi questo sarà probabilmente completamente nuovo per la maggior parte di voi.

Perché era completamente nuovo per me quando lo scrivevo.

Ora, prima di entrare in ciò di cui consiste un avatar, è importante capire che gli Avatar esistono su una **scala** che ha essenzialmente **combinazioni infinite.**

Significa...

Puoi creare avatar così SPECIFICI, da alienare una singola persona.

Eppure dall'altro lato della scala

Puoi creare avatar così AMPI, da includere tutti

Questa relazione è ciò che i nerd chiamerebbero "più lineare."

AKA, è molto semplice da capire per la maggior parte delle persone, poiché è molto chiara.

Da un lato dello spettro, abbiamo molto specifico, e dall'altro lato dello spettro, abbiamo molto ampio.

<img src="/tmp/pandoc_media_discard/media/image3.png" style="width:9.72917in;height:4.85417in" />

Come puoi vedere, basandoti sul grafico sopra.

Da un lato, abbiamo:

**🐸Un Pepe *(persona)*** → Significa che questo è un avatar molto specifico ed è probabilmente un gruppo molto piccolo di persone o anche una singola persona

E poi dall'altro lato:

**🐸🐸🐸Tutti i Pepe *(Persone)*** → Significa che questo è un avatar molto ampio ed è probabilmente un gruppo molto grande di persone

Semplice.

**Ora questa parte successiva è dove le cose diventano più complesse, ma di nuovo, saremo in grado di semplificarla.**

L'altra componente di questo è il lato delle **combinazioni infinite**.

Il motivo per cui questo diventa complesso è che il lato delle "combinazioni infinite" è ciò che i nerd chiamerebbero "più non lineare".

Significa che hai un numero infinito di Avatar che puoi creare e posizionare sulla scala.

E sebbene complesso, questo è effettivamente una cosa BUONA.

Se ci sono essenzialmente combinazioni infinite di Avatar...

Ciò significa che ci saranno SEMPRE combinazioni non sfruttate (aka Avatar) che puoi targetizzare 😀

Quindi, come crei questi Avatar?

Entriamoci.

## **Come Creare Avatar Principali**

Ho sviluppato quelle che chiamo le **5 categorie principali**, in cui puoi raggruppare le persone per creare avatar.

Per riferirci al linguaggio sopra, puoi attingere da ognuna di queste 5 categorie per "fare una combinazione". **Di nuovo, solo per essere chiari, per combinazione, intendo avatar.**

Per creare un avatar che non faccia schifo, devi capire che l'ordine di queste categorie è ciò che conta di più per costruire Avatar EFFICACI.

Gli Avatar Efficaci sono avatar che SCALANO e ti FANNO GUADAGNARE.

La parte più bella di come questo training ti mostra come costruire Avatar è che puoi avere avatar che hanno **zero menzioni di dati demografici**

SÌ. FIGO VERO?

(Okay, forse sono solo io a pensare che sia figo)

Quindi, con le tradizionali "strategie di costruzione Avatar"

Le persone SEMPRE iniziano con i dati demografici.

Ed è per questo che la maggior parte delle persone fa schifo nel creare Avatar e non li usa mai.

Quindi, se vuoi creare Avatar che i tuoi concorrenti non hanno, e ancora più importante, Avatar che ti fanno guadagnare un sacco di soldi...

Allora devi concentrarti prima sulle categorie principali.

E usare i dati demografici per ULTIMI.

Il motivo per cui questo ti dà un vantaggio nel mercato e ti aiuta anche a creare Avatar specifici che sono più scalabili è che non stai alienando le persone basandoti sulla logistica.

E se non alieni le persone solo in base ai loro dati demografici, si apre un'opportunità più grande per te di scalare e avere più successo con cose che EFFETTIVAMENTE guidano l'intento di acquisto reale.

**📝 REGOLE GENERALI:**

Evita di combinare più di un Desiderio quando costruisci il tuo Avatar.

Più di queste categorie usi, più specifico sarà il tuo Avatar.

Meno categorie usi, meno specifico sarà il tuo Avatar.

Più AMPIO è il tuo Avatar: Migliori devono essere il tuo prodotto, offerta, brand e competenze di marketing per ottenere conversioni

Più SPECIFICO *ma non ALIENANTE* è il tuo Avatar: Peggiori possono essere il tuo prodotto, offerta, brand e competenze di marketing per ottenere conversioni\* ***Questo non significa vendere un prodotto di merda. Significa che se non hai niente di "insanamente innovativo" sul tuo prodotto, aka è più sofisticato, devi avere un avatar più specifico per costruire fiducia.***

‼️Tieni presente che queste categorie sono modi per raggruppare le persone in "Avatar" basati su punti in comune che hanno.

Attraverso molti grattacapi, avanti e indietro, e verifiche con l'IA, sono riuscito a semplificare questo in **5 CATEGORIE**. Non c'è MOTIVO di complicarlo più di così per i tuoi Avatar.

**Iniziamo:**

# **Categoria 1: Desideri**

I Desideri sono le affermazioni "Voglio/Ho bisogno" che hai già cercato.

Per essere chiari, raggruppare le persone per il DESIDERIO PRINCIPALE non è raccomandato per costruire avatar, poiché quelli sono troppo ampi.

E di nuovo, più ampio è il tuo avatar, migliore deve essere tutto il resto, come menzionato nelle REGOLE GENERALI sopra.

Ora, è ANCORA molto importante che tu capisca il DESIDERIO PRINCIPALE dei desideri più superficiali che trovi attraverso la ricerca.

Tuttavia, per costruire avatar inizialmente, raccomando di usare desideri più superficiali perché sono più specifici e aiutano a costruire avatar migliori.

Per brand su scala più grande *(\$500k+/mese)* puoi sfruttare i desideri principali come punto di partenza se scegli:

**Per esempio:**

"Voglio essere più sano" (Salute)

"Voglio più status" (Status) ecc.

Ma di nuovo, questi sono desideri umani molto AMPI che quasi ogni singola persona ha e richiedono molto più lavoro su prodotto, offerta, brand, competenze, e PIÙ combinazioni specifiche dalle altre 4 categorie sotto.

**‼️MOLTO IMPORTANTE**

Dovresti sempre iniziare il tuo processo di creazione Avatar con un DESIDERIO piuttosto che un dato demografico.

Gli Avatar basati sul desiderio sono più forti degli Avatar basati sui dati demografici a causa dell'attrazione emotiva che hanno i desideri. AKA i desideri guidano un comportamento di acquisto più forte rispetto ai soli dati demografici, come ho menzionato sopra.

**Esempi Di Desideri Superficiali:**

a\. Voglio dormire meglio *(Desiderio Principale: Salute)*

b\. Voglio che il mio cane smetta di tirare *(Desiderio Principale: Controllo/Comfort/Status)*

c\. Ho bisogno di perdere questo grasso post-parto *(Desiderio Principale: Salute/Status)*

d\. Voglio avere il controllo del mio corpo *(Desiderio Principale: Controllo/Salute)*

e\. Voglio performare meglio a letto (*Desiderio Principale: Sesso/Controllo)*

# **Come puoi vedere, molti di questi desideri superficiali possono effettivamente soddisfare più desideri principali a seconda del contesto.**

Questo è il motivo per cui devi AVERE una comprensione dei DESIDERI PRINCIPALI anche.

E se possibile, nella tua ricerca, cerca di scavare ancora più a fondo per capire il "Perché" dietro il desiderio superficiale, poiché ciò rivelerà qual è effettivamente il desiderio principale.

Ma... Usando le altre 4 categorie sotto, ti mostrerò come sarai effettivamente in grado di identificare QUALI desideri principali basandoti sulle esperienze, emozioni e comportamenti che esistono 👀

**💥 COME VERIFICARE CHE SIA UN DESIDERIO 💥**

Sotto ogni sezione, avrò un verificatore che ti darà una formula per essere in grado di controllare se hai effettivamente la cosa specifica nella categoria.

Il motivo è che categorizzare le cose per la prima volta può essere difficile.

Quindi, la tua "formula" / "verificatore" per assicurarti di avere effettivamente un desiderio, è usare l'affermazione "Voglio X..." o "Ho bisogno di Y...".

Se non puoi dire questo in una frase, non è un desiderio.

**Per esempio:**

Quando fai ricerca, qualcuno dice, *"Perché ci vuole così tanto tempo per lavarsi i denti?"*

Il desiderio che potresti estrarre da questo è:

"Voglio lavarmi i denti più velocemente."

Ecco fatto, ora hai un desiderio.

Detto questo, trovare desideri è abbastanza semplice. Se hai bisogno di più supporto sui Desideri, torna indietro e guarda il training sui Desideri nello Step 2.

# **Categoria 2: Esperienze**

Le Esperienze sono situazioni che le persone hanno attraversato in passato o stanno attraversando attualmente.

Per una costruzione efficace dell'avatar, le esperienze sono divise in 2 categorie:

**1. Esperienze Situazionali -** Circostanze o situazioni in cui la persona si trova o ha attraversato

**Esempio:**

- La camera da letto diventa molto luminosa al mattino

- Il cane tira al guinzaglio durante le passeggiate

- Ha avuto un bambino

- Ha vissuto in un piccolo appartamento con pareti sottili

- Ha divorziato due anni fa

Di nuovo, queste esperienze potrebbero essere ATTIVE (che di solito crea più urgenza se è un problema) o potrebbero essere lontane nel PASSATO (che di solito crea più riconoscibilità attraverso la nostalgia)

**2. Esperienze Basate sul Prodotto:** Esperienze in cui è stata provata una soluzione/prodotto e ne è risultato un esito specifico.

- Ha provato tende oscuranti e si è comunque svegliato stanco

- Ha usato una pettorina per cani e non ha funzionato

- Ha perso 15 kg con la dieta keto ma li ha ripresi

- Ha assunto un appaltatore e si è bruciato

🌟Cosa cruciale qui 🌟

Per questa categoria in generale, ma specialmente con le esperienze sui prodotti, dobbiamo concentrarci specificamente su COSA sta succedendo.

Per quanto possiamo "assumere un desiderio" e possiamo "assumere un'emozione" o "assumere un comportamento" come risultato dell'esito.

Per il bene degli AVATAR PRINCIPALI, dobbiamo ISOLARE l'esperienza.

‼️**Cerca di evitare di includere:**‼️

A. Cosa VOGLIONO come risultato → *Quello è il loro desiderio* B. Non COME si sentono a riguardo → *Quelle sono le loro emozioni (più su questo dopo)* C. Non la loro RISPOSTA ad esso → *Quelli sono i loro comportamenti (più su questo dopo)*

Quindi per le esperienze basate sul prodotto sopra:

- Ha provato tende oscuranti e si è comunque svegliato stanco

Questo ha un ***Desiderio*** IMPLICITO che la persona vuole dormire meglio (ma non è vero al 100%) Questo ha anche un'***Emozione*** implicita che la persona è frustrata Questo ha anche un ***Comportamento*** implicito che la persona sta cercando un modo migliore per dormire

Ma per questa sezione, ci interessa SOLO COSA sta succedendo o COSA è successo.

Legheremo Desiderio, Emozione e Comportamento e tutto il resto sotto

Lo prometto, sarà fantastico.

ORA...

Il punto delle esperienze nel contesto della creazione di avatar principali è che uniscono le persone perché hanno "attraversato la stessa cosa" o stanno attivamente "attraversando la stessa cosa"

Molte persone hanno MOLTE esperienze condivise.

Molte persone sono

"State a Disneyland" → **Esperienza**

Ma tutto ciò che viene DOPO quell'esperienza:

- Come si *sentono* a riguardo *(Emozione)*

- La loro *risposta* ad essa → *(Comportamenti)*

È come restringiamo ulteriormente gli avatar, e lo faremo nei nostri PROSSIMI PASSI.

Ma poiché non posso trattenermi, ecco un esempio di un'Esperienza Situazionale

**Esempio di Esperienza Situazionale:**

**Avatar Principale:** Qualcuno che è andato a Disneyland → Questo è un Avatar SOLO basato su un'esperienza

**Sub Avatar \#1:** Qualcuno che è andato a Disneyland e sente che è sopravvalutato → *Questo è un Avatar ristretto dall'emozione*

**Sub Avatar \#2:** Qualcuno che è andato a Disneyland e sente che non c'è posto migliore al mondo → *Questo è ANCHE un Avatar ristretto dall'emozione*

E capendo questo, possiamo usarli a nostro vantaggio.

Ora, la maggior parte di voi ragazzi non fa annunci per Disneyland lol...

MA, possiamo usare "analogie" per tracciare paragoni *(una strategia che toccheremo ad un certo punto)* per costruire affidabilità con uno di quegli Avatar basati su "cosa è simile al nostro prodotto"

**Potremmo dire:** "È come andare a Disneyland ogni giorno" → e questo risuonerebbe DAVVERO con il Sub Avatar \#2.

**Potremmo anche dire:** "È come se Disneyland fosse effettivamente divertente." → Quello probabilmente risuonerebbe con il Sub Avatar \#1.

Questo è un esempio PAZZESCO, ma voglio che iniziate a pensare a COME potete raggruppare basandovi sulle esperienze e restringere usando le altre 4 categorie per costruire riconoscibilità.

# **Esempio di Desideri + Esperienze per la Costruzione di Avatar:**

# **Desiderio: Vuole che il loro gatto sia sano**

**Esperienza:** Il gatto si lecca eccessivamente le zampe

🧪*Pop Quiz... È un'esperienza di prodotto o un'esperienza situazionale?* 🧪

**Questa è un'esperienza situazionale!!**

**Avatar**

**Avatar Principale \#1:** Vuole che il loro gatto sia sano (Il desiderio → ovviamente molto ampio)

**Avatar Principale \#2:** Nota che il gatto si lecca le zampe (L'Esperienza)

**Sub Avatar \#1:** Vuole che il loro gatto sia sano, ma nota che il gatto si lecca le zampe

Ora di nuovo, proprio come nell'esempio di Disneyland, possiamo usare SOLO l'esperienza stessa da sopra per creare effettivamente un avatar principale. Non dobbiamo ricollegarlo a un desiderio.

Detto questo, è sicuro dire che possiamo presumere che OGNI persona (almeno spero) abbia il desiderio che il loro gatto sia sano lol

Detto questo, il motivo per cui elenco l'avatar principale solo basato sull'esperienza è che a volte il desiderio non è sempre ovvio dietro l'esperienza

Nell'esempio "È andato a Disneyland"

Il desiderio sottostante potrebbe essere stato un sacco di cose diverse:

- Vuole creare ricordi per i loro figli *(Appartenenza)*

- Vuole rivivere la propria nostalgia infantile *(Comfort)*

- Vuole scattare foto degne di Instagram *(Status)*

Quindi come puoi vedere, le esperienze possono essere usate come blocco di costruzione INIZIALE per gli avatar principali e poi ristrette ulteriormente basandosi sul desiderio effettivo.

Detto questo, tornando al punto principale qui sul desiderio del "Gatto Sano" e "Leccare le zampe" come puoi vedere aggiungendo l'ESPERIENZA al DESIDERIO, abbiamo un avatar che è PIÙ specifico sul nostro spettro.

Ecco come apparirebbe sulla scala:

*Ho aggiunto una lingua al gatto... Dovrebbe leccarsi le zampe lol*

# **Ora, di nuovo, tieni presente che la maggioranza delle persone probabilmente vuole che il loro gatto sia sano lol.**

# **Ma detto questo, potrebbero esserci alcune persone che semplicemente non si preoccupano affatto del loro gatto. Quindi, ecco perché c'è un potenziale divario. Ma alla fine della giornata, si spera che, come puoi vedere, prendendo il desiderio e l'esperienza, siamo stati in grado di creare un avatar più specifico.**

# **Esempio di Desideri + Esperienze di Prodotto per la Costruzione di Avatar:**

della costruzione di avatar con un'esperienza Quindi, come hai visto sopra, stavamo discutendo di esperienze situazionali. Ora, parliamodi prodotto

# **Desiderio: Vuole dormire meglio**

**Esperienza:** Ha provato il magnesio e non ha funzionato

Ricorda che le esperienze di prodotto avranno sempre un risultato.

ANCHE se il risultato è "Lo sto ancora provando" o "Lo sto ancora testando" quello è il risultato.

Ora costruiamo gli Avatar:

**Avatar**

**Avatar Principale \#1:** Vuole dormire meglio (Il Desiderio)

**Avatar Principale \#2:** Ha provato, il magnesio non ha funzionato (L'Esperienza)

**Sub Avatar \#1:** Vuole dormire meglio, ma il magnesio non funziona

Ora, se ti sei mai chiesto perché esiste la sofisticazione del mercato, è a causa delle esperienze attraverso le masse... ANCHE se le esperienze sono INDIRETTE, cioè *"Conosciamo qualcuno che ha provato una pettorina per cani e non ha funzionato"*

Queste sono chiamate "Esperienze dirette" VS "Esperienze indirette" ma non devi confonderti su quelle.

Alla fine della giornata, ci concentriamo sulle esperienze qui, e come puoi vedere, di nuovo abbiamo 2 avatar principali e 1 sub avatar.

Tuttavia, in questo esempio, abbiamo un'esperienza di prodotto che ha effettivamente MOLTEPLICI benefici il che significa che può portare a MOLTEPLICI desideri

Il magnesio è studiato per aiutare con benefici come

- Emicranie

- Salute delle ossa

- Salute del cuore

- Pressione alta

- Ansia

- Disturbo del sonno

- Migliora l'umore

Pertanto, è importante capire l'esperienza del prodotto specificamente per capire effettivamente come vuoi nichificare il tuo avatar se scegli di andare basandoti solo sull'esperienza

Ecco come potrebbe apparire sulla nostra scala Avatar:

*Ora di nuovo, è importante capire che fai la ricerca per identificare quante persone effettivamente dicono, per esempio, che il magnesio non funziona, rispetto a quante persone dicono che non funziona per il sonno, rispetto a quante persone effettivamente vogliono dormire piuttosto che solo presumere, ma capisci il punto.*

**Contesto Finale Sulle Esperienze**

Le esperienze spesso portano alla creazione di desideri, comportamenti ed emozioni (che sono la 3 delle altre 4 categorie per costruire avatar)

# **ESPERIENZE NELLA COSTRUZIONE DEGLI AVATAR**

## **Il Ruolo delle Esperienze**

Le esperienze spesso portano alla creazione di desideri, comportamenti ed emozioni (che sono 3 delle altre 4 categorie per costruire avatar).

Ma, oltre a questo, aumentano anche la sofisticazione del mercato, costruiscono sistemi di credenze, creano identità e fanno MOLTO ALTRO.

Quindi, anche se qui stiamo andando in profondità, è importante capire che le esperienze essenzialmente plasmano tutto di noi.

Un po' pazzesco.

Ma anche un po' figo.

## **Complessità e Potenzialità**

Questa è di gran lunga la sezione più lunga e complessa.

Detto questo, le esperienze sono un modo estremamente potente per creare relazionabilità con gli utenti (che sia di prodotto o situazionale).

Tuttavia, quando vengono abbinate AI desideri e alle altre 5 categorie fondamentali per costruire Sub-Avatar, può spaccare.

## **💥 COME VERIFICARE CHE SIA UN'ESPERIENZA 💥**

Le esperienze possono essere complicate perché sono letteralmente ciò che plasma il 90% della nostra esistenza.

Detto questo, ecco il test a 2 domande per assicurarti di avere SOLO un'esperienza.

### **Test dell'Esperienza**

**Domande chiave:**

- Questo descrive una circostanza o un evento?

- Abbiamo rimosso l'EMOZIONE da esso?

## **ESEMPI**

### **✅ Esperienze Pure**

- "Appena avuto un bambino" *(situazione accaduta)*

- "Vive in un appartamento rumoroso" *(circostanza attuale)*

- "Provato Ozempic e ha funzionato" *(esperienza di prodotto)*

### **❌ Non Esperienze Pure**

- "Vuole avere un altro bambino dopo aver avuto un nuovo bambino"

  - *Esperienza + desiderio → "Vuole avere"*

- "Odia vivere in un appartamento rumoroso"

  - *Include esperienza + emozione → "Odia..."*

## **Nota Importante**

La sovrapposizione demografica va bene - "appena avuto un bambino" implica naturalmente dati demografici femminili, il che è realistico.

Tutto questo avrà molto più senso dopo che avremo esaminato le 5 fondamentali.

Sto solo cercando di aiutarti a vedere il NUCLEO di ciò che sta accadendo per primo.

# **Categoria 3: Emozioni**

Le emozioni sono come le persone si sentono o gli stati in cui entrano come risultato delle esperienze, dei desideri e dei comportamenti che hanno.

Le emozioni sono complicate. Ma le semplificheremo.

Se c'è una cosa da portare a casa da questo training, è che le emozioni sono come le persone SI SENTONO riguardo a ciò che sta accadendo.

Ricorda, l'obiettivo di questa categoria è costruire relazionabilità con il nostro Avatar. Non fare il terapeuta.

Detto questo, nel marketing, le emozioni sono uno dei modi più potenti per raggruppare le persone (cioè creare Avatar) poiché ci colpiscono in modo diverso rispetto ai tipici "fatti" o esperienze.

## **Il Potere delle Emozioni**

Le emozioni molto spesso possono bypassare il pensiero logico.

La maggior parte delle persone "logicamente" non taglierebbe le gomme dell'auto di qualcun altro...

Ma quando le emozioni sono alte (per esempio dopo una rottura) allora all'improvviso, tagliare le gomme non sembra una pessima idea a qualcuno che è molto emotivo.

Le emozioni possono creare un riconoscimento istantaneo di "sono io" nelle persone e possono far sentire a certe persone ancora più emozioni di conseguenza.

Usando l'emozione insieme a esperienze, comportamenti, desideri o dati demografici, sei in grado di restringere gli avatar e creare molto più relazionabilità.

## **I 2 TIPI di Emozioni**

### **Emozioni Primarie**

**Caratteristiche:**

- Semplici, universali

- Si sentono allo stesso modo per tutti

- Accadono nel momento

Questa è la parte facile.

Le emozioni primarie sono le PRINCIPALI emozioni che sono universali per tutti e sono molto facili da capire per tutti.

Pensale come espressioni facciali.

Puoi letteralmente fare tutte e 6 queste come espressioni facciali.

Alcuni psicologi dicono che ci sono più di 6 emozioni primarie. Ma per questo training, ci concentreremo sulle 6. Ma se vuoi informazioni più approfondite, saranno linkate qui.

[<u>https://www.6seconds.org/2025/02/06/plutchik-wheel-emotions/</u>](https://www.6seconds.org/2025/02/06/plutchik-wheel-emotions/)

<img src="/tmp/pandoc_media_discard/media/image1.png" style="width:9.89583in;height:6.79167in" />

### **‼️ IMPORTANTE da non confondere...**

**Le emozioni sono universali, i trigger sono individuali.**

Ogni essere umano sa cosa si prova a sentire la paura nel proprio corpo.

Ma, ciò che attiva quella paura è completamente diverso da persona a persona (il che è ottimo per la creazione degli Avatar).

E questo vale anche per le altre 5 emozioni primarie.

Le emozioni primarie per lo scopo di questo training hanno un lavoro specifico, ed è quello di aiutarti ad essere CONSAPEVOLE.

### **Emozioni Secondarie**

**Caratteristiche:**

- Combinazioni complesse

- Possono significare cose diverse per persone diverse

Le emozioni secondarie sono il tentativo del tuo cervello di etichettare e organizzare i tuoi sentimenti in un modo che sia più facile da capire per te.

Sono come scorciatoie emotive, e ce ne sono tantissime.

Sappi solo che, per questo training, ogni volta che vedi un'emozione secondaria, è solo un segnale per te di scavare più a fondo.

Quindi, se qualcuno non dichiara specificamente un'emozione primaria o una sua versione, devi andare più a fondo e scompattarla e scoprire PERCHÉ si sentono in quel modo.

## **Esempi di Emozioni Secondarie**

**Ansioso** → Si sentono ansiosi perché probabilmente "temono" un'esperienza specifica. O stanno anticipando "Tristezza" come risultato che non è ancora accaduto.

**Frustrato** → Si sentono frustrati perché forse hanno sentito "gioia" in un'esperienza e poi quella "gioia" è andata via. E ora stanno attraversando altre esperienze per ottenere quella "gioia" ma non sta dando la stessa "gioia". O hanno un desiderio specifico ma non possono raggiungerlo quindi sperimentano "rabbia" per i fallimenti che porta a frustrazione.

**Sopraffatto** → Si sentono sopraffatti perché probabilmente "temono" di non riuscire a gestire tutte le richieste/responsabilità. O stanno sperimentando "rabbia" per avere troppo caricato su di loro senza controllo sulla situazione.

**Sicuro di sé** → Si sentono sicuri di sé perché probabilmente hanno sperimentato "gioia" da successi passati in situazioni simili. O hanno prove/esperienze specifiche che hanno rimosso la loro "paura" riguardo al risultato.

**Eccitato** → Si sentono eccitati perché stanno anticipando "gioia" da un'esperienza o risultato futuro. Stanno anticipando emozioni positive che non sono ancora accadute.

**Stressato** → Si sentono stressati perché "temono" le conseguenze di non soddisfare aspettative/scadenze. O stanno sperimentando "rabbia" per la pressione/richieste che vengono loro imposte.

**Motivato** → Si sentono motivati perché stanno anticipando "gioia" dal raggiungimento del loro obiettivo. O "temono" le conseguenze di NON agire, quindi sono spinti a muoversi.

**Preoccupato** → Si sentono preoccupati perché "temono" un risultato negativo specifico. Molto simile ad ansioso - stanno anticipando potenziale perdita o "tristezza".

**Deluso** → Si sentono delusi perché hanno sperimentato "tristezza" da aspettative non soddisfatte. Anticipavano "gioia" da qualcosa che non ha mantenuto le promesse.

**Insicuro** → Si sentono insicuri perché "temono" il giudizio, il rifiuto, o di non essere abbastanza bravi. O hanno sperimentato "tristezza" da fallimenti passati che li fanno dubitare di se stessi.

E ce ne sono molte altre; puoi trovare ancora più emozioni **linkate qui.[<u>Printing Ecom System</u>](https://docs.google.com/document/d/1RLwZ7F2_TpMA215sB1WS7V68dy1frk9aj1Ho4jZ5EnE/edit?tab=t.nm6x43ncmhho)**

## **‼️ IMPORTANTE**

Il takeaway qui è questo: **L'intero obiettivo di capire le emozioni è che tu possa veramente capire come qualcuno si sente, così sai come parlare a loro nella tua pubblicità.**

Alla fine della giornata, capisci che puoi usare l'Emozione come modo per creare Avatar da soli. Ma, la vera svolta arriverà quando usi l'emozione per restringere ulteriormente il tuo avatar in base al loro desiderio esistente, esperienze, comportamenti e dati demografici.

O per un metodo più avanzato, INIZIA con l'emozione come "Ansia", e restringila ulteriormente per chiamare davvero il motivo per cui quella persona sta sperimentando quell'emozione, con desideri, esperienze, comportamenti, dati demografici.

## **ESEMPI PRATICI**

### **Esempio di Desiderio**

**Core Avatar \#1:** Vuole avere gli addominali scolpiti (Avatar principale basato sul desiderio)

**Core Avatar \#2:** Si sente motivato (Avatar principale basato sull'emozione)

**Sub Avatar \#1:** Vuole avere gli addominali scolpiti (Desiderio), SI SENTE motivato ad ottenerli (emozione)

**Sub Avatar \#2:** Vuole avere gli addominali scolpiti (Desiderio), SI SENTE sconfitto (emozione di nuovo)

Quindi, sfruttando l'emozione intorno al desiderio, puoi creare avatar che sono più relazionabili e specifici per il desiderio.

### **Esempio di Esperienza**

**Core Avatar \#1:** Ha un cane che tira (Avatar principale basato sull'esperienza)

**Core Avatar \#2:** SI SENTE imbarazzato (Avatar principale basato sull'emozione)

**Sub Avatar \#1:** Ha un cane che tira (Esperienza) & SI SENTE imbarazzato per il cane che tira (emozione)

**Sub Avatar \#2:** Ha un cane che tira (Esperienza) & SI SENTE spaventato per il cane che tira (emozioni di nuovo)

Quindi, sfruttando il pezzo emotivo, puoi creare avatar che sono più relazionabili e specifici per l'esperienza.

### **Esempio Demografico**

Questo è relativamente semplice.

Ma di nuovo, immagina qualcuno che è:

**Core Avatar \#1:** 40 anni (Avatar principale basato sul demografico) non uno ottimo ma servirà.

**Core Avatar \#2:** Si sente eccitato (Avatar principale basato sull'emozione)

**Sub Avatar \#1:** 40enne (demografico) che si sente eccitato (emozione)

**Sub Avatar \#2:** 40enne (demografico) che prova estrema ansia per avere 40 anni (emozione)

### **Esempio di Emozione**

Come menzionato sopra, non tutte le emozioni devono essere legate a esperienze, desideri o dati demografici. Sei anche in grado di creare avatar usando solo le emozioni raggruppando le persone in base a come si sentono in generale.

Tuttavia, poiché la maggior parte delle emozioni sono molto ampie e non specifiche, sono più potenti quando combinate con desideri, esperienze, comportamenti o dati demografici che hanno effettivamente causato le emozioni.

**(Questo è ciò che fa sentire alle persone che stai leggendo la loro mente)**

**Esempio completo:**

- La persona si sente stanca (Emozione)

- Il bambino si sveglia alle 5 del mattino a causa della luce del mattino nella nursery (Esperienza)

- Vogliono che tutta la loro famiglia abbia un sonno migliore (Desiderio)

Come puoi vedere qui, abbiamo iniziato con l'emozione che la persona prova, che all'inizio può creare molta relazionabilità.

Ma come risultato dell'aggiunta dell'esperienza e dell'aggiunta del desiderio, ci permette di concentrarci davvero su quello che dovrebbe essere un Sub-Avatar più efficace.

**Core Avatar \#1:** Vogliono che tutta la loro famiglia abbia un sonno migliore (Avatar principale basato sul desiderio)

**Sub Avatar \#1:** Vogliono che tutta la loro famiglia abbia un sonno migliore (Desiderio), ma il loro bambino si sveglia alle 5 del mattino a causa della luce del mattino (Esperienza), e ora il genitore si sente stanco (emozione)

## **💥 COME VERIFICARE CHE SIA UN'EMOZIONE 💥**

**Domanda chiave:** Questo descrive come una persona SI SENTE RIGUARDO o IN RISPOSTA a qualcosa?

Da lì, se NON è una delle 6 emozioni primarie, chiedi PERCHÉ e COSA per capire davvero cosa stanno provando e perché.

**Esempi:**

- "Mi sento motivato" → Perché questa persona è motivata? Cosa specificamente la rende motivata?

- "Sono ansioso" → Perché questa persona è ansiosa? Cosa specificamente la rende ansiosa?

# **Categoria 4: Comportamenti e Abitudini**

I comportamenti sono schemi di azione regolari che le persone sviluppano come risposte alle loro esperienze, emozioni, desideri o dati demografici.

In termini semplici, i comportamenti sono come le persone agiscono.

Sono le cose che facciamo, e spesso sono prevedibili.

## **Origine dei Comportamenti**

I comportamenti sono spesso soluzioni molto specifiche a problemi derivanti da esperienze:

**Esperienza** = "Ho provato X e è successo Y"\
**Comportamento** = "Quindi ora faccio Z invece"

Possono anche sorgere come risultato di desideri:

**Desiderio** = "Voglio la cosa X"\
**Comportamento** = "Quindi ora faccio Z per cercare di ottenere X"

Possono derivare da emozioni:

**Emozione** = "Mi sento ansioso intorno ad altre persone"\
**Comportamento** = "Quindi ora non vado mai a eventi sociali"

E possono persino derivare da dati demografici:

**Demografico** = "Maschio di 45 anni"\
**Comportamento** = "Quindi ora prendo integratori di testosterone"

## **Il Potere dei Comportamenti**

La parte migliore dei comportamenti è che rivelano come qualcuno affronta la vita, prende decisioni e gestisce le situazioni.

Sono solitamente centrali per le nostre convinzioni (che analizzeremo nella sezione dei sub-avatar), e li facciamo di nuovo, come risultato di esperienze, desideri, dati demografici ed emozioni.

Ciò che rende i comportamenti così potenti è che sono CENTRALI per la nostra auto-identità. AKA sono molto spesso legati al nostro ego.

**Ego:** il senso di autostima o importanza personale di una persona.

E per la maggioranza delle persone, possono spesso fare cose per dispetto solo per il bene dell'"ego" o perché "sono quel tipo di persona".

Quindi, quando crei annunci che prendono di mira l'ego di un Avatar, AKA i comportamenti che li rendono chi sono, è lì che puoi creare un senso di coinvolgimento molto, molto più forte.

## **Prevedibilità dei Comportamenti**

Un'altra cosa che rende il targeting basato sui comportamenti per gli avatar così forte è il fatto che se comprendi i comportamenti di qualcuno, molte volte, puoi anche prevedere i loro comportamenti.

E quindi nei tuoi annunci, puoi quasi "dirgli il futuro" perché in base al comportamento, sai cosa farà dopo quel tipo specifico di persona.

In definitiva, i comportamenti sono incredibilmente potenti per la costruzione degli avatar perché chiamano direttamente in causa le azioni che intraprendiamo, le cose che facciamo e chi siamo.

I comportamenti ci permettono di mostrare un altro livello di comprensione per i nostri Avatar che la maggior parte delle persone non sfrutta mai nel marketing, poiché devi veramente capire a chi stai facendo marketing per chiamarli efficacemente in causa.

## **Esempi di Alcuni Comportamenti**

- Ricerca tutto prima di acquistare

- Fa acquisti solo durante i saldi

- Evita palestre affollate

- Controlla costantemente l'email

## **ESEMPI PRATICI**

Per aiutarti a capire come esperienze, emozioni, desideri e dati demografici creano comportamenti che possiamo usare per restringere e sviluppare avatar killer, esaminiamo alcuni esempi.

### **Esempio \#1**

Una donna è post-partum, cioè ha appena avuto un bambino (Esperienza + demografico presunto)

La donna ora ha il desiderio di perdere il peso post-partum. (Desiderio)

Come risultato dell'ESPERIENZA e del DESIDERIO che esiste, questa persona può sviluppare il COMPORTAMENTO di:

Scorrere Instagram per "trasformazioni del corpo di mamma" (comportamento)

O potrebbero sviluppare il comportamento di:

"Fare allenamenti rapidi da 15-20 minuti a casa" (comportamento)

### **Esempio \#1.5 Comportamento**

Ma ecco la parte bella...

L'esperienza post-partum potrebbe NON essere l'unico modo in cui qualcuno sviluppa il comportamento di "Fare allenamenti rapidi da 15-20 minuti a casa"

Quel comportamento potrebbe essere stato sviluppato anche da altre esperienze o desideri.

Qualcuno potrebbe aver:

Provato ad andare in palestra durante il giorno, ma ha dovuto continuare ad uscire presto per andare a prendere i bambini (esperienza)

Vuole essere conosciuto come una persona in forma (desiderio)

Ora, come risultato di quell'esperienza e desiderio, sviluppano il comportamento di:

Fare allenamenti rapidi da 15-20 minuti a casa (comportamento)

Quindi anche se le esperienze e i desideri sono leggermente diversi, le persone possono sviluppare lo STESSO comportamento.

Questa informazione è oro, perché puoi andare "più ampio" sulla scala Avatar semplicemente prendendo di mira il comportamento stesso.

O puoi effettivamente approfondire il comportamento con le altre 4 categorie per creare una quantità intensa di relazionabilità con i Sub Avatar.

## **ESEMPI: Esperienze Che Hanno Portato a Comportamenti**

### **Esempio 1**

**Esperienza:** I bambini hanno fatto capricci in luoghi pubblici\
**Comportamento:** Porta sempre snack e intrattenimento quando esce con i bambini

In questo caso, di nuovo, l'esperienza è stata che i bambini di questa persona stavano facendo capricci in pubblico (esperienza), e questo probabilmente ha creato una risposta emotiva; erano imbarazzati (emozione), quindi come risultato, hanno cambiato ciò che fanno, portando snack e intrattenimento (comportamento).

**✅ Esempio di Marketing:**

Ora, per mostrarti esempi di come questo può applicarsi specificamente ai tuoi annunci. Creiamo alcuni titoli su come potremmo targetizzare questo cliente:

"I tuoi figli fanno capricci in pubblico?" → Basato sull'esperienza

"Se non esci mai di casa senza snack per i tuoi figli, allora..." → Basato sul comportamento

Come puoi vedere, possiamo targetizzare 2 Core Avatar individualmente, o di nuovo, possiamo combinarli per creare un Sub Avatar più profondo.

### **Altri Esempi**

**Esperienza:** In una palestra affollata\
**Emozione:** Ha ansia\
**Comportamento:** Ora si allena solo a casa

**Esperienza:** Il cane continua a tirare durante le passeggiate\
**Comportamento:** Porta a spasso il cane solo alle 5 del mattino per evitare la folla

**Esperienza:** Attualmente incinta del primo bambino\
**Comportamento:** Legge ossessivamente ogni etichetta degli ingredienti

## **ESEMPI: Desideri Che Hanno Portato a Comportamenti**

### **Esempio 1**

**Desiderio:** Vuole perdere 20 libbre entro l'estate\
**Comportamento:** Prepara i pasti ogni domenica per la settimana

La persona ha il desiderio di perdere peso per l'estate (desiderio - salute/status probabilmente) e come risultato, ha sviluppato il comportamento di preparare i pasti ogni domenica (comportamento).

Ora solo per contesto extra, è importante notare che questa persona probabilmente ha avuto un'esperienza che ha portato a questo desiderio (hanno visto un ragazzo super in forma su Instagram, sono stati presi in giro per essere grassottelli da bambini, ecc.) O il desiderio potrebbe essere venuto anche dalle emozioni (si sentono disgustati da come appaiono allo specchio, non si sentono sicuri di sé).

**✅ Esempio di Marketing:**

Ora, per mostrarti esempi di come questo può applicarsi specificamente ai tuoi annunci. Creiamo alcuni titoli su come potremmo targetizzare questo cliente:

"Vuoi perdere 20 libbre entro l'estate?" → Basato sul desiderio (molto ampio)

"Se ancora prepari i pasti ogni domenica, allora X..." → Basato sul comportamento (più specifico)

Di nuovo, possiamo targetizzare quei 2 Core Avatar individualmente, o possiamo combinarli per creare un Sub Avatar più profondo.

Per un esempio di come potrebbe apparire per il Sub Avatar:

"Se stai cercando di perdere 20 libbre in tempo per l'estate e pensi che preparare i pasti ogni domenica funzionerà davvero, allora X..."

### **Altri Esempi**

**Desiderio:** Vuole apparire di successo e ben curato\
**Comportamento:** Compra solo articoli di marca anche quando il generico funziona

Quindi di nuovo, questa persona ha il desiderio di voler apparire di successo e ben curato (desiderio - status o anche appartenenza) e come risultato, il suo comportamento è ora comprare solo articoli di marca (comportamento).

**Desiderio:** Vuole sentirsi in controllo della salute e del futuro\
**Comportamento:** Prende 15+ integratori ogni mattina religiosamente

## **ESEMPI: Emozioni Che Hanno Portato a Comportamenti**

### **Esempio 1**

**Emozione:** Si sente insicuro riguardo alla propria pelle\
**Comportamento:** Ordina costantemente nuovi prodotti e sieri per la cura della pelle

Ora per le emozioni, questa persona SI SENTE insicura (emozione), e come risultato del sentirsi in quel modo, l'ha portata a provare ogni nuovo prodotto e siero per la cura della pelle (comportamento).

**✅ Esempio di Marketing:**

Per mostrarti più esempi di come questo può applicarsi specificamente ai tuoi annunci. Creiamo alcuni titoli su come potremmo targetizzare questo cliente:

"Se la tua pelle ti fa sentire insicuro..." → Basato sull'emozione (molto ampio)

"Se ordini costantemente prodotti per la cura della pelle..." → Basato sul comportamento (più specifico)

Di nuovo, possiamo targetizzare quei 2 Core Avatar individualmente, o possiamo combinarli per creare un Sub Avatar più profondo.

Per un esempio di come potrebbe apparire per il Sub Avatar:

"Se ordini costantemente nuovi prodotti per la cura della pelle perché ti senti insicuro..."

### **‼️ NOTA IMPORTANTE**

Voglio aggiungere una nota qui specificamente sulla cura della pelle.

Quando i mercati diventano più sofisticati, per esempio, come la cura della pelle, molti di questi tipi di avatar vengono già targetizzati a causa di quanto sofisticato è il mercato. Quindi, molto spesso, devi andare più in profondità e applicare più delle 5 categorie principali (invece di solo 1 o 2) per essere effettivamente in grado di relazionarti con qualcuno in questi mercati sofisticati.

### **Esempio 2**

**Emozione:** Si sente felice quando le persone la notano\
**Comportamento:** Compra costantemente pezzi di design distintivi

Di nuovo, la persona SI SENTE felice (gioia) quando le persone la notano (emozione + un po' di esperienza e demo), e come risultato del sentirsi in quel modo, l'ha portata a comprare costantemente pezzi distintivi così più persone la notano (comportamento).

## **CONCLUSIONE**

Si spera che ora con gli esempi sopra, tu possa vedere come i comportamenti non solo si sviluppano come risultato delle altre 4 categorie, ma come possono essere utilizzati per affinare il tuo avatar e ciò che FANNO.

## **💥 COME VERIFICARE CHE SIA UN COMPORTAMENTO/ABITUDINE 💥**

**Domanda chiave:\**
Questo descrive ciò che la persona fa?

**NOTA:** non deve essere un'azione fisica; può anche essere mentale.

"Pensare costantemente troppo alle cose" è anche un comportamento.

Da lì, se vuoi valutare la forza del comportamento, chiediti: "Quanto spesso potrebbero farlo?"

Più si fa il comportamento, più è forte, il che significa che sarà più relazionabile.

# **Categoria 5: Dati Demografici**

I dati demografici sono le caratteristiche relativamente statiche e fattuali che definiscono chi è qualcuno - cose che non cambiano frequentemente o affatto.

## **Introduzione**

Ultimo ma in realtà il meno importante, finalmente arriviamo al preferito abituale di tutti per gli Avatar... I Dati Demografici.

A differenza delle altre 4 categorie, i Dati Demografici sono molto diretti.

Come probabilmente hai notato sopra, basandosi su desideri, esperienze, emozioni e comportamenti, molto spesso i dati demografici sono assunti/impliciti.

Ciò significa che, se qualcuno ha attraversato l'esperienza di "Dare alla luce"

Almeno per ora, solo le Donne possono farlo.

Pertanto, quell'esperienza si restringe anche attraverso i dati demografici.

## **L'Utilizzo dei Dati Demografici**

Detto questo, come le altre categorie principali, i dati demografici possono efficacemente restringere i tuoi Avatar e costruire più relazionabilità, specialmente se il tuo prodotto funziona meglio per persone di un demografico specifico.

### **Esempio 1: Skincare per Donne Afroamericane**

Ad esempio, abbiamo lavorato con un brand che vende prodotti per la cura della pelle per donne afroamericane.

A causa del fatto che queste donne hanno pelle ricca di melanina, hanno esigenze più specifiche, e questo prodotto si rivolgeva a quello.

Pertanto, siamo stati efficacemente in grado di restringere gli avatar e avere successo con solo i dati demografici.

### **Esempio 2: Norse Organics**

Vedi anche questo con brand come "Norse Organics" che pubblicano annunci che chiamano in causa "Mamme di ragazzi di 15 anni" come strategia efficace.

## **IMPORTANTE: I Limiti dei Demografici**

Detto questo, i dati demografici NON dovrebbero essere il tuo principale differenziatore a meno che tu non sia a una scala molto maggiore.

Oltre a ciò, i Dati Demografici non generano nemmeno lontanamente tanta motivazione all'acquisto quanto le altre 4 categorie, quindi usali se vuoi andare molto specifico.

Altrimenti, i Dati Demografici molto spesso non sono nemmeno NECESSARI nel tuo processo di costruzione degli avatar.

Pazzesco, lo so.

## **L'Errore Più Grande**

Ma l'errore più grande che vedo fare a così tante persone è che isolano gli acquirenti solo in base ai dati demografici.

### **Esempio Pratico**

Una ragazza di 22 anni e un uomo di 54 anni potrebbero avere:

- Lo stesso desiderio (vogliono trovare un partner romantico)

- Esperienze simili (Non riescono a trovare la persona giusta)

- Emozioni simili (Hanno paura di non riuscire mai a trovare la persona giusta)

- E potrebbero persino avere lo stesso comportamento (Usano siti di incontri online)

Eppure, non appena aggiungi un demografico, può escludere persone.

## **Quando i Demografici Funzionano Bene**

Ora di nuovo, per un desiderio così grande, esperienze, emozioni e comportamenti COSÌ comuni, a volte i dati demografici possono effettivamente essere un ottimo differenziatore per aiutarti a costruire più relazionabilità.

Probabilmente hai visto questo anche con le app:

**Siti di incontri "Solo Agricoltori"** (Un po' pazzesco ma è reale)

E il motivo PER CUI lo fanno è perché, di nuovo, costruisce relazionabilità.

Ecco la "prova" secondo Google.

## **Esempio eCom: Hollow Socks**

Un altro ottimo esempio di questo (nel mondo eCom) è Hollow Socks.

Fanno oltre \$100k/giorno (Zach, il loro fondatore, ne parla pubblicamente)

E il suo PRINCIPALE avatar è in realtà basato su un demografico di Impiego specifico (Lavoratori edili)

Tuttavia, va più in profondità e comprende i loro desideri, esperienze, emozioni e comportamenti per essere in grado di targetizzarli efficacemente e scalare il suo brand.

## **Lista Completa dei Dati Demografici**

Per darti un'idea di tutti i diversi tipi di dati demografici, puoi fare riferimento alla lista qui sotto.

### **Tutti i Dati Demografici:**

- **Genere** (Maschio/Femmina/Altro)

- **Data di nascita/Generazione** ("Nato negli anni '90"/Boomer)

- **Razza ed Etnia** (Latino/Cinese)

- **Età** (25/65+)

- **Località** (Canada/Columbia Britannica/Vancouver/Surrey)

- **Lingua** (Inglese/Francese)

- **Religione** (Cristiano/Agnostico)

- **Stato civile** (Sposato/Fidanzato)

- **Istruzione** (Diploma/Dottorato)

- **Impiego** (Lavoratore Edile/Imprenditore)

- **Reddito** (\$100k all'anno/Classe Media/Top 1%)

- **Disabilità** (Cieco/Paralizzato/Sordo)

- **Condizioni di salute** (Ansia/Osso rotto/Diabete)

- **Altezza** (1,65m "basso" / 1,96m "alto")

- **Peso** (82kg/sovrappeso/magro)

## **Conclusione**

In definitiva, ricorda semplicemente che i dati demografici dovrebbero RARAMENTE essere il tuo punto di partenza per gli Avatar, poiché ci sono categorie molto più forti.

Detto questo, possono essere ottimi per costruire quel bit extra di relazionabilità.

Detto ciò, alcuni sono a volte assunti per avere desideri specifici. (Voglio che i miei figli siano sani = Mamma/Papà)

## **💥 COME VERIFICARE CHE SIA UN DATO DEMOGRAFICO 💥**

**Domanda chiave:\**
Rientra in una delle categorie sopra?

Se non lo fa, probabilmente non è un dato demografico.

Semplice e facile.

# **E le Credenze... Categoria 6?**

A un certo punto, mentre creavo questo documento, c'era effettivamente una sesta categoria chiamata:

**Credenze e Valori.**

Detto questo, dopo aver approfondito veramente le credenze in modo specifico, ho capito che non erano necessarie come blocco fondamentale per la costruzione degli avatar.

Le credenze sono spesso Esperienze, Emozioni e Comportamenti legati insieme.

## **Esempio di Scomposizione delle Credenze**

**"Persone che credono di non poter perdere peso"** diventa:

- **Esperienza:** "Ho provato più diete e ho ripreso il peso."

- **Emozione:** "Si sente senza speranza riguardo alla perdita di peso"

- **Comportamento:** "Evita di iniziare nuove diete perché si aspetta il fallimento"

## **Come Gestire le Credenze**

Quindi, per quanto CRUCIALI siano le credenze (e ci arriveremo nella sezione di ottimizzazione dei sub avatar)

Quando ti ritrovi a pensare in termini di credenze o individui credenze nella tua ricerca durante la costruzione del core avatar, chiediti semplicemente:

1.  **"Cosa è successo per fargli credere questo?"** (Identifica l'Esperienza)

2.  **"Come li fa sentire questa credenza?"** (Identifica l'Emozione)

3.  **"Cosa fanno a causa di questa credenza?"** (Identifica il Comportamento)

Questo ti costringe a diventare più specifico e attuabile mentre costruisci i tuoi avatar, poi puoi identificare le credenze risultanti più tardi per scopi di messaging.

# **Quanti Avatar Dovrei Creare?**

Questa è un'altra ottima domanda. Perché la verità è che, se me lo chiedi, non c'è una risposta giusta su quanti avatar dovresti avere.

Detto questo, ecco come raccomanderei dal punto di vista del focus, quanti Avatar dovresti avere:

## **Stage 1: \$0-\$100K/Mese**

Se sei a \$0-\$100k dovresti avere solo un core avatar su cui ti concentri alla volta. Preferibilmente basato su un Desiderio, Esperienza o Comportamento.

Ma, avrai BISOGNO di concentrarti sulla creazione di Sub Avatar attorno a quel Core Avatar così puoi essere PIÙ specifico e PIÙ relazionabile all'inizio.

**Più basso è il tuo fatturato, di solito PIÙ specifico devi essere.**

Come brand, ti GUADAGNI il diritto di andare più ampio.

E quindi se sei nello Stage 1, scegli 1 Core Avatar, e concentrati sulla creazione di Sub Avatar di quel principale Desiderio, Esperienza, o Core Avatar Basato sul Comportamento.

Per semplicità, il 99% di voi dovrebbe concentrarsi su un SINGOLO Core Avatar basato sul desiderio e costruire sub avatar attorno a quello.

### **Come Scegliere il Desiderio**

Se vuoi un'idea di "Quale desiderio" perseguire, raccomanderei di guardare il tuo più grande concorrente per vedere QUALE desiderio stanno scalando, e semplicemente andare più in profondità sui sub avatar così puoi:

**"Superarli con gli avatar"**

Piuttosto che "Superarli nel Marketing" → Perché onestamente, non sei ancora così bravo nel marketing.

Ora, se ti ritrovi bloccato e non riesci a far funzionare questi sub-avatar dopo 2-4 settimane di test, puoi quindi guardare a cambiare il tuo Core Avatar Basato sul Desiderio verso un NUOVO desiderio.

Ma capisci semplicemente che focus e profondità si compongono. Più vai in profondità, meglio diventi.

## **Stage 2: \$100K-\$1M/Mese**

A questo stage, genuinamente, non c'è molto che cambia dal punto di vista degli avatar.

Dovresti ancora essere concentrato su un core avatar e sub-avatar specifici che possono convertire meglio.

Idealmente, a questo punto, stai migliorando nel marketing, e quindi dovresti essere in grado di eseguire annunci migliori il che significa che puoi andare dopo avatar leggermente più ampi.

Tuttavia, quando superi i \$500k/mese, probabilmente vorrai iniziare a guardare all'aggiunta di Core Avatar aggiuntivi (quindi averne 2-3 in totale) per scalare ulteriormente.

A questo punto nel tuo brand, dovresti avere abbastanza larghezza di banda per te e il tuo team per andare in profondità su multipli Core Avatar invece di solo 1.

Tuttavia, siamo stati in grado di scalare a \$1M/mese con 1 Core Avatar e un'ottima esecuzione.

## **Stage 3: \$1M-\$10M/Mese**

Una volta raggiunto il traguardo di \$1M/mese, è qui che la creazione degli avatar inizia ad espandersi.

E più ti avvicini a \$10M al mese, più ampi devono essere gli Avatar o più Avatar devi avere (tipicamente una combinazione di entrambi).

Se hai scalato a un run rate di \$1m+ al mese, di solito significa che sei un buon marketer.

Tuttavia, a questo stage per arrivare a \$5M+ al mese, tu e il tuo team dovete diventare GRANDI marketer.

### **Focus Avanzato**

A questo stage, devi anche iniziare a weaponizzare Nuovi Meccanismi, Nuove Informazioni e VERE Nuove Identità (attraverso il branding, non la costruzione degli Avatar), per convincere più persone che non stanno solo comprando perché è relazionabile.

Quindi, il grande focus per quelli di voi che cercano di passare da 8 a multi-8 cifre, 9 cifre non è solo essere relazionabili con più avatar (anche se a questo stage di solito hai 3-10 Core Avatar)

Ma, devi anche avere un'esecuzione di livello mondiale per quegli Avatar E volume.

### **Caso Studio: Comfrt**

Di nuovo, se analizziamo uno dei brand più grandi attivamente in DTC (Comfrt)

Stanno massimizzando la relazionabilità su SCALA.

Generano oltre 10.000+ pezzi di contenuto a settimana

E anche se il 10% di loro sono relazionabili

Sono 1.000 pezzi di contenuto relazionabile pompati fuori in continuazione.

Non hanno scalato a \$50m/mese per caso.

**Avatar, Meccanismi (le loro felpe con cappuccio pesate), Brand (Supportare la salute mentale), Volume (E un sacco di esso)**

## **Stage 4: \$10M+/Mese**

Ho toccato questo brevemente con Comfrt sopra, ma a questo stage, devi sfruttare tutto in questo documento + volume.

Ma, probabilmente sei già in Apex o stai cercando di preparare il tuo business per un'uscita...

Quindi, possiamo parlare dell'approccio per te più 1-a-1.

## **Riepilogo per Stage**

| **Stage** | **Fatturato/Mese** | **Core Avatar** | **Focus Principale** |
|----|----|----|----|
| **1** | \$0-\$100K | 1 | Sub-Avatar specifici |
| **2** | \$100K-\$1M | 1-3 | Esecuzione migliore + Sub-Avatar |
| **3** | \$1M-\$10M | 3-10 | Meccanismi + Identità + Volume |
| **4** | \$10M+ | Multipli | Tutto + Volume Massimo |

4.1 Emozioni Secondarie

# **Le emozioni più comuni che le persone usano oltre a paura, rabbia, gioia, tristezza, sorpresa e disgusto**

Questa guida elenca le emozioni secondarie e complesse organizzate per frequenza d'uso nel mondo reale, basandosi su ricerche nella letteratura psicologica, studi di marketing, analisi dei social media e dati di feedback dei clienti. Ogni emozione include il suo contesto di prevalenza e utilità nel marketing.

## **Livello 1: Emozioni ad Altissima Frequenza (Usate Quotidianamente da Grandi Popolazioni)**

**Stress e Sopraffazione** Frequenza: Lo stato emotivo \#1 più riportato su tutte le piattaforme. Il 76% dei dipendenti riporta che lo stress impatta la produttività quotidianamente. L'emoji che piange forte (😭) esprimendo sopraffazione è stata usata 761 milioni di volte a livello globale nel 2024, rendendola l'espressione emotiva più usata online. Questa emozione appare costantemente attraverso le generazioni ma raggiunge il picco tra i millennials e la Gen Z.

**Ansia e Preoccupazione** Frequenza: 44 milioni di adulti negli Stati Uniti sperimentano ansia quasi quotidiana. Si classifica costantemente nella top-3 tra le app di monitoraggio dell'umore, social media e interazioni del servizio clienti. Gallup riporta la preoccupazione come l'emozione negativa più alta a livello globale. Questo stato emotivo guida un comportamento significativo dei consumatori, particolarmente nei servizi finanziari, sanità e settori tecnologici dove l'incertezza è alta.

**Frustrazione** Frequenza: Appare nell'85%+ delle interazioni negative del servizio clienti. Emozione più comune nei ticket di supporto e nelle recensioni di prodotti. La ricerca mostra che i clienti frustrati hanno il 30% di probabilità in più di abbandonare. Questa emozione segnala necessità di azione immediata da parte dei brand - è un identificatore critico di punti critici per lo sviluppo del prodotto e il miglioramento del servizio.

**Amore e Affetto** Frequenza: L'emoji del cuore rosso (❤️) si classifica costantemente nella top-3 su tutte le piattaforme. Emozione positiva più comune oltre alla gioia di base. La ricerca di Harvard Business Review mostra che i clienti emotivamente connessi hanno un valore lifetime del 306% più alto. L'amore trascende il "mi piace" - rappresenta una connessione profonda con il brand e spinge all'accettazione di prezzi premium.

**Soddisfazione e Appagamento** Frequenza: Emozione positiva più comune nel feedback transazionale. Metrica fondamentale tracciata da praticamente tutte le aziende. Il 94% dei clienti soddisfatti con esperienze a basso sforzo riacquista. Questa emozione positiva stabile indica una consegna dell'esperienza di base di successo e predice la retention meglio del piacere intenso.

## **Livello 2: Frequenza Molto Alta (Uso Settimanale da parte della Maggioranza)**

**Fiducia in Sé Stessi/Sicurezza** Impatto Marketing: Gallup identifica la fiducia come l'emozione più fondamentale nelle relazioni con i clienti B2B e B2C. I clienti che esprimono fiducia mostrano tassi di advocacy 3 volte più alti. Essenziale per servizi finanziari, sanità e marketing tecnologico dove le percezioni di fiducia e capacità guidano le decisioni.

**Solitudine e Isolamento** Rilevanza Attuale: Il 23% degli adulti a livello globale riporta solitudine quotidiana (Gallup 2024). Post-pandemia, questa emozione è aumentata del 42% nella segnalazione settimanale. Potente per brand che costruiscono comunità, piattaforme social e prodotti per il benessere. Particolarmente risonante con la Gen Z che riporta i tassi di solitudine più alti nonostante sia la generazione più connessa.

**Eccitazione e Anticipazione** Potere Virale: L'uso dell'emoji del fuoco (🔥) aumenta durante i lanci di prodotti e gli eventi culturali. L'eccitazione genera tassi di condivisione social 2 volte superiori rispetto all'appagamento. La ricerca Nielsen mostra che gli annunci che attivano l'eccitazione creano un aumento delle vendite del 23%. Critica per campagne di lancio, marketing di eventi e brand aspirazionali.

**Gratitudine** Tendenza in Crescita: L'emoji delle mani giunte (🙏) si classifica nella top-6 a livello globale. Le app per il diario della gratitudine mostrano una crescita del 500% dal 2020. I clienti che esprimono gratitudine mostrano tassi di retention dell'88% più alti. Potente per il marketing di cause, brand sostenibili e aziende orientate alle relazioni.

**Orgoglio** Valore Identitario: I clienti che percepiscono alto valore identitario attraverso l'orgoglio hanno 5 volte più probabilità di fare advocacy (Gallup). Emozione essenziale per brand di lusso, prodotti orientati al raggiungimento e servizi professionali. Gli acquirenti B2B che esprimono orgoglio professionale mostrano valori contrattuali 2 volte più alti.

## **Livello 3: Alta Frequenza (Occorrenze Multiple Settimanali)**

**Speranza e Ottimismo** Emozione di Ripresa: Il 78% riporta di sentirsi speranzoso almeno 1-2 giorni a settimana. La speranza si correla con un'intenzione d'acquisto del 45% più alta per prodotti orientati al futuro. Critica per pianificazione finanziaria, educazione, trasformazione della salute e messaggi di sostenibilità.

**Delusione** Divario di Aspettative: Comune nel 60% delle recensioni negative. Segnala aspettative non soddisfatte specifiche piuttosto che insoddisfazione generale. I clienti delusi che ricevono risoluzione mostrano lealtà più alta di quelli mai delusi. Chiave per strategie di gestione delle aspettative e recupero.

**Confusione** Critica per UX: Appare nel 40% del feedback sull'esperienza utente. I prospect confusi mostrano tassi di conversione del 70% più bassi. Emozione più gestibile attraverso migliore architettura dell'informazione e educazione del cliente. Particolarmente importante per prodotti e servizi complessi.

**Sollievo** Emozione di Risoluzione: Frequente dopo risoluzione di problemi di successo o completamento di decisioni. Il sollievo guida tassi di referral 3 volte più alti della mera soddisfazione. Potente per assicurazioni, sanità, servizi fiscali e qualsiasi prodotto che riduce l'ansia.

**Fiducia** Emozione Fondamentale: L'83% dei clienti cita la fiducia come influenza primaria sulla lealtà. La fiducia richiede in media 3,5 interazioni positive per costruirsi ma solo una negativa per rompersi. Metrica di sentiment del brand più tracciata. Essenziale per tutte le industrie ma critica per finanza, sanità ed e-commerce.

## **Livello 4: Frequenza Moderata-Alta (Settimanale per Segmenti Specifici)**

**Empowerment** Tendenza in Crescita: Specialmente importante per Gen Z e millennials. I clienti empowered mostrano tassi di engagement 4 volte più alti. Centrale per prodotti di trasformazione, tecnologia educativa e categorie di strumenti. Importanza crescente nel software B2B e soluzioni di produttività.

**Appartenenza e Connessione** Motore di Comunità: Guida un valore lifetime 2,5 volte più alto nei brand centrati sulla comunità. Essenziale per piattaforme social, brand lifestyle e aziende basate su membership. I bisogni di appartenenza si sono intensificati post-pandemia, particolarmente per lavoratori remoti e nativi digitali.

**Nostalgia** Moltiplicatore Emotivo: Il marketing nostalgico mostra tassi di engagement del 35% più alti. Particolarmente efficace per brand consolidati e targeting generazionale. Combina multiple emozioni positive creando forti trigger d'acquisto. Più efficace con millennials e Gen X.

**Sentirsi Valorizzati e Apprezzati** Pietra Angolare della Lealtà: Sentirsi valorizzati è il principale predittore della retention dei clienti. I clienti valorizzati mostrano una probabilità 15 volte più alta di raccomandare (Temkin). Critico per industrie di servizi, relazioni B2B e aziende in abbonamento.

**Ispirazione** Motore di Aspirazione: I contenuti che ispirano ottengono 3 volte più condivisioni rispetto ai contenuti informativi. Emozione chiave per brand lifestyle, fitness, educazione e industrie creative. L'ispirazione combinata con passi pratici mostra i tassi di conversione più alti.

## **Livello 5: Emozioni ad Alto Impatto Specifiche per Contesto**

**Colpa e Vergogna** Motivatori Complessi: Appaiono nel 30% dei messaggi di recupero carrello abbandonato. La colpa (verso gli altri) guida una risposta 2 volte più alta della vergogna (verso se stessi). Potente ma richiede attenta applicazione etica. Più efficace in contesti di sostenibilità, carità e salute.

**Invidia e Gelosia** Emozioni di Prova Sociale: Il marketing FOMO che sfrutta l'invidia mostra tassi di conversione del 60% più alti. Deve bilanciare con emozioni positive per evitare risentimento verso il brand. Più efficace in moda, lusso e offerte esclusive.

**Sicurezza e Protezione** Bisogno Fondamentale: Motore primario in servizi finanziari, assicurazioni e sanità. I messaggi focalizzati sulla sicurezza mostrano tassi di risposta del 40% più alti durante l'incertezza. L'importanza post-pandemia è aumentata attraverso tutti i dati demografici.

**Curiosità** Trigger di Engagement: I prospect curiosi spendono 2,4 volte più tempo interagendo con i contenuti. Guida il 50% dei tassi di click-through nel marketing via email. Essenziale per content marketing, prodotti educativi e brand innovativi.

**Realizzazione e Achievement** Soddisfazione di Completamento: Guida l'80% delle recensioni positive per prodotti educativi e fitness. Le emozioni di achievement creano il comportamento di referral più forte. Critico per prodotti orientati agli obiettivi e strategie di gamification.

## **Livello 6: Emozioni di Nicchia ma Potenti**

**Stupore e Meraviglia** Catalizzatore Virale: I contenuti che attivano stupore vengono condivisi 5 volte più della media. Particolarmente efficace per brand di viaggio, tecnologia e ambientali. Crea momenti di brand memorabili che guidano lealtà a lungo termine.

**Validazione** Contesto Professionale: Critica nel B2B dove la validazione dell'acquisto influisce sulla percezione della carriera. Gli acquirenti validati mostrano tassi di rinnovo 3 volte superiori. Importante per sviluppo professionale, programmi di certificazione e software enterprise.

**Urgenza** Motore d'Azione: Crea tassi di conversione immediata del 45% più alti. Deve bilanciare con la fiducia per evitare di sembrare manipolativo. Più efficace in offerte a tempo limitato e mercati competitivi.

**Comfort e Facilità** Qualità dell'Esperienza: Le esperienze a basso sforzo che creano comfort mostrano tassi di riacquisto del 94%. Sempre più importante poiché i consumatori cercano semplicità. Critico per l'esperienza utente e il design del servizio.

**Competenza e Capacità** Auto-Efficacia: I clienti che si sentono competenti con i prodotti mostrano costi di supporto del 90% più bassi. Essenziale per prodotti complessi che richiedono educazione dell'utente. Guida la disponibilità a pagare un premium negli strumenti professionali.

👤 FASE 5: Creare Avatar Efficaci per l'eCommerce

# **Come Creare Avatar Efficaci per l'eCommerce**

## **📋 PANORAMICA**

Questa guida ti mostrerà come costruire Avatar che:

- Creano riconoscibilità istantanea

- Aumentano le conversioni

- Riducono i costi pubblicitari

- Ti permettono di scalare

**Tempo necessario:** 2-4 ore per il primo Avatar **Risultato:** Avatar azionabili che puoi usare immediatamente nelle tue ads

## **FASE 1: PREPARAZIONE E MINDSET**

### **Step 1.1: Cambia il Tuo Approccio agli Avatar**

**❌ VECCHIO MODO (Non Funziona):** "Susan, 44 anni, lavora in azienda, ha 2 figli, guadagna €50k/anno"

**✅ NUOVO MODO (Funziona):** Avatar basati su Desideri, Esperienze, Emozioni e Comportamenti

**Perché questo cambia tutto:**

- I dati demografici da soli non motivano l'acquisto

- Le persone comprano per soddisfare desideri ed emozioni

- Gli Avatar tradizionali non sono azionabili nelle ads

### **Step 1.2: Comprendi la Scala degli Avatar**

SPECIFICO ←——————————————————→ AMPIO

🐸 Una Persona 🐸🐸🐸 Tutte le Persone

(Molto Ristretto) (Molto Ampio)

**REGOLA D'ORO:**

- Più AMPIO l'Avatar = Migliori devono essere Prodotto, Offerta, Brand e Skillset

- Più SPECIFICO (ma non alienante) = Più facile convertire anche con prodotto/offer medi

### **Step 1.3: Raccogli i Tuoi Strumenti**

**Hai bisogno di:**

1.  ✅ Risultati della ricerca sui clienti (interviste, recensioni, commenti)

2.  ✅ Foglio Excel o Notion per organizzare

3.  ✅ Template delle 5 Categorie (fornito sotto)

4.  ✅ 2-4 ore di tempo focalizzato

## **FASE 2: LE 5 CATEGORIE FONDAMENTALI**

### **Template di Raccolta Dati**

CATEGORIA 1: DESIDERI

\- Voglio \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\- Ho bisogno di \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\- Desiderio Principale: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

CATEGORIA 2: ESPERIENZE

Situazionali:

\- \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\- \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Basate su Prodotti:

\- Ho provato \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ e \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\- Ho provato \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ e \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

CATEGORIA 3: EMOZIONI

Primarie (Gioia, Tristezza, Paura, Disgusto, Rabbia, Sorpresa):

\- Si sente \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

Secondarie (Ansioso, Frustrato, Motivato, etc.):

\- Si sente \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ perché \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

CATEGORIA 4: COMPORTAMENTI

\- Fa sempre \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\- Non fa mai \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\- Il suo comportamento tipico è \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

CATEGORIA 5: DATI DEMOGRAFICI (Solo se necessario)

\- \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## **FASE 3: COSTRUIRE IL TUO CORE AVATAR**

### **Step 3.1: Scegli la Tua Categoria di Partenza**

**PER IL 90% DELLE PERSONE:** 👉 **Inizia con un DESIDERIO**

**Come trovare il desiderio giusto:**

1.  **Analizza i tuoi concorrenti più grandi**

    - Quale desiderio stanno targetizzando?

    - Guarda le loro ads principali

    - Che problema promettono di risolvere?

2.  **Usa il "Test del Desiderio"**

✅ "Voglio dormire meglio"

✅ "Ho bisogno di perdere peso post-parto"

✅ "Voglio che il mio cane smetta di tirare"

3.  **Verifica che sia a livello superficiale, non core**

    - ❌ "Voglio essere sano" (troppo ampio)

    - ✅ "Voglio dormire 8 ore senza svegliarmi" (specifico)

### **Step 3.2: Documenta il Tuo Core Avatar**

**Template Core Avatar:**

CORE AVATAR \#1: \[Nome Descrittivo\]

Categoria Base: Desiderio

Descrizione: Vuole \[desiderio specifico\]

Esempio:

CORE AVATAR \#1: "Il Genitore Esausto"

Categoria Base: Desiderio

Descrizione: Vuole che tutta la famiglia dorma meglio

## **FASE 4: CREARE SUB-AVATAR EFFICACI**

### **Step 4.1: Aggiungi la Seconda Categoria**

**Formula Base:**

SUB-AVATAR = CORE AVATAR + 1 CATEGORIA AGGIUNTIVA

**Esempio Pratico:**

CORE AVATAR: Vuole dormire meglio

\+ ESPERIENZA → SUB-AVATAR \#1:

"Vuole dormire meglio + Ha provato il magnesio e non ha funzionato"

\+ EMOZIONE → SUB-AVATAR \#2:

"Vuole dormire meglio + Si sente frustrato"

\+ COMPORTAMENTO → SUB-AVATAR \#3:

"Vuole dormire meglio + Prende 5+ integratori ogni mattina"

### **Step 4.2: Crea 5-10 Sub-Avatar per Ogni Core Avatar**

**Worksheet Sub-Avatar:**

CORE AVATAR: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

SUB-AVATAR 1:

Categoria Aggiuntiva: Esperienza

Descrizione: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ + \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

SUB-AVATAR 2:

Categoria Aggiuntiva: Emozione

Descrizione: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ + \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

SUB-AVATAR 3:

Categoria Aggiuntiva: Comportamento

Descrizione: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ + \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

SUB-AVATAR 4:

Categoria Aggiuntiva: Esperienza + Emozione

Descrizione: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ + \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_ + \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

SUB-AVATAR 5:

\[Continua...\]

### **Step 4.3: Test di Validazione**

**Per ogni Sub-Avatar, chiediti:**

✅ Riesco a scrivere un'ad per questa persona? ✅ È abbastanza specifico da creare riconoscibilità? ✅ Non è così specifico da alienare troppo pubblico? ✅ Questa persona esiste davvero nei miei dati di ricerca?

## **FASE 5: TRASFORMARE AVATAR IN ADS**

### **Step 5.1: Formula del Titolo**

**Template Base:**

ESPERIENZA:

"\[Esperienza che hanno vissuto\]?"

Esempio: "I tuoi figli fanno capricci in pubblico?"

COMPORTAMENTO:

"Se \[comportamento specifico\], allora..."

Esempio: "Se non esci mai di casa senza snack per i tuoi figli, allora..."

EMOZIONE:

"Se \[cosa\] ti fa sentire \[emozione\]..."

Esempio: "Se la tua pelle ti fa sentire insicuro..."

DESIDERIO + ESPERIENZA:

"Vuoi \[desiderio\] ma \[esperienza\]?"

Esempio: "Vuoi dormire meglio ma il magnesio non funziona?"

### **Step 5.2: Esempio Completo di Ad**

**SUB-AVATAR:** "Vuole che la famiglia dorma meglio + Bambino si sveglia alle 5 per la luce + Genitore si sente esausto"

**AD COPY:**

TITOLO:

"Se il tuo bambino si sveglia alle 5 del mattino a causa della luce..."

BODY:

"Sai quella sensazione di essere completamente esausto perché il tuo bambino si sveglia all'alba ogni singolo giorno?

Hai provato le tende oscuranti. Hai provato a cambiare la routine del sonno. Niente ha funzionato.

Il problema non è la quantità di luce bloccata. È il TIPO di luce bloccata.

\[Nome Prodotto\] usa tecnologia \[meccanismo\] che blocca specificamente le lunghezze d'onda che disturbano il sonno del bambino.

Risultato? Bambini che dormono fino alle 7-8. Genitori che finalmente riposano.

\[CTA\]"

## **FASE 6: ORGANIZZAZIONE E TESTING**

### **Step 6.1: Crea il Tuo Avatar Database**

**Struttura Consigliata:**

📁 AVATAR DATABASE

├── 📄 Core Avatar 1: \[Nome\]

│ ├── Sub-Avatar 1.1: \[Desiderio + Esperienza\]

│ │ └── Ads: Ad 1, Ad 2, Ad 3

│ ├── Sub-Avatar 1.2: \[Desiderio + Emozione\]

│ │ └── Ads: Ad 1, Ad 2

│ └── Sub-Avatar 1.3: \[Desiderio + Comportamento\]

│ └── Ads: Ad 1

├── 📄 Core Avatar 2: \[Nome\]

│ └── \[Ripeti struttura\]

### **Step 6.2: Piano di Testing**

**Settimana 1-2:**

- Testa 5 Sub-Avatar diversi dello stesso Core Avatar

- 2-3 ads per Sub-Avatar

- Budget: Distribuito equamente

**Settimana 3-4:**

- Scala i Sub-Avatar vincenti

- Crea variazioni dei Sub-Avatar che funzionano

- Taglia quelli che non performano

**Metriche da Monitorare:**

- CTR (Click-Through Rate)

- CPM (Cost Per Mille)

- CPC (Cost Per Click)

- Conversion Rate

- ROAS (Return on Ad Spend)

## **FASE 7: SCALING STRATEGICO**

### **Per Fatturato da €0 a €100k/mese:**

✅ 1 Core Avatar (basato su Desiderio)

✅ 10-20 Sub-Avatar specifici

✅ Focus: Profondità \> Ampiezza

✅ Obiettivo: Diventare MOLTO bravo con 1 Avatar

**Azioni Concrete:**

1.  Scegli 1 desiderio che i tuoi competitor stanno scalando

2.  Crea 15 Sub-Avatar attorno a quel desiderio

3.  Non cambiare Core Avatar per almeno 2-4 settimane

4.  Se proprio non funziona dopo 4 settimane, cambia desiderio

### **Per Fatturato da €100k a €1M/mese:**

✅ 1-2 Core Avatar

✅ 20-30 Sub-Avatar totali

✅ Inizi a poter andare leggermente più ampio

✅ Obiettivo: Migliorare execution

### **Per Fatturato da €1M a €10M/mese:**

✅ 3-10 Core Avatar

✅ 50+ Sub-Avatar

✅ Avatar più ampi

✅ Focus: World-class execution + Volume

## **CHECKLIST FINALE**

### **✅ Verifica Pre-Launch**

**Prima di lanciare le tue ads, assicurati di aver:**

- Identificato 1 Core Avatar chiaro basato su Desiderio

- Creato almeno 10 Sub-Avatar combinando 2+ categorie

- Scritto 3-5 ads per i tuoi top 5 Sub-Avatar

- Verificato che ogni ad parli specificamente al Sub-Avatar

- Organizzato tutto in un database tracciabile

- Impostato le metriche di tracciamento corrette

### **✅ Review Settimanale**

**Ogni lunedì, chiediti:**

- Quali Sub-Avatar hanno performato meglio?

- Cosa hanno in comune i vincenti?

- Posso creare più Sub-Avatar simili?

- Ci sono categorie che funzionano meglio?

- Sto andando abbastanza profondo o troppo ampio?

## **ERRORI COMUNI DA EVITARE**

### **❌ Errore \#1: Iniziare con i Dati Demografici**

**Invece:** Inizia sempre con Desiderio o Esperienza

### **❌ Errore \#2: Cambiare Core Avatar Troppo Presto**

**Invece:** Dai almeno 2-4 settimane con testing consistente

### **❌ Errore \#3: Creare Avatar Troppo Ampi**

**Invece:** Se sei sotto €500k/mese, vai più specifico

### **❌ Errore \#4: Non Documentare gli Avatar**

**Invece:** Crea un database organizzato fin dall'inizio

### **❌ Errore \#5: Avatar "Carini" ma Non Azionabili**

**Invece:** Ogni Avatar deve permetterti di scrivere un'ad immediatamente

## **TEMPLATE PRATICI DA USARE**

### **Template 1: Worksheet Core Avatar**

NOME CORE AVATAR: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

CATEGORIA BASE: □ Desiderio □ Esperienza □ Comportamento

DESCRIZIONE COMPLETA:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

DATI DI SUPPORTO DALLA RICERCA:

\- Quote 1: "\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_"

\- Quote 2: "\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_"

\- Quote 3: "\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_"

DIMENSIONE STIMATA AUDIENCE: □ Piccola □ Media □ Grande

LIVELLO DI URGENZA: □ Basso □ Medio □ Alto

COMPETITOR CHE LO TARGETIZZANO:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

### **Template 2: Worksheet Sub-Avatar**

SUB-AVATAR NOME: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

CORE AVATAR PARENT: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

CATEGORIE COMBINATE:

1\. \[Categoria Base\]: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2\. \[Categoria Aggiunta\]: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3\. \[Categoria Aggiunta - opzionale\]: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

DESCRIZIONE COMPLETA:

Una persona che \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

e anche \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

e si sente \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

HOOK POTENZIALI:

1\. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

2\. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

3\. \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

TEST STATUS: □ Da Testare □ In Test □ Vincente □ Non Funziona

### **Template 3: Ad Copy da Avatar**

SUB-AVATAR: \_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

TITOLO (chiama out l'avatar):

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

PRIMO PARAGRAFO (mostra che capisci):

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

AGITAZIONE/EMPATIA:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

SOLUZIONE (meccanismo):

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

PROVA SOCIALE:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

CTA:

\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_\_

## **RISORSE BONUS**

### **Framework Veloce: Domande per Ogni Categoria**

**DESIDERI:**

- Cosa vuole ottenere questa persona?

- Qual è il risultato finale che desidera?

- Perché lo vuole? (desiderio core)

**ESPERIENZE:**

- Cosa ha già provato?

- Cosa gli è successo?

- Quale situazione sta vivendo ora?

**EMOZIONI:**

- Come si sente riguardo alla situazione?

- È un'emozione primaria (gioia, paura, rabbia, etc.)?

- Perché si sente così?

**COMPORTAMENTI:**

- Cosa fa sempre questa persona?

- Cosa non fa mai?

- Come agisce in risposta al problema?

**DATI DEMOGRAFICI:**

- Ci sono dati demografici essenziali per il prodotto?

- Il prodotto funziona meglio per un demografico specifico?

**CONCLUSIONE**

**Ricorda il Principio Fondamentale:**

> "Gli Avatar non sono liste demografiche. Sono persone reali con desideri, esperienze, emozioni e comportamenti specifici. Quando capisci VERAMENTE chi sono, puoi creare ads che sembrano parlare direttamente a loro. E quando le persone sentono 'questo sono io', comprano."

**Il Tuo Obiettivo:**

Tra 30 giorni, dovresti avere:

- ✅ 1-2 Core Avatar validati

- ✅ 15-20 Sub-Avatar testati

- ✅ 5-10 Sub-Avatar vincenti

- ✅ Un sistema ripetibile per creare nuovi Avatar

**Inizia ORA. Non domani. ORA.**

Il miglior momento per creare Avatar efficaci era 6 mesi fa. Il secondo miglior momento è adesso.

Vai e crea Avatar che stampano soldi! 💰

🖤 FASE 6: Costruire Core Avatars

# **Come Costruire Core Avatars**

## **Introduzione**

Questa guida ti insegna a costruire "Core Avatars" (profili dei clienti ideali) per creare advertising più efficaci. L'esempio utilizzato sono le tende oscuranti (blackout blinds), ma il metodo è applicabile a qualsiasi prodotto.

## **FASE 1: Comprendi il Tuo Prodotto**

### **Step 1: Analizza Features e Benefici**

Rispondi a queste domande:

- Come funziona il tuo prodotto?

- Quali sono le caratteristiche principali?

- Quali benefici offre?

- Quali desideri soddisfa?

**Esempio Blackout Blinds:**

- **Features**: Tagliati su misura, sigillo speciale, nastro forte, facile installazione

- **Benefici**: Oscuramento totale, isolamento termico, riduzione rumore

- **Desires**: Sonno migliore, controllo ambiente, salute

## **FASE 2: Identifica i Desires Primari**

### **Step 2: Usa l'AI per Brainstorming Iniziale**

Utilizza un prompt AI (Claude/ChatGPT) per generare una lista di potenziali desires:

"Analizza questo prodotto \[descrizione\] e identifica:

\- I desires che le persone hanno

\- I benefici che cercano

\- I problemi che vogliono risolvere"

### **Step 3: Filtra i Desires**

**Elimina desires che sono:**

- Troppo generici ("vuole soluzioni che funzionano")

- Non collegati al prodotto

- Eccessivamente ampi per il tuo livello di business

**Mantieni desires che sono:**

- Specifici e collegati al prodotto

- Misurabili in termini di mercato

- Testabili con advertising

## **FASE 3: Categorizza per Tipo di Avatar**

### **Step 4: Focus su Desire-Based Avatars (Raccomandato)**

I **Desire-Based Avatars** sono i più efficaci. Identifica 2-4 desires principali:

**Esempi dalla lezione:**

1.  **Desire 1**: Vuole sonno ristoratore

2.  **Desire 2**: Vuole migliorare la propria salute

3.  **Desire 3**: Vuole dormire in un ambiente silenzioso

4.  **Desire 4**: Vuole oscurità totale

## **FASE 4: Valuta con la Scala Desire**

### **Step 5: Analizza Scope, Urgency, Staying Power**

Per ogni desire, valuta:

**SCOPE** (Quante persone lo condividono?)

- Alto: "Vuole migliorare la salute" 🔴 Molto ampio

- Medio: "Vuole sonno ristoratore" 🟡 Medio

- Basso: "Vuole dormire in silenzio" 🟢 Specifico

**URGENCY** (Quanto è urgente?)

- Alta: Problema attivo e fastidioso

- Media: Desiderio presente ma non critico

- Bassa: "Sarebbe bello averlo"

**STAYING POWER** (Si rinnova nel tempo?)

- Alto: Il desiderio persiste (es. salute)

- Medio: Si rinnova periodicamente (es. sonno)

- Basso: Una volta risolto, non serve più (es. rumore)

### **Step 6: Posiziona sulla Scala di Business**

**Se sei 0-100K/mese**: Parti da desires SPECIFICI (basso scope, alta urgency)

- Esempio: "Vuole dormire in ambiente silenzioso"

**Se sei 100K-1M/mese**: Usa desires MEDI

- Esempio: "Vuole sonno ristoratore"

**Se sei 1M-10M/mese**: Puoi attaccare desires AMPI

- Esempio: "Vuole migliorare la salute"

## **FASE 5: Ricerca di Mercato**

### **Step 7: Analizza Facebook Ads Library**

1.  Cerca il tuo prodotto o categoria

2.  Osserva cosa dicono i competitor

3.  Identifica:

    - **Labels** (etichette): "light sleeper", "shift worker"

    - **Desires nascosti**: "sonno durante il giorno"

    - **Angoli specifici**: "design aesthetic", "nursery"

    - **Livelli di sofisticazione** del mercato

**Cosa cercare:**

- ✅ Patterns ricorrenti

- ✅ Desires non sfruttati

- ✅ Linguaggio specifico usato

- ✅ Nicchie molto specifiche

### **Step 8: Ricerca su Reddit**

Cerca subreddit rilevanti e thread:

\- "How to improve deep sleep"

\- "Best blackout solutions"

\- "\[tuo prodotto\] recommendations"

**Cosa annotare:**

- Linguaggio reale degli utenti

- Problemi specifici menzionati

- Soluzioni già provate (product experiences)

- Termini tecnici (es. "REM sleep")

### **Step 9: Verifica con AI**

Quando trovi nuovi termini/concepts:

"Claude, che percentuale di persone conosce \[termine\]?

Considerando persone con reddito disponibile per investire

in \[categoria prodotto\], quanti lo conoscerebbero?"

## **FASE 6: Costruisci il Core Avatar**

### **Step 10: Crea il Template Avatar**

**Formula Base:**

DESIRE-BASED CORE AVATAR \#\[numero\]

Desire: \[Vuole/Ha bisogno di...\]

Scope: \[Ampio/Medio/Specifico\]

Urgency: \[Alta/Media/Bassa\]

Staying Power: \[Alto/Medio/Basso\]

Livello Business Target: \[0-100K / 100K-1M / 1M-10M\]

**Esempio Compilato:**

DESIRE-BASED CORE AVATAR \#1

Desire: Vuole sonno ristoratore

Scope: Medio (molte persone, ma non tutti)

Urgency: Media-Alta (dipende dalla situazione)

Staying Power: Alto (desiderio continuo)

Livello Business Target: 100K-1M/mese

### **Step 11: Aggiungi Note di Ricerca**

Per ogni avatar, documenta:

- **Potential Headlines** (hook trovati nella ricerca)

- **Labels** (come si definiscono queste persone)

- **Product Experiences** (cosa hanno già provato)

- **Behaviors** (cosa fanno regolarmente)

- **Informazioni chiave** (statistiche, facts)

## **FASE 7: Identifica Sub-Avatars (Anticipazione)**

### **Step 12: Crea Sub-Avatars Basici**

**Formula Sub-Avatar:**

Core Desire: \[Desire principale\]

\+ Behavior: \[Cosa fanno\]

\+ Experience: \[Cosa hanno vissuto\]

\+ Demographics: \[Chi sono\]

**Esempio:**

SUB-AVATAR 1.1

Desire: Vuole migliorare la salute

Behavior: Fa investimenti smart per la salute

Label: "Health-conscious investor"

Hook Potenziale: "Se sei il tipo di persona che investe

nella propria salute..."

## **FASE 8: Genera Headline Ideas**

### **Step 13: Usa AI per Headline Generation**

Prompt base:

"Ho un core avatar: \[descrizione desire + behavior/experience\].

Dammi 5 headline per ads che parlino a questa persona.

Il prodotto è \[descrizione\]."

**Esempio dalla lezione:**

- Input: "Persona vuole migliorare deep sleep, ha provato magnesio"

- Output: "Magnesium got you sleeping longer. This gets you sleeping deeper."

### **Step 14: Collega Research a Headlines**

Trasforma insights di ricerca in hooks:

- Reddit quote: "9PM looks like middle of the night"

- Diventa: "Turn 9PM into 2AM" (headline)

## **FASE 9: Validazione e Testing**

### **Step 15: Checklist Pre-Launch**

Prima di lanciare ads basate sul tuo avatar:

**✓ Il desire è abbastanza specifico?**

- ❌ "Vuole soluzioni che funzionano" (troppo vago)

- ✅ "Vuole sonno ristoratore" (specifico)

**✓ Hai fatto ricerca approfondita?**

- Almeno 30-60 minuti su Reddit

- Analisi 20+ ads competitor

- Verifica informazioni con fonti multiple

**✓ Puoi articolare chiaramente l'avatar?**

- Chi è questa persona?

- Cosa vuole?

- Perché lo vuole?

- Cosa ha già provato?

**✓ Hai headline testabili?**

- Almeno 3-5 hook diversi per avatar

## **FASE 10: Organizzazione e Documentazione**

### **Step 16: Crea il Documento Avatar**

**Struttura consigliata:**

PRODOTTO: \[Nome Prodotto\]

DATA: \[Data ricerca\]

═══════════════════════════════════════

DESIRE-BASED CORE AVATARS

1\. \[Nome Avatar\] - Scope: \[X\] \| Urgency: \[X\] \| Staying Power: \[X\]

Desire: \[...\]

Target Business Level: \[...\]

SUB-AVATARS:

1.1 \[Behavior/Experience\]

1.2 \[Behavior/Experience\]

HEADLINES POTENZIALI:

\- \[headline 1\]

\- \[headline 2\]

LABELS: \[label1, label2\]

RICERCA: \[key insights\]

═══════════════════════════════════════

BEHAVIOR-BASED AVATARS (Opzionale)

\[Stessa struttura\]

═══════════════════════════════════════

NOTES & INSIGHTS

\- \[Pattern osservati\]

\- \[Opportunità uniche\]

\- \[Angoli non sfruttati\]

## **BEST PRACTICES & MINDSET**

### **✨ Principi Chiave**

1.  **Start with ONE core avatar** - Non crearne 20 subito

2.  **Desire-based first** - È il più efficace per iniziare

3.  **Research is everything** - "Your work works more on you than you work on it"

4.  **Use AI as assistant, not oracle** - Verifica sempre

5.  **Think in ads** - Ogni insight deve poter diventare un ad

### **⚠️ Errori Comuni da Evitare**

- ❌ Desires troppo ampi senza validazione mercato

- ❌ Usare solo AI senza ricerca umana

- ❌ Non collegare avatar a headline concrete

- ❌ Analizzare troppo senza agire

- ❌ Ignorare il livello di business appropriato

### **🎯 Quando Sei Pronto**

**Segnali che hai un buon Core Avatar:**

- Riesci a visualizzare questa persona

- Hai almeno 3 headline diverse per testarla

- Conosci cosa hanno già provato

- Sai perché il tuo prodotto è la soluzione

- Puoi scrivere un ad in 10 minuti

## **QUICK START CHECKLIST**

Usa questa per la tua prima sessione:

- Descrivi prodotto: features → benefits → desires

- Genera 5-10 desires con AI

- Filtra a 2-4 desires più promettenti

- Valuta con scala Scope/Urgency/Staying Power

- 30 min ricerca Facebook Ads Library

- 30 min ricerca Reddit

- Identifica 3 labels/behaviors chiave

- Genera 5 headlines per desire

- Documenta in template avatar

- Scegli 1 avatar per primo test

## **PROSSIMI PASSI**

Dopo aver creato il tuo Core Avatar:

1.  **Sviluppa Sub-Avatars** dettagliati (prossimo modulo)

2.  **Scrivi ad variations** per ogni sub-avatar

3.  **Testa sistematicamente** partendo dal più specifico

4.  **Scala** verso desires più ampi man mano cresci

**Remember**: L'obiettivo finale è creare **ads vincenti**. Ogni parte di questa ricerca deve poter tradursi in marketing concreto.

COMPRENDERE IL TUO PRODOTTO - PARTE 1

# **COMPRENDERE IL TUO PRODOTTO - PARTE 1**

## **La chiave del successo nel marketing: conoscere veramente cosa vendi**

## **1. PERCHÉ DEVI COMPRENDERE IL TUO PRODOTTO**

**Non puoi vendere ciò che non comprendi.** Questo è il principio basilare che molti ignorano.

Il problema principale è che la maggior parte delle persone crede di conoscere il proprio prodotto, ma non ha mai fatto la ricerca necessaria per capire davvero cosa sta accadendo sul mercato. Senza questa comprensione profonda:

- Non puoi creare desideri efficaci

- Non puoi identificare i giusti livelli di sofisticazione del mercato

- Non puoi creare avatar mirati

- Le tue agenzie (se ne usi) non riusciranno a vendere per te

## **2. LA DOPPIA REALTÀ DI OGNI PRODOTTO**

Ogni prodotto è in realtà **due prodotti in uno**:

### **A) IL PRODOTTO FISICO**

Ciò che il prodotto **è** materialmente:

- Materiali e ingredienti

- Dimensioni e peso

- Caratteristiche fisiche misurabili

- Componenti manifatturieri

**Esempio della tazza in acciaio inossidabile:** È un pezzo di metallo modellato a forma circolare con un marchio stampato sopra.

### **B) IL PRODOTTO FUNZIONALE**

Ciò che il prodotto **fa** per l'utente:

- I benefici che offre

- I problemi che risolve

- Le prestazioni che garantisce

- Le esperienze che crea

**Esempio della tazza:**

- Contiene l'acqua

- Mantiene l'acqua fredda (grazie all'acciaio inossidabile)

- Offre fiducia grazie al marchio riconosciuto

- Evita il consumo di microplastiche (rispetto alle bottiglie di plastica)

## **3. LA REGOLA D'ORO DEL MARKETING**

**Le persone comprano ciò che il prodotto FA, non ciò che il prodotto È.**

Questo è cruciale da comprendere. Non acquisti una tazza perché è "un pezzo di metallo", ma per tutti i benefici che ti offre: acqua fredda, salute, praticità, affidabilità del marchio.

### **L'errore comune**

Molti marketer si concentrano solo sulle caratteristiche tecniche (features) invece che sui benefici funzionali. Dire "acciaio inossidabile" non è abbastanza. Devi spiegare che **l'acciaio inossidabile mantiene l'acqua fredda** e perché questo è importante per l'utente.

## **4. L'ERRORE PIÙ COMUNE: DESIDERI IRRAGGIUNGIBILI**

**Il problema:** Molti cercano di targetizzare desideri che il loro prodotto non può soddisfare.

### **Come funziona**

Il tuo prodotto è al centro, circondato da numerosi desideri possibili del mercato. Il tuo **marketing è il ponte** che collega il prodotto al desiderio.

**Esempio estremo:** Se vendi cappelli ma vuoi risolvere il mal di schiena, dovrai creare un ponte narrativo impossibile (forse inventando una storia su un contadino che non deve spalmare crema solare sulla schiena perché porta un cappello...).

### **La zona ottimale**

Esistono desideri più vicini al tuo prodotto e altri più lontani:

- **Vicini:** Più competitivi ma più credibili e facili da comunicare

- **Lontani:** Meno competitivi ma molto difficili da rendere credibili

Devi operare nella zona in cui il tuo prodotto può realisticamente soddisfare il desiderio dichiarato.

### **Quando i desideri sono già soddisfatti**

Anche se un desiderio esiste ed è reale (esempio: acqua fredda), se il mercato è già saturo di soluzioni efficaci, la tua proposta non funzionerà a meno che tu non offra un **meccanismo nuovo o migliore**.

## **5. IL SEGRETO DEI BRAND DA MILIARDI: PARTIRE DAL CLIENTE**

### **Il processo inverso**

I brand più grandi al mondo non iniziano dal prodotto, ma da:

1.  Il cliente e i suoi desideri

2.  I problemi reali che vuole risolvere

3.  Solo dopo creano o trovano il prodotto giusto

### **Esempi concreti**

- **Hexclad:** Il fondatore odiava tutte le padelle perché si bruciavano e rovinavano rapidamente. Ha creato padelle che durano per sempre. Valore: circa 1 miliardo di dollari.

- **Ridge Wallet:** I portafogli tradizionali erano ingombranti e disordinati. Hanno creato portafogli sottili e compatti.

- **Grunts (integratori gommosi):** Le persone non volevano bere il succo verde di AG1. Hanno trasformato il prodotto in caramelle gommose. Hanno anche innovato gli avatar: invece di adulti, hanno targetizzato genitori che vogliono far assumere vitamine ai bambini.

### **La lezione pratica**

Prima di scegliere un prodotto casuale, fai ricerca su:

- Cosa vogliono veramente le persone

- Quali problemi lamentano

- Quali soluzioni esistenti non funzionano

Solo dopo trova o crea il prodotto che risolve quel problema specifico.

## **6. I MECCANISMI DEL PRODOTTO**

### **Definizione**

Il **meccanismo** è il modo specifico in cui il tuo prodotto crea i risultati. Non è **cosa** fa, ma **come** lo fa.

### **Esempi pratici**

**Tazza in acciaio inossidabile:**

- Cosa fa: Mantiene l'acqua fredda

- Come lo fa (meccanismo): Utilizza l'acciaio inossidabile che isola termicamente

**Umidificatore CarePod:**

- Cosa fa: È facile da pulire

- Come lo fa (meccanismo): È fatto in acciaio inossidabile (materiale non poroso)

**Integratore per perdere peso:**

- Versione base: "Il nostro integratore ti fa perdere peso"

- Con meccanismo: "Il nostro integratore blocca l'assorbimento degli zuccheri, così il tuo corpo brucia grassi"

- Con meccanismo + ingrediente: "Il peptide 47D blocca l'assorbimento degli zuccheri, così il tuo corpo brucia grassi invece di accumularli"

### **Perché i meccanismi sono fondamentali**

- **Creano credibilità** nei mercati sofisticati

- **Danno nuova speranza** alle persone che hanno già provato altre soluzioni

- **Ti differenziano** da tutto ciò che hanno già testato

I meccanismi fanno credere alle persone che questa volta funzionerà, anche se tutto il resto ha fallito.

## **7. LA GERARCHIA DELLA CONOSCENZA**

Prima di preoccuparti di:

- Chi targetizzare

- Cosa dire

- Come scalare

- Strategie ABO o CBO

**Devi padroneggiare cosa fa il tuo prodotto.** Tutto il resto diventa più facile di conseguenza.

### **Il processo corretto**

1.  Comprendi il tuo prodotto (fisico + funzionale)

2.  Identifica i meccanismi

3.  Mappa i desideri che può soddisfare

4.  Crea gli avatar appropriati

5.  Sviluppa le campagne marketing

Saltare i primi passaggi è il motivo per cui molte campagne falliscono.

## **CONCLUSIONE**

La comprensione profonda del prodotto è la base di tutto il marketing efficace. Devi conoscere:

- **I due tipi di prodotto:** fisico e funzionale

- **La differenza tra caratteristiche e benefici:** le persone comprano i benefici

- **I meccanismi:** come il prodotto crea i risultati promessi

- **L'allineamento desideri-prodotto:** non inseguire desideri irraggiungibili

Senza questa chiarezza, non potrai selezionare i desideri giusti, creare avatar efficaci o sviluppare campagne che convertono. Il prossimo passo sarà compilare il template di analisi del prodotto per mettere in pratica questi concetti e costruire una base solida per tutte le attività di marketing successive.

COMPRENDERE IL TUO PRODOTTO - PARTE 2

# **COMPRENDERE IL TUO PRODOTTO - PARTE 2**

## **Guida pratica: compilare manualmente il documento di analisi del prodotto**

### **INTRODUZIONE**

Questa lezione mostra come compilare manualmente il template di analisi del prodotto, partendo da zero senza ricerche pregresse. È destinata a chi compila il documento per la prima volta e non ha ancora informazioni dettagliate. Viene utilizzato come esempio pratico il brand "Dog Friendly Co" e il loro prodotto: una pettorina per cani.

## **1. INFORMAZIONI BASE DEL PRODOTTO**

### **Nome del prodotto**

Identificare chiaramente cosa si sta vendendo.

**Esempio:** Dog Harness (Pettorina per cani)

### **Prezzo**

Indicare il prezzo di vendita attuale, incluse eventuali promozioni.

**Esempio:** \$42 (prezzo scontato da \$52)

## **2. COME FUNZIONA IL PRODOTTO**

### **Descrizione completa**

Spiegare il processo, il metodo di utilizzo e i risultati che offre.

**Esempio per la pettorina:** "Il Dog Friendly Harness è la pettorina per cani più comoda e facile da usare, supportata da una garanzia di vestibilità perfetta di 60 giorni. È resistente allo sfregamento, si può indossare in 2-3 secondi, è leggera, può essere personalizzata con targhetta nome personalizzata e ha un design anti-soffocamento per passeggiate confortevoli."

### **Versione semplificata (livello di lettura 6° elementare)**

È fondamentale riscrivere la descrizione in modo che sia comprensibile a tutti. La maggior parte delle persone legge a un livello di 6° elementare.

**Strumento consigliato:** Hemingway App (hemingwayapp.com) per verificare il livello di leggibilità.

**Esempio semplificato generato con Claude AI:** "La pettorina avvolge il petto e la schiena del tuo cane. Questo distribuisce la trazione quando il cane cammina, così non gli fa male al collo come farebbe un collare. Puoi metterla super velocemente, solo 2-3 secondi. Il materiale morbido non sfrega la pelle del cane. È anche molto leggera, quindi il tuo cane non si sentirà appesantito. Puoi aggiungere il nome del tuo cane per renderla speciale e il tuo cane sarà più comodo e felice durante le passeggiate perché la pettorina non gli stringe la gola."

## **3. CARATTERISTICHE PRINCIPALI (FEATURES)**

Elencare le caratteristiche fisiche e tecniche del prodotto.

**Esempio per la pettorina:**

- Fibbia sicura ITW infrangibile

- Cinghie regolabili

- Tessuto premium resistente allo sfregamento

- Maniglia robusta per maggior controllo

- Anello a D heavy-duty

- Personalizzabile con nome

### **Uso strategico di Claude AI**

Quando non si conosce una caratteristica tecnica, si può chiedere aiuto all'AI.

**Esempio:** "Cos'è una fibbia ITW?"

**Risposta di Claude:** Le fibbie ITW sono prodotte da ITW Nexus (Illinois Tool Works), un importante produttore di fibbie in plastica di alta qualità. Sono progettate per estrema resistenza agli impatti e carichi elevati, utilizzate in equipaggiamento militare, tattico, outdoor, pettorine per animali, attrezzatura medica e applicazioni marine. Sono prodotte negli USA.

## **4. BENEFICI DERIVATI DALLE CARATTERISTICHE**

Per ogni caratteristica, identificare **perché è importante** per il cliente.

### **Metodo: collegare caratteristica → beneficio**

**Caratteristica:** Fibbia ITW infrangibile\
**Benefici:**

- Il cane non scappa dalla pettorina (sicurezza)

- Prodotto fatto negli USA (qualità e patriottismo)

- Resistenza a lungo termine

**Caratteristica:** Cinghie regolabili\
**Beneficio:** Vestibilità perfetta per il cane → maggior comfort

**Caratteristica:** Anello a D heavy-duty\
**Benefici:**

- Permette di attaccare il guinzaglio frontalmente per ridurre la trazione

- Gestisce cani che tirano forte

- Non si rompe sotto pressione

**Caratteristica:** Personalizzabile\
**Benefici:**

- Esprimere la personalità del proprietario

- Identificazione rapida del cane

- Riduce il rischio di smarrimento

## **5. DESIDERI PROFONDI (ASSUMED DESIRES)**

Per ogni beneficio, chiedersi: **"Perché qualcuno lo vuole?"**

Questo rivela i desideri emotivi più profondi che il prodotto soddisfa.

### **Esempi di mappatura benefici → desideri**

**Beneficio:** Il cane non scappa dalla pettorina\
**Desiderio:** Voglio sentirmi sicuro che il mio cane sia al sicuro, non importa quanto sia eccitato o forte

**Beneficio:** Prodotto americano\
**Desiderio:** Voglio supportare i lavori americani e comprare prodotti di qualità di cui mi posso fidare

**Beneficio:** Vestibilità perfetta\
**Desiderio:** Voglio che il mio cane sia comodo e felice durante ogni passeggiata

**Beneficio:** Riduce la trazione\
**Desiderio:** Voglio passeggiate piacevoli e senza stress dove ho il controllo

**Beneficio:** Identificazione del cane\
**Desiderio:** Voglio sapere che se succede qualcosa, il mio cane troverà la strada per tornare da me

### **Uso di Claude per generare desideri**

Si possono fornire i benefici a Claude AI e chiedere di trasformarli in desideri dal punto di vista del cliente.

## **6. NUOVI MECCANISMI (USP - UNIQUE SELLING PROPOSITIONS)**

Identificare cosa rende il prodotto **veramente unico** rispetto alla concorrenza.

### **Meccanismi unici della pettorina**

**Meccanismo 1:** Targhetta nome personalizzabile integrata\
Non è comune nelle pettorine; elimina la necessità di targhette separate che tintinnano

**Meccanismo 2:** Anello a D frontale\
Non tutte le pettorine lo hanno; permette un controllo anti-trazione superiore

**Meccanismo 3:** Tecnologia militare infrangibile\
Fibbia ITW utilizzata in equipaggiamento militare e di salvataggio

**Meccanismo 4:** Sistema di aggancio rapido 2-3 secondi\
Applicazione ultra-veloce che riduce lo stress per il cane

**Meccanismo 5:** Ingegneria comfort resistente allo sfregamento\
Materiali leggeri specificamente progettati per prevenire irritazioni cutanee

### **Importanza dei meccanismi**

I meccanismi unici sono **la cosa più potente** che puoi avere. Se il tuo prodotto non ha meccanismi distintivi, sarà molto più difficile differenziarti.

## **7. ANALISI DEI MECCANISMI NASCOSTI**

Questa sezione aiuta a scoprire angoli di marketing non sfruttati attraverso domande creative.

### **A) Cosa fa il tuo prodotto che non pubblicizzi?**

Identificare benefici esistenti ma non comunicati.

**Esempio:** La tecnologia militare ITW non è attualmente pubblicizzata, ma potrebbe essere un punto di forza enorme.

### **B) Quali ingredienti/componenti hai che i concorrenti non hanno?**

**Esempi per la pettorina:**

- Targhette nome personalizzate

- Anello a D frontale (alcuni concorrenti ce l'hanno, ma non tutti)

- Fibbia ITW di grado militare

### **C) Se il prodotto funzionasse troppo bene, di cosa si lamenterebbero i clienti?**

Questa è una domanda **creativa** per generare idee pubblicitarie originali e identificare benefici inaspettati.

**Esempi generati con Claude:**

- "Le passeggiate sono così noiose ora che il cane non tira più"

- "Il mio cane è dipendente dalle passeggiate"

- "Ora anche io non vedo l'ora di fare passeggiate"

- "Gli altri proprietari si sentono male quando vedono la mia pettorina"

- "Tutti si fermano e mi chiedono dove l'ho comprata – non posso più fare passeggiate veloci"

- "Il mio cane è diventato uno spettacolo"

- "Non posso più usare le passeggiate come allenamento per le spalle"

Questi "problemi ironici" possono trasformarsi in angoli creativi per le campagne pubblicitarie.

### **D) Se qualcuno spiegasse questo prodotto a un amico, cosa direbbe?**

Creare un dialogo **naturale e casuale** (non commerciale) che suona autentico.

**Esempio generato da Claude (versione corretta per sembrare meno commerciale):**

*"L'ho comprata perché quella vecchia di Jake si è rotta – la fibbia di plastica si è spezzata un giorno quando ha fatto uno scatto improvviso verso qualcosa. Questa ha una fibbia heavy-duty che dovrebbe essere infrangibile o qualcosa del genere.*

*Sai, la cosa che mi piace davvero è quanto velocemente si mette. Sai come Jake odiava quando gli mettevamo la pettorina e cercava di indietreggiare? Questa si aggancia super velocemente, quindi c'è meno dramma. E ha il suo nome sopra, il che è carino. Ero sempre preoccupato di perdere quelle piccole targhette ID che tintinnano.*

*Ma onestamente, la più grande differenza è che non tira più così tanto. Il guinzaglio si aggancia davanti invece che dietro, quindi quando prova a tirare, lo reindirizza. Non so se è la pettorina o se sta solo invecchiando, ma le nostre passeggiate sono molto meno stressanti ora.*

*È anche resistente. Penso di averla da circa otto mesi. Nessun problema finora. Perché, Buddy ti sta dando problemi durante le passeggiate? Potresti provare qualcosa come questa. Penso di averla presa online, fammi vedere se riesco a trovare il link."*

**Questo linguaggio naturale può essere utilizzato direttamente nelle campagne pubblicitarie per creare contenuti autentici.**

## **8. I SETTE PASSAGGI PER COMPILARE IL DOCUMENTO**

Riepilogo del processo completo:

**Step 1:** Nome del prodotto e prezzo\
**Step 2:** Come funziona il prodotto (descrizione completa)\
**Step 3:** Versione semplificata (livello 6° elementare)\
**Step 4:** Caratteristiche principali (features)\
**Step 5:** Benefici derivati dalle caratteristiche\
**Step 6:** Desideri profondi associati ai benefici\
**Step 7:** Nuovi meccanismi (USP)\
**Step 8:** Analisi meccanismi nascosti (domande creative)

## **CONCLUSIONE**

Compilare manualmente il documento di analisi del prodotto è un esercizio fondamentale che **il tuo lavoro lavora su di te**. Anche se sembra basilare, tornare regolarmente a fare questo tipo di analisi aiuta a:

- Scoprire nuove idee pubblicitarie

- Identificare angoli di marketing non sfruttati

- Comprendere profondamente cosa vendi

- Generare meccanismi unici da comunicare

Il tempo investito in questo documento renderà tutto il resto (targeting, creatività, scaling) molto più facile ed efficace. Anche se hai già esperienza, **è utile tornare ai fondamentali** perché "a volte hai bisogno di essere ricordato più che di essere insegnato".

Nella prossima lezione si approfondiranno i **desideri** e come identificarli e targetizzarli correttamente.

COMPRENDERE IL TUO PRODOTTO - PARTE 3

# **COMPRENDERE IL TUO PRODOTTO - PARTE 3**

## **Utilizzare l'intelligenza artificiale per compilare rapidamente il documento di analisi del prodotto**

### **INTRODUZIONE**

Questa lezione mostra come utilizzare Claude AI per compilare automaticamente il template di analisi del prodotto in modo veloce ed efficiente. Sebbene il metodo manuale sia fondamentale per l'apprendimento, l'AI può accelerare notevolmente il processo una volta che si dispone dei documenti di ricerca necessari. Questa è la versione rapida che integra l'approccio manuale visto nella Parte 2.

## **1. PERCHÉ USARE CLAUDE AI**

### **Lo strumento consigliato**

**Claude AI è uno strumento salvavita** che si consiglia a tutti di utilizzare. Vale la pena investire nella versione a pagamento (circa \$20 al mese) per le sue capacità avanzate.

### **Vantaggi principali**

- Velocità operativa eccezionale

- Ottimizzazione del flusso di lavoro

- Capacità di processare grandi quantità di informazioni

- Generazione di contenuti basata su contesto specifico

### **Avvertenza importante**

**"Il tuo lavoro lavora più su di te di quanto tu lavori su di esso"**

Anche se l'AI è potente, fare il lavoro manualmente almeno una volta è essenziale per l'apprendimento profondo. L'AI dovrebbe essere usata per accelerare, non per sostituire completamente il processo di riflessione.

## **2. CONFIGURARE UN PROGETTO CLAUDE**

### **Creare un nuovo progetto**

Invece di usare solo una chat normale, si consiglia di creare un **Progetto Claude** dedicato per ogni brand.

**Passaggi:**

1.  Aprire Claude AI

2.  Creare un nuovo progetto

3.  Nominarlo (es. "Brand Example for Origins")

4.  Aggiungere una descrizione dell'obiettivo (prompt specifico)

### **Differenza tra chat normale e progetto**

- **Chat normale (versione gratuita):** Si possono caricare file direttamente nella conversazione

- **Progetto (consigliato):** L'AI viene "addestrata" su file specifici che rimangono come contesto permanente per tutte le conversazioni in quel progetto

## **3. DOCUMENTI DA CARICARE NEL PROGETTO**

Per ottenere risultati ottimali, Claude necessita di **tre tipi di file** come contesto:

### **A) Recensioni dei clienti**

- **Formato:** Qualsiasi file contenente feedback reali dei clienti

- **Perché è importante:** Aiuta Claude a capire come i clienti reali parlano del prodotto e quali benefici apprezzano maggiormente

- **Alternativa:** Se non hai recensioni, usa temporaneamente il documento di ricerca

### **B) Documento di ricerca**

- **Contenuto:** Tutte le ricerche di mercato, analisi dei competitor, analisi dei social media, ecc.

- **Importanza:** Fornisce il contesto di mercato necessario per comprendere dove si posiziona il prodotto

- **Nota:** Questo documento dovrebbe essere stato completato nelle fasi precedenti del processo

### **C) Documento di self-onboarding**

- **Contenuto:** Informazioni dettagliate sul brand, mission, valori, storia, caratteristiche uniche

- **Funzione:** Aiuta Claude a comprendere l'identità del brand e il posizionamento desiderato

- **Disponibilità:** Template fornito nel programma

## **4. PROMPT PER COMPILARE IL TEMPLATE**

### **Il processo semplificato**

Una volta caricati i documenti nel progetto:

1.  Copiare l'intero template di analisi del prodotto

2.  Incollarlo nella chat di Claude

3.  Aggiungere il prompt: **"Hey Claude, puoi per favore compilare il seguente template?"**

4.  (Opzionale) Aggiungere: **"Se non puoi compilare qualcosa o hai domande, fammelo sapere"**

### **Cosa genera Claude automaticamente**

Claude compila tutte le sezioni del template:

- **Step 1:** Nome del prodotto e prezzo

- **Step 2:** Come funziona il prodotto (descrizione dettagliata)

- **Step 3:** Versione semplificata (livello 6° elementare)

- **Step 4:** Caratteristiche principali

- **Step 5:** Benefici derivati dalle caratteristiche

- **Step 6:** Desideri profondi (assumed desires)

- **Step 7:** Nuovi meccanismi (USP)

- **Step 8:** Analisi meccanismi nascosti

**Esempio di output:**

PRODUCT OVERVIEW

Product Name: GARP Lines Dog Harness

Price Point: \$42 (reduced from \$52)

How does your product work?

\[Claude genera descrizione completa\]

Sixth Grade Version:

\[Claude semplifica il linguaggio\]

Features:

\[Claude elenca le caratteristiche\]

Assumed Benefits:

\[Claude mappa benefici per ogni caratteristica\]

\[... e così via per tutte le sezioni\]

## **5. VANTAGGI E LIMITI DELL'APPROCCIO AI**

### **Vantaggi**

**Velocità estrema** Ciò che richiederebbe ore di lavoro manuale viene completato in pochi minuti.

**Completezza** Claude non dimentica sezioni e mantiene coerenza in tutto il documento.

**Creatività assistita** L'AI può suggerire angoli e benefici che potresti non aver considerato.

### **Limiti e avvertenze critiche**

**Non impari molto usando solo l'AI**

Compilare il documento manualmente ti costringe a riflettere profondamente sul prodotto. L'AI toglie questo processo di apprendimento.

**Claude fa supposizioni educate**

L'AI **assume** basandosi sui dati forniti. Non ha conoscenza diretta del tuo prodotto o dei tuoi clienti reali.

**È necessaria la verifica umana**

Dopo che Claude genera il documento, devi:

- Rivedere ogni sezione attentamente

- Identificare cosa è "fluff" (riempitivo) e cosa è accurato

- Validare le supposizioni con dati reali

- Correggere eventuali errori o fraintendimenti

## **6. QUANDO USARE L'APPROCCIO AI VS MANUALE**

### **Usa il metodo manuale quando:**

- È la **prima volta** che compili il documento per un prodotto

- Vuoi **imparare profondamente** il processo

- Non hai fatto ancora ricerca approfondita sul prodotto

- Sei nuovo nel marketing e devi costruire le tue capacità analitiche

- Vuoi generare **nuove idee creative** attraverso il processo di riflessione

### **Usa il metodo AI quando:**

- Hai **già compilato** il documento manualmente almeno una volta

- Hai completato la **ricerca di mercato** approfondita

- Devi **aggiornare** rapidamente il documento con nuove informazioni

- Stai lavorando su **più prodotti** contemporaneamente

- Hai bisogno di velocizzare il workflow dopo aver padroneggiato i fondamentali

## **7. WORKFLOW CONSIGLIATO: APPROCCIO IBRIDO**

### **La sequenza ottimale**

**Fase 1 - Apprendimento (Manuale)**

1.  Compila il documento manualmente la prima volta

2.  Usa la Parte 2 come guida step-by-step

3.  Fai la ricerca necessaria mentre compili

4.  Genera i tuoi insight e idee creative

**Fase 2 - Validazione (AI-Assistito)**

1.  Dopo aver completato il lavoro manuale, carica i documenti in Claude

2.  Chiedi a Claude di compilare il template

3.  Confronta il tuo lavoro con quello di Claude

4.  Identifica gap o opportunità che hai perso

5.  Integra i migliori insight di entrambi gli approcci

**Fase 3 - Aggiornamento (AI-Veloce)**

1.  Per aggiornamenti futuri, usa Claude per velocità

2.  Rivedi sempre criticamente l'output

3.  Aggiungi manualmente insight che Claude non può generare (es. feedback diretto dai clienti)

## **8. IL PRINCIPIO DELLE "SUPPOSIZIONI ASSUNTE"**

### **Perché il documento dice "Assumed"**

Noterai che molte sezioni del template usano termini come:

- **Assumed Benefits** (Benefici Assunti)

- **Assumed Desires** (Desideri Assunti)

- **Assumed New Mechanisms** (Nuovi Meccanismi Assunti)

### **Significato importante**

Questi sono **ipotesi educate** basate su:

- La tua conoscenza del prodotto

- Ricerca preliminare

- Intuizioni di mercato

- Dati disponibili

**NON sono fatti verificati** finché non:

- Testi le campagne

- Raccogli feedback reali

- Analizzi i risultati di vendita

- Parli direttamente con i clienti

### **Il processo iterativo**

1.  **Assumi** cosa fanno il prodotto e i suoi benefici

2.  **Testa** queste supposizioni con campagne marketing

3.  **Valida** o invalida attraverso i risultati

4.  **Aggiorna** il documento con dati reali

5.  **Ripeti** il ciclo per affinare continuamente

Questo è il motivo per cui compilare manualmente almeno una volta è fondamentale: ti aiuta a distinguere tra ciò che **pensi** sia vero e ciò che **sai** essere vero.

## **9. PASSI PRATICI PER INIZIARE**

### **Checklist di implementazione**

**Preparazione:**

- \[ \] Creare un account Claude AI (preferibilmente a pagamento)

- \[ \] Creare un nuovo progetto Claude per il tuo brand

- \[ \] Raccogliere tutti i documenti necessari

**Caricamento documenti:**

- \[ \] Caricare recensioni clienti (se disponibili)

- \[ \] Caricare documento di ricerca di mercato

- \[ \] Caricare documento di self-onboarding

**Generazione:**

- \[ \] Copiare il template di analisi del prodotto

- \[ \] Incollarlo in Claude con il prompt appropriato

- \[ \] Attendere la generazione completa

**Revisione critica:**

- \[ \] Leggere ogni sezione attentamente

- \[ \] Eliminare informazioni generiche o "fluff"

- \[ \] Verificare l'accuratezza dei benefici

- \[ \] Validare i meccanismi unici dichiarati

- \[ \] Integrare con insight personali

## **CONCLUSIONE**

L'utilizzo di Claude AI per compilare il documento di analisi del prodotto è uno strumento potente per velocizzare il workflow, **ma non deve sostituire la comprensione profonda che deriva dal lavoro manuale**.

### **Il principio fondamentale**

**"Il tuo lavoro lavora più su di te di quanto tu lavori su di esso"**

Questo significa che il processo di compilazione manuale ti trasforma come marketer, affinando la tua capacità di pensare strategicamente al prodotto. L'AI può accelerare, ma l'apprendimento avviene nel fare.

### **Prossimi passi**

Dopo aver completato il documento di analisi del prodotto (sia manualmente che con AI):

1.  **Revisione approfondita** di tutte le sezioni

2.  **Validazione** delle supposizioni dove possibile

3.  **Passaggio ai desideri:** La prossima lezione approfondirà come identificare e targetizzare correttamente i desideri del mercato

4.  **Sofisticazione del mercato:** Comprendere a che livello di consapevolezza si trova il tuo pubblico

5.  **Creazione avatar:** Definire i profili cliente ideali basandosi su questa analisi

Il documento compilato diventerà la **base fondamentale** per tutte le decisioni di marketing, targeting e creatività future.

**Prompt:**

Hello, I would like to create a custom project tailored to assist our marketing agency in creating more effective, data-driven ads for our client, an E commerce Brand. Brand name: **BRAND** Brand website: **YOURWEBSITE** The purpose of this custom project is to support the following key marketing functions for this brand: Customer Understanding & Market Trends: Analyze customer surveys, buyer personas, and behavioral data to uncover customer preferences, pain points, and purchasing motivations.Identify market trends and audience segments relevant to this brand’s products. Market Research & Competitive Analysis: Gather and analyze data on competitors and broader industry trends. Identify opportunities for differentiation in brand’s positioning and advertising strategies. Creative Ideation & Strategy: Generate new creative concepts and strategies for ad campaigns based on insights from market data, customer feedback, and competitive analysis. Provide feedback on existing ideas, suggesting improvements grounded in customer insights and market trends. Scriptwriting & Copy Development: Assist with crafting persuasive, targeted scripts for ads and other marketing materials. Review and critique copy-writing to ensure it resonates with the target audience, incorporating customer pain points and desires. Ad Review & Performance Feedback Loop: Assist in analyzing post-launch ad performance by reviewing metrics such as ad spend, ROAS, hook rate, hold rate, CTR, etc. Provide insights on why certain ads performed well or underperformed, identifying key learnings from each campaign. Close the feedback loop by suggesting actionable takeaways from winning and losing ads, incorporating these learnings into future creative strategies. Knowledge Base: This project should use the attached files as its primary knowledge base and refer to the information within when providing insights or recommendations. Whenever this project provides an answer, it should be informed by the content within the knowledge base. It should autonomously apply the insights from the attached files to ensure all responses are grounded in data and relevant context. Key Responsibilities: Interpret customer feedback and survey data to identify trends and actionable insights. Suggest ad strategies, creative angles, and copy that align with market research and customer insights. Ensure all insights, scripts, and suggestions are data-driven and relevant to brand’s target audience, drawing on the knowledge base provided. Analyze ad performance post-launch, using key metrics to provide insights into ad success or failure. Instructions: Always ground your responses in the content within the knowledge base. Highlight any recommendations based on specific insights or principles from the provided data or resources. Prioritize relevance to brand’s audience, and use data to back up your suggestions."

🎨 7. STRATEGIA CREATIVA: WORKFLOW COMPLETO

# **STRATEGIA CREATIVA: WORKFLOW COMPLETO PER CREARE ADVERTISING VINCENTI**

## **Una guida sistematica per trasformare insight di mercato in campagne pubblicitarie efficaci**

## **INTRODUZIONE**

Questa lezione rappresenta il cuore del corso sull'advertising, introducendo la **strategia creativa** come disciplina fondamentale per creare campagne pubblicitarie vincenti. La strategia creativa va oltre le semplici tecniche di editing o design: è il processo sistematico che traduce i desideri profondi dei clienti, i dati di mercato e l'analisi competitiva in concetti pubblicitari capaci di generare connessioni autentiche tra prodotti e pubblico. In questa guida imparerai il workflow completo utilizzato dai migliori strategist creativi, dalla ricerca iniziale fino al testing e ottimizzazione delle campagne.

## **1. COS'È LA STRATEGIA CREATIVA**

### **Definizione Formale**

La strategia creativa è il **processo sistematico di traduzione** degli insight di mercato, dei desideri del cliente e dell'analisi competitiva in concetti pubblicitari che creano connessioni significative tra i prodotti e le loro audience.

### **Definizione Semplificata**

**Scoprire come rendere le persone interessate ad acquistare il tuo prodotto, capendo ciò che vogliono davvero.**

### **La Metafora delle Due Colline**

Per comprendere visivamente la strategia creativa, immagina questo scenario:

- **Collina 1** = Lo stato attuale del cliente (Bob)

  - Problema, dolore, desiderio insoddisfatto

- **Collina 2** = Lo stato desiderato del cliente

  - Soluzione, risultato ideale, desiderio realizzato

- **Il Ponte tra le Colline** = Il tuo prodotto

  - La strategia creativa costruisce questo ponte

  - Aiuta Bob a passare dalla Collina 1 alla Collina 2

**Il tuo compito come strategist creativo**: capire chi è Bob, quali sono i suoi problemi e desideri, e posizionare il tuo prodotto come il ponte perfetto per raggiungere i suoi obiettivi.

## **2. RESPONSABILITÀ DEL CREATIVE STRATEGIST**

### **Analisi Fondamentale**

- Analizzare i dati del cliente per identificare desideri chiave, preoccupazioni e punti di dolore

- Comprendere lo stato attuale del mercato in termini di consapevolezza e sofisticazione

- Mappare il viaggio psicologico del cliente rispetto alla categoria di prodotto

- Identificare i "mass desire" più potenti collegabili al prodotto

### **Sviluppo Strategico**

- Determinare il posizionamento ottimale nel mercato

- Identificare dove il prodotto si colloca nello spettro di consapevolezza per diversi segmenti

- Scegliere il punto d'entrata più efficace per i messaggi di marketing

- Sviluppare un meccanismo unico o angolo che differenzia il prodotto dai competitor

### **Esecuzione e Pianificazione**

- Creare hook e copy che catturano l'attenzione e scatenano risposte emozionali

- Sviluppare un'architettura di messaggi consistente attraverso tutti i canali

- Scrivere copy persuasiva e strategica

### **Chiusura del Feedback Loop**

- **Fondamentale**: processare ogni advertising creato

- Analizzare perché un'ad funziona o non funziona

- Imparare da ogni test per migliorare continuamente

- Dopo 7-10 giorni di test, valutare performance e trarre lezioni

## **3. FONDAMENTALI DELLA STRATEGIA CREATIVA**

### **Conoscere i Tuoi Clienti**

- Scopri cosa li rende felici, preoccupati o frustrati

- Comprendi quanto conoscono già il tuo prodotto

- Mappa il loro viaggio: da "non sapere nulla" a "ho bisogno di questo"

- Identifica i grandi desideri condivisi da molte persone

### **Posizionamento Rispetto ai Competitor**

- Ricerca i tuoi competitor

- Scopri come differenziarti e distinguerti

- Identifica qualcosa di speciale nel tuo prodotto che ti fa emergere

### **Livelli di Consapevolezza**

**Fondamentale**: le persone che non sanno di avere un problema necessitano di advertising completamente diverso rispetto a chi cerca attivamente una soluzione.

**Esempio pratico**:

- Persona inconsapevole: non sa che la luce blu fa male agli occhi → serve educazione

- Persona consapevole: sa del problema e cerca una soluzione → serve presentazione della soluzione

### **Creazione del Messaggio**

- Scrivi hook che rendono le persone curiose

- Assicurati che tutte le tue ad raccontino la stessa storia coerente

- Costruisci fiducia mostrando prove nell'ordine giusto

- Dipingi un'immagine vivida nella testa del cliente

## **4. IL WORKFLOW OPERATIVO COMPLETO**

### **FASE 1: ONBOARDING DEL CLIENTE**

**Quando inizi a lavorare con un brand**, la prima azione è raccogliere informazioni complete attraverso una **Onboarding Form**.

**Informazioni da raccogliere**:

- Nome dell'azienda e URL del sito

- Tutti i profili social

- Influencer o celebrity che collaborano con il brand

- Brand guidelines completi (font, palette colori, logo)

- Top 5 prodotti

- Differenziatori chiave del business

- Come si distinguono dalla competizione

- Mission e valori del brand

- Tono di voce

- Informazioni sui competitor principali

- Link a contenuti esistenti

**Perché è cruciale**: nessuno conosce il brand meglio del proprietario. Questa fase fornisce la base per tutto il lavoro successivo.

### **FASE 2: RICERCA INIZIALE**

Utilizzando **AI agents**, condurrai una ricerca di mercato approfondita che genererà un **documento di ricerca di 30-40 pagine** contenente:

- Analisi del prodotto

- Analisi del mercato

- Profilazione dettagliata dell'audience

- Studio dei competitor

- Opportunità e insights strategici

Questa ricerca ti renderà esperto del prodotto, del mercato e dell'audience prima ancora di iniziare a creare campagne.

### **FASE 3: RICERCA DATI**

**Audit dell'Ad Account**

- Richiedi accesso all'account pubblicitario (anche solo visualizzazione)

- Analizza le campagne passate

- Identifica le advertising vincenti

- Trascrivi le ad vincenti in un documento dedicato

- Analizza PERCHÉ hanno funzionato

- Estrai lezioni e pattern

**Audit dei Contenuti**

- Raccogli tutti i contenuti del brand

- Video, immagini, UGC (User Generated Content)

- Questo è essenziale: molte idee pubblicitarie vincenti nascono dall'analisi dei contenuti esistenti

- Rimani aggiornato su nuovi contenuti prodotti dal brand

**Sondaggi Post-Acquisto**

- **Dato preziosissimo**: risposte dei clienti reali

- Domande tipo: "Perché hai comprato questo prodotto?", "Qual è stata la caratteristica più utile?"

- Permette di prendere decisioni basate su dati reali

**Export delle Recensioni**

- Esporta tutte le recensioni del sito (possibile tramite app Shopify)

- Analizza cosa pensano i clienti del prodotto

- Identifica temi ricorrenti, benefici apprezzati, obiezioni

### **FASE 4: CONSOLIDAMENTO**

Crea una **cartella centralizzata** (Google Drive o locale) dove colleghi:

- Documento di ricerca AI

- Onboarding form

- Transcripts delle ad vincenti

- Report e analisi

- Sondaggi post-acquisto

- Export delle recensioni clienti

**Obiettivo**: avere tutti i dati in un unico posto, organizzati e facilmente accessibili.

### **FASE 5: SETUP - IL GROWTH GUIDE**

Il **Growth Guide** è il documento centrale dove traccerai e pianificherai tutte le tue creatività pubblicitarie.

**Struttura del Growth Guide**:

| **Campo** | **Descrizione** |
|----|----|
| **Batch Number** | Numero progressivo del gruppo di test |
| **Concept Name** | Nome del concetto (es. "Screen Time" per blue light glasses) |
| **Avatar** | A quale sub-avatar ti rivolgi |
| **Mass Desire** | Quale desiderio profondo stai attivando |
| **Awareness Level** | Livello di consapevolezza target |
| **Concept Explanation** | Spiegazione del concetto e perché dovrebbe funzionare |
| **Format** | Statico, Video o Promo |
| **Test Result** | Working → Learning → Finished (Win/Loss) |
| **Learnings** | Cosa hai imparato da questo test |

**Workflow del Growth Guide**:

1.  Segni "Working" quando inizi a lavorare sull'ad

2.  Passi a "Learning" quando l'ad è in fase di test

3.  Dopo 5-10 giorni segni "Finished" e valuti: Win o Loss

4.  **Cruciale**: scrivi le lezioni apprese da ogni test

**Tracking automatico della Win Rate**:

- Il documento calcola automaticamente la percentuale di successo

- Esempio: 3 ad testate, 2 loss = 33% win rate

- Monitoraggio in tempo reale delle tue performance

### **FASE 6: STRATEGIA E IDEAZIONE**

Questa è la fase creativa dove:

- Analizzi tutti i dati raccolti

- Generi idee per nuove advertising

- Sviluppi concetti strategici

- Pianifichi iterazioni di ad esistenti

**Tre tipologie principali di ad**:

1.  **Ideazione** - Nuova idea completamente originale

2.  **Iterazione** - Variazione di un'ad esistente

3.  **Imitazione** - Ispirazione da competitor o altre fonti

**Strumenti per la ricerca**:

- Atria

- AdSpy

- Analisi competitor

- Contenuti del brand

- Database di ad vincenti

### **FASE 7: PRODUZIONE**

Una volta che hai:

- Il concetto definito

- Il brief scritto

- La copy preparata

Passi alla fase di produzione:

- Editing video o creazione statica

- Inserimento dell'ad nella piattaforma

- Portare il concetto in vita

### **FASE 8: AI AD REVIEW**

**Sistema di ottimizzazione pre-lancio**:

Prima di lanciare qualsiasi advertising, utilizza un **AI Review System** basato su:

- Analisi di 10-15 ad vincenti reali

- Identificazione di pattern comuni alle ad di successo

- Creazione di una checklist di ottimizzazione

**Processo**:

1.  Completa la tua ad

2.  Passa l'ad attraverso l'AI Review System

3.  Verifica se la tua ad segue tutti i pattern vincenti identificati

4.  Ottimizza prima del lancio

Questo processo esiste sia per **video ads** che per **static/image ads**.

### **FASE 9: TESTING E FEEDBACK LOOP**

1.  **Lancio dell'ad** → Status "Learning"

2.  **Periodo di test** → 7-10 giorni

3.  **Analisi risultati** → Win o Loss?

4.  **Processamento**:

    - Se WIN: perché ha funzionato? Quali elementi replicare?

    - Se LOSS: cosa non ha funzionato? Come migliorare?

5.  **Documentazione** nel Growth Guide

6.  **Ritorno alla fase strategica** con nuovi insight

**Questo loop continuo** ti rende sempre più intelligente e migliora costantemente la tua win rate.

## **5. AVVERTIMENTO ETICO**

⚠️ **IMPORTANTE**: Tutte le tecniche insegnate possono essere utilizzate per manipolare le persone. Come advertiser, hai la responsabilità di:

- Usare queste conoscenze **solo per il bene**

- Non manipolare le persone

- Applicare la strategia creativa in modo etico

- Parlare ai desideri profondi delle persone con onestà

Imparerai a comunicare con i desideri e le paure più profonde delle persone - questo è un potere che va usato responsabilmente.

## **CONCLUSIONE**

La strategia creativa è l'**intersezione tra ciò che i clienti vogliono profondamente e ciò che un prodotto offre in modo unico**, comunicata nel modo più convincente possibile.

**Il sistema presentato**:

- È sistematico e ripetibile

- Combina analisi razionale con esecuzione creativa

- Si basa su dati reali e feedback continuo

- Migliora costantemente attraverso il testing

**Prossimi passi**:

- Implementare l'onboarding form

- Impostare il Growth Guide

- Iniziare la ricerca con AI

- Generare avatar e mass desires

- Creare le prime ad strategiche

**Ricorda**: ogni ad è un'opportunità di apprendimento. Chiudi sempre il feedback loop, documenta le lezioni e diventa progressivamente migliore con ogni test.

♾️ AD IDEAS 101: ITERAZIONI

# **AD IDEAS 101: ITERAZIONI**

## **Come ottimizzare e moltiplicare gli annunci performanti attraverso variazioni strategiche**

## **INTRODUZIONE**

Questa lezione spiega il concetto di "iterazione" nella creazione pubblicitaria: il processo di creare varianti di annunci che stanno già performando bene o che mostrano potenziale. Le iterazioni sono la tipologia di ad ideas più semplice da generare perché si basano su dati reali e risultati misurabili, permettendo di amplificare ciò che funziona attraverso modifiche strategiche e creative.

## **1. CONCETTO DI ITERAZIONE**

Le iterazioni sono variazioni di annunci esistenti che hanno dimostrato performance positive.

### **QUANDO FARE ITERAZIONI**

Le iterazioni si applicano a:

- **Annunci performanti**: ads che stanno raggiungendo o superando i KPI

- **Annunci con potenziale**: ads che mostrano segnali promettenti anche se non ancora profittevoli

- **Annunci che ricevono spend**: ads che catturano budget nell'account, indicando che l'algoritmo li favorisce

### **PERCHÉ LE ITERAZIONI SONO PIÙ FACILI**

- Hai già dati di performance su cui basare le decisioni

- Conosci il concept e sai che risuona con il pubblico

- Le idee fluiscono più facilmente perché hai un punto di partenza validato

- Puoi misurare direttamente l'impatto delle modifiche

**Principio fondamentale**: quando trovi qualcosa che funziona, la domanda diventa "come posso farlo ancora meglio?" anziché partire da zero.

## **2. TIPI DI ITERAZIONI COMUNI**

### **ITERAZIONI TECNICHE**

- **Cambio di hook**: sostituire l'apertura dell'annuncio con varianti più forti

- **Editing diverso**: modificare il montaggio basandosi sull'analisi di hook rate e hold rate

- **Cambio di creator**: far consegnare lo stesso script da un creator diverso (per UGC ads)

- **Cambio di formato**: trasformare un video in static ad, VSL, o contenuto organico

### **ITERAZIONI STRATEGICHE**

- **Cambio di angolo**: mantenere il concept ma modificare l'angolo di attacco

- **Approfondimento elementi vincenti**: espandere le parti che generano più engagement

- **Semplificazione**: ridurre elementi che potrebbero causare friction

- **Amplificazione emotiva**: enfatizzare gli elementi emotivi che risuonano

## **3. CASO STUDIO: FLOW POUCH - ANNUNCIO "30 GIORNI"**

### **L'ANNUNCIO ORIGINALE**

**Performance iniziale:**

- Riceveva buono spend ma non era altamente profittevole

- Mostrava chiari segnali di potenziale

- Hook molto forte: "L'ho preso per 30 giorni per vedere cosa sarebbe successo"

**Elementi vincenti identificati:**

- **Curiosity gap**: la promessa di vedere "cosa succede in 30 giorni" crea anticipazione

- **Journey format**: seguire la progressione giorno per giorno mantiene l'interesse

- **Focus su Lion's Mane**: spiegazione scientifica di come funziona l'ingrediente

- **Risultati tangibili**: benefici concreti (focus, meno distrazioni, controllo emotivo)

### **STRATEGIA DI ITERAZIONE**

Basandosi sui learnings dell'annuncio originale, sono state sviluppate variazioni:

**Nuovi hooks testati:**

- "Ecco cosa è successo dopo aver usato Flow per 30 giorni"

- "Questo è ciò che succede al tuo corpo dopo 30 giorni di Flow"

- "Ho preso Flow ogni giorno per aumentare il mio focus ed ecco cosa è successo. Risultati scioccanti."

**Nuovo formato di esecuzione:**

- AI voiceover invece di creator parlante

- B-roll sopra la narrazione

- Mantenimento della struttura "journey" settimanale

## **4. APPLICAZIONE AVANZATA: CONTENUTO ORGANICO TRASFORMATO IN AD**

### **IL RITROVAMENTO FORTUNATO**

Il team ha scoperto un creator su YouTube che aveva spontaneamente documentato il suo journey di 30 giorni con Flow Pouch, senza essere pagato o sponsorizzato.

**Vantaggi di questo contenuto:**

- **Autenticità estrema**: testimonianza genuina non sollecitata

- **Formato già validato**: conferma che il concept "30 giorni" risuona organicamente

- **Emotional storytelling**: condivisione profonda e personale

### **TECNICA DI EDITING: RETENTION STILE MR. BEAST**

L'annuncio è stato editato applicando principi di retention avanzati:

**Struttura del video:**

1.  **Hook fortissimo** (risultati finali mostrati subito)

    - "Volevo smettere con queste cose"

    - "Se funzionano, sarebbe fantastico"

2.  **Teasing dei benefici\**

    - "Solo cose positive sono successe da quando ho iniziato"

    - "Sento che stanno davvero funzionando"

3.  **Social proof anticipato\**

    - "Se vuoi provarli, ci sono stati solo benefici per me"

    - "Nessun effetto collaterale negativo"

4.  **Journey dettagliato\**

    - Settimana 1: "Mi sono svegliato pronto ad affrontare la giornata"

    - Progressione settimanale con risultati specifici

    - Testimonianze emotive (ansia eliminata, ritorno al "vecchio me")

5.  **Validazione esterna\**

    - Messaggio dell'amico: "Quei Flow pouches devono spaccare perché è bello rivederti come il tuo vecchio io"

    - Momento emotivo: "Quasi mi sono commosso leggendolo"

### **RISULTATI E LEARNINGS**

**Performance:**

- Lanciato il 10 marzo

- 4k di spend in un giorno (11 marzo)

- Non ha raggiunto il ROAS target ma ha mostrato forte potenziale

- Ha "catturato" tutto lo spend dell'account (segnale algoritmico positivo)

**Insight chiave:**

- Il formato "journey" funziona

- L'autenticità è più potente della produzione perfetta

- La progressione settimanale mantiene l'attenzione

- I momenti emotivi creano connessione profonda

## **5. ANALISI DEI LEARNINGS E FEEDBACK LOOP**

### **TESTING A/B: ANALISI DELLE VARIAZIONI**

**Test condotto su tre variazioni:**

1.  **"Stop Feeding, Start Flowing"\**

    - Con callout: "Tolerance-free focus"

    - Risultato: nessuna performance

2.  **"Addiction-Free Focus Hack"** ⭐ VINCITORE

    - Background più interessante

    - Visual più accattivante (funghi/ingredienti)

    - Risultato: migliore performance

3.  **"Hits the Same Every Time"\**

    - Risultato: nessuna performance

### **LEARNINGS STRATEGICI**

**Dal test è emerso che:**

- **Il messaging "addiction-free" risuona fortemente** con il target

- **I visual degli ingredienti (funghi)** aumentano l'interesse

- **La presentazione visiva** conta tanto quanto il copy

- **L'angolo "libertà dalla dipendenza"** è un driver emotivo potente

## **6. APPLICAZIONE DEI LEARNINGS: NUOVA ITERAZIONE**

### **STRATEGIA DI ITERAZIONE BASATA SU DATI**

Basandosi sui learnings, è stata pianificata una nuova iterazione:

**Target Avatar:** Nicotine Quitter (chi vuole smettere con la nicotina)

**Claim principale:** Focus sostenuto senza crash o nervosismo

**Market Awareness:** Solution aware (sanno che esistono alternative alla nicotina)

**Formato:** Organic-style ad con AI voiceover

**Elementi chiave da includere:**

- **Headline vincente**: "Addiction-Free Focus Hack"

- **Tono skeptical e relatable**: far sembrare che provenga da una persona reale

- **Ricerca scientifica**: backing sui funghi e sul quitting nicotine

- **Momento "fuck yeah"**: "Colpisce allo stesso modo ogni volta perché non costruisci tolleranza alla nicotina"

**Obiettivo:** Creare un ad che appaia autentico e organico, mantenendo gli elementi vincenti identificati attraverso i test precedenti.

## **7. FRAMEWORK PER ITERAZIONI EFFICACI**

### **PROCESSO IN 5 STEP**

1.  **Identifica l'annuncio base\**

    - Deve essere performante o mostrare potenziale

    - Verifica metriche: ROAS, spend catturato, engagement

2.  **Analizza gli elementi vincenti\**

    - Cosa funziona nell'hook?

    - Quali parti generano più retention?

    - Quale messaging risuona di più?

3.  **Brainstorma variazioni\**

    - Come posso fare questo in modo diverso?

    - Quali formati alternativi posso usare?

    - Quali angoli posso esplorare?

4.  **Crea le iterazioni\**

    - Static ad dal video performante

    - VSL (Video Sales Letter) basato sul concept

    - UGC con creator diverso

    - Organic-style con editing diverso

5.  **Documenta e impara\**

    - Annota cosa funziona e cosa no

    - Chiudi il feedback loop

    - Applica i learnings alla prossima iterazione

### **DOMANDE GUIDA PER GENERARE ITERAZIONI**

Quando hai un annuncio performante, chiediti:

- **Formato**: Come posso trasformarlo in static ad, VSL, o organic content?

- **Hook**: Quali altri hooks potrei testare mantenendo il concept?

- **Angolo**: Posso attaccare lo stesso desiderio da una prospettiva diversa?

- **Editing**: Posso migliorare il pacing o la retention?

- **Creator**: Un altro volto/voce potrebbe performare meglio?

- **Visual**: Quali elementi visivi posso enfatizzare o cambiare?

## **8. PERCHÉ LE ITERAZIONI SONO CRUCIALI**

### **VANTAGGI STRATEGICI**

- **Rischio ridotto**: parti da qualcosa che già funziona

- **Velocità di esecuzione**: non devi ripartire da zero nella ricerca

- **Scaling facilitato**: moltiplichi gli annunci vincenti per catturare più budget

- **Apprendimento composto**: ogni iterazione insegna qualcosa di nuovo

- **Ottimizzazione continua**: migliori progressivamente la performance

### **IL PROBLEMA REALE**

**Le iterazioni sono facili quando hai annunci performanti.** La vera sfida è generare idee quando:

- Non hai ancora nessun annuncio vincente

- Stai lottando per trovare qualcosa che mostri potenziale

- Non hai dati su cui basare le decisioni

Questa è la situazione più difficile per un media buyer o creative strategist, ed è per questo che avere un processo solido per generare "Imitation Ideas" e "Innovation Ideas" è fondamentale (argomenti delle lezioni precedenti).

## **CONCLUSIONE**

Le iterazioni rappresentano il modo più efficiente per amplificare il successo pubblicitario. La chiave sta nell'identificare con precisione cosa funziona negli annunci performanti e nel moltiplicare quei elementi attraverso variazioni creative e strategiche. Il processo richiede:

1.  Analisi rigorosa delle performance

2.  Identificazione degli elementi vincenti

3.  Creatività nell'esplorazione di formati alternativi

4.  Documentazione sistematica dei learnings

5.  Applicazione rapida degli insight

Ricorda: le iterazioni sono efficaci solo quando hai già qualcosa che funziona. Per questo motivo, il framework completo di Ad Ideation (Imitation → Innovation → Iteration) è essenziale per mantenere un flusso costante di annunci performanti, indipendentemente dalla fase in cui si trova l'account pubblicitario.

🎭 AD IDEAS 101: IMITAZIONE

# **AD IDEAS 101: IMITAZIONE**

## **Come generare idee pubblicitarie ispirandosi ad annunci esistenti senza copiare direttamente i competitor**

## **INTRODUZIONE**

Questa lezione è la prima parte di una serie di tre video dedicati alla generazione di idee pubblicitarie. Il focus è sull'imitazione: come trovare ispirazione da annunci esistenti per creare concept pubblicitari per il proprio brand. Viene spiegato come usare strumenti come Instagram, Atria, AdSpy e X per raccogliere idee, con un importante avvertimento: le imitazioni dirette raramente producono annunci vincenti, ma possono essere utili come punto di partenza creativo.

## **1. AVVERTIMENTO FONDAMENTALE SULLE IMITAZIONI**

Prima di immergersi nelle tecniche, è cruciale comprendere i limiti di questo approccio.

### **PERCHÉ LE IMITAZIONI HANNO SUCCESSO LIMITATO**

**Problema principale**: copiare esattamente un annuncio di un competitor non porta risultati perché, anche se l'esecuzione è perfetta, si può al massimo essere "secondi migliori" in quel mercato. Il competitor sta già eseguendo quella strategia.

**Le imitazioni sono tentanti perché:**

- Sono facili e veloci da creare (15 minuti)

- Richiedono poco sforzo creativo

- Danno l'illusione di aver fatto un lavoro strategico

**Realtà**: l'agenzia del relatore non ha trovato molti annunci vincenti attraverso imitazioni dirette. Questo metodo va usato con intelligenza, non come copia-incolla.

**Approccio corretto**: cercare ispirazione in format, strutture e angoli creativi, non replicare letteralmente gli annunci dei competitor diretti.

## **2. METODO 1: SOCIAL MEDIA RESEARCH**

Il primo e più semplice metodo per raccogliere idee di imitazione.

### **COME FUNZIONA**

**Processo base:**

1.  Scrollare Instagram, TikTok o Facebook durante il tempo libero

2.  Prestare attenzione agli annunci che catturano l'attenzione

3.  Analizzare mentalmente: "Perché questo annuncio funziona?"

4.  Salvare l'annuncio in un documento o app di note

**Sistema di archiviazione:**

- Creare una cartella o documento dedicato

- Salvare il link dell'annuncio

- Aggiungere una nota breve (es. "hook incredibile, potrei fare qualcosa di simile per Flow Pouch")

- Non limitarsi solo agli annunci del proprio settore

### **MINDSET RICHIESTO**

**Cambio di prospettiva**: quando si è sui social media, anche durante le pause, il lavoro di un creative strategist è identificare e analizzare annunci. Non è più solo svago passivo, ma ricerca attiva.

### **COLLABORAZIONE DI TEAM**

**Esempio dell'agenzia:**

- Canale Discord chiamato "Adinspo"

- Tutti i membri del team condividono annunci interessanti trovati online

- Esempio condiviso: brand con un typo intenzionale ("refreshment") diventato virale

- Crea un flusso costante di ispirazione creativa

**Community**: esiste anche un canale "Adinspiration" nella community del corso dove i membri possono condividere annunci e idee.

## **3. METODO 2: RICERCA SU ATRIA**

Atria è uno strumento professionale per spy ads che permette ricerche più strutturate.

### **FILOSOFIA DI RICERCA**

**Principio chiave**: NON cercare i competitor diretti. Invece, cercare brand che:

- Hanno un'estetica creativa interessante

- Producono annunci di alta qualità

- Operano in qualsiasi settore (non necessariamente lo stesso)

- Hanno una comunicazione che "vibra" con te

**Perché evitare i competitor diretti:**

- Tentazione di copiare troppo letteralmente

- Rischio di essere sempre un passo indietro

- Mancanza di differenziazione strategica

### **CASO STUDIO: 8 HOURS**

**Brand scoperto**: 8 Hours (integratore per il sonno)

**Perché è stato salvato:**

- Annunci estremamente creativi

- Esempi: "Feeling like Monday Lisa, we got you"

- "Bored of counting sheep in 2025"

- Linguaggio visivo forte e distintivo

**Come è stato utilizzato:**

Trovato un annuncio particolare: "We've done the research so we can do the sleeping"

**Analisi dell'annuncio:**

- Angolo di **trasparenza e ricerca scientifica**

- Mostra che il brand non ha paura di rivelare gli ingredienti

- Comunica l'impegno nel creare un prodotto basato su studi

**Applicazione a Flow Pouch:**

L'idea è stata trasformata in "Research Statics" - annunci statici che mostrano la ricerca scientifica dietro i prodotti Flow Pouch.

## **4. INSERIMENTO IDEE NEL GROWTH GUIDE**

Ogni idea trovata deve essere documentata sistematicamente nel Growth Guide.

### **FRAMEWORK DI DOCUMENTAZIONE**

**Campi da compilare:**

1.  **Nome del concept**: es. "Research Statics"

2.  **Target Avatar**: a chi si rivolge questo annuncio?

    - Esempio: "The Biohacker"

    - Razionale: i biohacker sono ossessionati dagli ingredienti e dalla ricerca

3.  **Desire collegato**: quale desiderio soddisfa?

    - Esempio: "Voglio ottimizzare le mie performance cognitive naturalmente"

4.  **Market Awareness Level**:

    - **Solution Aware** in questo caso

    - Il pubblico sa che esistono alternative (caffè, energy drink, mushroom coffee)

    - L'obiettivo è differenziarsi mostrando trasparenza e ricerca

5.  **Descrizione del test**: cosa si sta creando e perché si ha fiducia che funzionerà

    - Esempio: "Voglio creare static ads sulla trasparenza dietro i prodotti Flow, angolo ingredienti. Struttura: 'Abbiamo fatto la ricerca così tu puoi \[beneficio\]'"

6.  **Variazioni da testare**:

    - "Abbiamo fatto la ricerca così tu puoi concentrarti"

    - "Abbiamo fatto la ricerca così tu puoi lavorare"

    - Ogni variazione testa un desiderio diverso

7.  **Tipo di annuncio**: Imitation, Static

8.  **Risultati** (dopo il test): Winning Ad / Losing Ad

9.  **Learnings**: cosa si è imparato dal test

### **PROCESSO SETTIMANALE CONSIGLIATO**

**Workflow dell'agenzia:**

- Strategy call ogni lunedì

- Durante la settimana: raccogliere idee nel Growth Guide

- Una volta a settimana: bloccare 1 ora dedicata

- Trasformare le idee grezze in concept completi

- Spostare il concept in "Working" quando si inizia a lavorarci

**Beneficio**: controllo totale su cosa si sta testando per ogni brand/cliente.

## **5. ANALOGIA FONDAMENTALE: IL MARKETING COME MUSCOLO**

Un'importante riflessione sulla natura dell'apprendimento nel marketing.

### **IL MARKETING È COME LA PALESTRA**

**Parallelo completo:**

- **All'inizio sei fuori forma**: quando inizi con la creative strategy, è normale fare fatica

- **Non puoi sollevare 25kg subito**: non puoi aspettarti di essere un genio creativo dal primo giorno

- **Più ti alleni, più cresci**: più annunci crei, più migliori

- **Se smetti, regredisci**: fermare l'apprendimento continuo porta a perdere l'acutezza mentale

### **SVILUPPO DELLA SKILL**

**Come si sviluppa l'intuito creativo:**

- Facendo più annunci possibili

- Venendo esposti a più esempi

- Praticando continuamente l'analisi

- Testando e imparando dai risultati

**Processo di crescita:**

1.  All'inizio non si sa identificare cosa rende buono un annuncio

2.  Con l'esperienza si sviluppa un "feeling" per la qualità

3.  Si impara a riconoscere pattern vincenti

4.  Si diventa capaci di prevedere cosa funzionerà

### **ATTEGGIAMENTO NECESSARIO**

**Caratteristiche del marketer di successo:**

- **Curiosità costante**: cercare sempre nuovi modi di fare le cose

- **Fame di apprendimento**: educarsi continuamente

- **Mentalità evolutiva**: niente è scolpito nella pietra, tutto evolve

- **Resilienza**: non scoraggiarsi se all'inizio si fatica

**Reminder importante**: "Se fai schifo all'inizio, va bene. Tutti facevano schifo all'inizio. Anche io facevo schifo."

## **6. DETERMINARE IL MARKET AWARENESS LEVEL**

Una competenza cruciale che si sviluppa con la pratica.

### **ESEMPIO: RESEARCH STATICS**

**Perché è "Solution Aware":**

- I biohacker sanno che esistono caffè, energy drink, mushroom coffee come alternative

- Conoscono già le soluzioni disponibili sul mercato

- L'obiettivo è distinguersi mostrando **trasparenza e ricerca scientifica**

- Messaggio: "Abbiamo fatto la ricerca, ecco perché siamo migliori"

### **COME IMPARARE**

**Se non sei sicuro del Market Awareness Level:**

- Chiedere nella community del corso

- Condividere l'annuncio e chiedere feedback

- Con il tempo si sviluppa l'intuito

**Nota**: questo richiede pratica e non c'è una formula magica. È parte del "muscolo" da allenare.

## **7. METODO 3: ADSPY - FILTRARE PER SHARES**

Un metodo più avanzato basato su dati di engagement.

### **IL LEARNING CHIAVE**

**Insight dell'agenzia**: la maggior parte degli annunci vincenti nell'ad account hanno un buon numero di **shares** (condivisioni).

**Logica**: se le persone condividono un annuncio, significa che:

- È sufficientemente interessante da volerlo mostrare ad altri

- Ha un valore percepito (educativo, divertente, utile)

- Sta generando conversazione organica

### **COME USARE ADSPY**

**Processo:**

1.  Cercare il nome del competitor (es. "Mudwater")

2.  Filtrare per "Shares" in ordine decrescente

3.  Analizzare gli annunci con più condivisioni

4.  Identificare pattern e format vincenti

**Nota su Atria**: al momento della lezione, Atria non aveva ancora questa funzione, ma il founder aveva confermato che l'avrebbe aggiunta. Il filtro "longest running" (annunci attivi più a lungo) esiste ma è meno affidabile.

### **CASO STUDIO: ANNUNCIO MUDWATER "SPIDERS AND CAFFEINE"**

**Metriche dell'annuncio:**

- Creato: 14 ottobre 2024

- Last seen: 11 febbraio (circa 4 mesi di durata)

- 746 commenti

- 361 shares

**Contenuto dell'annuncio:**

Hook: "Gli scienziati hanno dato caffeina a dei ragni. Ecco cosa è successo."

**Struttura narrativa:**

1.  **Setup curioso**: esperimento del 1995 sugli effetti di varie droghe

2.  **Risultato scientifico**: la caffeina ha creato le ragnatele più caotiche perché sovrastimolava il sistema nervoso

3.  **Bridge al problema umano**: "Ovviamente gli umani non sono ragni, ma il jitter da caffè è reale"

4.  **Transizione al prodotto**: "Passa a Mudwater"

5.  **Benefici**: 2000mg di funghi funzionali, frazione della caffeina, energia calma senza crash

6.  **Proof**: 150 milioni di tazze spedite

7.  **Call to action**: "Provalo, il tuo cervello lo amerà"

### **PERCHÉ QUESTO ANNUNCIO È GENIALE**

**Analisi strategica:**

**Non aggredisce subito il problema**: non dice "smetti di bere caffè, fa male"

**Educa attraverso storytelling**: usa un fatto scientifico interessante e inaspettato

**Crea condivisibilità**: è il tipo di contenuto che le persone vogliono mostrare agli amici

**Fa credere senza predicare**: instilla subtilmente l'idea che la caffeina possa non essere ideale

**Transizione naturale**: dal problema scientifico alla soluzione prodotto

**Market Awareness Level: UNAWARE**

- Le persone non sanno necessariamente che la caffeina è "cattiva"

- L'annuncio le educa sul problema

- Poi le fa diventare consapevoli della soluzione

**Takeaway per Flow Pouch**: questo type di format educativo/intrattenimento può essere adattato per vari angoli.

## **8. METODO 4: RICERCA SU X (TWITTER)**

Un metodo meno strutturato ma efficace per trovare format vincenti.

### **COME FUNZIONA**

**Attività:**

- Scrollare X cercando post di advertiser e brand owner

- Vedere cosa condividono come casi di successo

- Analizzare i format che dichiarano funzionare

### **ESEMPIO: VENN DIAGRAM FORMAT**

**Post trovato su X:**

"Abbiamo testato diversi format pubblicitari. Il vincitore? Diagramma di Venn con solo due benefici chiave. Semplice, chiaro, facile da capire in secondi. Il tuo pubblico non dovrebbe dover pensare troppo, rendi le decisioni facili per loro."

**Perché il relatore ama questo format:**

- Immediata comprensione visiva

- Si ottengono tutte le informazioni con un'occhiata

- Format pulito e professionale

### **APPLICAZIONE A FLOW POUCH**

**Idea generata**: "Venn Diagram Statics"

**Target**: Nicotine Quitter

**Desire**: "Voglio ridurre l'uso di stimolanti senza sacrificare la produttività"

**Market Awareness**: Problem Aware

**Variazioni da testare:**

1.  **Versione 1**:

    - Cerchio sinistro: "Focus ed energia divini"

    - Cerchio destro: "100% senza nicotina e caffeina"

    - Intersezione: Flow Pouch

2.  **Versione 2**:

    - Cerchio sinistro: "Insanely locked in" (estremamente concentrato)

    - Cerchio destro: "Migliorare la salute cerebrale"

    - Intersezione: Flow Pouch

3.  **Versione 3**:

    - Cerchio sinistro: "Smettere con la nicotina"

    - Cerchio destro: "Sblocca il tuo pieno potenziale"

    - Intersezione: Flow Pouch

**Obiettivo del test**: capire a quali benefici il pubblico è più sensibile testando diverse combinazioni.

### **EVOLUZIONE DEL CONCEPT**

**Versione a tre cerchi:**

- Cerchio 1: "Boost Focus" (aumenta concentrazione)

- Cerchio 2: "Quit Nicotine" (smetti nicotina)

- Cerchio 3: "Keep the Ritual" (mantieni il rituale)

Razionale: gli utenti di nicotina hanno bisogno di mantenere il rituale orale, quindi questo è un beneficio aggiuntivo importante.

**Altre variazioni eseguite:**

- "Oral fixation satisfied + Brain power amplified"

- "Ditch addictive stimulants + Unlock your full potential"

**Risultato**: il graphic designer ha eseguito bellissime versioni di questi concept, dimostrando come un'idea trovata su X può trasformarsi in annunci professionali.

## **9. WORKFLOW COMPLETO: DALL'IDEA ALL'ESECUZIONE**

Riassunto del processo end-to-end per gestire le idee di imitazione.

### **STEP 1: RACCOLTA CONTINUA**

**Durante la settimana:**

- Scrollare social media con occhio critico

- Salvare annunci interessanti in un documento/app

- Aggiungere note rapide su perché l'annuncio funziona

- Cercare su Atria brand interessanti

- Usare AdSpy per trovare annunci con molte shares

- Monitorare X per format dichiarati vincenti

### **STEP 2: SESSIONE STRATEGICA SETTIMANALE**

**Una volta a settimana (es. lunedì):**

- Bloccare 1 ora di tempo dedicato per brand

- Aprire il Growth Guide

- Rivedere tutte le idee raccolte durante la settimana

- Selezionare le più promettenti

### **STEP 3: TRASFORMAZIONE IN CONCEPT**

**Per ogni idea selezionata:**

1.  Dare un nome al concept

2.  Identificare il Target Avatar più adatto

3.  Collegare a un Mass Desire specifico

4.  Determinare il Market Awareness Level

5.  Scrivere la descrizione del test

6.  Definire le variazioni da testare

7.  Categorizzare come "Imitation"

### **STEP 4: ESECUZIONE**

- Spostare il concept in "Working" quando si inizia

- Creare il copy (verrà spiegato in video successivi)

- Produrre l'annuncio (static, video, ecc.)

- Lanciare il test

### **STEP 5: LEARNING LOOP**

**Dopo il test:**

- Marcare come "Winning Ad" o "Losing Ad"

- Documentare i learnings nel Growth Guide

- Applicare gli insight ai futuri concept

- Chiudere il feedback loop

## **10. LIMITAZIONI E ASPETTATIVE REALISTICHE**

Ripasso finale sui limiti del metodo di imitazione.

### **COSA LE IMITAZIONI POSSONO FARE**

**Benefici:**

- Fornire ispirazione creativa

- Aiutare a vedere cosa funziona nel mercato più ampio

- Offrire format e strutture da adattare

- Stimolare nuove idee attraverso l'esposizione

### **COSA LE IMITAZIONI NON POSSONO FARE**

**Limiti:**

- Raramente producono annunci vincenti se copiate direttamente

- Non sostituiscono l'innovazione e l'ideation originale

- Non garantiscono successo anche se l'originale funzionava

- Possono portare a essere sempre "secondi migliori"

### **APPROCCIO BILANCIATO**

**Raccomandazione finale:**

- Usa le imitazioni come **uno** dei metodi, non l'unico

- Cerca ispirazione nei format e nelle strutture, non nel contenuto letterale

- Evita di copiare direttamente i competitor del tuo settore

- Combina l'imitazione con Ideation (idee fresche) e Iteration (ottimizzazione)

**Mindset corretto**: le imitazioni sono un punto di partenza per stimolare la creatività, non una scorciatoia per evitare il lavoro strategico.

## **CONCLUSIONE**

Le idee di imitazione rappresentano il metodo più facile e veloce per generare concept pubblicitari, ma anche il meno efficace se usato in modo superficiale. La chiave sta nell'usare questo approccio intelligentemente: cercare ispirazione in format, strutture narrative e angoli creativi piuttosto che copiare letteralmente gli annunci dei competitor.

Il vero valore delle imitazioni emerge quando si combinano con un'analisi strategica profonda: identificare il target avatar giusto, collegare ai mass desires, determinare il market awareness level e creare variazioni da testare. Ricorda che il marketing è un muscolo che si sviluppa con la pratica costante - più annunci analizzi e crei, più affinerai la tua capacità di riconoscere cosa funziona e perché.

Nei prossimi video della serie verranno esplorati metodi più avanzati: Ideation (generare idee completamente originali) e Iteration (ottimizzare annunci che già performano), completando così il framework completo per non rimanere mai senza idee pubblicitarie da testare.

💡 AD IDEAS 101: IDEATION

# **AD IDEAS 101: IDEATION**

## **Come generare idee pubblicitarie originali e data-driven che producono risultati vincenti**

## **INTRODUZIONE**

Questa lezione si concentra sull'**ideation**: il processo di generazione di idee pubblicitarie completamente originali basate su ricerca approfondita del mercato, del brand e dei clienti. La maggior parte degli annunci vincenti proviene da questo metodo, che richiede il massimo sforzo e impegno ma produce i risultati migliori proprio perché pochi brand investono così tanto nella creazione di concept freschi e unici.

## **1. PERCHÉ L'IDEATION È LA FONTE PRINCIPALE DI WINNING ADS**

### **IL VALORE DELLE IDEE ORIGINALI**

**Principio fondamentale**: la maggior parte degli annunci vincenti dell'agenzia proviene dall'ideation, non dall'imitazione o dall'iterazione.

**Perché l'ideation funziona meglio:**

- Richiede il massimo sforzo e creatività

- È il metodo più difficile da eseguire correttamente

- Pochi brand investono abbastanza energia in idee fresche

- Produce concept unici che non esistono già nel mercato

- Si basa su ricerca approfondita e comprensione profonda

**Mindset necessario**: quando fai ideation, devi entrare in uno stato di focus totale, bloccare tutte le distrazioni e concentrarti esclusivamente sulla domanda: "Come posso vendere questo prodotto in modo nuovo e efficace?"

## **2. METODO 1: STUDIARE IL MARKET RESEARCH DOCUMENT**

### **APPROCCIO ATTIVO: STUDIO CONCENTRATO**

**Imperativo fondamentale**: devi studiare. Non c'è modo di aggirarlo.

**Processo:**

1.  Bloccare tempo dedicato (1-4 ore)

2.  Leggere completamente il market research document

3.  Prendere note su tutto ciò che sembra interessante

4.  Quando trovi qualcosa di promettente, fare ricerca approfondita online

5.  Usare AI per scomporre ulteriormente le idee

**Risultato atteso**: semplicemente studiando il market research document, dovresti generare almeno 10 concept completamente nuovi da testare.

### **APPROCCIO PASSIVO: IDEE INASPETTATE**

**Momento di insight**: le migliori idee arrivano spesso quando fai le cose più casuali - sotto la doccia, durante una passeggiata, prima di dormire.

**Perché succede:**

- Il cervello non sta pensando attivamente

- Le idee dal retro della mente emergono naturalmente

- Lo stato rilassato favorisce connessioni creative

**AZIONE CRITICA**: quando hai un'idea brillante in un momento casuale:

- **Scrivila IMMEDIATAMENTE**

- Non aspettare di essere all'ufficio

- Interrompi ciò che stai facendo se necessario

- Le dimenticherai altrimenti (succede sempre)

### **L'IMPORTANZA DI DIVENTARE UN ESPERTO**

**Non basta caricare il document nel Brand AI e dimenticarsene.**

**Cosa devi fare:**

- Studiare il market research document per ore

- Diventare un esperto nel settore specifico

- Familiarizzare profondamente con il prodotto

- Comprendere completamente il mercato

- Capire chi sono i clienti e come pensano

**Espansione della ricerca:**

- Andare su YouTube e cercare video sull'argomento

- Guardare contenuti educativi sul settore

- Dedicare un'intera giornata a immergersi nella nicchia

- Imparare come le persone nella nicchia parlano e pensano

**Risultato**: quando diventi un vero esperto, sai automaticamente come posizionare il prodotto, come parlare al pubblico e quali angoli funzioneranno.

## **3. METODO 2: ANALIZZARE CONTENUTI E ADS ESISTENTI**

### **LIBRERIA DI CONTENUTI DEL BRAND**

**Processo:**

- Aprire la libreria di contenuti del brand

- Scorrere tutti i video, immagini e materiali

- Osservare quali tipi di visual hanno

- Identificare hook interessanti

- Cercare pattern nei contenuti performanti

**Obiettivo**: spesso vedere semplicemente i contenuti esistenti accende idee su come trasformarli in concept pubblicitari.

### **ANALISI DEGLI ADS PERFORMANTI**

Anche se tecnicamente è un'iterazione, può generare idee completamente fresche analizzando **perché** un annuncio funziona.

## **4. CASO STUDIO: "HIT THE SAME EVERY TIME / NO ADDICTION"**

### **L'ANNUNCIO ORIGINALE**

**Performance:**

- Stava ricevendo buono spend

- Non era altamente profittevole ma mostrava potenziale

- Conteneva un insight chiave nascosto

**Script dell'annuncio:**

"Questo è un Deep Flow Pouch ed è un assoluto cheat code se sei ambizioso. Nel momento in cui ne metti uno, sarai laser-focused e locked in entro due minuti perché contiene cinque potenti nootropici provati per metterti in uno stato di deep flow. **E la parte migliore è che non costruisci tolleranza perché non contiene caffeina o sostanze che creano dipendenza. Quindi colpiscono allo stesso modo ogni singola volta che li usi.**"

### **L'INSIGHT CHIAVE**

**La frase che ha fatto scattare tutto:**

"Non costruisci tolleranza... quindi colpiscono allo stesso modo ogni volta"

**Perché è potente:**

- Gli utenti di nicotina fumano sempre più sigarette nel tempo (da 2 a 10 a 40 al giorno)

- Costruiscono tolleranza e diventano dipendenti

- Con Flow Pouch, ottieni la stessa soddisfazione ogni volta

- Nessuna spirale di dipendenza

**Decisione strategica**: trasformare questo insight in un static ad con focus sull'angolo "addiction-free".

### **INSERIMENTO NEL GROWTH GUIDE**

**Struttura del concept:**

- **Nome**: Hit the Same Every Time / No Addiction

- **Target Avatar**: Nicotine Diehard (quelli ossessionati dalla nicotina)

- **Desire**: Ridurre l'uso di stimolanti senza sacrificare la produttività

- **Market Awareness**: Problem Aware (o forse Unaware)

- **Descrizione**: Creare static ad che comunica che non si costruisce tolleranza

**Razionale per targeting Nicotine Diehard:**

Se riesci a convincere queste persone - che amano la nicotina e rifiutano alternative - diventeranno clienti long-term di alto valore.

### **RISULTATI REALI**

**L'annuncio è stato creato e testato:**

- **Lanciato**: 3 marzo

- **Durata**: oltre 12 giorni (ancora attivo il 15 marzo)

- **Spend**: quasi 6K

- **ROAS**: poco sotto 2x

- **Acquisti**: 194

- **Fatturato**: \$11,500

**Visual dell'annuncio:**

- **Headline**: "Addiction-Free Focus Hack"

- **Visual**: prodotto con funghi AI-generated come sfondo

- **Call-out principale**: "100% Caffeine and Nicotine-Free"

- **Altri benefit**: ingredienti naturali, chiarezza mentale, energia senza jitter, benefici long-term per il cervello

### **TEST A/B CONDOTTO**

**Tre variazioni testate:**

1.  **"Stop Feeding, Start Flowing"** + callout "Tolerance-free focus"

    - Risultato: nessuna performance

2.  **"Addiction-Free Focus Hack"** ⭐ VINCITORE

    - Background più interessante

    - Visual più accattivanti (funghi/ingredienti)

    - Risultato: migliore performance

3.  **"Hits the Same Every Time"\**

    - Risultato: nessuna performance

### **LEARNINGS CHIAVE**

**Dal test è emerso:**

- Il messaging "addiction-free" risuona fortemente

- I visual degli ingredienti (funghi) aumentano l'interesse

- La presentazione visiva conta tanto quanto il copy

- Questo angolo merita ulteriore sviluppo

**Azione successiva**: creare un video ad completo dedicato esclusivamente all'angolo "addiction-free" e "hits the same every time" come iterazione del concept vincente.

## **5. CASO STUDIO: "BUCKLE MECHANISM" (NUOVO MECCANISMO)**

### **GENESI DELL'IDEA**

**Origine**: l'idea è emersa mentre il relatore registrava il video sul market research document, dimostrando come le idee possano nascere durante l'apprendimento attivo.

### **IL CONCEPT: MARKET SOPHISTICATION**

**Contesto di mercato:**

Il mercato della produttività/focus sta diventando sempre più saturo con prodotti simili:

- Nootropics vari

- Mushroom coffee

- Altri prodotti a base di funghi

**L'opportunità di Flow Pouch:**

Flow Pouch è di per sé un **completamente nuovo meccanismo** a causa della forma e del metodo di assunzione (pouches buccali invece di bevande da bere).

**Principio di Market Sophistication:**

Quando introduci un nuovo meccanismo, sali di livello nella sofisticazione di mercato e dai alle persone **nuova speranza** che questo prodotto risolverà il loro problema meglio delle soluzioni precedenti.

### **IL BUCKLE ABSORPTION METHOD**

**Cosa lo rende diverso:**

**Metodo tradizionale (mushroom coffee):**

1.  Bevi il prodotto

2.  Deve passare attraverso il sistema digestivo

3.  Deve essere processato

4.  Benefici ritardati

5.  Spesso seguito da crash pomeridiano (se contiene caffeina)

**Buckle Mechanism (Flow Pouch):**

1.  Posizioni la pouch sulla guancia

2.  Assorbimento diretto attraverso la mucosa buccale

3.  **Risultati istantanei**

4.  **Nessun crash**

5.  **Nessun slump**

6.  Solo puro focus

**Messaging chiave**: "Le pouches sono 10 volte migliori di tutti gli altri prodotti per il focus grazie al modo in cui le assumi."

### **ESECUZIONE PIANIFICATA**

**Format**: Video ad con AI voiceover maschile

**Durata**: circa 1 minuto

**Obiettivo**: educare le persone sul buckle mechanism e perché è superiore

**Tone**: educativo ma accessibile

## **6. RICERCA APPROFONDITA CON AI**

### **PROCESSO CON CLAUDE**

Dopo aver identificato un concept promettente, il passo successivo è fare ricerca approfondita usando AI.

**Setup:**

- Aprire un nuovo chat in Claude (NON nel progetto custom)

- Claude ha capacità di search internet nelle chat normali

- I progetti custom non hanno questa funzionalità (limitazione attuale)

### **ESEMPIO: RICERCA SUL BUCKLE MECHANISM**

**Prompt iniziale:**

Hey, sto lavorando su un nuovo concept pubblicitario per questo brand: \[link al sito\]

Vendono mushroom pouches che aiutano con focus, produttività, chiarezza mentale, ecc.

Stavo facendo ricerca questa settimana e questo è sicuramente in cima alla mia lista di annunci da testare:

\[copiare la descrizione del concept dal Growth Guide\]

Puoi fare più ricerca su questo concept e forse trovare fonti rilevanti e informazioni che potremmo usare quando scriviamo uno script per questo annuncio? Sarà un video ad.

Vai anche su Reddit e guarda se qualcuno sta parlando di cose che potrebbero essere rilevanti per noi quando facciamo questo annuncio. Guarda cosa dicono le persone, come lo dicono, di cosa si lamentano riguardo ai competitor, ecc.

Per favore cita esattamente cosa dicono e fornisci link alle fonti per ogni pezzo di informazione che dai così posso fare più ricerca se necessario.

### **RISULTATI OTTENUTI**

**Claude fornisce un report completo con:**

1.  **Spiegazione scientifica del buckle absorption\**

    - Fonti: pagina ingredienti del brand website

    - Wikipedia per background scientifico

    - Studi di ricerca specifici

2.  **Identificazione degli ingredienti principali\**

    - Lista dettagliata con benefici

    - Meccanismo d'azione

3.  **Insights da Reddit\**

    - Citazioni dirette con link alle discussioni

    - Sentiment degli utenti

    - Domande comuni

4.  **Competitive advantages\**

    - Come comunicare il valore

    - Angoli differenzianti

    - Positioning suggestions

### **UTILIZZO DEL REPORT**

**Cosa fare con le informazioni:**

1.  Salvare il report in un Google Doc

2.  Studiare le fonti fornite

3.  Approfondire gli aspetti più interessanti

4.  Educarsi completamente sul meccanismo

5.  Usare queste informazioni per scrivere lo script

**Importanza**: è fondamentale capire veramente come funziona ciò che vendi per scrivere script convincenti e autentici.

## **7. LEVERAGING BRAND AI: ANALISI REVIEWS E COMMENTI**

### **IL POTERE DEI CUSTOMER DATA**

Nel Brand AI Project hai caricato:

- Instagram ad comment analysis

- Facebook ad comment analysis

- Customer questionnaire results

**Questi sono miniere d'oro** per generare idee pubblicitarie autentiche.

### **PROMPT 1: IDENTIFICARE LINGUAGGIO POTENTE**

**Obiettivo**: estrarre frasi, slang, linguaggio emotivo e inside jokes che risuonano con il target.

**Prompt da usare:**

Basandoti sui reviews e i documenti di analisi commenti Facebook e Instagram che sono stati caricati nella tua knowledge base, vorrei che guardassi attraverso questi reviews/commenti e identificassi frasi potenti, slang, inside jokes, linguaggio di nicchia, linguaggio emotivo, o qualsiasi cosa simile con cui questi clienti specifici risuoneranno.

Voglio anche che cerchi copy da questi reviews che colpisca un nervo e faccia sentire qualcosa alle persone. Dovrebbero essere statements che catturano emozioni crude e impattanti e risuonano profondamente con il target audience.

Voglio che mostri un minimo di 15 frasi o detti direttamente dai reviews che sono classificati in base a quanto riconoscibili e rilevanti sono per il pubblico, con le espressioni più relatable in cima.

### **RISULTATI DEL PROMPT**

**Output di esempio (Flow Pouch):**

1.  **"Sono uno zin crackhead"** ⭐ TOP

    - Identificazione immediata del target avatar

    - Linguaggio autentico

2.  **"Voglio smettere di usare zins"\**

    - Desiderio chiaro

    - Pain point espresso direttamente

3.  **"Sembra una buona pouch da mettere in bocca per superare quel craving mentale di avere qualcosa nelle gengive"\**

    - Descrive perfettamente il benefit

    - Linguaggio emotivo e specifico

4.  **"Pulisce la mente e ti fa essere locked in"\**

    - Linguaggio del target

    - Benefit chiaramente espresso

5.  **"Ho smesso di usare zins dopo aver usato questo"\**

    - Testimonial potente

    - Prova di efficacia

6.  **"Sto smettendo con la nicotina da un anno. Questa potrebbe essere davvero una soluzione"\**

    - Speranza e desiderio

    - Lotta continua

7.  **"Zin free da 5 giorni ma sto ancora feening, quindi ho comprato 8 confezioni"\**

    - Urgenza

    - Withdrawal symptoms

    - Commitment al prodotto

### **INSIGHT IMMEDIATI**

**Dall'analisi emerge:**

- **Nicotine Diehard / Zin Crackhead è un avatar potentissimo**

- Le persone vogliono smettere ma mantenere il rituale orale

- Il linguaggio "locked in" risuona fortemente

- Molti sono in lotta attiva con la dipendenza da nicotina

**Angolo scoperto nei commenti:**

"Uno di questi nello zin" - alcune persone stanno **mischiando** Flow Pouch con zin. Questo è un potenziale angolo pubblicitario completamente nuovo.

## **8. PROMPT 2: GENERARE HEADLINES E HOOKS**

### **PARTIRE DAI HOOKS**

**Principio strategico**: quando generi idee, è spesso più efficace partire dall'hook o headline perché:

- L'hook è la parte più importante di qualsiasi annuncio

- Per static ads, l'headline determina il successo

- Un hook potente può generare l'intero concept

**Se hai un sick hook, puoi costruire l'intero annuncio attorno ad esso.**

### **PROMPT PER HOOKS**

**Obiettivo**: far generare a Claude headlines e hook ideas basate sui commenti e reviews.

**Il prompt andrà nel documento prompts** e chiede a Claude di:

- Analizzare i commenti nella knowledge base

- Identificare frasi che potrebbero diventare hooks

- Creare variazioni creative

- Focalizzarsi su ciò che cattura attenzione

### **RISULTATI E ITERAZIONE**

**Prima iterazione - risultati troppo letterali:**

Claude si focalizza troppo sulle frasi esatte dai commenti:

- "It clears the mind and gets you locked in" (buono, usabile)

- "Feel alert but calm at the same time" (decente)

- "Better sleep" (interessante ma generico)

**Feedback di miglioramento:**

Per favore non focalizzarti solo sullo scrivere questi headlines strettamente dai commenti/reviews. Usa commenti e reviews solo come ispirazione e crea le tue idee creative di headline/hook che possiamo usare negli annunci.

**Seconda iterazione - risultati migliorati:**

- **"Your afternoon crash just crashed"** (gioco di parole creativo)

- **"Your 3 p.m. second weapon"** (specifico e intrigante)

- **"Mental energy that doesn't burn out"** (benefit chiaro)

- **"The flow you've been waiting for"** (promessa emotiva)

- **"Clarity comes in pouches now"** (nuovo meccanismo)

### **UTILIZZO PRATICO**

**Da hooks a concepts:**

Una volta che hai una lista di hooks forti, puoi:

1.  Scegliere i più promettenti

2.  Sviluppare un concept completo attorno ad essi

3.  Definire target avatar e desire

4.  Creare variazioni da testare

5.  Documentare tutto nel Growth Guide

## **9. SOCIAL MEDIA RESEARCH**

Uno dei metodi preferiti del relatore per generare idee fresche.

### **RICERCA SU TIKTOK/INSTAGRAM**

**Processo base:**

1.  Cercare termini rilevanti nella tua nicchia

2.  Esempio: se vendi un hairdryer, cerca "hairdryer", "hair care", "hair routine"

3.  Osservare quale contenuto è popolare

4.  Analizzare come i creator presentano il prodotto

5.  Studiare gli elementi visivi vincenti

### **FOCUS SUI COMMENTI**

**Il vero tesoro sta nei commenti dei video virali.**

**Cosa cercare:**

- Obiezioni ricorrenti

- Domande comuni

- Linguaggio emotivo

- Pain points espressi

- Desires nascosti

### **ESEMPIO: LIFEND HAIRDRYER**

**Scenario**: video con 300K likes

**Commenti significativi trovati:**

1.  **"Le recensioni su Amazon..."** + emoji preoccupata

    - Segnale: controllare le recensioni Amazon

    - Possibili problemi da indirizzare negli ads

2.  **"Ha un diffusore per capelli ricci?"\**

    - Domanda specifica tecnica

    - Potenziale angolo per targeting

3.  **"Volevo amarlo ma secca i capelli e li lascia croccanti"\**

    - Obiezione seria

    - Deve essere affrontata nel marketing

4.  **"La potenza è troppa"** ⭐

    - Questo è oro puro

    - Può essere trasformato da negativo a positivo

    - Potenziale headline: "The Power Is Too Much"

**Azione immediata**: andare nel Brand AI Project e chiedere a Claude di generare idee su come trasformare "la potenza è troppa" in un angolo positivo.

### **TIKTOK COMMENT MINING TOOL**

**Strumento**: TikTok Comment Mining (website)

**Come funziona:**

1.  Copiare il link del video TikTok

2.  Incollarlo nel tool

3.  Il tool scarica tutti i commenti in formato CSV

4.  Scaricare il file CSV

**Utilizzo del CSV:**

1.  Aprire il file per verificare il contenuto

2.  Caricare il CSV in Claude

3.  Chiedere a Claude di analizzare:

    - Sentiment generale

    - Temi ricorrenti

    - Obiezioni comuni

    - Desires espressi

    - Linguaggio usato

**Limitazioni**: il tool a volte ha problemi con video che hanno troppi commenti, ma in generale funziona bene.

## **10. REDDIT E GIGABRAIN**

### **REDDIT: MINIERA D'ORO DI INSIGHTS**

**Perché Reddit è così prezioso:**

- Le persone sono brutalmente oneste

- Discussioni approfondite su prodotti e problemi

- Linguaggio autentico e non filtrato

- Pain points espressi chiaramente

- Comparazioni dirette tra brand

**Come usare Reddit:**

- Cercare subreddit rilevanti alla nicchia

- Leggere thread su problemi che il tuo prodotto risolve

- Analizzare come le persone descrivono i loro problemi

- Identificare pattern nel linguaggio

- Scoprire obiezioni che non conoscevi

**Raccomandazione forte**: quando trovi un thread interessante, immergiti completamente in esso. Leggi tutti i commenti, le risposte, le discussioni secondarie. **Troverai pepite d'oro** che puoi usare negli script.

### **GIGABRAIN: AI-POWERED REDDIT SEARCH**

**Cosa fa**: cerca attraverso Reddit e YouTube per rispondere a domande usando contenuti reali degli utenti.

**Esempio di ricerca:** "best hairdryer"

**Processo:**

1.  GigaBrain cerca su Reddit

2.  Analizza le discussioni

3.  Compila una risposta comprensiva

4.  Fornisce link a tutte le fonti

5.  Mostra anche video YouTube rilevanti

**Vantaggi:**

- Risparmia tempo nella ricerca manuale

- Fornisce fonti verificabili

- Dà una panoramica rapida del sentiment

- Permette poi di approfondire manualmente

**Output tipico:**

- Spiegazione dettagliata delle raccomandazioni

- Lista di brand menzionati più frequentemente

- Pro e contro discussi dagli utenti

- Link diretti ai thread originali

**Nota**: Claude può fare ricerche simili, ma GigaBrain è ottimizzato specificamente per Reddit e offre un'interfaccia dedicata.

## **11. ANSWERTHEPUBLIC: SEARCH INTENT ANALYSIS**

### **COSA FA IL TOOL**

**AnswerThePublic** mostra cosa le persone stanno cercando su Google riguardo a un termine specifico.

**Organizzazione dei risultati:**

- Domande che iniziano con "Can"

- Domande che iniziano con "How"

- Domande che iniziano con "What"

- Domande che iniziano con "When"

- Domande che iniziano con "Where"

- Domande che iniziano con "Why"

- Comparazioni ("vs")

- Preposizioni

**Visual**: le query con colore più intenso hanno volume di ricerca più alto.

### **ESEMPIO: HAIRDRYER**

**Queries interessanti trovate:**

**Can:**

- "Can hairdryer go in carry on?" → Angolo travel

**How:**

- "How hairdryer works" → Opportunità educativa

**What:**

- "What hairdryer should I buy?" → Intent di acquisto alto

**When:**

- "When hairdryer invented" → Curiosità storica

**Why:**

- "Why was the hairdryer invented?"

- "Who created the hairdryer?"

**Insight chiave**: C'è enorme interesse sulla **storia del hairdryer**.

### **APPLICAZIONE PRATICA**

**Idea generata**: creare un annuncio educativo stile "spiders and caffeine" (Mudwater) sulla storia del hairdryer.

**Struttura dell'annuncio:**

1.  Hook: fatto interessante sulla storia

2.  Educare: perché fu inventato, come si è evoluto

3.  Bridge: collegarsi ai problemi moderni

4.  Transizione: come il tuo prodotto risolve quei problemi meglio

5.  CTA: invito all'azione

**Tipo di annuncio**: Unaware - educare prima, poi vendere.

### **EXPORT E ANALISI CON AI**

**Funzionalità avanzata:**

- Esportare tutti i dati come CSV

- Caricare nel Claude Project

- Chiedere a Claude di analizzare:

  - Quali queries mostrano intent di acquisto

  - Quali rivelano pain points

  - Come collegare le searches al prodotto

  - Quali angoli sono più promettenti

## **12. PROCESSO COMPLETO E MINDSET**

### **LA CURVA DI APPRENDIMENTO**

**Verità fondamentale**: padroneggiare l'ideation richiede tempo e pratica.

**Aspettative realistiche:**

- All'inizio probabilmente farai fatica

- È normale non essere bravi subito

- Richiederà diversi tentativi

- La qualità migliorerà con l'esperienza

**Messaggio di incoraggiamento**: "Se fai schifo all'inizio, va bene. Tutti fanno schifo quando iniziano. Anche io facevo schifo. Devi solo continuare a farlo."

### **DIVENTARE COMPETENTE CON L'AI**

**Skill cruciale**: devi diventare comodo nel conversare con AI per generare idee.

**Come sviluppare questa skill:**

- Chattare regolarmente con Claude/ChatGPT

- Sperimentare con prompt diversi

- Iterare basandosi sui risultati

- Non accontentarsi della prima risposta

- Chiedere specificamente ciò che vuoi

**La qualità dei dati determina la qualità dei risultati**: migliori sono le informazioni che fornisci all'AI, migliori saranno le idee generate.

### **WORKFLOW CONSIGLIATO**

**Sequenza operativa:**

1.  **Immersione**: studiare market research document per ore

2.  **Identificazione**: trovare angoli promettenti

3.  **Ricerca AI**: approfondire con Claude/internet search

4.  **Social listening**: analizzare commenti, Reddit, TikTok

5.  **Synthesis**: combinare tutti gli insights

6.  **Ideation**: generare concept basati sui dati

7.  **Documentation**: inserire tutto nel Growth Guide

8.  **Execution**: trasformare concept in annunci

## **13. SINTESI DEI METODI**

**Ricapitolando tutti i metodi presentati:**

### **METODI CORE**

1.  **Market Research Document\**

    - Studio approfondito e immersione

    - Diventare esperto nel settore

    - Ricerca attiva e passiva

2.  **Analisi Contenuti Esistenti\**

    - Libreria di contenuti del brand

    - Ads performanti del brand

    - Estrazione di insights nascosti

3.  **Leverage Brand AI\**

    - Analisi reviews e commenti

    - Generazione headlines e hooks

    - Ricerca approfondita con AI

4.  **Social Media Research\**

    - TikTok e Instagram scroll strategico

    - Analisi commenti su video virali

    - TikTok Comment Mining tool

5.  **Reddit e GigaBrain\**

    - Immersione in discussioni autentiche

    - AI-powered Reddit search

    - Identificazione pain points reali

6.  **AnswerThePublic\**

    - Analisi search intent

    - Identificazione trend di ricerca

    - Export e analisi con AI

### **PRINCIPI TRASVERSALI**

**Per tutti i metodi:**

- **Qualità \> Quantità**: meglio poche idee eccellenti che molte mediocri

- **Data-driven**: ogni idea deve essere basata su ricerca

- **Autenticità**: usare il linguaggio reale dei clienti

- **Iterazione**: migliorare continuamente il processo

- **Documentazione**: tracciare tutto nel Growth Guide

## **CONCLUSIONE**

L'ideation è il metodo più difficile ma anche più efficace per generare annunci vincenti. A differenza dell'imitazione (facile ma poco efficace) e dell'iterazione (efficace solo quando hai già winner), l'ideation ti permette di creare concept completamente originali basati su una comprensione profonda del mercato, del brand e dei clienti.

Il processo richiede investimento significativo di tempo ed energia: devi studiare intensamente, diventare un esperto nella nicchia, usare intelligentemente gli strumenti AI, immergerti nei social media con occhio critico e analizzare sistematicamente il feedback dei clienti. Ma proprio perché pochi brand sono disposti a fare questo livello di lavoro, chi lo fa ottiene un vantaggio competitivo enorme.

Ricorda: l'ideation è una skill che si sviluppa con la pratica. Non scoraggiarti se all'inizio è difficile - è normale. Più lo fai, più diventi bravo a riconoscere opportunità, collegare insights e trasformare ricerca in concept pubblicitari vincenti. La chiave è la consistenza: continua a studiare, ricercare, sperimentare e documentare. Con il tempo, diventerai capace di generare un flusso costante di idee fresche che producono risultati reali.

📖 8. COME PIANIFICARE LE ADV

DEFINIZIONI

# **DEFINIZIONI**

**Ti preghiamo di notare che le definizioni che seguono sono quelle che abbiamo scelto di utilizzare. Alla fine, voglio che tu usi le definizioni che hanno più senso per te. Ma speriamo che queste ti aiutino a orientarti così possiamo pensare meno ai termini e alle filosofie e concentrarci solo sulla pura esecuzione.**

## **💻 3:2:2**

**⇒ 3 creatività, 2 body copy e 2 headline**

**Definizione per un dodicenne: La struttura di test che usiamo dentro Meta.**

**Esempio: TUTTO questo insieme è un Concetto.**

- **"3" = Variazioni di quel singolo Concetto**

- **"2:2" = 2 Headline + 2 Body copy per quel Concetto che inserisci dentro Meta**

## **📂 Concept/Batch/Test**

**⇒ Il numero di tracciamento per questo test**

**Definizione per un dodicenne: Il numero che usi per tenere traccia di quale test stai facendo**

**Esempi: Batch \#1, Batch \#29, Batch \#133**

## **💡 Concept/Swing**

**⇒ La strategia di test - cosa stai testando in questo batch**

**Definizione di Concetto per un dodicenne: La grande idea dietro gli annunci che vuoi testare**

**Esempi:**

- **"Testare un'iterazione su un video vincente"**

- **"Testare angoli superlativi"**

- **"Testare formato UGC"**

- **"Testare avatar diversi"**

## **🔗 Angle (Angolo)**

**⇒ La strategia di vendita - come scegli di vendere il prodotto**

**Definizione di Angolo per un dodicenne: Il motivo principale che stai dando a qualcuno per comprare**

**Esempi:**

- **"Buy It For Life" (Compralo per sempre)**

- **"Peso post-partum nonostante abbia provato tutto"**

- **"Acciaio inossidabile / Progettato da dottori / Il più pulito"**

**Intuizione chiave: Ogni annuncio ha bisogno di un angolo. Anche se il tuo concetto è "testare formati", devi comunque definire cosa stai vendendo. Se il tuo concetto è "Testare l'angolo X", il concetto diventa l'angolo. Ma per scopi di tracciamento, preferisco effettivamente ANNOTARE l'angolo due volte così possiamo essere sicuri.**

## **🔀 Variations (Variazioni)**

**⇒ Esecuzioni individuali dell'angolo/angoli**

**Definizione di Variazioni per un dodicenne: Modi diversi di comunicare il tuo motivo/motivi di vendita**

**Esempio: Se il tuo angolo è "Buy It For Life", le variazioni potrebbero essere:**

- **"Una pettorina, una vita di avventure"**

- **"Compralo una volta, avventure per la vita"**

- **"Fine del ciclo di sostituzioni"**

**Se testi angoli multipli, le variazioni potrebbero essere angoli diversi come:**

- **"Acciaio inossidabile"**

- **"Progettato da dottori"**

- **"Il più facile da pulire"**

## **🖼️ Format (Formato)**

**⇒ Come distribuisci l'annuncio**

**Definizione di Formato per un dodicenne: Il tipo di annuncio che stai creando**

**Esempio: Potresti mostrare lo stesso messaggio come:**

- **Un video di una persona reale che parla**

- **Una presentazione di immagini**

- **Solo un'immagine del prodotto**

**Ad Definitions:**

Please note that the definitions that follow are the ones we have chosen to use.\
\
At the end of the day, I want you to use the definitions that make the most amount of sense to you.

But hopefully these help guide you so we can think less about terms and philosophies and just focus on pure execution.

**💻3:2:2** ⇒ 3 creatives, 2 body copies, and 2 headlines\
**12-Year-Old Definition:** The testing structure we use inside of Meta.\
**Example:\**
*This ENTIRE thing is a Concept. “3” = Variations of that 1 Concept.\
“2:2” = 2 Headline + 2 Body copy for that Concept that you put inside of Meta.\
\
\*
📂**Concept/Batch/Test \#:**⇒ The tracking number for this test

**12-Year-Old Definition:** The number you use to keep track of which test you're on

**Examples:\**
*Batch \#1, Batch \#29, Batch \#133\*

**💡Concept/Swing** ⇒ The test strategy - what you're testing in this batch

**12-Year-Old Concept Definition:** The big idea behind the ads you want to test

**Examples:\**
*"Test an iteration on a winning video."*

*"Test superlative angles."*

*"Test UGC format"*

*"Test different avatars."*

**🔗Angle**⇒The selling strategy - how you're choosing to sell the product

**12-Year-Old Angle Definition:** The main reason you're giving someone to buy\
**Examples:\**
*"Buy It For Life"*

*"Postpartum weight despite trying everything"*

*"Stainless steel / Doctor-designed / Cleanest"*

*Key insight: Every ad needs an angle. Even if your concept is "testing formats," you still need to define what you're selling. If your concept is “Testing X Angle” the concept becomes the angle. But for tracking purposes, I prefer to actually JOT DOWN the angle twice so we can be sure.*

**🔀Variations** ⇒ Individual executions of the angle(s)\
**12-Year-Old Variations Definition:** Different ways to communicate your selling reason(s)

**Example:\**
*If your angle is "Buy It For Life," variations might be: "One harness, lifetime of adventures," "Buy it once, adventure for life," or "End the replacement cycle"*

*If testing multiple angles, variations might be different angles like "Stainless steel," "Doctor-designed," "Easiest to clean."\
\
\*
🖼️**Format** ⇒ How you deliver the ad

**12-Year-Old Format Definition:** The type of ad you're making

*Example: You could show the same message as a video of a real person talking, a slideshow of pictures, or just a product image.*

COME CREARE ANGOLI PUBBLICITARI VINCENTI

# **COME CREARE ANGOLI PUBBLICITARI VINCENTI**

## **La chiave per annunci ad alta conversione: comprendere e applicare gli angoli pubblicitari centrati sul cliente**

### **INTRODUZIONE**

Questa lezione approfondisce uno degli aspetti più critici e fraintesi del marketing: gli angoli pubblicitari (ad angles). La maggior parte dei marketer confonde concetti con angoli, concentrandosi su ciò che vogliono testare anziché su ciò che il cliente vuole. Questa lezione spiega la differenza fondamentale, mostra come estrarre angoli vincenti dai sub-avatar e introduce un potente sistema basato su AI per generare headline e hook efficaci.

## **1. LA CONFUSIONE COMUNE: CONCETTO VS ANGOLO**

### **Il problema fondamentale**

**La maggior parte dei marketer non comprende veramente cosa sia un angolo pubblicitario.** Confondono costantemente il concetto (cosa vogliono testare) con l'angolo (come vendono il prodotto al cliente).

### **Definizioni chiare**

**CONCETTO:** La grande idea che vuoi testare. È ciò che riguarda te e la tua strategia di test.

- Formati da testare

- Iterazioni

- Livelli di awareness

- Tipologie di annunci

**ANGOLO:** Come scegli di vendere il prodotto. Deve sempre essere definito. È ciò che riguarda il cliente e il motivo per cui dovrebbe comprare.

### **L'errore critico**

**La definizione di angolo del marketer medio non ha NULLA a che fare con il cliente.** Ecco perché la maggior parte degli annunci non funziona.

I marketer pensano all'angolo come al modo di posizionare il prodotto, ma in realtà pensano solo all'idea che vogliono testare, non al cliente.

## **2. ESEMPI DI FALSI "ANGOLI" (SONO CONCETTI)**

### **Analisi di un post Reddit popolare**

Un marketer ha elencato "angoli pubblicitari comuni che i brand di successo usano", ma in realtà ha elencato **concetti**, non angoli.

#### **"Us vs Them" (Noi vs Loro)**

**NON è un angolo. È un concetto.**

Ha un angolo più ampio sottinteso di "comparazione", ma **comparare COSA?** Il "cosa" è l'angolo.

**Esempio corretto:**

- Concetto: Us vs Them

- Angolo: Cosa stai effettivamente comparando (caratteristica specifica, beneficio, meccanismo)

#### **"Before and After" (Prima e Dopo)**

**NON è un angolo. È un concetto.**

Assume un angolo più ampio di "trasformazione", ma **trasformazione di COSA?** Il "cosa" è l'angolo.

#### **"Problem Aware Ads" (Annunci consapevoli del problema)**

**NON è un angolo. È un concetto.**

Stai testando annunci problem-aware, ma **di QUALE problema?** Il "cosa" è l'angolo.

#### **"Post-it Note Ads" (Annunci con post-it)**

**Questo è quasi un formato.**

Non c'è considerazione di **cosa scrivi nei post-it**. Ciò che scrivi è l'angolo, ed è più importante del semplice avere un post-it.

### **La verità scomoda**

**Se hai mai testato un formato che "apparentemente funziona per tutti" e per te non ha funzionato, è perché il tuo angolo faceva schifo.**

I formati aiutano a catturare l'attenzione (sono buoni hook e headline), ma se l'angolo è debole, nessuno comprerà solo perché hai usato un post-it o un "3 motivi perché non dovresti comprare".

## **3. IL PRINCIPIO FONDAMENTALE: CONCETTO VS ANGOLO**

### **Framework per distinguerli**

**CONCETTI:** Si concentrano su di te e su cosa vuoi testare

- "Voglio testare una versione video"

- "Voglio testare us vs them"

- "Voglio fare un'iterazione"

- "Voglio testare 3 motivi perché non dovresti comprare"

**ANGOLI:** Si concentrano sul cliente e su cosa vuole

- Perché il cliente dovrebbe comprare?

- Quale problema risolvi per loro?

- Quale desiderio soddisfi?

### **Quando concetto e angolo coincidono**

Quando il tuo concetto è testare un angolo specifico, i termini diventano intercambiabili:

**Esempio:**

- Concetto: Testare l'angolo "buy it for life" (compralo per sempre)

- Angolo: Buy it for life

**Esempio:**

- Concetto: Testare l'angolo "sleep deprived" (privato del sonno)

- Angolo: Targetizzare persone private del sonno

### **Best practice universale**

**Per ogni concetto che scrivi, chiediti sempre: "Come sto posizionando questo al cliente? Come sto scegliendo di vendere questo al cliente?"**

Anche se dici "sto testando questo angolo", scrivi comunque qual è l'angolo. Questo ti mantiene focalizzato su ciò che conta davvero.

## **4. ESERCIZIO PRATICO: IDENTIFICARE CONCETTI VS ANGOLI**

### **Esempi con soluzioni**

**1. "Versione video"**

- **È un angolo?** NO. È un concetto.

- **Perché?** Non dà al cliente un motivo per comprare.

- **Azione:** Identifica l'angolo che userai nel video.

**2. "Iterazione"**

- **È un angolo?** NO. È un concetto.

- **Perché?** Iterazione di cosa? Quale angolo stai iterando?

- **Azione:** Identifica l'angolo che stai iterando.

**3. "Stops tossing and turning" (Ferma il rigirarsi nel letto)**

- **È un angolo?** SÌ.

- **Perché?** Dà alla persona un motivo per comprare. Risolve il loro problema.

**4. "Us vs Them"**

- **È un angolo?** NO. È un concetto.

- **Perché?** Cosa stai comparando di noi vs loro? Non c'è un motivo chiaro.

- **Azione:** Identifica l'angolo della comparazione.

**5. "Brings back your energy" (Riporta la tua energia)**

- **È un angolo?** SÌ.

- **Perché?** Dà alla persona un motivo per comprare.

### **La regola d'oro**

**Se il concetto non dà al cliente un motivo per comprare, non è ancora un angolo.**

## **5. GLI ANGOLI ESISTONO SU UNO SPETTRO**

### **Il problema della complessità**

Anche dopo aver definito gli angoli, molti si chiedono:

- "Come faccio a sapere cosa è un angolo?"

- "Perché alcuni angoli sono così ampi e altri così specifici?"

- "Qual è la differenza tra angolo e non-angolo?"

**Esempio di angolo ampio:** "Superlative angle" (il migliore, il primo, il più pulito)

- Questo è quasi un concetto perché: superlativo di COSA?

- Gli angoli specifici sarebbero: "World's first doctor-designed humidifier" o "World's cleanest humidifier"

- "Clean" (pulito) è un angolo diverso

- "Doctor-designed" (progettato da dottori) è un altro angolo

### **La soluzione: i sub-avatar fanno il lavoro per te**

**Hai già trovato gli angoli che devi testare costruendo i sub-avatar.**

Se costruisci un sub-avatar, hai già il tuo angolo. Non devi preoccuparti se è troppo ampio o troppo specifico.

**Punto critico:** Quando crei il concetto e scegli l'angolo, stai già considerando l'avatar. L'angolo è essenzialmente l'avatar in forma azionabile.

## **6. PROCESSO TRADIZIONALE VS PROCESSO AVANZATO**

### **Cosa fa il 99% dei marketer (SBAGLIATO)**

1.  Guardano il loro prodotto

2.  Identificano le caratteristiche

3.  Identificano i benefici

4.  Creano un angolo generico tipo "fix your acne" (sistema la tua acne)

5.  Costruiscono un avatar superficiale: "Sarah, 32 anni, donna corporate con pelle problematica"

6.  Testano annunci con quell'angolo in vari formati

7.  Sperano che qualcosa funzioni

**Risultato:** Il 99% delle volte non funziona perché non stanno davvero considerando il cliente.

### **Cosa fanno i marketer del top 1% (CORRETTO)**

1.  **Iniziano dal prodotto:** Cosa fa il mio prodotto?

2.  **Identificano i desideri:** Perché qualcuno vuole questo beneficio?

3.  **Costruiscono avatar basati sui desideri:** Cosa può effettivamente offrire il mio prodotto?

4.  **Identificano un core avatar** (o multipli per brand scalati)

5.  **Costruiscono tutti i sub-avatar**

6.  **Estraggono gli angoli dai sub-avatar**

**Risultato:** Angoli che considerano effettivamente la persona che compra il prodotto, non solo "come vendo la mia roba".

### **Il vantaggio competitivo**

Fare questo lavoro extra porta a **angoli azionabili e relatable** che effettivamente convertono e scalano.

**Se vuoi risultati da top 1%, devi fare ciò che fa il top 1%**, non ciò che fa il 99%.

## **7. HOOK E HEADLINE: COME COMUNICARE L'ANGOLO**

### **Definizioni rapide**

**HOOK O HEADLINE:** Come catturi l'attenzione per vendere il prodotto. È come comunichi l'angolo.

Alcuni "boomer" del marketing li chiamano "lead" (vecchia scuola di copywriting).

### **Principio per principianti: diretto \> indiretto**

Finché non raggiungi un livello avanzato, **il tuo hook o headline dovrebbe sempre comunicare direttamente l'angolo** anziché indirettamente.

### **Esempi di comunicazione diretta**

**Angolo:** Ferma il gonfiore\
**Hook diretto:** "14+ ore, zero gonfiore"

**Angolo:** Ti tiene pieno come un pasto\
**Hook diretto:** "Questo è un pasto, non un protein shake"

**Angolo:** Ti impedisce di scattare con le persone\
**Hook diretto:** "5 minuti per installare, zero scatti nervosi"

**Angolo:** Perdita di peso a un'età specifica\
**Hook diretto:** "Ho perso accidentalmente 12 libbre a 52 anni"

**Angolo:** Teen lunatico (sub-avatar: genitore con teen irritabile)\
**Hook diretto:** "Teen sempre scontroso?"

### **Perché la comunicazione diretta funziona per principianti**

Non devi fare "roba extra complicata". Comunichi semplicemente cosa fa il prodotto per loro in modo chiaro e immediato.

Le strategie avanzate (comunicazione indiretta) vengono coperte più avanti.

## **8. ESTRARRE ANGOLI DAI SUB-AVATAR: PROCESSO MANUALE**

### **La chiave del successo**

**Mantieni gli angoli azionabili.** Gli angoli sono illimitati riguardo a cosa può fare il tuo prodotto, ma finché sono azionabili, scrivere annunci diventa molto più facile.

### **Esempio pratico: The Nose Strip Sleeper**

**Sub-avatar:**

- **Desiderio:** Vuole sonno ristoratore Fare un buona prima impressione

- **Comportamento:** Indossa cerotti nasali a letto per forzare la respirazione dal naso

**Angolo estratto:** "Meglio dei cerotti nasali"

### **Processo in 3 step**

**Step 1:** Guarda cosa vuole (il desiderio)\
**Step 2:** Guarda cosa fa attualmente per ottenere quel desiderio (il comportamento)\
**Step 3:** Identifica il gap che questo sub-avatar ha

Nel caso del "nose strip sleeper":

- Vuole sonno migliore

- Sta già usando cerotti nasali

- C'è ancora un gap (vuole ancora più sonno ristoratore)

**Quindi l'angolo:** "Better than nose strips" è un angolo potenziale da questo sub-avatar.

### **Angoli alternativi dallo stesso sub-avatar**

**Angolo 2:** "Questo combinato con i cerotti nasali ti darà il miglior sonno della tua vita"

Parla di come combinare meccanismi per ottenere il desiderio (sonno migliore).

### **Consiglio**

Prova a estrarre manualmente angoli da alcuni dei tuoi sub-avatar usando questo processo in 3 step. Ti aiuterà a capire il pensiero dietro.

## **9. ESTRARRE ANGOLI DAI SUB-AVATAR: PROCESSO AI**

### **Perché usare AI**

**AI può fare questo lavoro molto meglio e più velocemente di noi** nella maggior parte dei casi, MA non dovresti essere eccessivamente dipendente o ciecamente fiducioso nell'AI.

A volte l'AI può darti risultati eccellenti, altre volte può darti spazzatura.

### **Il prompt fornito**

È disponibile un **PDF con un prompt dettagliato** che può essere caricato in Claude AI (raccomandato) o ChatGPT.

### **Cosa serve per il prompt**

**1. Informazioni sul prodotto**

- Caratteristiche

- Benefici

- Meccanismi

- Cosa fa il prodotto

**2. Almeno un profilo sub-avatar**

Non hai bisogno di ogni singolo campo (desiderio, pain points, comportamenti, emozioni, ecc.). Anche sub-avatar di base con solo desiderio e comportamento funzionano.

### **Esempio di output AI**

**Sub-avatar inserito:** "The No Screener"

- **Desiderio:** Sonno ristoratore

- **Comportamento:** Non usa schermi un'ora prima di dormire

**Output di Claude AI:**

#### **Angolo 1: "La tua disciplina viene sprecata"**

**Ragione d'acquisto:\**
"Sei abbastanza disciplinato da mettere via il telefono un'ora prima di andare a letto. Ma l'inquinamento luminoso sta distruggendo la produzione di melatonina che stai lavorando così duramente per proteggere. I tuoi sforzi vengono sabotati."

**Hook 1:** "Zero schermi per un'ora, zero luce per otto ore"\
**Hook 2:** "Hai smesso con gli schermi, ora smetti con la luce"\
**Hook 3:** "5 minuti per installare, 0% della tua disciplina sprecata"

#### **Angolo 2: "Completa il tuo protocollo del sonno"**

**Ragione d'acquisto:\**
"Hai già fatto la parte difficile: controllare il tuo comportamento. Questo è il pezzo ambientale finale che corrisponde al tuo livello di impegno. Smetti di usare soluzioni casuali per una disciplina seria."

**Hook 1:** "Tu controlli gli schermi, noi controlliamo la luce"\
**Hook 2:** "Zero schermi = disciplina, Zero luce = risultati. Questa non è una tenda. Questo è un protocollo del sonno."\
**Hook 3:** "Proteggi la tua produzione di melatonina al 100%"

#### **Angolo 3: "Proteggi la produzione di melatonina"**

**Ragione d'acquisto:\**
"Stai evitando gli schermi per preservare la melatonina, ma la luce mattutina sta aumentando il cortisolo e distruggendo la stessa produzione di melatonina prima ancora che ti svegli."

**Hook 1:** "0% luce blu di notte, 0% luce solare al mattino"\
**Hook 2:** "Blocca il 100% della luce, protegge il 100% della melatonina"

### **Priorità di test suggerite da AI**

**Inizia con Angolo 1, Hook 1:** "Zero schermi per un'ora, zero luce per otto ore"

**Perché:**

- Colpisce la frustrazione centrale

- Stanno già facendo sacrifici

- Valida il loro sforzo mostrando il pezzo mancante

- Il contrasto temporale (1 ora di disciplina vs 8 ore di protezione) rende il valore ovvio

**Se performa:** Testa variazioni dell'Angolo 1\
**Se non performa:** Passa all'Angolo 2, Hook 3

## **10. LA POTENZA DEGLI ANGOLI GENERATI DA AI**

### **Cosa rende questi angoli eccezionali**

**1. Sono azionabili\**
Potrebbero essere quasi headline o hook da soli. Danno una ragione per comprare.

**2. Considerano il cliente\**
Non partono dal prodotto, partono dalla persona e dal suo comportamento specifico.

**3. Sono relatable\**
"Hai smesso con gli schermi, ora smetti con la luce" parla direttamente a qualcuno che già pratica quella disciplina.

**4. Non li avresti mai scritti partendo dal prodotto\**
Se guardi solo "vendo tende oscuranti", mai scriveresti "la tua disciplina viene sprecata".

Ma guardando il sub-avatar (persona disciplinata che evita schermi), l'angolo diventa ovvio.

### **Esempio di headline vincente**

**"Tu controlli gli schermi, noi controlliamo la luce"**

Questo è un headline **malato** (nel senso di "straordinario"). È potente, diretto, relatable.

**AI non avrebbe mai scritto questo headline senza il contesto del sub-avatar specifico.**

### **La rivelazione**

Questo è esattamente il processo con cui si creano annunci che scalano a \$100,000/giorno di spesa.

**Ora, con AI, è più facile per chiunque replicare questo processo** avendo essenzialmente un team che scrive questi headline, hook e angoli per te.

## **11. ORGANIZZARE E TESTARE GLI ANGOLI**

### **Cosa fare con gli angoli generati**

Questi non sono script completi o video completi, sono **headline e hook**. Ma rappresentano il punto di partenza per creare annunci vincenti.

### **Prossimi passi**

La lezione successiva mostrerà come organizzare questi angoli e testarli usando diverse strategie di esecuzione.

### **Strategia di test 3-2-2**

Molti possono semplicemente testare **i tre migliori hook** usando la strategia 3-2-2 (che verrà spiegata).

### **L'obiettivo finale**

Ogni punto di questo training è progettato per aiutarti a vedere **come tutto può essere trasformato in annunci**.

## **CONCLUSIONE**

Comprendere e applicare correttamente gli angoli pubblicitari è ciò che separa i marketer mediocri dai top performer. La maggior parte delle persone non capisce che:

**1. Concetto ≠ Angolo (nella maggior parte dei casi)**

I concetti riguardano te e cosa vuoi testare. Gli angoli riguardano il cliente e perché dovrebbe comprare.

**2. Gli angoli devono essere centrati sul cliente**

Se il tuo "angolo" non dà al cliente un motivo per comprare, è solo un concetto.

**3. I sub-avatar contengono già i tuoi angoli**

Facendo il lavoro di costruire sub-avatar dettagliati, hai già scoperto gli angoli più potenti da testare.

**4. Hook e headline comunicano gli angoli**

Per i principianti, la comunicazione diretta funziona meglio. L'hook dovrebbe dire chiaramente cosa fa il prodotto per il cliente.

**5. AI può accelerare drasticamente il processo**

Con i prompt giusti e il contesto dei sub-avatar, AI può generare angoli e headline che altrimenti non avresti mai pensato.

**6. I template funzionano, ma solo con angoli forti**

Se i tuoi post-it, "3 motivi perché" o altri formati non funzionano, non è colpa del formato. È colpa dell'angolo debole che ci hai messo dentro.

Il lavoro che hai fatto nelle fasi precedenti (comprendere il prodotto, identificare i desideri, costruire avatar e sub-avatar) ora si trasforma in angoli azionabili che puoi testare immediatamente. Questo è il processo che porta a annunci che scalano a livelli massicci.

AI PROMPT

\*\*Situation\*\*

You are a direct response marketing strategist specializing in customer avatar analysis and angle development. You work with businesses to identify the most compelling marketing angles based on deep customer psychology, using sub-avatar frameworks to uncover specific pain points, desires, and emotional triggers that drive purchasing decisions.

\*\*Task\*\*

The assistant should analyze the provided product information and sub-avatar profiles to generate targeted marketing angles. For each sub-avatar, identify 3 potential marketing angles by examining their most painful or specific attributes, framing these as problems from their perspective, and converting them into compelling "reason to buy" statements that are relatable. Then provide 3 strategic written hooks/headlines that could be used for each angle for proper implementation. You MUST but the strongest angles and the strongest hooks/headlines up at the top first and make sure to remind the user that they do NOT have to test each angle separately. They can do a concept that tests “multiple angles” with the best hook/headline.

\*\*Objective\*\*

Enable the user to develop data-driven, psychologically-targeted marketing angles that resonate with specific customer segments, allowing them to either test multiple approaches simultaneously or focus resources on the highest-probability angle with multiple execution variations.

\*\*Knowledge\*\*

**Definition of Angle:**

- **Concept** = The big idea (what you're testing)

  - Could be: Testing formats, testing iterations, testing awareness levels, or angles

- **Angle** = How you choose to sell the product (must always be defined)

  - If your concept is anything but "testing angle(s)" you need to identify the angle

The average marketer's definition of angle oftentimes has NOTHING to do with the customer.\
\
And that’s why most people DON’T MAKE good ads.

They aren’t thinking about the Angle *(how we’re going to position the product to the customer)*. They are just thinking about the idea they want to test.\
\
**These are BAD examples of what “Angle” is:**

**Us vs Them** → This is a Concept, with an “assumed” broader angle (comparison)... But Comparing what?? ***The “What” is the angle\***
\
**Before & After** → Again, this is a Concept. We are “assuming” some kind of broader angle (transformation)... But transformation of what? ***Again, the “What” is the angle\***
\
**Problem-Aware Angle Ads** → Another CONCEPT. We are going to test problem-aware ads. But of WHAT problem?? ***The “what” is the angle.***

**‘Post It Note’ Ads** → Some of these are also such basic concepts that become Formats because people don’t understand “Concept” or “Angle”. Post-It Notes is a Native-style image format, but at the end of the day, people put 0 consideration into the ANGLE.

Now, differentiating Concepts from Angles should hopefully make more sense. Again:

Concepts = Our big idea we want to test *(more focused on us)\*
Angles = How we choose to sell the product. *(more focused on the customer)*

**Now, this is where most people get confused:**

When your concept IS to test angle(s).

And in this instance, people will begin to use the terms interchangeably.\
\
**Example:**

- **Concept:** "Test Buy It For Life Angle" → Angle: "Buy It For Life"

- **Concept: “**Test Sleep Deprived Angle” → Angle: “Sleep Deprived”

So, if you've ever wondered why people will use concept and angle interchangeably, this is why.

But as a result of this training, hopefully you will start to be able to see that Concepts can be Angles…

**But not 100% OF THE TIME.**\
\
Let’s look at some examples of concepts to try to identify

**Concept = About you/your test strategy** (internally focused)

- "I want to test a video version."

- "I want to test Us vs Them"

- "I want to do an iteration on"

- “I want to test buy it for life”

- “I want to test vets' trust us”

**Angle = About the customer's reason to buy** (externally focused)

If the concept doesn't give the customer a reason to buy, it's not an angle yet.

- Video version → Does not give a customer a reason to buy = ***Identify the angle(s)***

- Iteration → Iteration of what angle? No clear reason = ***Identify angle(s)***

- Stops tossing and turning → This gives a person a reason (it solves their problem) = ***This is an angle***

- Us vs Them → What about Us vs Them? No clear reason = ***Identify the angle(s)***

- Brings back your energy → this gives a person a reason to buy = ***This is an angle***

If your concept is NOT testing an Angle, you NEED to make sure you specify what Angle is you're testing.

But if you just want to avoid making mistakes, the best practice is always to make sure you write down “What the Angle is,” aka THE REASON SOMEONE SHOULD BUY for EVERY concept.

Now with that clear. Let's go deeper on angles themselves.

Now, if you're anything like me, you likely went through this training and you think you get that Angles are how we choose to sell the product to people.

But at the end of the day…

What TF does that even mean?

It’s way too broad 😭

Because, even after I defined it, and after I went through and did tons of examples, I just kept saying myself, okay…But, what is an angle?

How do I know what the angle is?

What is the difference between an angle and not an angle?

Why are some angles so broad, and why are some so specific?

**Well, the truth is, similar to avatars, angles also exist on a spectrum.**

But fortunately for you, because you're doing the work of identifying sub-avatars, you're essentially already discovering angles that are specific enough to relate with customers and help you sell your product.

So just like how you could have a Core Avatar like:

**Desire: Wants better sleep**

You can also pull an angle from that that is very broad.

Literally, you could just write:

**“Want better sleep?**

Or

**“Feel like you’re not getting enough sleep?”**

And the truth is, yes, those actually are angles. That's how you're choosing to sell your product.

But they're pretty shitty angles because of how broad they are.

That’s why broad avatars are usually harder to sell to… You have to use broader angles.

**<u>Headlines/Hooks</u>**

Now, before getting into those examples of extracting avatars, I also want to explain one other final thing of importance, which is what I did above with:

"Feel like you're not getting enough sleep?"

That is something that we would call a **Hook** or a **Headline** *(or some boomers call them “leads)*

The Hook/Headline is how we get attention to sell the product *(basically, how you communicate the angle)*

Now, until you get to a more advanced level, your hook/headline should always be more **direct** instead of **indirect.**

**<u>Examples of “Direct” Hooks:</u>**\
\
**Angle:** Stops swelling\
**Hook:** "14+ Hours. No Swelling"\
→ Hook directly communicates the angle

**Angle:** Keeps you full like a meal\
**Hook:** "This is a meal. Not a protein shake"\
→ Hook directly communicates the angle

**Angle:** Stops you from snapping at people\
**Hook:** "5 minutes to install. No more snapping"\
→ Hook directly communicates the angle\
\
As a Jr. writer, these are much easier hooks/headlines to write.

We cover more advanced strategies later on in EVOLVE.

**Now, with that additional context provided**

The KEY to extracting angles from sub avatars is simple:

**KEEP THEM ACTIONABLE.**

*Angles are basically limitless (regarding your product and what it can do)*

As long as you're angles are ACTIONABLE, writing will become much easier. And the goal of ALL of this work is to make writing winning ads EASIER.

\*\*Additional Context\*\*

Below, you have been given winning ads that you will reference when providing your answer for the three specific angles, as well as the three specific hooks and headlines.

**\
Example:\
Angle:** Stops Swelling\
**Hook/Headline:** 14+ Hours. No Swelling**\
Additional Context on why this ad works:**\
<img src="/tmp/pandoc_media_discard/media/image4.png" style="width:6.5in;height:3.65278in" />

**Example:\
Angle:** How the protein shake keeps you full\
**Hook/Headline:** This is a meal. Not a protein shake**\
Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image10.png" style="width:6.5in;height:3.20833in" />

**Example:\
Angle:** Don’t sacrifice things you like to be healthy\
**Hook/Headline:** Don’t change your life, just change lunch**\
Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image15.png" style="width:6.5in;height:3.08333in" />

**Example:\
Angle:** Sleeping better\
**Hook/Headline:** Sleep like a baby

**Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image18.png" style="width:6.5in;height:3.09722in" />

**Example:\
Angle:** Getting rid of double chin\
**Hook/Headline:** Drains double chin in 7 days

**Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image14.png" style="width:6.5in;height:3.09722in" />

**Example:\
Angle:** Getting rid of double chin\
**Hook/Headline:** Drains double chin in 7 days

**Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image12.png" style="width:6.5in;height:3.33333in" />

**Example:\
Angle:** Nutella turns bread into breakfast\
**Hook/Headline:** This is bread. This is breakfast

**Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image7.png" style="width:6.5in;height:3.38889in" />

**Example:\
Angle:** take control of your life with better food\
**Hook/Headline:** Grab life by the bowls

**Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image9.png" style="width:6.5in;height:3.125in" />

**Example:\
Angle:** losing weight without even trying\
**Hook/Headline:** I accidentally lost 12 pounds at 52

**Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image5.png" style="width:6.5in;height:3.55556in" />

**Example:\
Angle:** losing hormonal weight\
**Hook/Headline:** I flushed 19 pounds of hormonal weight

**Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image2.png" style="width:6.5in;height:3.625in" />

**Example:\
Angle:** dealing with a grumpy teenager\
**Hook/Headline:** Teen always grumpy?

**Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image16.png" style="width:5.60938in;height:3.16426in" />

**Example:\
Angle:** Show people who don’t think they have wavy hair, how to get wavy hair\
**Hook/Headline:** 3 signs your hair is actually wavy

**Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image13.png" style="width:6.5in;height:3.69444in" />

**Example:\
Angle:** Showing how tick preventatives don’t work\
**Hook/Headline:** Ever wonder why tick preventatives don’t work anymore?

**Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image17.png" style="width:6.5in;height:3.66667in" />

**Example:\
Angle:** Vitamin deficiency in kids\
**Hook/Headline:** 3 red flags of vitamin deficiency in kids

**Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image6.png" style="width:6.5in;height:3.75in" />

**Example:\
Angle:** Get a Shampoo with better ingredients\
**Hook/Headline:** Watch for these ingredients when buying shampoo

**Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image11.png" style="width:6.5in;height:3.66667in" />

**Example:\
Angle:** A wallet that is RFID proof\
**Hook/Headline:** Why millennials are ditching their old wallets

**Additional Context on why this ad works:**

<img src="/tmp/pandoc_media_discard/media/image8.png" style="width:6.5in;height:3.66667in" />

\*\*Example Of Perfect Output\*\*

**Marketing Angles & Hooks**

## **Total Blackout Blinds - Restorative Sleep Avatar**

## **PRIORITY NOTE:**

You do NOT have to test each angle separately. Test the \#1 hook from Sub-Avatar \#3 first—it carries the most emotional weight. You can layer in supporting benefits from other angles in your body copy.

## **SUB-AVATAR \#3: Short Fuse Avatar ⭐ STRONGEST**

**Angle 1: Stops You From Snapping At People**

Reason to Buy: Complete darkness lets your nervous system actually recover, so you stop being irritable and short-tempered with the people you care about.

Hook: **"5 minutes to install. No more snapping."**

*Inspired by: "14+ Hours. No Swelling" - Timeline + Specific outcome elimination*

**Angle 2: Restores Your Patience**

Reason to Buy: Your brain needs pitch-black sleep to reset your nervous system. Get that, get your patience back.

Hook: **"This blocks light. This saves relationships."**

*Inspired by: "This is bread. This is breakfast" - Simple "This does X. This does Y" pattern*

**Angle 3: Eliminates The "On Edge" Feeling**

Reason to Buy: Stop feeling wired and irritable all day by giving your body the complete darkness it needs to actually repair while you sleep.

Hook: **"Seals 100% of light. Restores 100% of patience."**

*Inspired by: "14+ Hours. No Swelling" - Specific percentage + outcome promise*

## **SUB-AVATAR \#1: Cool Sleeper ⭐ SECOND STRONGEST**

**Angle 1: Completes Your Cool Sleep Setup**

Reason to Buy: You already have the fan and AC. This is the missing piece that blocks heat AND light so your room stays cool and dark all night.

Hook: **"You have the fan. You have the AC. You need this."**

*Inspired by: "Don't change your life, just change lunch" - Minimal change, maximum impact framing*

**Angle 2: Keeps Room Cooler Than AC Alone**

Reason to Buy: These block heat transfer from the sun, so your room stays cooler without cranking the AC. Better sleep, lower energy bills.

Hook: **"This is a curtain. This is a cooling system."**

*Inspired by: "This is a meal. Not a protein shake" - Product redefinition pattern*

**Angle 3: The Final Sleep Optimization Step**

Reason to Buy: You've optimized temperature. Now optimize light. This is what serious sleep optimizers add after mastering cooling.

Hook: **"Cool room in 5 minutes. Deep sleep in 8 hours."**

*Inspired by: "Drains double chin in 7 days" - Dual timeline showing speed + result*

## **SUB-AVATAR \#2: Night Faster ⭐ THIRD PRIORITY**

**Angle 1: Matches Your Sleep Discipline**

Reason to Buy: You're disciplined enough to fast before bed. Now use equipment that's equally serious about blocking 100% of light.

Hook: **"Serious about fasting? Serious about darkness."**

*Inspired by: "Moms of 15 year olds" - Direct avatar call-out with identity match*

**Angle 2: Protects Your Melatonin Production**

Reason to Buy: Your fasting discipline is wasted if light is destroying your melatonin production every morning. Protect both.

Hook: **"0% light. 100% melatonin production."**

*Inspired by: "14+ Hours. No Swelling" - Percentage-based outcome promise*

**Angle 3: Professional Tools For Serious Sleepers**

Reason to Buy: People who fast before bed aren't casual about sleep. Stop using casual blackout curtains.

Hook: **"This is a blackout curtain. This is a sleep protocol."**

*Inspired by: "This is bread. This is breakfast" - Elevation from commodity to system*

## **TESTING PRIORITY:**

Start with Sub-Avatar \#3, Angle 1. Test that hook first. If it hits, run variations. If not, move to Sub-Avatar \#1, Angle 1.

I 3 METODI DI TEST DEGLI ANGOLI PUBBLICITARI

# **I 3 METODI DI TEST DEGLI ANGOLI PUBBLICITARI**

## **Come testare gli angoli in modo organizzato e strategico per scalare i tuoi annunci da zero a \$100k/giorno**

### **INTRODUZIONE**

Questa lezione presenta i tre metodi fondamentali per testare gli angoli pubblicitari che hai scoperto attraverso il lavoro sui sub-avatar: il Metodo Marksman (tiratore scelto), il Metodo Sniper (cecchino) e il Metodo Shotgun (fucile a pompa). Imparerai quando e come usare ciascun metodo, come combinarli strategicamente e perché la consapevolezza dell'angolo è il 99% della battaglia. Questo sistema è ciò che permette di scalare da \$5k/giorno a \$80k/giorno in 6 settimane.

## **1. IL PRINCIPIO FONDAMENTALE: LA CONSAPEVOLEZZA È IL 99% DELLA BATTAGLIA**

### **Il cambio di mindset essenziale**

**Non importa quale metodo scegli, ciò che conta davvero è che ora SEI CONSAPEVOLE dell'angolo e da dove proviene.**

La persona (sub-avatar) che hai identificato ti ha dato l'angolo. Quando sai che un angolo specifico funziona, sai che è probabilmente legato alla persona che stai targetizzando.

### **Evitare la paralisi da analisi**

Anche se dopo questa lezione non sai quale metodo di test scegliere, **non importa. Scegli uno e vai avanti, ma sii consapevole.**

La maggior parte delle persone non è consapevole degli angoli che crea. Vedrai nel video successivo che anche all'inizio il team non era completamente consapevole, sapevano solo che dovevano andare più in profondità.

### **Perché hai fatto il lavoro sugli avatar**

**L'obiettivo del lavoro sugli avatar è avere angoli effettivamente relatable per i tuoi concetti.**

La domanda che molti si pongono è: "Come testo tutti questi angoli che ho trovato in modo organizzato?" Hai costruito diversi sub-avatar, hai diversi angoli, e ora ti chiedi cosa fare. Ecco perché esistono questi metodi.

## **2. METODO \#1: IL METODO MARKSMAN (TIRATORE SCELTO)**

### **Definizione e analogia**

**Testi molte cose contemporaneamente per vedere cosa funziona, ma lo fai in un ambiente controllato.**

L'analogia delle armi (per chi ha giocato a Call of Duty): la maggior parte conosce Shotgun e Sniper, ma Marksman è la via di mezzo tra entrambi.

**Non sei preciso come un cecchino, ma non sei nemmeno disordinato come con un fucile a pompa. Sei il meglio di entrambi.**

### **Come funziona nella pratica**

Nella vita reale, molti fucili sparano a **raffica di 3 colpi**. Quando premi il grilletto: BANG BANG BANG.

Questo si collega perfettamente alla strategia **3:2:2**:

- Quando "premi il grilletto" su un angolo

- Ottieni **3 raffiche** = 3 variazioni

**Con il Metodo Marksman, spari 3 angoli diversi contemporaneamente.**

### **Esempio pratico: Concetto Superlative**

Nel caso studio che verrà mostrato:

**Concetto:** Superlative (concetto ampio)\
**Realtà:** Stavamo testando 3 angoli diversi

**Le 3 variazioni non erano:**

- 3 modi di dire "acciaio inossidabile"

**Le 3 variazioni erano:**

- Variazione 1: Angolo "Stainless Steel" (acciaio inossidabile)

- Variazione 2: Angolo "Easiest to Clean" (più facile da pulire)

- Variazione 3: Angolo "Doctor Designed" (progettato da dottori)

**Questo è il Metodo Marksman:** un angolo per variazione, ma 3 angoli totali nel concetto.

### **Pro del Metodo Marksman**

**1. Molto più fluido**

Puoi fare: questo angolo qui, quest'angolo là, quest'angolo laggiù. È meno rigido di "dobbiamo rimanere entro le linee di questo angolo specifico per questo concetto."

**2. Focalizzato sulla qualità**

È più come: "Lasciami fare il miglior annuncio che posso per questo angolo" o "Scrivere il miglior headline/hook che posso per questo angolo", e poi fai lo stesso per le altre due variazioni.

**3. Obiettivo chiaro: trovare una direzione velocemente**

Quando non hai dati significativi o sei in plateau, questo metodo ti aiuta a identificare in quale direzione andare più velocemente.

**DIREZIONE = Identificare l'angolo specifico su cui dovresti approfondire, fare più ricerca e iterare per creare annunci più scalabili.**

### **Contro del Metodo Marksman**

**1. Non testi le cose completamente**

Non vai sempre fino in fondo nel testare un angolo nel miglior modo possibile.

**2. Difficile dire con certezza che un angolo non funziona**

Questo è difficile comunque, ma con questo metodo non vai abbastanza in profondità in uno specifico angolo per validarlo completamente.

**3. Il trade-off**

Puoi testare più cose contemporaneamente per trovare una direzione su cui approfondire. Stai testando solo 1 variazione per angolo.

### **Quando usare il Metodo Marksman**

- Quando non hai dati significativi

- Quando sei in plateau

- Quando hai 3 angoli da un sub-avatar che vuoi testare

- Quando hai 3 sub-avatar con 1 angolo ciascuno da testare

- Preferibile rispetto all'approccio sniper su ogni singolo annuncio nell'era dell'algoritmo di Meta con contenuti AI

## **3. METODO \#2: IL METODO SNIPER (CECCHINO)**

### **Definizione**

**Testi in un ambiente rigoroso per avvicinarti a learnings significativi il più velocemente possibile.**

A differenza del Metodo Marksman (dove testi angoli multipli contemporaneamente), il Metodo Sniper riguarda testare **esecuzioni diverse, stili diversi, headline diverse, hook diversi di uno specifico angolo**.

### **Quando e come usarlo**

**Una volta trovato un angolo che sai funziona, usi il Metodo Sniper per andare all-in su quell'angolo al fine di creare i migliori annunci possibili.**

### **Pro del Metodo Sniper**

**1. Comprensione più chiara di cosa funziona**

Avrai una visione molto più nitida dei meccanismi vincenti.

**2. Più organizzato**

La tua struttura di test è rigida e chiara.

**3. Impari cosa funziona più velocemente**

Acceleri la curva di apprendimento su quello specifico angolo.

**4. Maggiore confidenza nella validazione**

Invece di testare solo 1 variazione di un angolo e dire "questo angolo non funziona", testerai 3 variazioni di quello specifico angolo, eliminando il "problema di esecuzione".

**5. Elimina il dubbio dell'esecuzione**

Il problema dell'esecuzione (che verrà approfondito in un altro modulo) è una delle cause principali di falsi negativi. Il Metodo Sniper lo risolve.

### **Quando funziona meglio**

**Il Metodo Sniper spacca quando ottieni una direzione dal Metodo Marksman.**

Una volta che Meta ti dice quale angolo sta funzionando bene (attraverso risultati), puoi estrarre il massimo da quell'angolo con questo metodo.

### **Contro del Metodo Sniper**

**1. Molto meno fluido**

È rigido e può limitare la creatività a volte, impedendoti di fare semplicemente i migliori annunci che puoi.

**2. Difficile rimanere così focalizzati**

La maggior parte delle persone non riesce a mantenere questo livello di focus su una sola direzione specifica.

**3. Rischio di iteration overload**

Puoi finire in un loop dove iteri continuamente sullo stesso angolo ancora e ancora, rimanendo bloccato in questo "funk" senza uscirne.

**4. Più lento**

Pensa a un cecchino: non spara 3 proiettili contemporaneamente. Spara un proiettile (BANG), deve ricaricare, spara di nuovo (BANG). È più preciso ma molto più lento.

**5. Mancanza di breakthrough su altri angoli**

Essendo così specifico e limitandoti a testare un solo angolo, potresti perdere la capacità di trovare scoperte su altri angoli.

### **Trade-off finale**

**Puoi andare molto più in profondità su un concetto pubblicitario specifico per validarlo e testarlo completamente, ma puoi mancare della capacità di trovare breakthrough su altri angoli** a causa di quanto sei specifico.

### **Esempio visivo del Metodo Sniper**

Nel caso studio mostrato, il secondo test era un approccio sniper più piccolo:

**Tutti gli annunci erano focalizzati su UN angolo:** l'angolo "Stainless Steel"

Stavano testando cose diverse (esecuzioni, formati, hook), ma **tutto ruotava attorno allo stesso angolo**. Questo è l'approccio sniper.

## **4. COME COMBINARE I DUE METODI: LA STRATEGIA DELL'AGENZIA**

### **Il workflow strategico**

**FASE 1: Metodo Marksman\**
Usato per primo per trovare la direzione di quali angoli possono essere vincenti.

**FASE 2: Metodo Sniper\**
Usato dopo per andare più in profondità e trovare vincitori una volta identificata una direzione.

**FASE 3: Ritorno al Marksman\**
Usato di nuovo quando le performance vanno in plateau su un angolo e senti di aver "sniperizzato" fino allo sfinimento. Devi trovare un nuovo angolo su cui approfondire.

### **Regola semplice**

**Un angolo = Approccio Sniper\**
Stesso angolo, modi diversi di mostrarlo

**Angoli multipli = Approccio Marksman\**
Angoli diversi, solitamente un solo modo di mostrarli o dirli

### **Il principio più importante**

**INDIPENDENTEMENTE DA QUESTO APPROCCIO, PER FAVORE FAI I MIGLIORI ANNUNCI CHE PUOI.**

Al cliente non importa della tua strategia o filosofia. Il cliente vuole solo vedere un buon annuncio.

Se ti concentri nel fare i migliori annunci possibili, quando elabori i feedback loop e completi i learnings (e ora sei consapevole di cosa cercare), scoprirai quali avatar funzionano.

## **5. LA REALTÀ DEL TESTING MODERNO E META**

### **Perché il testing perfetto è impossibile**

**Oggigiorno è quasi impossibile fare single variable testing perfetto** a causa degli aggiornamenti di Meta.

Le oscillazioni minuscole che fai a volte **non sono abbastanza significative perché Meta se ne accorga** o le veda come diverse dall'annuncio singolo che hai inserito.

### **La versione semplificata (se i metodi ti confondono)**

**STEP 1:** Testa molti nuovi angoli all'inizio

**STEP 2:** Quando trovi angoli che ottengono trazione (cioè spesa), vai più in profondità su quel singolo angolo che sembra catturare l'attenzione delle persone

**STEP 3:** Fai un'ipotesi sul perché quella cosa sta vincendo e perché al cliente importa

**STEP 4:** Testa quelle ipotesi per restringere il motivo per cui qualcosa sta vincendo, per ottimizzarlo ancora di più

### **La parte difficile vs la parte facile**

**Lo Step 1 è il più difficile.** Una volta superato, gli Step 2 e 3 diventano la parte facile.

**Questo è dove vedi persone scalare da \$5k/giorno a \$80k/giorno in 6 settimane:** hanno capito perché il loro annuncio funziona, e continuano a renderlo migliore.

Non si preoccupano più dell'angolo, sanno che l'angolo funziona. Ora stanno solo cercando di **comunicare l'angolo ancora meglio.**

**È qui che il marketing diventa molto divertente.**

## **6. COME FARE LEARNINGS CORRETTAMENTE**

### **Learnings tradizionali (SBAGLIATI)**

La maggior parte delle persone fa learnings così:

- "Questo annuncio funziona perché è un video"

- "Funziona perché ha un buon hook rate"

- "Dovremmo riusare questa clip"

- "Dovremmo testare la versione UGC"

**Questi learnings si concentrano su componenti strutturali, che non sono ciò che conta di più.**

### **Learnings avanzati (CORRETTI)**

Dopo questo training, sarai in grado di identificare:

**1. Chi è il soggetto (il sub-avatar)**

**2. Qual è l'angolo**

**3. Dovresti fare più ricerca su quella persona\**
Per scrivere nuovi annunci specifici per quella persona

### **Il cambio di focus**

**Sarai focalizzato sul cliente invece che sui componenti strutturali.**

**Ciò di cui il cliente ha bisogno di sentire influenzerà i componenti strutturali**, non il contrario.

### **Esempi di learnings centrati sul cliente**

Invece di dire:

- ❌ "È un video, ecco perché funziona"

Dirai:

- ✅ "Penso che funzioni perché generiamo curiosità nell'hook"

- ✅ "Penso che funzioni perché educhiamo la persona su questa cosa specifica"

- ✅ "In questa clip specifica, catturiamo la loro attenzione mostrando il risultato che vogliono"

- ✅ "Ci siamo davvero posizionati come un'autorità in questo video, dovremmo fare più di questo"

### **Il principio d'oro dei learnings**

**Più velocemente capisci PERCHÉ qualcosa NON sta vincendo → più velocemente puoi scalare**

**Più velocemente capisci PERCHÉ qualcosa STA vincendo → più velocemente puoi scalare**

## **7. METODO \#3: IL METODO SHOTGUN (FUCILE A POMPA)**

### **Definizione**

**Testi un sacco di cose casuali contemporaneamente e vedi cosa attecchisce.**

È dove "spari nel mucchio" senza strategia.

### **La realtà: la maggior parte usa questo metodo**

**Questo è ciò che sta facendo la maggior parte di voi.** Lanciate un mucchio di annunci e sperate che qualcosa funzioni.

### **Quando il Metodo Shotgun è accettabile**

Se sei confuso e stai facendo paralisi da analisi pensando "Dovrei fare Marksman? Dovrei fare Sniper?", allora va bene:

**Spara un mucchio di roba nel tuo account pubblicitario.**

**MA:** quando qualcosa funziona, devi prendere tutto ciò che hai imparato da questo training e applicarlo. Fai ciò di cui abbiamo parlato sopra.

### **Il modo GIUSTO di usare il Metodo Shotgun**

**Attraverso TikTok Shop o strategie di product seeding con creator.**

Ricevi un mucchio di contenuti da diversi creator, non hai tempo di strategizzare ogni singolo video. L'obiettivo è diverso quando lavori con i creator:

**"Ecco un po' di linee guida, fate quello che volete, sparate pure."**

Poi prendi quel contenuto, lo metti nell'account pubblicitario. Se qualcosa funziona, **applichi il Metodo Marksman o Sniper per raffinare e creare più annunci vincenti.**

Ma lo fai solo **dopo aver elaborato i learnings.**

### **Caso studio reale**

Questo è esattamente ciò che il team ha fatto di recente per scalare un brand a **\$40,000/giorno di spesa**.

(Il video è stato rimosso perché il cliente non era felice che fosse condiviso pubblicamente, ma la strategia è quella descritta.)

### **Quando ha senso una Shotgun Engine**

**Se fai meno di \$100k/mese:** probabilmente non ne hai bisogno.

**Se sei a scala maggiore** e non hai una shotgun engine o strategia shotgun nel tuo business, potrebbe aiutare perché stai solo ricevendo un mucchio di cose casuali nel tuo account.

Quando qualcosa attecchisce, puoi applicare questo training e la tua conoscenza per capire perché sta funzionando.

## **8. L'ERRORE \#1 CHE I BRAND FANNO CON LA STRATEGIA CREATIVA**

### **Il modo SBAGLIATO di fare strategia creativa**

**NON usare shotgun nel 2025 quando si tratta di strategia creativa.**

Non sparare dozzine di iterazioni o dozzine di video con minuscoli cambiamenti di hook e sperare che qualcosa funzioni.

### **Perché è un errore fatale**

**1. L'algoritmo di Meta non se ne frega**

Non si preoccupano di tutte quelle piccole iterazioni. Stai facendo un sacco di lavoro extra per niente.

**2. Stai competendo contro persone che sanno cosa stanno facendo**

Stanno applicando il Metodo Marksman o Sniper. Sono calcolati con gli annunci che creano.

Se stai solo "sparando a caso" sperando che qualcosa attecchisca, **le probabilità che funzioni come unica e principale strategia non sono molto alte.**

### **Per chi pensa che il volume sia l'unica risposta**

**Sì, il volume è ottimo. Ma questo tipo di volume dove fai solo un mucchio di roba casuale è stupido.**

Non è la strategia che Meta sta permettendo o premiando, specialmente con il nuovo algoritmo.

### **Il modo GIUSTO di scalare il volume**

**Con manpower (forza lavoro).**

Le persone che fanno 20 annunci al giorno di solito hanno:

- Un team in-house (a volte anche due)

- Un'agenzia o due agenzie creative che fanno anche annunci per loro

**Esempio del team dell'agenzia:**

- 1 Creative Director

- 1 Creative Strategist

- 2 Video Editor

- 1 Graphic Designer

**= 5 persone**

Queste 5 persone con **intento molto alto** possono fare **15 concetti a settimana.**

Ci sono 5 giorni in una settimana, quindi fanno **3 concetti al giorno** = **9 annunci al giorno** (con 3:2:2).

### **Il benchmark per chi non ha un grande team**

**Se non hai un team così grande, concentrati solo su 1 concetto al giorno.**

### **I risultati reali delle ultime 2 persone intervistate**

**Le ultime 2 persone che ho intervistato che hanno raggiunto \$100k/giorno testavano 1 concetto al giorno.**

- 5-7 concetti a settimana

- 15-21 annunci a settimana

**Questo è tutto.**

### **L'importanza dei concetti vs annunci**

**È più sui concetti che sugli annunci.**

Pensa: 1 concetto con la strategia Marksman è quasi come 3 concetti che stai testando.

**Capisci quanto più velocemente ottieni dati quando fai quello?** E quanto più velocemente puoi scalare quando trovi una direzione e capisci "Oh, questo è l'angolo che Meta sta apprezzando"?

Poi raddoppi su quello con il Metodo Sniper, testi esecuzioni diverse, formati diversi, headline diversi, modi diversi di dirlo, o magari vai più in profondità sul sub-avatar specifico per capire di più su di loro.

**Poi inizi a pompare quelli fuori e boom: vincitore, vincitore, vincitore. Non puoi sbagliare.**

**È questione di intento.**

## **9. RIEPILOGO DELLA STRATEGIA COMPLETA**

### **I 3 metodi in sintesi**

**MARKSMAN:**

- Angoli multipli, 1 variazione ciascuno

- Trovare direzione velocemente

- Primo passo quando non hai dati o sei in plateau

**SNIPER:**

- Un angolo, esecuzioni multiple

- Validare completamente e ottimizzare

- Secondo passo dopo aver trovato direzione

**SHOTGUN:**

- Solo per content strategy con creator

- MAI per creative strategy interna

- Quando qualcosa funziona, passa a Marksman/Sniper

### **Il workflow vincente**

**INIZIO → MARKSMAN\**
(Trova quale angolo funziona)

↓

**DIREZIONE TROVATA → SNIPER\**
(Ottimizza quell'angolo al massimo)

↓

**PLATEAU → MARKSMAN\**
(Trova un nuovo angolo)

↓

**NUOVO ANGOLO → SNIPER\**
(Ciclo continua)

## **CONCLUSIONE**

I tre metodi di test degli angoli rappresentano un framework completo per passare da test casuali a una strategia pubblicitaria scalabile e ripetibile. Il Metodo Marksman ti permette di esplorare rapidamente terreno nuovo testando 3 angoli diversi contemporaneamente, trovando la direzione vincente. Il Metodo Sniper ti consente poi di estrarre ogni goccia di valore da quell'angolo, creando variazioni multiple per ottimizzare le performance. Il Metodo Shotgun ha il suo posto solo nella content strategy con creator esterni, mai nella strategia creativa interna.

**La chiave non è scegliere il metodo perfetto, ma essere consapevoli dell'angolo che stai testando e perché.** Quando elabori i learnings, non concentrarti su "è un video" o "ha un buon hook rate", ma su chi è il cliente, quale angolo risuona con loro e perché gli importa. Questo cambio di mentalità dal prodotto al cliente è ciò che separa chi scala da \$5k/giorno a \$80k/giorno in 6 settimane da chi rimane bloccato.

La consapevolezza è il 99% della battaglia. Ora che hai questi strumenti, il video successivo ti mostrerà come applicarli in un caso studio reale.

COME FUNZIONANO I METODI DI TEST

# **REVISIONE PRATICA: COME FUNZIONANO I METODI DI TEST**

## **Caso studio reale: da \$10k/settimana a \$80k/settimana applicando Marksman + Sniper Method su un umidificatore**

### **INTRODUZIONE**

Questa lezione presenta un'analisi approfondita di un caso studio reale in cui il team non aveva ancora il framework degli avatar documentato, ma applicava istintivamente i principi corretti. Attraverso l'analisi dettagliata di un test "Superlative Concept" (concetto superlativo) per un umidificatore, imparerai come identificare retrospettivamente gli avatar negli annunci vincenti, come estrarre learnings corretti, e come applicare questa conoscenza sia ai tuoi annunci che a quelli dei competitor. Questo processo ha trasformato un annuncio da \$10k/settimana a \$80k/settimana mantenendo lo stesso ROAS.

## **1. IL VALORE DELL'ANALISI RETROSPETTIVA DEGLI ANNUNCI**

### **Il messaggio chiave iniziale**

**Questa clip è stata spostata dall'inizio per enfatizzare la sua importanza.**

Puoi applicare questo processo ai tuoi competitor. Invece di copiare ciecamente o rubare (il che è illegale), puoi:

**Studiare gli annunci vincenti e identificare:**

- Quale desiderio stanno targetizzando

- Quale comportamento ha l'avatar

- Quale esperienza di prodotto specifica hanno avuto

- **Poi chiederti:** "Come potrei dirlo meglio? Come potrei trovare qualcuno simile? Come potrei renderlo più relatable?"

### **Il mindset del marketer vincente**

**Questo è ciò che fa un buon marketer.**

È l'oro di questo training: darti il skillset per fare questo. Se lo fai, **farai molti più soldi per molto più tempo** rispetto a chi si affida alla fortuna copiando il contenuto di altri.

Poi, un paio di mesi dopo, non sanno cosa fare.

### **L'ammissione importante**

**"Per voi nerd là fuori" (shoutout a Nick Shackleford che chiama tutti "nerd"):**

Il fatto di essere in un Google Doc a parlare di breakdown di annunci e identificare avatar è nerdy. **Ma i nerd fanno i soldi.**

### **La realtà del caso studio**

**Chiarimento critico: Non avevamo questo avatar training quando abbiamo inizialmente creato questi annunci.**

Non sapevamo cosa stavamo facendo. Beh, sapevamo, ma non era documentato.

**Ma la buona notizia:** Lo abbiamo ora.

Alcuni di voi potrebbero aver già fatto annunci vincenti. Questo video ti aiuterà a capire come analizzare i tuoi annunci per identificare potenziali avatar e creare più **super winner**.

## **2. COSA SONO I "SUPER WINNER"**

### **Definizione**

**Super winner = Annunci che:**

- Ottengono tutta la spesa (pull off the spend)

- Ti permettono di aumentare il budget

- Non solo ottengono spesa, ma **aumentano anche il ROAS**

**Se hai un ROAS più alto, puoi scalare.**

Alcune persone li chiamano "breakthrough" (svolta).

## **3. IL PROBLEMA COMUNE: IDENTIFICARE GLI AVATAR NEGLI ANNUNCI**

### **La sfida che probabilmente affronti**

Stai cercando di capire **quale avatar è nei tuoi migliori annunci** o, ancora meglio, **quale avatar è negli annunci dei tuoi competitor**.

**Questo è del materiale che nessuno insegna.**

### **Le domande critiche**

- **Chi stanno targetizzando?**

- **Come puoi identificarlo solo dall'angolo e dall'headline?**

### **Il potere di questa conoscenza**

Quando vedi un angolo funzionare (nel tuo account o in altri), devi **andare più in profondità per capire perché**.

**Avere questa conoscenza per capire e identificare gli avatar che vengono targetizzati nell'angolo è così potente.**

### **Il vantaggio competitivo**

**A differenza di altri marketer:** quando vedi un angolo funzionare, ora ti fornirà una direzione per andare più in profondità.

Quando lo fai, ti permette di scrivere annunci più relatable. **Gli annunci relatable scalano.**

## **4. IL CASO STUDIO: SUPERLATIVE CONCEPT PER UMIDIFICATORE**

### **Contesto del concetto**

**Concetto:** Sfruttare angoli multipli usando superlativi per vendere l'umidificatore

**Cosa sono i superlativi?** Quando dici che sei il migliore, il primo al mondo, ecc. È una grande affermazione (big claim).

### **Distinzione importante: Angolo ampio vs Angoli azionabili**

**"Usare superlativi" = Angolo ampio (quasi un concetto)**

**Gli angoli che stavamo effettivamente targetizzando sono molto più azionabili:**

1.  **Angolo 1:** Stainless Steel (acciaio inossidabile)

2.  **Angolo 2:** Easiest to Clean (più facile da pulire)

3.  **Angolo 3:** Doctor Designed (progettato da dottori)

### **Le 3 variazioni (Metodo Marksman)**

**Variazione 1:** "World's First Stainless Steel Humidifier"\
**Variazione 2:** "World's Easiest to Clean Humidifier"\
**Variazione 3:** "World's First Doctor-Designed Humidifier"

**Questi sono swing diversi** = Angoli diversi.

### **Perché si chiama Marksman Method**

**Stiamo testando angoli multipli per vedere cosa funziona.**

Un modo unico di comunicare ogni singolo angolo individuale.

## **5. ORIGINE DEL CONCETTO E REALIZZAZIONE RETROSPETTIVA**

### **Come è nato il concetto**

Il cliente ha effettivamente menzionato che sarebbe stato bene per noi provare a fare alcune affermazioni audaci (bold claims). **Pensavamo a livello superficiale.**

### **La realizzazione**

Ogni variazione di questo angolo superlativo è **un angolo diverso in sé**.

**Questo è dove c'è la "matrice degli angoli"** e molti si confondono.

### **Cosa significa questo**

**Stavamo testando angoli multipli in questo test.**

Se stiamo testando angoli multipli, significa che stiamo usando il **Metodo Marksman**.

### **Implicazione sugli avatar**

**Se il tuo concetto è focalizzato sul testare angoli** (raccomandato all'inizio), a seconda delle variazioni che usi, probabilmente **targetizzerai anche avatar diversi**.

### **Il desiderio retrospettivo**

**"Vorrei aver potuto dirvi che avevamo identificato:**

- Persone che si preoccupano dell'acciaio inossidabile

- Persone che si preoccupano di cose facili da pulire

- Persone che si preoccupano dei dottori"

**Ma non l'abbiamo fatto.**

### **La reinterpretazione**

**Se lo avessi fatto, questo concetto potrebbe semplicemente essere:**

"Sto per testare diversi sub-avatar. E il tipo di esecuzione è: userò i superlativi per comunicarlo."

Anche se abbiamo chiamato questo il "Superlative Concept", ciò che è in realtà è:

- **Testare diversi sub-avatar che si preoccupano di queste cose specifiche**

- **Poi usare i superlativi per comunicarlo o eseguirlo**

## **6. BREAKDOWN DETTAGLIATO: VARIAZIONE 1 - STAINLESS STEEL**

### **L'angolo**

**"World's First Stainless Steel Humidifier"**

**L'angolo qui è:** il nuovo meccanismo dell'acciaio inossidabile.

Abbiamo identificato: "Hey, questo è qualcosa che la maggior parte degli umidificatori non ha. Non hanno acciaio inossidabile. Parliamone."

### **Chiarimento critico: Angolo ≠ Nessun Avatar**

**Solo perché questo angolo sfrutta un nuovo meccanismo NON significa che non sta targetizzando un avatar.**

### **Possibili avatar targetizzati**

**Ipotesi Avatar 1:**

Potrebbe targetizzare un avatar che ha un **desiderio di volere un umidificatore senza plastica**.

**Ipotesi Avatar 2:**

Potrebbe anche targetizzare qualcuno che ha un **desiderio più ampio di voler eliminare l'aria secca** (cosa che fanno gli umidificatori), poi **ristretto da un comportamento:** evita di usare prodotti di plastica a causa delle microplastiche.

### **Principio fondamentale (richiamo)**

**I problemi tecnologici creano desideri.**

Quando qualcuno ha un problema con la tecnologia di un prodotto, vengono creati nuovi desideri come volere un umidificatore senza plastica.

**Questi sono i fondamenti trattati nella sezione Desires.**

## **7. L'IMPORTANZA DELLE IPOTESI (HYPOTHESIS)**

### **Perché servono ipotesi**

**Quando rivedi gli annunci, devi sempre formulare un'ipotesi sul perché pensi che qualcosa funzioni.**

**Per chi non ha prestato attenzione in classe di scienze:** Un'ipotesi è un'ipotesi educata (educated guess).

### **La realtà della confusione**

**L'avatar potrebbe non essere il primo avatar che assumi.** Potrebbe essere un avatar diverso.

### **Non esiste giusto o sbagliato (all'inizio)**

**Quando rivedi gli annunci, non c'è giusto e sbagliato.**

Direi che **c'è giusto e sbagliato:**

- **Il learning giusto è quello che effettivamente ti fa creare un annuncio vincente.**

- **È così che sai di aver fatto un buon learning.**

Ma all'inizio, stai solo indovinando. "Ok, sto ipotizzando che questo è ciò di cui la gente si preoccupa." Questa è un'ipotesi.

**E poi cosa fai?** Vai e crei annunci attorno all'ipotesi. **È così che funziona.**

**È così che fai progressi nel tuo account pubblicitario. Non testi le cose alla cieca.**

## **8. POSSIBILI DESIDERI E LA TECNICA DEL "PERCHÉ"**

### **Esempio di desiderio superficiale vs core**

**Desiderio superficiale:** "Vuole un umidificatore senza plastica"

Potrebbe essere il desiderio sbagliato. O il comportamento "evita di usare prodotti di plastica a causa delle microplastiche" potrebbe essere il comportamento sbagliato.

### **La cosa più importante**

**Le persone stanno comprando da questo headline, da questo hook o da questo angolo per un motivo.**

**È il tuo lavoro trovare quel motivo.**

### **La prima migliore cosa da fare**

**Pensa logicamente a te stesso** basandoti sulla ricerca che hai fatto: **Perché qualcuno se ne preoccuperebbe?**

### **Il core desire ovvio**

**A un certo punto, sai per certo che stanno comprando questo prodotto a causa del core desire più ovvio che esiste.**

In questo caso: **Questa persona vuole essere più sana** a causa di ciò che fa il nostro prodotto.

### **La tecnica del "Perché"**

**Pro tip:** Se hai bisogno di aiuto a capire qual è il tuo core desire, **continua a chiedere perché**.

**Esempio:**

**Desiderio superficiale:** Vuole un umidificatore senza plastica (o ancora meglio: vuole un umidificatore in acciaio inossidabile)

**Perché?** "Non voglio microplastiche umidificate nella mia casa"

**Perché?** "Perché è pericoloso per la mia salute"

**Core desire:** Vuole essere più sano

### **Principio generale**

**Non perderti troppo nella salsa.** Ricorda che hai un prodotto che fa certe cose che forniscono certi desideri.

**Il tuo prodotto può soddisfare solo un numero limitato di desideri.**

## **9. IL RISULTATO: TROVARE LA DIREZIONE**

### **Cosa abbiamo scoperto dal Marksman Method**

**Come risultato dell'ottenere direzione da questo test Marksman Method:**

Abbiamo scoperto che **questo headline sta funzionando specificamente** (stainless steel), ed è qui che puoi iniziare a lanciare test pubblicitari aggiuntivi attorno a questo angolo usando il **Sniper Method**.

### **L'obiettivo del Sniper Method**

Testare **quali desideri, comportamenti o esperienze sottostanti stanno realmente guidando le conversioni**.

## **10. VARIAZIONE 2: EASIEST TO CLEAN**

### **L'angolo**

**"World's Easiest to Clean Humidifier"**

### **Differenza chiave**

**Questo angolo ci porta a un avatar un po' diverso.**

Questo ha più un **headline focalizzato sul beneficio** rispetto a uno guidato dalla caratteristica come stainless steel.

### **È più semplice identificare l'avatar**

**Avatar probabile:**

Qualcuno che ha un **desiderio di superficie di volere un umidificatore più facile da pulire**, che probabilmente è venuto da:

- **Esperienza di prodotto:** con un umidificatore difficile da pulire (problema tecnologico di massa)

- **Comportamento:** non pulisce il loro umidificatore

### **Stesso processo**

Stesso processo delineato sopra si applica qui.

### **Il punto principale**

**Con la Variazione 2, stiamo ora effettivamente targetizzando un sub-avatar diverso perché stiamo prendendo un angolo diverso.**

**Stiamo usando il Metodo Marksman qui, il che significa che stiamo mescolando angoli.**

### **Promemoria: Non è caos**

**Questo non è caos. Questo è caos controllato.**

### **Il tuo vantaggio**

**A differenza di altri marketer che non stanno facendo questo training, guarderai più in profondità negli avatar che stai targetizzando.**

Se guardi più in profondità, hai la capacità di fare effettivamente **iterazioni di variazioni con strategia che conta** invece di iterazioni chiacchierone senza cervello e clip casuali che rubi.

## **11. L'IMPORTANZA DEI LEARNINGS (ANCHE DAGLI ANNUNCI CHE NON FUNZIONANO)**

### **La realtà di questa variazione**

**Questo headline specificamente non ha funzionato.** L'headline stainless steel è quello che ha ottenuto la maggior parte della spesa e delle performance.

### **Ma puoi ancora avere learnings**

**Se questo fosse stato l'headline che faceva meglio, questi sarebbero alcuni dei learnings che avrei:**

- "Ecco alcuni dei comportamenti su cui potenzialmente devo approfondire"

- "Ecco alcuni dei desideri che penso"

- "Ecco alcune delle esperienze di prodotto che credo le persone abbiano avuto"

**Sto processando learnings e ora sto pensando di nuovo a clienti e avatar prima** piuttosto che solo "Oh, questo headline fa schifo."

**Questo è l'obiettivo.**

## **12. VARIAZIONE 3: DOCTOR DESIGNED**

### **L'angolo**

**"World's First Doctor-Designed Humidifier"**

### **Avatar probabile**

**Su questa variazione finale, questo angolo targetizza un avatar che ha probabilmente avuto un'esperienza positiva con i dottori.**

### **Potrebbero esserci altri comportamenti?**

**Assolutamente.** E per questo fare ricerca per analizzare questo è importante.

### **Il learning da questo test**

**Considerando che questo headline non ha funzionato e che per angoli futuri che abbiamo testato ancora non ha funzionato, questo ci dice che:**

In questa istanza particolare, **alle persone non importa se l'umidificatore è stato progettato da un dottore.**

Vogliono solo un umidificatore che non faccia schifo.

### **La lezione critica**

**A volte gli angoli che pensi siano davvero buoni angoli che funzionano bene, alle persone semplicemente non importa.**

Voglio sottolineare questo perché è così importante: **Questi angoli che pensi siano super fighi, le persone potrebbero semplicemente non preoccuparsene.**

### **Il problema dei marketer**

**Noi come marketer pensiamo di sapere cosa vogliono le persone.**

Quando vedi che i tuoi annunci stanno ottenendo spesa e scalano, sicuramente lo sai.

**Ma se i tuoi annunci non stanno ottenendo spesa e non stanno scalando, stai solo facendo annunci in un modo che:**

1.  **Le persone non si preoccupano di ascoltare** (esecuzione - ne parleremo)

2.  **Stai solo facendo cose di cui alle persone non importa**

Alle persone non importa che questo sia stato progettato da un dottore. Fico, bro. Non è il punto di vendita principale. Voglio solo un umidificatore che non faccia schifo.

## **13. PERCHÉ LA RICERCA È CRUCIALE: ANGOLI PRODUCT-FIRST VS CUSTOMER-FIRST**

### **Come abbiamo creato questi angoli (modo sbagliato)**

**La ricerca che abbiamo fatto per creare questi angoli era product-first:**

- "Hey, il nostro dottore l'ha progettato. Parliamone. Diciamolo alle persone."

- "Hey, è in acciaio inossidabile. Diciamolo alle persone."

- "Hey, è facile da pulire. Diciamolo alle persone."

**Questo è come abbiamo creato quegli angoli. Non è il modo giusto di farlo.**

### **Può ancora funzionare?**

**Ora, può ancora funzionare? Sì, certo.**

### **Il tuo vantaggio**

**Ma quando gli angoli che state creando riguardano cose di cui le persone si preoccupano** (grazie alla ricerca), quando lo fate in quel modo:

A differenza della nostra situazione, sarete in grado di identificare che **probabilmente non è l'angolo il motivo per cui qualcosa non funziona.**

**È probabilmente come l'avete eseguito**, perché avete fatto ricerca per trovare questa roba.

### **Se non funziona quando vai product-first**

Se stai facendo tipo: "Parliamo di come il nostro prodotto fa questo" e pensi che alle persone importerà, e se non funziona, **indovina? Alle persone semplicemente non importa.**

## **14. LA PROFONDITÀ DELL'ANALISI**

### **Quanto siamo andati in profondità**

**Siamo 15 minuti dentro solo cercando di capire cosa sta effettivamente succedendo con questo concetto.**

Testando questo Superlative Concept (che è la grande idea), e al livello di variazione testando angoli multipli, possiamo iniziare a **restringere quali avatar dobbiamo approfondire basandoci su cosa performa**.

### **La realtà di questo caso**

In questa istanza, stiamo targetizzando diversi sub-avatar, anche se non lo sapevamo al momento.

**E sono qui per dire che va bene se avete fatto annunci e non sapevate quali fossero i vostri sub-avatar.**

Il punto è che **sarete in grado di identificarlo effettivamente ora perché avete questo training.**

### **Quando scrivete angoli e variazioni**

Quando scrivete questi angoli e quando scrivete queste variazioni, **saprete effettivamente cosa sta succedendo.**

### **Se non avete fatto questa analisi profonda**

**Se non siete andati in profondità per cercare di capirlo come ho appena fatto sul vostro annuncio con le migliori performance, siete potenzialmente a un paio di swing o un paio di test creativi di distanza dal trovare un super winner.**

## **15. IL SALTO ESPONENZIALE: DA \$10K A \$80K/SETTIMANA**

### **Fase 1: Metodo Marksman (Test iniziale)**

**Concetto:** Superlative Angles\
**Variazioni:**

- Doctor Designed

- World's First Stainless Steel

- Cleanest

**Risultato:** Stainless steel ha ottenuto trazione

### **Fase 2: Metodo Sniper (Prima iterazione - piccolo swing)**

**Focus:** Angolo stainless steel\
**Test:** Cose granulari attorno all'annuncio

- Immagini diverse

- Sottotest diversi

**Risultato:** \$18,000/settimana a 2.8X ROAS

**Questo è dove la maggior parte delle persone si ferma.**

Fanno un'iterazione come questa, trovano una nuova iterazione che funziona, ottengono il doppio della spesa. È fantastico.

### **Fase 3: Metodo Sniper (Secondo giro - swing più grande)**

**Cosa abbiamo fatto:**

- Più ricerca

- Restringi l'avatar ancora di più con un demografico (chiamare fuori i genitori)

- Formato diverso applicato (AI voiceover)

- Versione di storytelling più scalabile che fornisce più contesto

**Risultato:** \$80,000/settimana allo stesso identico ROAS

### **Il salto esponenziale**

**Da \$10k/settimana → \$18k/settimana → \$80k/settimana**

**Stesso ROAS mantenuto attraverso tutto.**

## **16. LA LEZIONE PRINCIPALE (MAIN TAKEAWAY)**

### **È ok testare angoli multipli**

**MA SOLO se sei consapevole di loro.**

### **Perché la consapevolezza conta**

**Se sei consapevole degli angoli:**

Una volta trovato l'angolo vincente, puoi:

1.  **Andare più in profondità in un avatar specifico** raffinandolo

2.  **Capire di più su di loro**

3.  **Cercare di essere più relatable**

4.  **Testare formati diversi per loro**

**Questo a sua volta ti permetterà di scalare ulteriormente.**

## **17. APPLICARE QUESTO AI COMPETITOR**

### **Il processo**

**Puoi applicare questo ai tuoi competitor.**

Seguire le strategie insegnate per trovare i migliori annunci vincenti.

### **Invece di copiare**

**Piuttosto che copiarli senza cervello o rubbarli (il che è illegale):**

Puoi studiarli e cercare:

- "Hmm, sta effettivamente andando dopo questo desiderio"

- "Forse sta andando dopo qualcuno che ha questo comportamento"

- "O ha avuto questa esperienza di prodotto specifica"

- "Ecco il loro avatar"

**Poi chiediti:**

- "Mi chiedo come potrei dirlo meglio"

- "Mi chiedo come potrei potenzialmente cercare qualcuno simile"

- "Forse posso renderlo più relatable"

### **Questo è ciò che fa un buon marketer**

**Questo è l'oro di questo training.**

Darti il skillset per essere in grado di fare questo. Perché se fai questo, **farai molti più soldi per molto più tempo** rispetto alle persone che semplicemente hanno fortuna e usano il contenuto di qualcun altro.

E poi all'improvviso, un paio di mesi dopo, non sanno cosa fare.

## **CONCLUSIONE**

L'analisi approfondita di questo caso studio dimostra il potere trasformativo di comprendere gli avatar nascosti negli annunci. Anche senza aver pianificato consapevolmente i sub-avatar all'inizio, il team è riuscito a scalare da \$10k a \$80k/settimana applicando il Metodo Marksman per trovare direzione (stainless steel funziona), poi il Metodo Sniper per ottimizzare progressivamente quell'angolo attraverso iterazioni strategiche e ricerca più profonda.

**I principi chiave da portare con te:**

1.  **La consapevolezza è tutto** - Anche se stai testando angoli multipli, sapere che lo stai facendo ti permette di estrarre learnings corretti

2.  **Le ipotesi guidano il progresso** - Non esiste giusto o sbagliato all'inizio, solo ipotesi testate che diventano conoscenza

3.  **La tecnica del "Perché"** - Continua a chiedere perché per arrivare ai core desires

4.  **Product-first fallisce** - Gli angoli basati su "abbiamo questa feature" spesso non risuonano; gli angoli basati su ricerca del cliente scalano

5.  **La profondità batte la velocità** - 20 minuti di analisi profonda su un annuncio possono rivelare la direzione per mesi di scale

**Puoi applicare questo skillset sia ai tuoi annunci vincenti che a quelli dei competitor**, studiandoli per identificare avatar, desideri, comportamenti ed esperienze di prodotto, poi creando versioni ancora più relatable. Questo è ciò che separa i marketer che costruiscono business sostenibili da quelli che copiano e sperano nella fortuna.

**I nerd fanno i soldi.** Ora vai a fare la tua analisi profonda.

METTERE INSIEME TUTTA LA PIANIFICAZIONE

# **METTERE INSIEME TUTTA LA PIANIFICAZIONE: ESEMPI PRATICI**

*TEMPLATEs*

[<u>https://www.canva.com/design/DAGv0-DtovY/5zQYd6JKf0oIEGN7lsYPHg/edit</u>](https://www.canva.com/design/DAGv0-DtovY/5zQYd6JKf0oIEGN7lsYPHg/edit)

[<u>https://www.canva.com/design/DAGv1K4k9Dw/iszxebXRuZ4tX6qEqFvCug/edit</u>](https://www.canva.com/design/DAGv1K4k9Dw/iszxebXRuZ4tX6qEqFvCug/edit)

## **Come integrare concetti, angoli, variazioni e metodi di test nella creazione degli annunci**

### **INTRODUZIONE**

Questa lezione mostra come combinare tutti gli elementi della pianificazione pubblicitaria attraverso esempi concreti di annunci. Verranno analizzati concetto, spiegazione del concetto, angoli, variazioni, formato e metodo di test utilizzato, per comprendere come tutto si unisce nella pratica della creazione di campagne efficaci.

## **1. ESEMPIO BASE: ANNUNCIO CON DUE VARIAZIONI**

**Concetto:** Annuncio in stile Nutella\
**Spiegazione:** Il team si è ispirato ai 13 modelli vincenti di annunci disponibili nel programma.

### **Angoli testati (Metodo Marksman):**

- **Angolo 1:** Fiducia/confidenza durante la passeggiata con il cane

- **Angolo 2:** Controllo del cane (riferimento alle pettorine tradizionali)

### **Sub-avatar identificati:**

**Per angolo "fiducia":**

- Desidera che il cane smetta di tirare

- Ha provato pettorine tradizionali

- Si sente imbarazzato a portare fuori il cane

- Evita di passeggiare in certe situazioni

**Per angolo "controllo":**

- Desidera che il cane smetta di tirare

- Ha provato pettorine tradizionali senza successo

### **Caratteristiche dell'esecuzione:**

- **Formato:** Statico con design grafico

- **Metodo di test:** Marksman (due angoli diversi con una variazione ciascuno)

- **Variazioni:**

  - Immagine 1: "This is a harness. This is confidence."

  - Immagine 2: "This is pulling. This is control."

### **Cosa fare se un annuncio vince:**

1.  Studiare perché ha funzionato

2.  Approfondire la comprensione del sub-avatar

3.  Identificare ulteriori punti di dolore

4.  Creare versioni video

5.  Testare iterazioni con il metodo Sniper

## **2. ESEMPIO VIDEO: POV CON ETICHETTE**

**Concetto:** Video POV (Point of View) con etichette per chiamare direttamente i sub-avatar\
**Prodotto:** Tende oscuranti totali

### **Angoli e sub-avatar testati:**

1.  **Lavoratore notturno\**

    - Angolo: Dormire meglio di giorno con oscuramento totale

    - Hook: "POV: You work the night shift"

2.  **Chi soffre di insonnia\**

    - Angolo: Dormire più regolarmente con oscuramento totale

    - Hook: "POV: You have insomnia"

3.  **Chi ha il sonno leggero\**

    - Angolo: Evitare risvegli prematuri con oscuramento totale

    - Hook: "POV: You're a light sleeper"

4.  **Chi si sveglia presto\**

    - Angolo: Restare addormentati dopo l'alba con oscuramento totale

    - Hook: "POV: You hate being an early riser"

### **Caratteristiche dell'esecuzione:**

- **Formato:** Video con sottotitoli

- **Metodo:** Marksman (angoli multipli)

- **Struttura:** Hook specifico + Hold generico che mostra il prodotto

- **Hold comune:** Dimostrazione dell'oscuramento totale

### **Nota importante:**

I video non usano le stesse clip, ma mantengono lo stesso concetto base. Le clip sono scelte per risuonare con l'etichetta specifica chiamata nell'hook.

## **3. ESEMPIO 2.5: ITERAZIONE CON METODO SNIPER**

**Evoluzione:** Dopo aver identificato che "lavoratori notturni" funziona, si approfondisce con il metodo Sniper.

### **Nuovo approccio ottimizzato:**

**Sub-avatar:** Lavoratore notturno\
**Angolo unico:** Dormire meglio di giorno con oscuramento totale

### **Variazioni di hook testate:**

- "Graveyard shift"

- "I'm finding it impossible to sleep in the morning"

- "Night shift is killing me"

- "Night shift job, but I can't sleep all day"

- "My life is taking a quick downturn"

### **Problema di esecuzione identificato:**

**Hold troppo generico:**

- "Fix your sleep with 100% darkness"

- "5 minutes, custom made"

- "3-day at-home trial"

**Cosa mancava:**

- Comportamenti specifici dei lavoratori notturni

- Emozioni legate al lavoro notturno

- Esperienze concrete (es: tornare a casa alle 7 del mattino, sole che sorge, bambini che si preparano per scuola)

**Lezione:** Quando si usa il metodo Sniper, il hold deve essere specifico quanto l'hook, non generico.

## **4. MARKSMAN VS SNIPER: GUIDA SEMPLIFICATA**

### **Per chi è sotto i 100K/mese e vuole semplicità:**

**IMMAGINI → Usa Marksman**

- Testa 3 angoli diversi

- Un'immagine per angolo

- Mantieni coerenza visiva con l'angolo

**VIDEO → Usa Sniper**

- Un angolo alla volta

- Vai in profondità

- 3 variazioni dello stesso angolo

### **Come funziona il Marksman con i video:**

**Principio base:**

- **Hook:** Specifico per ogni sub-avatar

- **Hold:** Generico, deve funzionare per tutti gli hook

**Esempio:**

- Hook 1: "POV: You work night shift"

- Hook 2: "POV: You're a light sleeper"

- Hook 3: "POV: You have insomnia"

- Hold comune: Dimostrazione del meccanismo (oscuramento totale)

**Perché funziona:** Tutti e tre i sub-avatar condividono lo stesso desiderio centrale (dormire meglio), quindi un hold generico che dimostra il meccanismo funziona per tutti.

## **5. L'IMPORTANZA DELL'ESECUZIONE**

### **Verità fondamentale:**

**Creare un buon annuncio immagine è più difficile che creare un buon video**

**Perché:**

- Hai solo uno spazio 1:1 o 4:5 per comunicare tutto

- Servono headline eccezionali

- Ogni elemento deve lavorare insieme perfettamente

- Non hai 30 secondi per spiegare, ma pochi istanti

### **Errore comune:**

"Le mie immagini non ricevono spesa perché Facebook preferisce i video."

**Realtà:** Le tue immagini non ricevono spesa perché non sono abbastanza buone.

### **Problema dell'esecuzione generica:**

**Esempio:** Annuncio "Career-ending injury" per equipaggiamento hockey

**Hook specifici testati:**

- "Don't risk a career ending injury"

- "That's the best way to stay protected"

- "This is the best way to prevent career ending injuries"

**Hold generico (PROBLEMA):**

- "15x stronger"

- "360° neck and wrist protection"

- "Breathable, comfortable, secure"

- "Zero distractions"

**Cosa mancava:**

- Nessun riferimento specifico agli infortuni che finiscono la carriera

- Nessuna storia o contesto

- Nessun dato emotivo o comportamentale

- Hold applicabile a qualsiasi angolo

**Cosa avrebbe dovuto esserci:**

- Statistiche sugli infortuni

- Storia di un quasi-infortunio grave

- Comportamenti specifici del target

- Emozioni legate alla paura di fine carriera

## **6. ESEMPIO FINALE: ANNUNCI PER BAMBINI (Rabbit R1)**

**Concetto:** Dispositivo AI per bambini\
**Sub-avatar:** Genitore preoccupato per la sicurezza tecnologica dei figli

### **Caratteristiche del sub-avatar:**

- **Desiderio:** Vuole che i figli siano al sicuro

- **Emozione:** Preoccupato per gli effetti della tecnologia sui bambini

- **Comportamento:** Toglie i dispositivi ai figli per limitare il tempo davanti allo schermo

### **Variazioni testate (Metodo Sniper):**

1.  "Tech independence, not app dependence"

2.  "The only AI device your kids should use"

3.  "Safer than a phone, smarter than a book"

**Formato:** Fotografia di prodotto con headline

**Nota:** Tutte e tre le variazioni comunicano allo stesso sub-avatar in modi diversi, mantenendo focus sull'unico angolo (sicurezza per bambini).

## **7. EVITARE LA PARALISI DA ANALISI**

### **Messaggi chiave:**

**Non rimanere bloccato nella "matrice degli angoli":**

- Gli angoli esistono su uno spettro

- Come i sub-avatar, possono avere infinite combinazioni

- L'importante è che sia un punto di vendita valido

**Quando sei confuso:**

- Marksman = Immagini (testa più angoli)

- Sniper = Video (vai in profondità su un angolo)

**Cosa conta davvero:**

- L'esecuzione è tutto

- Un angolo valido può fallire con cattiva esecuzione

- Fai le migliori pubblicità possibili

- Completa i cicli di feedback per capire cosa funziona

## **CONCLUSIONE**

### **Sintesi operativa:**

1.  **Identifica il concetto** (ispirato da modelli vincenti o creatività)

2.  **Definisci gli angoli** (punti di vendita per sub-avatar specifici)

3.  **Scegli il metodo:**

    - Marksman: testa più angoli con variazioni minime

    - Sniper: approfondisci un angolo con esecuzioni multiple

4.  **Esegui con precisione:** Hook specifici + Hold coerente (generico per Marksman, specifico per Sniper)

5.  **Analizza i risultati** e itera

### **La sfida vera non è la strategia, ma l'esecuzione:**

- Hai il framework giusto

- Hai gli strumenti

- Hai la comprensione teorica

**Ciò che ti separa dal successo ora è la capacità di eseguire bene le pubblicità.**

Il prossimo modulo affronterà proprio "Il problema dell'esecuzione" e come evitare di trarre conclusioni sbagliate da test mal eseguiti.

**Azione richiesta:** Prendi queste conoscenze e inizia a creare annunci concreti. L'analisi senza azione non porta risultati.

Execution Problem

# **Execution Problem**

Quindi, quando si tratta della tua pubblicità, dovresti avere tutto ben organizzato. Hai: **Concept** - l'idea per il tuo test **Angle (Angolazione)** - come scegli di vendere il prodotto **Variation (Variazione)** - Le singole esecuzioni dell'angolazione/i **Format (Formato)** - Come distribuisci l'annuncio **Testing Method (Metodo di Test)** - Come testi l'angolazione (marksman, sniper) **Execution (Esecuzione)**: ???

Tuttavia, anche dopo aver organizzato tutto questo, l'annuncio può ancora fallire.

Questa è la parte del marketing con cui tanti marketer faticano perché sentono di aver fatto tutto correttamente. Tuttavia, quando si tratta dell'aspetto pratico dell'esecuzione, hanno mancato il bersaglio.

E ancora peggio, a volte i marketer abbandonano delle angolazioni o rinunciano ad esse semplicemente perché non sanno come eseguirle.

Il che ci porta a una delle lezioni più dolorose, ma anche più importanti che tutti voi dovete conoscere: **il problema dell'esecuzione**.

Il problema dell'esecuzione si verifica essenzialmente quando la tua angolazione è corretta e comprendi davvero il tuo Avatar.

Tuttavia...

Il MODO in cui hai eseguito l'annuncio, cioè le parole che hai scritto E il contenuto che hai usato, non era abbastanza BUONO da convertire effettivamente il cliente.

È qui che tanti marketer faticano nonostante vadano in profondità e comprendano il loro avatar. Semplicemente non sanno come comunicare adeguatamente quella comprensione.

Ora, grazie alla formazione che hai seguito, dovresti avere tantissimi dettagli specifici e frasi dei clienti che puoi usare per scrivere essenzialmente i tuoi script.

E poiché ti ho anche fornito formati per le immagini, in particolare quelli testati e validati per funzionare, possiamo ridurre alcuni dei problemi di esecuzione.

Ma quando si tratta di video e di copywriting in generale, c'è ancora molta possibilità di fallire.

E di nuovo, non voglio che tu fallisca.

Tuttavia, proprio come sei consapevole degli avatar, ora ti renderò consapevole del problema dell'esecuzione.

Quello che ho elencato di seguito sono ragioni molto comuni per cui la tua esecuzione è stata difettosa. Non è ogni singola ragione, ma è un numero sufficiente di cose che posso dire con sicurezza hanno portato al FALLIMENTO degli annunci.

## **Lista Di Ragioni Per Cui Il Tuo Annuncio Sta Fallendo (Dal Punto Di Vista Dell'Esecuzione)**

**Il tuo copywriting manca di impatto emotivo** Il tuo annuncio non fa SENTIRE nulla alle persone. Vuoi che SENTANO qualcosa. Più sembra una conversazione interna che il tuo avatar avrebbe nella sua testa, maggiore è l'impatto emotivo.

**Il tuo annuncio non crea curiosità** La curiosità è una delle cose più importanti da sfruttare nell'esecuzione perché, senza di essa, a nessuno importerà di guardare il tuo annuncio o fare clic. Devi dare naturalmente alle persone una ragione per interessarsi, FERMARE quello che stanno facendo e guardare/cliccare il tuo annuncio.

**Il tuo annuncio non crea suspense (video)** Non c'è motivo per la persona di continuare a guardare il tuo annuncio. Una volta che hai agganciato qualcuno, quello è solo il primo passo. Devi mantenere la suspense affinché le persone continuino a guardare il tuo annuncio. Se non c'è una RICOMPENSA in arrivo, non c'è motivo per loro di continuare a guardare (esempio Mr. Beast).

**Il tuo annuncio è troppo complesso** Se il tuo annuncio si legge a un livello superiore alla sesta elementare, probabilmente sta andando oltre la comprensione delle persone. Devi usare un linguaggio che più persone capiscono, e il mio strumento preferito per questo è l'app Hemingway.

**Il tuo annuncio usa affermazioni vuote** Questa è una delle ragioni più comuni per cui vedo fallire le angolazioni: hai affermazioni vuote. Ad esempio, dici di avere il miglior X o di essere migliore di Y. Ma NON riesci a fornire un motivo reale per cui le persone dovrebbero crederci.

**Il tuo annuncio usa affermazioni autoritarie** Un'altra delle mie preferite è vedere persone dire nei loro annunci: "guarda questi prossimi 5 secondi" o "Devi smettere di scorrere". Hanno funzionato per alcune persone? Certo, ma la maggior parte delle volte, dire alle persone cosa fare quando non gli importa chi sei o cosa hai da dire è una strategia terribile.

**Il tuo annuncio usa affermazioni ripetitive** Se stai facendo le stesse affermazioni, nello STESSO MODO dei tuoi concorrenti... Non c'è motivo per cui ti credano. Ricorda, hanno già sentito tutto prima. Quindi devi trovare NUOVI modi per fornire le informazioni.

**Il tuo annuncio ha uno script scritto e NON parlato** Questa è una cosa che tantissime persone dimenticano. Il modo in cui PARLI è molto diverso dal modo in cui scrivi. Quindi, se scrivi uno script e lo dai a un'intelligenza artificiale per un voiceover, NON suonerà naturale. Devi assicurarti di caricare script che suonino PARLATI (usando la dettatura vocale o chiedendo all'IA di farlo per te).

**Hai scritto l'annuncio per te stesso** Il tuo annuncio è scritto nel modo in cui TU vuoi scriverlo e usa parole che TU usi... Invece di usare le parole esatte del tuo cliente e scriverlo in un modo che piacerebbe al tuo cliente.

**L'angolazione nel tuo annuncio è troppo generica** Ora, grazie a questa formazione sugli avatar, si spera che questo non sia un problema per te, ma alcuni di voi semplicemente non stanno creando annunci o scrivendo i vostri annunci in modo abbastanza relazionabile. Spesso, dopo aver fatto questa formazione, ignorate semplicemente la formazione e tornate a copiare modelli.

**L'angolazione nel tuo annuncio viene detta da tutti gli altri (Sofisticazione)** L'angolazione che stai perseguendo è un'angolazione molto competitiva, e poiché ti manca competenza nel copywriting, non riesci a distinguerti nel tuo mercato.

**Lo stile di editing che stai usando non risuona con il target demografico** Ora, so che dico che i dati demografici non contano. Tuttavia, quando si tratta di consumare contenuti, contano sicuramente... Potresti creare annunci che TU pensi siano belli come un ventenne-venticinquenne, mentre devi creare annunci che siano belli per un cinquantacinque-sessantacinquenne. Devi allineare la tua PROSPETTIVA con quella del tuo cliente (VSL per un Gen Z).

**Hai scelto un formato sbagliato** Potenzialmente, il formato dell'annuncio che hai scelto per eseguire il video semplicemente non era il modo migliore per eseguirlo. Ad esempio, se decidi di fare un annuncio Statico, solo perché quel formato non ha funzionato non significa che l'angolazione non funzioni. Potresti aver semplicemente scelto un formato sbagliato e devi testare un'esecuzione migliore.

Sappi solo che più facile è il formato, MIGLIORE devono essere il messaggio e il copy.

## **Testa Più Formati Per Angolazione**

**Concept 1**: Fotografia di prodotto + Titolo **Concept 2**: Statico/Graphic Design **Concept 3**: Voiceover con b-roll

Se tutti e 3 falliscono, è probabilmente una questione di strategia. Se 2 falliscono ma uno fornisce una direzione, è un problema di esecuzione, e devi solo concentrarti sul comunicarlo meglio.

## **Usa Template Creativi Provati**

Prima di testare nuovi avatar/angolazioni, valida la tua capacità di esecuzione creativa usando:

- Strutture di annunci vincenti dal tuo account

- Strutture di annunci vincenti simili dall'industria in generale

E quando dico "Strutture", intendo COME hai scritto il video + editato l'annuncio stesso.

Questo ti permette di eliminare un po' di supposizioni su "funziona questa angolazione" perché stai usando uno stile di esecuzione che ha funzionato in precedenza.

### **🚨 2 COSE IMPORTANTI**

- Se stai testando un avatar molto diverso, allora potresti aver bisogno di ottimizzare una struttura DIVERSA per quell'avatar

- Ciò che sta vincendo nel tuo account ovviamente non sta vincendo abbastanza perché vuoi scalare ulteriormente. Quindi mi piace l'idea di analizzare annunci che stanno effettivamente scalando ulteriormente, piuttosto che annunci che ti hanno bloccato alla tua spesa attuale.

## **Parametri Di Riferimento Per La Qualità Creativa**

Queste non sono metriche che ti diranno al 100% che il tuo annuncio è cattivo. Ma quando guardo nel complesso i nostri annunci vincenti, queste sono alcune metriche che vedo.

- **Hook Rate** è almeno del 25%

- **Hold Rate** è almeno il 30% di qualunque sia l'hook rate (thruplays/impressions)

- **CTR** è almeno dell'1%

Se i tuoi annunci sono al di sotto di queste metriche, ciò che hai detto o mostrato probabilmente non sta risuonando abbastanza perché le persone si fermino e prestino attenzione.

Ma di nuovo, queste sono metriche indicative. Ci sono annunci con hook rate del 50% che fanno schifo e annunci con hook rate del 20% che spaccano.

Usale come guida per aiutarti a capire se le persone stanno effettivamente interagendo con i tuoi annunci e facendo clic.

## **FAQ**

**Per quanto tempo dovresti testare uno specifico avatar/angolazione prima di cancellare quell'avatar?** Non c'è un periodo prestabilito.

Detto questo, se hai testato un concept Marksman e non ha funzionato, ma eri sicuro di quell'avatar, puoi sicuramente testare un secondo batch usando un approccio con metodo sniper per dargli una vera opportunità e cercare di validarlo.

Dopo di che, se completi un feedback loop sull'annuncio e sei sicuro che sia stato un problema di esecuzione il motivo per cui non ha convertito, puoi farne un terzo.

Tuttavia, qualsiasi cosa dopo 3 è probabilmente solo un segno che non riesci a eseguire questa angolazione correttamente, e quindi potresti dover passare a un'angolazione diversa.

**Quanti concept dovrei creare su un'angolazione?** Se è un annuncio perdente, è uguale a quanto sopra.

Se è un annuncio vincente, puoi crearne quanti ne vuoi. Fai solo attenzione al sovraccarico di iterazioni perché a un certo punto puoi iterare troppo su un'angolazione, e potresti dover fare una pausa e concentrarti invece su altre angolazioni per dare al tuo cervello un "reset" e uno "spazio" per creare.

🖼️ COPY PER STATIC ADS con AI

# **COME SCRIVERE COPY PER STATIC ADS CON AI**

## **Sistema completo con prompt avanzato da 14 pagine per generare annunci statici vincenti**

## **INTRODUZIONE**

Questa lezione presenta un workflow completo per scrivere copy di static ads usando AI, specificamente un prompt da 14 pagine progettato per lavorare in tandem con il Claude Project personalizzato per ogni brand. Il sistema non sostituisce la ricerca strategica, ma la amplifica: funziona solo se hai già fatto ricerca approfondita, compreso il mercato e generato concept solidi nel Growth Guide. L'AI accelera l'esecuzione, non elimina il pensiero strategico.

## **1. PREMESSA FONDAMENTALE**

### **L'AI NON È UNA SCORCIATOIA**

**Verità critica**: questo prompt e sistema **NON funzionano** se non hai fatto ricerca preliminare e non hai buone idee pubblicitarie.

**Cosa devi avere prima di usare il prompt:**

- Comprensione profonda del mercato

- Conoscenza dettagliata del prodotto

- Familiarità con i clienti target

- Concept già sviluppati nel Growth Guide

- Ricerca completata e documentata

**Scopo del prompt**: renderti più veloce, non sostituire il tuo lavoro strategico.

**Se usi questo sistema senza ricerca preliminare, fallirai.**

### **IL RUOLO DEL CREATIVE STRATEGIST**

**Responsabilità irrinunciabili:**

- Fare ricerca autonoma

- Generare idee originali

- Comprendere profondamente il brand

- Scegliere quali headlines/copy usare tra quelle generate

- Applicare giudizio strategico basato su conoscenza del mercato

**L'AI come amplificatore**: una volta che hai le basi strategiche solide, questi prompts ti permettono di produrre volume senza sacrificare qualità.

## **2. ANATOMIA DEL PROMPT DA 14 PAGINE**

### **STRUTTURA COMPLESSIVA**

Il prompt è lungo 14 pagine e altamente strutturato per massimizzare la qualità dell'output.

**Sezioni principali:**

1.  Definizione del ruolo e obiettivo

2.  Prospettiva critica da mantenere

3.  Integrazione con knowledge base

4.  Psicologia delle headlines vincenti

5.  Esempi di annunci eccellenti

6.  Istruzioni per la creazione

7.  Regole finali per image ads

### **SEZIONE 1: DEFINIZIONE DEL RUOLO**

**Setup del ruolo:**

"Sei un elite ad copywriter specializzato nella creazione di scroll-stopping Facebook e Instagram image ads."

**Definizione di successo:**

Un winning image ad è definito come uno con:

- Visual audace che cattura l'attenzione

- Headline potente

- Che permette all'azienda di aumentare lo spend profittevolmente

- Che acquisisce più nuovi clienti

### **SEZIONE 2: PROSPETTIVA CRITICA**

**Mindset fondamentale che l'AI deve adottare:**

**Il target audience:**

- Non conosce il brand

- Non gli importa del brand

- Interessato solo a se stesso

**Implicazione strategica:**

L'image ad DEVE fare appello mostrando che il brand:

- Li capisce

- Comprende i loro problemi

- Conosce i loro desires

- Comprende le loro aspirazioni

**Questo shift di prospettiva è cruciale** - senza questo, l'AI scrive copy centrato sul prodotto invece che sul cliente.

### **SEZIONE 3: INTEGRAZIONE CON KNOWLEDGE BASE**

**Istruzione chiave nel prompt:**

"Devi analizzare e incorporare approfonditamente tutte le informazioni dai documenti nella knowledge base del progetto quando crei ads."

**Cosa include la knowledge base:**

- Market research document

- Customer reviews e feedback

- Analisi commenti ads (Facebook + Instagram)

- Customer questionnaire results

- Competitor analysis

- Tutto ciò che hai caricato nel Brand AI Project

**Perché questo è potente**: l'AI attinge da centinaia di pagine di ricerca simultaneamente, trovando connessioni e insights che potresti non vedere manualmente.

## **3. PSICOLOGIA DELLE GREAT HEADLINES**

### **PRINCIPI PSICOLOGICI INSEGNATI ALL'AI**

Il prompt educa l'AI sui meccanismi psicologici che rendono efficaci le headlines.

**1. PATTERN INTERRUPT**

**Principio**: il cervello umano è progettato per filtrare ciò che è familiare.

**Applicazione**: la headline deve rompere questo sistema di riconoscimento pattern presentando qualcosa di:

- Inaspettato

- Intrigante

- Emotivamente carico

**2. EMOTIONAL RESPONSE**

**Principio**: le persone devono **sentire qualcosa** quando vedono l'annuncio.

**Emozioni target:**

- Curiosità

- Sorpresa

- Riconoscimento ("questo sono io")

- Desiderio

- Urgenza

**3. DEEP DESIRES**

**Principio**: parlare ai desires profondi, non ai bisogni superficiali.

**Esempi:**

- Non "prodotto per il sonno" ma "finalmente svegliarsi riposati"

- Non "focus supplement" ma "smettere di procrastinare e realizzare il potenziale"

**4. INFORMATION GAP**

**Principio**: creare un gap tra ciò che sanno e ciò che vogliono sapere.

**Meccanismo**: la headline apre un loop che può essere chiuso solo leggendo l'annuncio.

**5. VALUE PROMISE**

**Principio**: promettere valore specifico e tangibile.

**Evitare**: promesse vaghe come "migliora la tua vita"

**Preferire**: specifiche come "30 minuti di focus profondo in 2 minuti"

**6. SPECIFIC LANGUAGE**

**Principio**: più specifico = più credibile e interessante.

**Esempio generico**: "Perdi peso velocemente"

**Esempio specifico**: "Perdi 7kg in 30 giorni senza contare calorie"

**7. MAINTAIN CLARITY**

**Principio**: essere clever, non confusi.

**Bilancia**: creatività + comprensione immediata

## **4. ESEMPI DI ANNUNCI ECCELLENTI NEL PROMPT**

### **PERCHÉ GLI ESEMPI SONO CRUCIALI**

**Learning by example**: l'AI impara pattern, tecniche e approcci psicologici dagli esempi forniti.

**Strategia**: fornire esempi eccellenti da nicchie diverse così l'AI può applicare principi universali senza copiare letteralmente.

### **ESEMPI INCLUSI NEL PROMPT**

**1. RYANAIR - Semplicità efficace**

Visual: Pizza vs. Biglietto aereo

Copy: "Pizza: €19 \| Londra-Pisa: €19"

Tagline: "The world's cheapest airline"

**Lezione**: la comparazione semplice e scioccante funziona.

**2. TESLA MODEL S - Specificity**

"Ci vogliono 3.1 secondi per leggere questo annuncio. Lo stesso tempo che serve alla Model S per andare da 0 a 60 miglia all'ora."

**Lezione**: usare numeri specifici e creare connessioni sorprendenti.

**3. NUTELLA - Visual storytelling**

Visual: toast con Nutella che forma un viso sorridente

Copy minimale: "Breakfast"

**Lezione**: a volte l'immagine comunica tutto.

**4. IPOD - Benefit chiaro**

"Say hello to iPod. 1000 songs in your pocket."

**Lezione**: benefit tangibile espresso in modo memorabile.

**5. IKEA - Reframe**

"Roma non fu costruita in un giorno. Ma una cucina può esserlo. Non tutto ciò che è grande richiede una vita."

**Lezione**: ribaltare obiezioni comuni in selling points.

**6. FIAT 500 - Umorismo intelligente**

Visual: Fiat 500 piccola

Copy: "Rimorchia 5 volte più donne di una Lamborghini"

**Lezione**: trasformare un "difetto" (piccola) in vantaggio con umorismo.

**7. NIVEA - Word play**

Visual: click destro su Nivea (come su computer)

Copy: "Let's Nivea it" (play su "Let's clear it")

**Lezione**: giochi di parole memorabili quando ben eseguiti.

### **FILOSOFIA DEGLI ESEMPI**

**Istruzione critica nel prompt:**

"Usa gli annunci di esempio come ispirazione per tecniche, approcci psicologici e strutture efficaci, ma crea headlines originali su misura per questo prodotto e concept. NON adattare o imitare semplicemente le headlines di esempio. Invece applica i principi sottostanti per sviluppare headlines fresche e creative che risuonano con il target audience."

**Obiettivo**: imparare i principi, non copiare le esecuzioni.

## **5. WORKFLOW PRATICO: COME USARE IL PROMPT**

### **STEP 1: PREPARAZIONE**

**Cosa ti serve:**

1.  Claude Project configurato per il brand

2.  Knowledge base popolata con documenti

3.  Concept sviluppato nel Growth Guide

4.  Prompt PDF scaricato

**Download del prompt:**

- Vai al documento del prompt

- Download as PDF

- Salvalo localmente

### **STEP 2: AVVIARE LA SESSIONE**

**Processo:**

1.  Aprire il Claude Project del brand

2.  Drag & drop il PDF del prompt nella chat

3.  Attendere che carichi

4.  Scrivere: "Run this prompt"

**Perché allegare come PDF:**

Quando alleghi il prompt come PDF, Claude può **vedere** tutti gli esempi di annunci inclusi (immagini) e riconoscere i visual patterns, non solo leggere il testo.

### **STEP 3: SPIEGARE IL CONCEPT**

**Claude chiederà**: "What's the core idea behind this static ad concept?"

**Come rispondere efficacemente:**

**Struttura della risposta:**

1.  **Contesto**: dove hai trovato l'idea

2.  **Insight chiave**: quale elemento specifico ti ha colpito

3.  **Angolo proposto**: come vuoi trasformarlo in annuncio

4.  **Dettagli aggiuntivi**: qualsiasi informazione rilevante

**Esempio reale (Flow Pouch - "Hit The Same Every Time"):**

Sto lavorando su un static ad che parla di come Flow colpisce allo stesso modo ogni volta e come non c'è buildup di dipendenza e non costruisci tolleranza contro di esso, come fai con zins o nicotina o caffeina, per esempio.

Ho avuto l'idea guardando uno dei nostri video ads performanti, ecco il transcript:

\[transcript completo dell'annuncio\]

Questa linea mi ha colpito: "E la parte migliore è che non ottieni nessun buildup di tolleranza perché non contiene caffeina o sostanze che creano dipendenza. Quindi colpiscono allo stesso modo ogni singola volta che li usi."

Quindi voglio fare alcuni static ads su quell'angolo di: hit the same every time / no addiction.

**Principio chiave**: più contesto dai, migliori risultati ottieni.

### **STEP 4: RICEVERE LE HEADLINES**

**Output di Claude:**

Dopo aver processato la tua richiesta, Claude genera multiple headline options.

**Esempio di output (Flow Pouch):**

1.  "The only high that never fades"

2.  "The focus that never fades"

3.  "Coffee crashes and fades. Flow doesn't"

4.  "Caffeine fades. Nicotine weakens. Flow delivers"

5.  "They fade away. We hit the same"

6.  "When caffeine fails, Flow is still working"

7.  "The power that doesn't build tolerance"

8.  "Hit different every time? Not here."

**Come valutare le headlines:**

- Quale risuona emotivamente?

- Quale è più specifica?

- Quale crea più curiosità?

- Quale parla direttamente al pain point?

### **STEP 5: ITERARE E RAFFINARE**

**Conversazione continua con Claude:**

Non fermarti alla prima generazione. Chatta con Claude per sviluppare il concept.

**Esempi di follow-up:**

**Per ottenere benefit statements:**

Mi piace questa headline: "Anxiety down. Performance up."

Puoi darmi alcuni benefit statements per questa headline?

**Per variazioni di formato:**

Posso avere versioni di queste headlines ottimizzate per:

\- Venn diagram format

\- Callout boxes

\- Comparison layouts

**Per targeting specifico:**

Quali di queste headlines funzionerebbe meglio per il Nicotine Diehard avatar rispetto al Biohacker?

### **STEP 6: CONTINUARE NELLA STESSA CHAT O NUOVA**

**Opzione A - Continuare nella stessa chat:**

Ok, sono soddisfatto di questo concept. Ora, usando lo stesso prompt, per favore crea un annuncio per questo nuovo angolo:

\[spiega il nuovo concept\]

**Opzione B - Nuova chat:**

- Aprire nuova chat nel Project

- Attach prompt PDF di nuovo

- Run this prompt

- Spiegare il nuovo concept

**Pro/contro di ciascun approccio:**

**Stessa chat:**

- Pro: mantiene contesto

- Contro: può confondere concepts diversi

**Nuova chat:**

- Pro: clean slate per ogni concept

- Contro: deve ricaricare il prompt

## **6. ESEMPIO PRATICO: VENN DIAGRAM AD**

### **IL CONCEPT**

**Format**: Venn diagram con due benefits e prodotto al centro.

**Visual reference**: annuncio esempio con due cerchi sovrapposti.

**Obiettivo**: comunicare visualmente che il prodotto offre entrambi i benefits simultaneamente.

### **PROCESSO CON CLAUDE**

**Step 1 - Allegare reference visual:**

Stiamo lavorando su un Venn diagram ad concept.

Vedi immagine allegata per riferimento.

Su un lato dovrebbe esserci un benefit, sull'altro lato un secondo benefit, e Flow al centro.

**Step 2 - Allegare immagine prodotto:**

Attach: foto del prodotto Flow Pouch

**Step 3 - Lasciare Claude generare opzioni**

### **OUTPUT GENERATO**

**Headline combinations proposte:**

1.  **"Brainpower + No Stimulants"\**

    - Cerchio sinistro: Brainpower

    - Cerchio destro: No Stimulants

    - Centro: Flow

2.  **"Mental Focus + Zero Caffeine"\**

    - Cerchio sinistro: Mental Focus

    - Cerchio destro: Zero Caffeine

    - Centro: Flow

3.  **"Quit Nicotine + Stay Productive"\**

    - Cerchio sinistro: Quit Nicotine

    - Cerchio destro: Stay Productive

    - Centro: Flow

4.  **"Clean Energy + Deep Focus"\**

    - Cerchio sinistro: Clean Energy

    - Cerchio destro: Deep Focus

    - Centro: Flow

5.  **"Keep Your Routine + Upgrade Results"** ⭐

    - Cerchio sinistro: Keep Your Routine

    - Cerchio destro: Upgrade Results

    - Centro: Flow

    - **Rationale**: perfetto per nicotine users che vogliono mantenere il rituale orale

6.  **"Anxiety Down + Performance Up"** ⭐⭐

    - Cerchio sinistro: Anxiety Down

    - Cerchio destro: Performance Up

    - Centro: Flow

    - **Rationale**: comunica due benefits molto desiderati simultaneamente

7.  **"Brain Upgrade + No Dependency"\**

    - Cerchio sinistro: Brain Upgrade

    - Cerchio destro: No Dependency

    - Centro: Flow

8.  **"Natural Ingredients + Supernatural Results"\**

    - Cerchio sinistro: Natural Ingredients

    - Cerchio destro: Supernatural Results

    - Centro: Flow

### **SELEZIONE STRATEGICA**

**Come scegliere quale testare:**

Non tutti i suggerimenti sono uguali. La tua conoscenza del mercato determina quali provare.

**Esempio di reasoning:**

"**Anxiety Down + Performance Up** è probabilmente l'opzione migliore perché:

- Dalla ricerca so che molti clienti Flow lottano con ansia e ADHD

- Entrambi sono huge benefits del prodotto

- Sono due desires che possono essere pairati naturalmente

- Abbiamo già avuto feedback positivo su ads che menzionano ansia

- Il linguaggio è semplice e diretto"

**Questo ragionamento richiede che tu abbia fatto la ricerca preliminare.**

## **7. CHATGPT PER GENERAZIONE VISUAL RAPIDA**

### **CAPACITÀ DI DALL-E 3**

ChatGPT Plus include DALL-E 3, che può generare static ads completi inclusi text e layout.

**Vantaggi:**

- Genera visual + copy insieme

- Rapidissimo per mockup

- Può seguire reference visual

- Utile per brainstorming visuale

### **PROCESSO CON CHATGPT**

**Prompt utilizzato (esempio reale):**

Crea un annuncio come questo.

\[Allega immagine: esempio Venn diagram\]

Ma fallo per questo prodotto: Flow

\[Allega immagine: prodotto Flow Pouch\]

A sinistra voglio il testo: "Anxiety Down"

A destra voglio il testo: "Performance Up"

E Flow dovrebbe ovviamente essere al centro.

### **RISULTATO**

**Output di ChatGPT:**

ChatGPT genera un'immagine completa con:

- Layout Venn diagram

- Prodotto al centro

- Text "Anxiety Down" a sinistra

- Text "Performance Up" a destra

- Styling coerente con il brand

**Qualità**: decente per mockup rapidi, ma probabilmente richiede rifinitura per ads finali.

### **QUANDO USARE CHATGPT VS DESIGNER**

**Usa ChatGPT per:**

- Mockup rapidi per approvazione concept

- Brainstorming visuale

- Testing rapido di layout ideas

- Prime iterazioni

**Usa designer professionista per:**

- Ads finali da lanciare

- Brand consistency perfetta

- High-quality assets

- Animazioni o elementi complessi

## **8. L'IMPORTANZA DELLA RICERCA PRELIMINARE**

### **PERCHÉ L'AI DA SOLA NON BASTA**

**Scenario comune fallimentare:**

Qualcuno va su ChatGPT → "Scrivi una headline per questo brand" → ChatGPT restituisce qualcosa di generico → "L'AI fa schifo!"

**La verità**: l'AI restituisce output proporzionale all'input.

**Confronto:**

- **Prompt generico** (1 frase) = output mediocre

- **Prompt da 14 pagine** + knowledge base + ricerca = output eccellente

### **COSA DEVI SAPERE PRIMA DI USARE L'AI**

**Conoscenza essenziale:**

1.  **Del mercato\**

    - Chi sono i competitor?

    - Come parlano al pubblico?

    - Quali angoli sono già saturi?

    - Quale market sophistication level?

2.  **Del prodotto\**

    - Quali sono i veri benefici?

    - Come funziona esattamente?

    - Cosa lo differenzia davvero?

    - Quali sono i use cases principali?

3.  **Dei clienti\**

    - Quali pain points hanno?

    - Come parlano dei loro problemi?

    - Cosa hanno provato prima?

    - Perché quelle soluzioni hanno fallito?

    - Quali desires profondi hanno?

4.  **Degli annunci esistenti\**

    - Cosa ha performato bene?

    - Perché ha funzionato?

    - Quali pattern emergono?

    - Cosa non ha funzionato e perché?

### **ESEMPIO: "ANXIETY DOWN + PERFORMANCE UP"**

**Perché il relatore sa che questa headline funzionerebbe:**

"So che questa headline sarebbe molto interessante per loro perché:

- So che molti nostri clienti lottano con ansia e ADHD (da customer research)

- So che vogliono anche essere produttivi (da survey e reviews)

- So che questi sono due huge benefits di Flow (da product knowledge)

- So che possiamo pairare questi due naturalmente (da understanding del prodotto)

- Abbiamo già testato ads e ricevuto questo feedback (da results analysis)"

**Nessuna di queste informazioni viene dall'AI - viene dalla ricerca umana.**

### **IL RUOLO DELL'ESPERTO UMANO**

**L'AI genera opzioni. Tu scegli le migliori.**

**Competenze irrinunciabili:**

- **Giudizio strategico**: quale headline testare per prima?

- **Prioritizzazione**: quali concepts hanno più potenziale?

- **Intuizione creativa**: quale angolo è fresco vs. sfruttato?

- **Comprensione psicologica**: cosa risuonerà emotivamente?

- **Conoscenza del brand**: cosa è on-brand vs. off-brand?

## **9. WORKFLOW COMPLETO END-TO-END**

### **FASE 1: PREPARAZIONE (PRIMA DELL'AI)**

**Tempo richiesto**: 2-8 ore per concept

**Attività:**

1.  Studiare market research document

2.  Identificare insight chiave

3.  Sviluppare concept iniziale

4.  Documentare nel Growth Guide

5.  Definire target avatar e desire

6.  Determinare market awareness level

**Output**: concept chiaro e ben definito pronto per execution.

### **FASE 2: GENERAZIONE HEADLINES**

**Tempo richiesto**: 10-20 minuti

**Processo:**

1.  Aprire Claude Project

2.  Attach prompt PDF

3.  Run prompt

4.  Spiegare concept dettagliatamente

5.  Ricevere 8-12 headline options

6.  Selezionare le 2-3 più promettenti

**Output**: headlines finalizzate pronte per design.

### **FASE 3: SVILUPPO COPY COMPLETO**

**Tempo richiesto**: 15-30 minuti per ad

**Attività:**

1.  Chiedere benefit statements

2.  Ottenere callouts

3.  Sviluppare body copy se necessario

4.  Creare variazioni per A/B testing

5.  Refinare basandosi su feedback

**Output**: copy completo per ogni elemento dell'ad.

### **FASE 4: VISUAL CREATION**

**Opzione A - ChatGPT rapid mockup:**

- Tempo: 2-5 minuti

- Usa per: concept approval

- Attach reference + product image

- Genera mockup

**Opzione B - Designer professionista:**

- Tempo: 1-4 ore

- Usa per: final ads

- Fornisci: headlines, copy, concept brief

- Ricevi: polished final assets

### **FASE 5: DOCUMENTAZIONE E TESTING**

**Attività finali:**

1.  Salvare tutte le varianti nel Growth Guide

2.  Marcare come "Working" → "Testing"

3.  Lanciare A/B tests

4.  Monitorare performance

5.  Documentare learnings

6.  Iterare based on data

## **10. BEST PRACTICES E TIPS**

### **COMUNICARE EFFICACEMENTE CON L'AI**

**Principio d'oro**: più contesto fornisci, migliori risultati ottieni.

**Template per spiegare concepts:**

Sto lavorando su \[tipo di ad\] che \[obiettivo principale\].

Ho avuto questa idea perché \[source dell'insight\].

L'elemento chiave che voglio comunicare è \[core message\].

\[Informazioni aggiuntive rilevanti, transcript, data, etc.\]

Il target è \[avatar\] che vuole \[desire\].

Sono al \[market awareness level\].

### **ITERARE INTELLIGENTEMENTE**

**Non accontentarti della prima generazione.**

**Follow-up strategici:**

- "Dammi 5 variazioni più aggressive di \#3"

- "Rendi \#2 più emotiva"

- "Combina il tone di \#1 con il messaging di \#4"

- "Versione più corta di \#7 (max 5 parole)"

- "Quale di queste funzionerebbe meglio per \[avatar specifico\]?"

### **EVITARE ERRORI COMUNI**

**❌ Errore 1: Usare l'AI senza ricerca**

Non chiedere mai all'AI di generare idee dal nulla. Deve sempre basarsi su insights reali.

**❌ Errore 2: Accettare passivamente l'output**

L'AI suggerisce, tu decidi. Non lanciare mai ads senza applicare giudizio critico.

**❌ Errore 3: Non fornire abbastanza contesto**

Prompt di 2 righe = output mediocre. Spiega dettagliatamente il concept.

**❌ Errore 4: Dimenticare la knowledge base**

Se il Brand AI Project ha knowledge base vuota, l'output sarà generico.

**❌ Errore 5: Non testare variazioni**

Genera sempre multiple options e testa in A/B, non scegliere una sola headline "migliore".

### **OTTIMIZZARE IL PROMPT**

**Puoi personalizzare ulteriormente:**

- Aggiungere esempi specifici della tua nicchia

- Includere winners passati del brand

- Aggiungere tone of voice guidelines specifiche

- Incorporare brand vocabulary

- Definire constraint specifici (lunghezza, parole da evitare, etc.)

**Il prompt da 14 pagine è un punto di partenza eccellente, non un endpoint.**

## **CONCLUSIONE**

La scrittura di copy per static ads con AI rappresenta un cambio paradigmatico nel modo in cui i creative strategist lavorano, ma con una precisazione critica: l'AI amplifica l'expertise umana, non la sostituisce. Il prompt da 14 pagine è potente perché insegna all'AI la psicologia delle headlines vincenti, fornisce esempi eccellenti come training, e si integra profondamente con la knowledge base del Brand AI Project.

Tuttavia, tutto questo sistema collassa se non hai fatto il lavoro preliminare essenziale: ricerca approfondita del mercato, comprensione profonda del prodotto, familiarità con i clienti, e sviluppo di concept solidi basati su insights reali. L'AI può generare centinaia di headlines in minuti, ma solo tu - con la tua conoscenza del brand, del mercato e dei risultati passati - puoi scegliere quali testare e perché.

Il workflow presentato (preparazione → generazione headlines → sviluppo copy → visual creation → testing) funziona perché rispetta questa gerarchia: pensiero strategico umano prima, execution accelerata da AI dopo. Quando qualcuno dice "l'AI fa schifo per il marketing", il problema non è l'AI - è che stanno cercando di saltare la fase di ricerca e pensiero strategico. Con preparazione adeguata e questi strumenti, puoi produrre volumi di static ads di alta qualità mantenendo la profondità strategica che separa gli ads vincenti da quelli mediocri.

📽️ SCRIPT PER VIDEO ADS con AI

# **COME SCRIVERE SCRIPT PER VIDEO ADS CON L'INTELLIGENZA ARTIFICIALE**

## **Una guida completa per creare script pubblicitari efficaci attraverso tre formati strategici**

### **INTRODUZIONE**

Questa lezione illustra un metodo strutturato per creare script per video pubblicitari utilizzando l'intelligenza artificiale. Il processo si basa su prompt AI avanzati che integrano principi di psicologia della persuasione e tecniche di copywriting professionale. Il sistema è progettato per generare tre tipologie principali di video ads: General Ads, Organic Ads e Storytelling Ads, ciascuna con caratteristiche specifiche e obiettivi differenti.

## **1. PANORAMICA DEL PROCESSO**

Il processo per creare script video con AI è simile a quello per gli annunci statici, con alcune differenze chiave specifiche per il formato video.

**Flusso di lavoro base:**

- Il prompt AI chiede quale sia l'idea principale del concept pubblicitario

- L'utente descrive il concept e fornisce il contesto necessario

- Il sistema chiede quale tipo di ad si vuole creare (General, Organic o Storytelling)

- L'AI genera 6 hook diversi con suggerimenti visivi

- Viene prodotto uno script completo con breakdown strategica

**Elemento distintivo:** Ogni script generato include una spiegazione dettagliata dei principi psicologici utilizzati, rendendo il processo educativo oltre che operativo.

## **2. I TRE TIPI DI VIDEO ADS**

### **GENERAL ADS (Annunci Generali)**

**Caratteristiche:**

- Parla dalla prospettiva del brand

- È chiaramente riconoscibile come pubblicità

- Ha un tono educativo e/o intrattenente

- Si rivolge direttamente all'audience come azienda

- Mantiene alta qualità ma è intenzionalmente un annuncio

**Quando usarlo:** Quando l'obiettivo è costruire brand awareness e comunicare in modo diretto i benefici del prodotto.

### **ORGANIC ADS (Annunci Organici)**

**Caratteristiche:**

- Parla dalla prospettiva del pubblico target

- Sembra creato da un utente reale, non da un marketer

- Ha un tono autentico e testimoniale

- L'obiettivo è che le persone non capiscano immediatamente che è un annuncio

- Mantiene tutti i principi di copywriting ma in modo "invisibile"

**Quando usarlo:** Quando si vuole creare fiducia attraverso testimonianze apparentemente spontanee e autentiche.

### **STORYTELLING ADS (Annunci Narrativi)**

**Caratteristiche:**

- Presenta il prodotto attraverso una storia coinvolgente

- Crea intrigo facendo sembrare che lo spettatore stia ricevendo informazioni "segrete"

- Usa pattern narrativi che suggeriscono rivelazioni scioccanti o insider secrets

- Spesso inizia con domande o affermazioni che suggeriscono un "cover-up" o cospirazione

- Il linguaggio fa sembrare l'informazione esclusiva e privilegiata

**Esempi di hook narrativi:**

- "Ho passato quattro anni come segretaria di un CEO milionario, e le cose che mi faceva fare erano pazzesche..."

- "Questo tizio sta attaccando l'industria più predatoria del mondo, e persino I Simpson lo avevano previsto anni fa..."

**Quando usarlo:** Quando si vuole catturare l'attenzione attraverso curiosità e intrigo, facendo apparire il messaggio pubblicitario come contenuto interessante piuttosto che come advertising puro.

## **3. COME FUNZIONA IL SISTEMA DI PROMPT AI**

### **FASE 1: Input dell'Idea**

L'AI chiede di descrivere il concept principale. Più contesto e dettagli vengono forniti, migliori saranno i risultati.

**Elementi da includere:**

- L'idea centrale del video

- Contesto di mercato o competitivo

- Ricerche o dati rilevanti

- Script di riferimento se disponibili

- Angolazioni o hook che si vogliono esplorare

### **FASE 2: Selezione del Tipo di Ad**

Dopo aver ricevuto l'idea, il sistema chiede quale formato utilizzare tra General, Organic o Storytelling.

### **FASE 3: Generazione degli Output**

**Il sistema produce:**

1.  **6 Hook Differenti**: Aperture alternative con suggerimenti visivi per ciascuna

2.  **Script Completo**: Testo strutturato pronto per la produzione

3.  **Strategic Breakdown**: Analisi dettagliata dei principi psicologici applicati

### **FASE 4: Iterazione e Raffinamento**

Il vero valore sta nella capacità di dialogare con l'AI per perfezionare lo script:

- "Puoi rendere questo più ampio, focalizzato sull'industria del tabacco in generale?"

- "Puoi accorciare lo script e usare una struttura diversa?"

- "Mi piace questa parte, puoi mantenerla ed espandere il resto?"

## **4. PRINCIPI PSICOLOGICI INTEGRATI**

Tutti gli script, indipendentemente dal tipo, incorporano principi fondamentali di persuasione:

### **PATTERN INTERRUPT**

Interrompere il pattern di scorrimento dell'utente con un'apertura inaspettata.

### **ASSEMBLE, DON'T CREATE**

Il copy non si scrive da zero ma si assembla da blocchi di:

- Claims (affermazioni)

- Desideri del pubblico

- Meccanismi unici

**Principio chiave:** il copy costruisce un mondo di desiderio in cui il prospect può immergersi e proiettarsi.

### **GRADUALIZATION**

Presentare informazioni in modo graduale per costruire credibilità.

### **MECHANIZATION**

Spiegare il "come funziona" per rendere credibile la promessa.

### **INTENSIFICATION**

Aumentare progressivamente l'intensità emotiva del messaggio.

### **CONCENTRATION**

Eliminare sistematicamente le alternative per concentrare il desiderio sul prodotto specifico.

### **REDEFINING THE PROBLEM**

Ridefinire il problema in modo che la soluzione sia necessariamente il prodotto offerto.

**Perché è importante:** Scrivere uno script manualmente tenendo a mente tutti questi principi simultaneamente è estremamente difficile. L'AI può farlo automaticamente se istruita correttamente.

## **5. ESEMPI PRATICI**

### **ESEMPIO 1: GENERAL AD PER FLOW (NICOTINE POUCHES)**

**Contesto fornito:**

- Script di riferimento di un annuncio top-performing

- Richiesta di combinare l'angolazione "nicotina" con il concept esistente

- Ricerche sull'industria del tabacco/nicotina

- Suggerimenti per hook iniziali

**Hook generati:**

- "Quello che la Big Tobacco nasconde ai propri clienti"

- "È arrivato il peggior incubo dell'industria dell'addiction"

**Risultato:** Script che usa concentration per eliminare alternative (nicotina tradizionale) posizionando Flow Pouches come soluzione superiore.

**Iterazioni richieste:**

1.  "Rendilo più ampio, focalizzato sull'industria del tabacco/nicotina in generale, non solo sulle pouches"

2.  "Accorcia lo script e senti libero di usare una struttura diversa dall'esempio"

3.  "Rendilo leggermente più lungo e mantieni questa parte specifica"

### **ESEMPIO 2: ORGANIC AD PER CAREPOD (HUMIDIFIER)**

**Contesto fornito:**

- Convinzione comune: tutti gli umidificatori sono di plastica

- Paure del pubblico: microplastiche, difficoltà di pulizia, muffa

- Unique mechanism: primo umidificatore in acciaio inossidabile al mondo

- Hook suggerito: "Pensavo che tutti gli umidificatori fossero di plastica"

**Script risultante (estratto):** "Onestamente pensavo che tutti gli umidificatori fossero fatti di plastica. Non me lo ero mai nemmeno chiesto, ma il problema è che sono impossibili da pulire correttamente..."

**Differenza chiave:**

- General ad: parla in terza persona dalla prospettiva del brand

- Organic ad: parla in prima persona dalla prospettiva del cliente

- Mantiene tutti i principi psicologici ma in modo "invisibile" e conversazionale

### **ESEMPIO 3: STORYTELLING AD PER FLOW**

**Concept:** Segretaria di un CEO milionario che racconta le abitudini "folli" del capo, incluso l'uso di Flow Pouches per mantenere focus e performance.

**Hook:** "Sono stata la segretaria di un CEO da nove cifre per quattro anni, e le cose che mi faceva fare erano pazzesche"

**Struttura narrativa:**

1.  Apertura intrigante con promessa di informazione "segreta"

2.  Costruzione della storia con dettagli autentici

3.  Transizione naturale verso il prodotto come "scoperta"

4.  Mantenimento dell'interesse attraverso curiosità e rivelazione

**Altro esempio (industria alimentare/ginger):** Hook: "Ho passato quattro anni con uno degli estetisti più pagati di New York, e le cose che mi faceva fare per sembrare perfetta erano folli..."

- Crea intrigo personale

- Promise di informazioni esclusive

- Porta naturalmente al prodotto (in questo caso, tonico allo zenzero)

### **ESEMPIO 4: STORYTELLING AD PER GIFTING (LUXURY PRODUCTS)**

**Concept:** Storia di una donna che lotta per impressionare la suocera esigente con i regali di compleanno.

**Perché funziona:**

- Target audience: donne 30-40 anni

- Scenario relatable: dinamiche familiari complicate

- La storia inquadra il prodotto come "il regalo perfetto"

- Logica implicita: "Se ha impressionato una suocera esigente, può impressionare chiunque"

**Approccio:** Invece di dire "Ecco le migliori idee regalo di lusso" e mostrare il prodotto, si costruisce una narrazione che porta naturalmente alla soluzione.

## **6. IL VALORE DELLA STRATEGIC BREAKDOWN**

Ogni script generato include una sezione che spiega:

### **PRINCIPI PSICOLOGICI UTILIZZATI**

Esempio di breakdown:

- **Pattern Interruption**: Come l'hook interrompe lo scroll

- **Concentration**: Come elimina alternative sistemicamente

- **Mechanization**: Come spiega il meccanismo che rende credibile la promessa

- **Redefining the Problem**: Come ridefinisce il problema per far sembrare la soluzione inevitabile

- **Intensification**: Come aumenta progressivamente l'intensità emotiva

### **EMOTIONAL TRIGGERS ATTIVATI**

Il sistema identifica quali emozioni vengono attivate nello script:

- Paura (di perdere opportunità, di fare scelte sbagliate)

- Curiosità (informazioni "nascoste" o "segrete")

- Aspirazione (diventare come figure di successo)

- Sollievo (finalmente una soluzione che funziona)

### **PERCHÉ L'APPROCCIO DOVREBBE FUNZIONARE**

Spiegazione razionale del concept basata su psicologia del consumatore e dinamiche di mercato.

**Valore educativo:** Questa breakdown previene lo "spam testing" di creatività senza comprensione. Aiuta a capire *perché* uno script è costruito in un certo modo, sviluppando competenze di marketing strategico.

## **7. BEST PRACTICES PER L'UTILIZZO**

### **FORNIRE CONTESTO DETTAGLIATO**

**Approccio migliore:**

- Descrizione completa del concept

- Research esistenti

- Script di riferimento (se disponibili)

- Angolazioni specifiche da esplorare

- Contesto competitivo

**Approccio minimo (funziona ma risultati inferiori):**

- Descrizione breve dell'idea

- Tipo di ad desiderato

### **NON ASPETTARSI PERFEZIONE AL PRIMO COLPO**

**Realtà:** Gli script generati sono generalmente all'80% della perfezione. Richiedono iterazioni e aggiustamenti basati su:

- Conoscenza del mercato

- Familiarità con il pubblico

- Intuizione strategica personale

**Vantaggio dei modelli conversazionali:** Permettono input umano continuo, che è essenziale per ottimizzazione.

### **ITERARE ATTRAVERSO CONVERSAZIONE**

**Esempi di feedback efficaci:**

- "Questo è buono ma troppo simile all'esempio che ti ho dato. Usa una struttura diversa"

- "Mi piace questa parte specifica, mantienila ed espandi il resto"

- "Rendilo più breve/lungo"

- "Cambia il tone da educativo a conversazionale"

- "Non ripetere l'hook nel body dello script"

### **USARE LA BREAKDOWN STRATEGICA**

Non limitarsi a copiare lo script. Leggere e comprendere:

- Quali principi sono stati applicati

- Perché quella struttura dovrebbe funzionare

- Quali emozioni vengono attivate

- Come si differenzia da altri approcci

Questo sviluppa competenze di marketing strategico a lungo termine.

## **8. WORKFLOW OPERATIVO COMPLETO**

### **STEP 1: PREPARAZIONE**

- Copiare il prompt completo

- Aprire il progetto brand su Claude AI

- Incollare il prompt e dire "run this prompt"

### **STEP 2: DEFINIZIONE CONCEPT**

Quando l'AI chiede "What's the core idea behind this video ad concept?", rispondere con:

- Idea principale

- Contesto rilevante

- Research disponibile

- Riferimenti o ispirazioni

### **STEP 3: SELEZIONE TIPO**

Rispondere alla domanda "Should this be a general ad, organic ad, or storytelling ad script?" con una delle tre opzioni.

### **STEP 4: REVISIONE OUTPUT**

Ricevere e valutare:

- 6 hook con visual suggestions

- Script completo

- Strategic breakdown

### **STEP 5: ITERAZIONE**

Continuare la conversazione per raffinare:

- "Puoi modificare X?"

- "Aggiungi Y"

- "Rimuovi Z"

- "Cambia l'approccio a..."

### **STEP 6: FINALIZZAZIONE**

Quando soddisfatti dello script, passare alla fase di produzione video.

## **9. DIFFERENZE CHIAVE TRA I TRE FORMATI**

### **TONO E VOCE**

**General Ad:**

- Tono: Educativo, autorevole, diretto

- Voce: Terza persona, "noi" come brand

- Esempio: "Le nostre pouches offrono..."

**Organic Ad:**

- Tono: Conversazionale, autentico, relatable

- Voce: Prima persona, "io" come utente

- Esempio: "Ho scoperto che queste pouches..."

**Storytelling Ad:**

- Tono: Intrigante, narrativo, rivelatore

- Voce: Prima persona con prospettiva unica

- Esempio: "Quando lavoravo per un CEO milionario ho scoperto..."

### **OBIETTIVO PRIMARIO**

**General Ad:** Comunicare chiaramente value proposition e benefici.

**Organic Ad:** Costruire fiducia attraverso testimonianza apparentemente spontanea.

**Storytelling Ad:** Catturare attenzione attraverso curiosità e mantenere engagement con narrazione.

### **CALL-TO-ACTION**

**General Ad:** Diretta e chiara: "Prova ora", "Scopri di più", "Acquista oggi"

**Organic Ad:** Soft e naturale: "Te lo consiglio davvero", "Devi provarlo", "Link in bio se ti interessa"

**Storytelling Ad:** Integrata nella storia: "È così che ho scoperto...", "Ecco il segreto..."

## **10. PRINCIPI AVANZATI DI COPYWRITING APPLICATI**

### **IL CONCETTO DI "ASSEMBLY"**

Il copy non si *scrive*, si *assembla* da building blocks:

**Building Blocks:**

- Claims specifiche sul prodotto

- Desideri già presenti nel pubblico

- Meccanismi unici di funzionamento

- Proof elements (prove sociali, testimonial, dati)

**Metafora chiave:** "Stai costruendo una città di desiderio in cui il tuo prospect può vivere"

Ogni elemento dello script deve essere un mattone che costruisce questa città, non parole casuali.

### **DIFFICOLTÀ DELLA SCRITTURA MANUALE**

Scrivere uno script efficace manualmente richiede:

- Tenere a mente simultaneamente 5-7 principi psicologici

- Bilanciare tono e autenticità

- Strutturare gradualmente l'informazione

- Eliminare alternative competitrici

- Mantenere engagement continuo

**Nota:** questa è la parte più difficile del copywriting.

**Soluzione AI:** L'AI può applicare tutti questi principi simultaneamente se istruita correttamente attraverso prompt strutturati.

### **ORGANIC ADS: LA SFIDA DELLA STEALTH PERSUASION**

**Paradosso:**

- Deve sembrare completamente spontaneo e non-commerciale

- Deve comunque implementare tutti i principi di persuasione

**Come lo script AI lo risolve:**

- Usa linguaggio quotidiano e colloquiale

- Nasconde la struttura persuasiva in conversazione naturale

- Implementa concentration e mechanization in modo "invisibile"

- Mantiene pattern interrupt attraverso autenticità inaspettata

**Risultato:** Script che anche un copywriter esperto farebbe fatica a creare manualmente, perché richiede bilanciare spontaneità e strategia simultaneamente.

## **CONCLUSIONE**

Il sistema di generazione script per video ads con AI rappresenta un'evoluzione significativa nel processo creativo pubblicitario. I tre formati - General, Organic e Storytelling - coprono l'intero spettro delle esigenze di advertising video, dalla comunicazione diretta di brand alla persuasione sottile attraverso narrazione.

**Vantaggi chiave del sistema:**

- Integrazione automatica di principi psicologici complessi

- Capacità di iterare rapidamente attraverso conversazione

- Educational breakdown che sviluppa competenze strategiche

- Flessibilità per adattarsi a diverse industry e prodotti

**Limitazioni da ricordare:**

- Gli script raramente sono perfetti al primo tentativo (80% accuracy)

- Richiedono input umano e conoscenza del mercato per ottimizzazione

- La qualità dipende dalla qualità del contesto fornito

**Filosofia operativa:** L'AI non sostituisce il marketer strategico, ma amplifica la sua capacità di produrre contenuti di qualità scalando l'applicazione di principi complessi che sarebbero impossibili da gestire manualmente in modo consistente. L'obiettivo è permettere a chi ha la visione strategica di concentrarsi su quella, delegando l'execution tecnica del copywriting all'AI.

Il risultato finale è un workflow che combina il meglio dell'intelligenza umana (strategia, contesto, intuizione di mercato) con il meglio dell'AI (applicazione consistente di principi, produzione rapida, strutturazione ottimale).

🌅 STRUTTURA AD HORMOZI

## **📍 FASE 1: SAPERE DOVE FARE PUBBLICITÀ**

### **Trova una Piattaforma con Queste Caratteristiche**

✅ **L'ho già usata** e ottenuto valore come consumatore, so come funziona

✅ **Posso targettare** persone interessate ai miei prodotti

✅ **So come formattare** annunci per la piattaforma

✅ **Ho il budget minimo** richiesto per pubblicare

### **Strategia di Posizionamento**

Le piattaforme hanno vari posizionamenti dove pubblicare. **Scegli quello dove i competitor stanno pagando adv, replica prima di iterare.**

## **🎯 FASE 2: FAR SÌ CHE IL PUBBLICO GIUSTO LO VEDA**

1.  **Seleziona la piattaforma**

2.  **Seleziona il target** all'interno della piattaforma

**⚠️ Mercati Locali:** Non essere troppo specifico con i filtri

## **🎨 FASE 3: CREARE IL MIGLIOR ANNUNCIO**

### **Analizza i Competitor su 3 Elementi:**

## **1️⃣ CALL-OUT**

## **2️⃣ ELEMENTI DI VALORE**

## **3️⃣ CALL-TO-ACTION**

## **1️⃣ CALL-OUT: ATTIRARE L'ATTENZIONE**

**La parte più importante dell'annuncio** - deve essere abbastanza **specifico** da attirare le persone giuste e sufficientemente **ampio** da catturare il maggior numero possibile.

### **4 Tipologie di Call-Out**

### **🏷️ ETICHETTE**

Parole che classificano le persone in gruppi (caratteristiche, tratti, titoli, luoghi):

- *Mamme di Milano*

- *Proprietari di Palestre*

- *Lavoratori in Remoto*

- *Sto cercando XYZ*

**Regola**: I clienti ideali devono identificarsi immediatamente con l'etichetta.

### **✅ DOMANDE "SÌ"**

Domande dove rispondendo "sì, sono io" si qualificano automaticamente:

- *Ti svegli per fare pipì più di una volta a notte?*

- *Hai difficoltà ad allacciarti le scarpe?*

- *Hai una casa del valore superiore ai 400.000€?*

### **⚡ AFFERMAZIONI "SE-ALLORA"**

Se soddisfano le condizioni, li aiuti a decidere:

- *Se spendi oltre 10.000€ al mese in pubblicità, possiamo farti risparmiare il 20% o più...*

- *Se sei nato tra il 1978 e il 1986 a Roma, potresti avere diritto a un'azione legale collettiva*

- *Se vuoi ottenere XYZ, allora presta attenzione...*

### **🤯 RISULTATI RIDICOLI**

Situazioni bizzarre, rare o straordinarie:

- *Centro massaggi prenotato per due anni. Clienti furiosi.*

- *Questa donna ha perso 25 kg mangiando pizza e ha licenziato il personal trainer*

- *Il governo sta distribuendo assegni da mille euro a chiunque sappia rispondere a tre domande*

### **Elementi Visivi**

**Richiami sono: visivi, testuali, suoni e musiche**

- **Contrasto**: Elementi che spiccano nei primi secondi (colori vivaci, movimenti, suoni distintivi, persone attraenti, oggetti in movimento)

- **Somiglianza**: Mostra visivamente etichette e caratteristiche con cui il target si identifica

### **📊 Formula Call-Out Illimitati**

**30 hooks + 10 creatività = 300 variazioni** Registra 10 annunci e 30+ hooks per i primi 5 secondi

## **2️⃣ ELEMENTI DI VALORE: FRAMEWORK COSA-CHI-QUANDO**

### **Obiettivo**

Rispondere a: **"Perché dovrei essere interessato a ciò che offri?"**

**Regola**: **Grandi vantaggi + Costi minimi** (il costo non deve superare i benefici)

### **🎁 COSA: I 4 Pilastri del Valore**

### **🏆 RISULTATO DEI SOGNI**

**✨ Sogno (+Più)**: Massimo beneficio che il prospect può ottenere

- **Veloce** ⚡ **Facile** 🎯 **Probabile** ✅

**😱 Opposto - Incubo (-Meno)**: Peggiori inconvenienti senza la tua soluzione

- **Lento** 🐌 **Difficile** 😰 **Rischioso** ⚠️

### **📈 PROBABILITÀ PERCEPITA DI SUCCESSO**

**Come Aumentarla:**

- Minimizza/spiega fallimenti passati

- Enfatizza successo di persone simili

- Usa garanzie, autorità, certificazioni

- Mostra possibilità migliori di successo

**Opposto - Rischio**: Mostra quanto sia rischioso non agire, come ripeteranno fallimenti e problemi peggioreranno.

### **⏰ VELOCITÀ vs RITARDO TEMPORALE**

**Velocità**: Quanto più rapidamente otterranno il risultato

**Opposto**: Quanto sia lenta la loro traiettoria attuale o che non otterranno mai quello che vogliono al ritmo attuale

### **💪 FACILITÀ vs SFORZO E SACRIFICIO**

**Facilità**: Come evitare cose che odiano, fare più cose che amano, senza lavorare duramente e ottenere il risultato dei sogni

**Opposto**: La quantità di lavoro e competenze necessarie senza la tua soluzione. Come saranno costretti a rinunciare a cose che amano, soffrire per cose che odiano, lavorare duramente e sacrificare tantissimo senza arrivare da nessuna parte. In altre parole: **sprecano più tempo e denaro** facendo quello che fanno attualmente!

### **👑 CHI: STATUS SOCIALE**

Gli esseri umani sono spinti dallo **status** - come vengono trattati dagli altri.

**Mostra come il prodotto migliora lo status** e come gli altri conferiscono/tolgono status:

**Persone che Danno/Tolgono Status:**

- Se stessi 🪞

- Famiglia 👨‍👩‍👧‍👦

- Amici 👥

- Colleghi 💼

- Rivali ⚔️

- Altri 🌍

### **⏳ QUANDO: PROSPETTIVA TEMPORALE**

Le persone considerano solo l'**impatto immediato**, ma devi mostrare effetti di scelte passate e conseguenze future.

**Timeline da Mostrare:**

- **📜 Passato**: Effetti delle scelte precedenti

- **📍 Presente**: Situazione attuale

- **🔮 Futuro**: Conseguenze del comprare/non comprare

**Focus**: Cambiamento di status con le persone che conoscono per vedere il valore della decisione in questo momento.

### **📏 REGOLA DI EFFICIENZA**

**Specificità Massima + Lunghezza Minima = Efficienza Ottimale**

Usa video/audio per aggiungere dettagli senza appesantire il testo.

## **3️⃣ CALL-TO-ACTION**

### **Principio di Urgenza**

I clienti hanno **grande motivazione** ma solo per **breve periodo** dopo aver visto un annuncio interessante.

### **CTA Efficaci**

- **Specifica**: Di' esattamente cosa fare

- **Rapida**: "Clicca qui", "Chiama questo numero"

- **Facile**: Rimuovi ogni attrito

## **💡 RICERCA COMPETITIVA ILLIMITATA**

### **Metodo per Ispirazione**

1.  **Cerca** "\[PIATTAFORMA\] ad library" su Google

2.  **Identifica** annunci attivi da oltre un mese (= redditizi)

3.  **Analizza 50+ annunci** per richiami, elementi di valore e CTA

4.  **Prendi nota** di parole usate e come dimostrano i benefici

**Risultato**: Enorme vantaggio iniziale per creare annunci vincenti.

## **📋 PASSI OPERATIVI COMPLETI**

### **OBIETTIVO**

Ottenere quanti più angoli pubblicitari possibili usando il framework Cosa-Chi-Quando.

### **COSA**

- Conosci come il prodotto soddisfa ogni elemento di valore

- Conosci come aiuta a evitare i loro opposti

### **CHI**

- Mostra come gli 8 elementi cambiano lo status del prospect

- Dimostra come le persone danno/tolgono status

### **QUANDO**

- Fai vedere conseguenze attraverso passato, presente, futuro

- Focus su cambiamento di status per vedere valore della decisione

## **🎯 PRESUPPOSTO FONDAMENTALE**

> Scrivi sempre supponendo che il pubblico non abbia idea di chi tu sia, di cosa offri o di come funzioni — che sia di fretta e con un livello di lettura molto basso.
>


🧠 HOOKS

# **1. Hooks** 

## **Comprendi gli Stadi di Consapevolezza del Tuo Potenziale Cliente**

<img src="/tmp/pandoc_media_discard/media/image19.png" style="width:5.12014in;height:7.24122in" />

### **STADIO 1: Inconsapevole (Unaware)**

Le persone non sanno ancora di avere un problema. Il tuo obiettivo è far emergere questa consapevolezza, educandole e aiutandole a comprendere che esiste un problema reale che le riguarda.

**Il miglior approccio:** creare storie, segreti e contenuti di infotainment — ovvero comunicazioni che informano e intrattengono allo stesso tempo, catturando l'attenzione e risvegliando curiosità nel pubblico.

### **STADIO 2: Consapevole del Problema (Problem Aware)**

Le persone riconoscono di avere un problema, ma non conoscono ancora la soluzione. Il tuo compito è mostrare che una soluzione esiste, spiegare come funziona ed educarle gradualmente a comprendere perché la tua è la scelta giusta.

**Il miglior approccio:** concentrarsi sui pain points (i punti di dolore) e sui benefici nel risolvere il problema: mostra cosa accade se il problema resta irrisolto e, al contrario, come la vita delle persone può migliorare una volta trovata la soluzione.

### **STADIO 3: Consapevole della Soluzione (Solution Aware)**

Le persone sanno di avere un problema e conoscono le diverse soluzioni possibili, ma non sanno ancora quale faccia davvero al caso loro. Il tuo obiettivo è far capire che la tua soluzione è quella giusta da approfondire, introducendo con naturalezza il prodotto come esempio o dimostrazione pratica, senza ancora spingerlo direttamente alla vendita.

### **STADIO 4: Consapevole del Prodotto (Product Aware)**

Le persone conoscono il tipo di prodotto che può risolvere il loro problema, ma non sono ancora completamente convinte che il tuo sia la scelta giusta per loro. Il tuo obiettivo è dimostrare in modo concreto che il prodotto funziona, utilizzando prove reali, testimonianze, recensioni, before/after e qualsiasi elemento di credibilità che rafforzi la fiducia.

**Approccio:** dimostrare con prove che il prodotto funziona (Proof that the product works).

### **STADIO 5: I Più Consapevoli (Most Aware)**

Le persone sanno di avere un problema e riconoscono che il tuo prodotto è la soluzione migliore. A questo punto non serve più convincerle, ma spingerle all'azione. Vogliono sapere quanto costa, quali offerte o vantaggi possono ottenere e perché devono acquistare ora. Il tuo obiettivo è stimolare l'acquisto attraverso sconti, offerte a tempo limitato, bonus esclusivi e senso di urgenza.

**Approccio:** offerte, promozioni e prezzi (Offers, promotions & pricing).

## **Il Desiderio del Tuo Potenziale Cliente Definisce lo Stadio di Consapevolezza**

### **Esempio Pratico**

**Inconsapevole:** "Io voglio sentirmi meglio con me stesso." → Non collega ancora il desiderio al problema dell'altezza.

**Problem Aware:** "Io voglio smettere di sentirmi inferiore quando parlo con persone più alte." → Sa che c'è un disagio, ma non sa come risolverlo.

**Solution Aware:** "Io voglio qualcosa che mi faccia sembrare più alto senza che nessuno se ne accorga." → Desidera la soluzione, ma non conosce ancora il prodotto giusto.

**Product Aware:** "Io voglio scarpe che mi alzino davvero e siano belle da indossare ogni giorno." → Sa cosa cerca, ma non è ancora sicuro del brand.

**Most Aware:** "Io voglio le SkyKickz, sono perfette per me." → Desiderio chiaro, definito, pronto all'acquisto.

## **Capire da Quale Stadio di Consapevolezza Partire**

Capire da quale stadio di consapevolezza partire dipende dal **livello di sofisticazione del mercato** del tuo prodotto.

### **Mercato Poco Sofisticato**

In un mercato poco sofisticato, dove le persone non conoscono ancora il problema o la soluzione, devi partire da **Unaware** o **Problem Aware**. Qui il tuo compito è educare e creare consapevolezza.

**Attenzione:** Più il pubblico è inconsapevole, più è difficile vendere: servono tempo, storytelling e contenuti che generino curiosità.

### **Mercato Molto Sofisticato**

In un mercato molto sofisticato, dove tutti conoscono già le soluzioni e i competitor sono tanti, puoi partire da **Product Aware** o **Most Aware**. Qui la vendita è più diretta: devi solo differenziarti, mostrare prove e spingere all'acquisto.

## **Esempio: Dolore alla Schiena (Back Pain)**

**🔹 Anni fa:** "Ho mal di schiena, sarà lo stress." → Mercato poco consapevole → serviva educazione e spiegazione del problema.

**🔹 Oggi:** "So che ci sono cuscini ortopedici, quale funziona davvero?" → Mercato maturo → serve prova, credibilità e differenziazione.

## **Relazione tra Consapevolezza e Difficoltà di Vendita e Scalabilità**

Facile da vendere ────────────────────────► Difficile da vendere

Most Aware Product Aware Solution Aware Problem Aware Unaware

Meno scalabile ◄──────────────────────────── Più scalabile

## **In Sintesi**

👉 **Più il cliente è inconsapevole, più devi educarlo.**

👉 **Più è consapevole, più è pronto a comprare.**

# **Struttura Hook**

VISUAL VIDEO

I primi 3 secondi sono i più importanti, perché determinano se un potenziale cliente si ferma sulla nostra inserzione.

Se non si ferma, continua a scorrere e non vedrà mai il resto dell’annuncio.

Raddoppiare l’hook rate significa portare il doppio delle persone a guardare il resto dell’ad.

**Tipi di Clip Hook**

- **NO** Hook in stile clickbait **NO\**

- Mostra il risultato o la soluzione ideale

- Clip ASMR / strane

- Mostra il problema

- Mostra il prodotto

TESTUALE

Il tuo hook text deve:

- Richiamare il pubblico giusto

- Promettere un beneficio

- Spingere le persone a voler leggere di più

Ti senti sempre stanco e senza energia durante l’inverno?

X (Brand) ti aiuta a respirare meglio e a sentirti rinvigorito ogni giorno.

L’aria secca rovina la pelle e rende l’ambiente pesante da respirare.

Con X (Brand) mantieni la tua casa sana, idratata e piacevole in ogni stagione.

**Enhancers**

- Invertire i video per renderli più strani o coinvolgenti

- Raccontarlo dalla prospettiva di un'altra persona. Invece di "Ho perso così tanto peso" \> "Non posso credere che tu abbia perso così tanto peso, sembri fantastico"

Le persone si preoccupano molto di più di ciò che gli altri o la società pensano di loro. Può riguardare l'aspetto personale, come viene presentato il loro bambino, i loro mobili, ecc.

La maggior parte delle persone cerca di impressionare gli altri.

# 

# 

🧠 HOOK 2

# **VIDEO HOOKS PT.2:** 

L'hook di un video pubblicitario è l'elemento più critico dell'intera campagna. Hai circa tre secondi, forse meno, per fermare lo scroll dell'utente e catturare la sua attenzione. Non importa quanto sia perfetto il resto del video: senza un hook efficace, nessuno arriverà a vederlo. Questa lezione analizza i principi fondamentali per creare hook che funzionano, le tecniche di testing sistematico e gli errori da evitare.

## **1. PERCHÉ L'HOOK È TUTTO**

L'hook determina il successo o il fallimento dell'intero annuncio pubblicitario. La maggior parte delle persone scorre il feed in modo automatico, con il pollice in movimento costante. **Il tuo hook deve fermare quel pollice immediatamente.**

L'errore più comune è dedicare ore alla perfezione del prodotto, dello script e della struttura dell'ad, per poi aggiungere un hook generico e banale. Il risultato? Performance scadenti.

**Principio chiave:**

- Hai 3 secondi o meno per catturare l'attenzione

- Se l'hook non funziona, nessuno vedrà il resto del video

- L'hook è più importante di qualsiasi altro elemento dell'ad

## **2. COMPOSIZIONE: CHIAREZZA IMMEDIATA**

La composizione non è un termine tecnico sofisticato, ma un principio pratico: **nei primi tre secondi, le persone devono capire immediatamente cosa stanno guardando.**

### **Considerazioni pratiche:**

- Gli utenti tengono il telefono a circa mezzo metro dal viso

- Nessuno guarda i Reels o scorre Facebook con il telefono lontano

- Il tuo hook deve essere ovvio e il testo leggibile

- Deve esserci un unico punto focale chiaro

**Regola d'oro:** Le persone non devono essere confuse. Se devono fermarsi a pensare "Cosa sto guardando?", hai già perso la loro attenzione.

## **3. CONTESTO: RENDERE IL VIDEO SCANSIONABILE**

Gli utenti non guardano i contenuti sui social media, li **scansionano**. Quando vedono un blocco di testo enorme, cercano qualcosa da scansionare rapidamente. Il tuo hook deve fornire contesto immediato.

### **Come dare contesto:**

**Attraverso il testo (hook text):**

- Testo grande, in grassetto, facile da leggere

- Posizionato nella parte superiore dello schermo

**Attraverso visual chiari:**

- Un video di qualcuno che lancia un telefono contro il muro non ha bisogno di testo esplicativo

- La storia deve essere immediatamente comprensibile

### **Confusione vs Intrigue: la differenza critica**

**❌ Confusione negativa:** "Non capisco cosa sto guardando" → Perdita di attenzione

**✅ Intrigue positiva:** "Aspetta, come funziona? Voglio saperne di più" → Cattura l'attenzione

**Esempio:**

- "Ho perso 5 kg mangiando pizza ogni due giorni" → Questo crea intrigue, non confusione

- Sfida le credenze dell'utente e lo spinge a voler sapere di più

## **4. HOOK TEXT: IL TESTO CHE VENDE**

L'hook text non sono i sottotitoli standard che seguono il parlato. È un elemento strategico che appare nei primi secondi e dice esattamente perché l'utente dovrebbe interessarsi.

### **Caratteristiche dell'hook text efficace:**

- **Specifico, non generico:** Evita frasi come "La migliore protezione per gli occhi di sempre"

- **Relazionabile:** Parla direttamente a un problema specifico del target

- **Presente dal frame 1:** Niente animazioni fancy, niente slide-in ritardati

- **Più grande dei caption normali:** Deve essere immediatamente visibile

- **Posizionato strategicamente:** Non deve competere con il visual principale

**Esempio debole:** "Questa è la migliore protezione per gli occhi di sempre"

**Esempio forte:** "Ho smesso di avere mal di testa e gioco ancora a Minecraft 5 ore ogni notte" → Specifico, relazionabile, risolve un problema chiaro per i gamer

## **5. ESERCIZIO PRATICO: CONDENSARE I MESSAGGI**

Molti creator fanno introduzioni lunghe e prolisse. Il tuo compito è condensarle in hook text efficaci che le persone possano scansionare in mezzo secondo.

### **Esempio 1:**

**Messaggio originale:** "Passavo ore in palestra a fare cardio, ma non vedevo mai risultati finché non ho scoperto questa routine di allenamento di 15 minuti"

**Hook text ottimizzato:** "Ho sostituito 2 ore di cardio con 15 minuti di QUESTO"

**Perché funziona:**

- Mantiene il contrasto tra allenamenti lunghi e brevi

- "QUESTO" in maiuscolo crea curiosità

- Diretto e scansionabile

### **Esempio 2:**

**Messaggio originale:** "Ero scettico all'inizio perché ho provato ogni integratore per dormire sul mercato, ma questo mi ha davvero aiutato a dormire tutta la notte per la prima volta in anni"

**Hook text ottimizzato:** "Questo integratore mi ha finalmente fatto dormire 8 ore da insonne"

**Perché funziona:**

- Elimina tutto il setup scettico

- Si concentra sul risultato

- Identifica chi è il target (insonni)

### **Esempio 3:**

**Messaggio originale:** "Come gamer professionista che passa 12 ore al giorno davanti agli schermi, avevo terribili mal di testa finché non ho trovato questi occhiali"

**Hook text ottimizzato:** "Come gioco 12 ore al giorno senza mal di testa da pro esports"

**Perché funziona:**

- Mantiene le 12 ore (impressionante)

- "Pro esports" dà autorità maggiore di "gamer"

- Mostra esattamente a chi è rivolto

## **6. TESTING SISTEMATICO: LA CHIAVE DEL SUCCESSO**

Non si lancia mai una sola versione di un annuncio. Il testing è ciò che separa i professionisti dagli amatori. Quando testi, devi focalizzarti su due elementi principali: **messaging** e **visuals**, e testarli **separatamente**.

### **SCENARIO 1: Testing del Messaging**

Prendi lo stesso video identico e crea tre variazioni con hook text diversi, ognuno che targettizza un desiderio differente:

**Esempio - Prodotto dimagrante:**

- Variazione 1: "Ho perso 30 kg senza rinunciare ai carboidrati" → Targettizza la libertà alimentare

- Variazione 2: "Finalmente entro nei miei vecchi jeans" → Targettizza obiettivi specifici

- Variazione 3: "Non mi nascondo più nelle foto" → Targettizza la trasformazione emotiva

**Stesso video, stesso visual, solo il messaggio cambia.**

### **SCENARIO 2: Testing dei Visual**

Mantieni il messaggio esattamente identico e testa diversi hook visivi:

- Variazione 1: Apertura con trasformazione prima/dopo

- Variazione 2: Persona che fatica ad abbottonare i jeans

- Variazione 3: Persona felice e sicura che mostra i risultati

**Stesso messaggio, tre approcci visivi diversi.**

### **Perché NON testare entrambi insieme?**

Se testi messaggio e visual contemporaneamente e la variazione 2 performa meglio, **non saprai mai perché:**

- Era il messaggio?

- Era il visual?

- Stai solo indovinando.

**Indovinare è da amatori. I professionisti testano metodicamente.**

## **7. ITERAZIONE: DAL VINCITORE AL SUPER VINCITORE**

Quando trovi l'hook vincente, non fermarti. Usalo come nuovo baseline e testa nuove variazioni contro di esso.

**Esempio:**

- Scopri che "prima/dopo" funziona meglio

- Ora crea tre diverse versioni di "prima/dopo"

- L'hook numero 6 potrebbe performare ancora meglio dell'originale

**I brand di successo non creano semplicemente ads, conducono esperimenti controllati.** Ogni lancio è un'opportunità per imparare qualcosa di nuovo sul proprio pubblico.

La differenza tra lanciare una versione e testare hook multipli può essere la differenza tra **perdere soldi** e **scalare alle stelle**.

## **8. L'EGO: IL NEMICO NASCOSTO DEL TESTING**

Dopo aver speso oltre 20 milioni in advertising, la lezione più importante appresa è questa: **il tuo intuito è probabilmente sbagliato più spesso di quanto sia giusto.**

### **Lezioni apprese sul campo:**

- Le idee più stupide che quasi non sono state lanciate hanno generato profitti incredibili

- Le strategie su cui il team ha lavorato per una settimana, con ricerche approfondite e massima fiducia, sono fallite miseramente

**I dati non si preoccupano del tuo ego.**

- I dati non si preoccupano se pensi che un'idea sia stupida

- I dati si preoccupano solo di ciò che funziona

### **Approccio pratico:**

Chiunque nel team (editor, strategist, designer, copywriter, intern o senior) può proporre idee per gli ads. Dopo essere stati umiliati troppe volte da ads che pensavamo avrebbero fallito ma hanno stampato soldi, abbiamo imparato a **lasciare che siano i numeri a parlare** invece del nostro istinto.

**Quando qualcuno del team propone un'idea che sembra ridicola, testala comunque.** Alcuni dei tuoi ads vincenti più grandi verranno dalle idee che quasi non hai provato.

## **9. RIEPILOGO: ANATOMIA DI UN HOOK KILLER**

Quando metti insieme tutti gli elementi, un hook video efficace è composto da:

### **1. Visual che ferma lo scroll**

- Non si tratta solo di ottenere attenzione casuale o fare clickbait

- Si tratta di ottenere **la giusta attenzione**

- Il visual deve essere istantaneamente chiaro per il tuo pubblico target

- Zero confusione, zero caos

- Solo impatto visivo cristallino che fa pensare al cliente ideale: "Aspetta, questo potrebbe interessarmi"

### **2. Testo strategico di supporto**

- Non un romanzo

- Non animazioni fancy

- Solo testo chiaro e leggibile che dà contesto

- Dice alle persone esattamente perché dovrebbero continuare a guardare

**Pensa all'hook come a due componenti:**

- Il visual fa fermare lo scroll

- Il testo dà contesto e li fa rimanere

In questo modo hai **due hook in uno** e aumenti le probabilità che più persone si fermino.

### **3. Testing basato sui dati**

- Testa visual diversi mantenendo il testo uguale

- Oppure testa messaggi diversi mantenendo il visual uguale

- Lascia che i dati e le performance degli ads ti dicano cosa funziona

- Non affidarti al tuo istinto o a cosa fanno i competitor

## **CONCLUSIONE**

L'hook è l'elemento più critico di qualsiasi video pubblicitario. Determina se il tuo messaggio verrà visto o ignorato. Per creare hook efficaci:

- **Fornisci chiarezza immediata** attraverso composizione e contesto

- **Usa hook text strategici** che siano specifici, relazionabili e scansionabili dal frame 1

- **Distingui tra confusione e intrigue** - vuoi la seconda

- **Testa sistematicamente** messaging e visuals separatamente

- **Itera sui vincitori** per trovare versioni ancora più performanti

- **Abbandona il tuo ego** e lascia che siano i dati a guidarti

Il successo negli ads non viene dall'intuito, ma dalla disciplina nel testare, misurare e ottimizzare continuamente. Le tue migliori idee potrebbero essere quelle che quasi non hai provato.

⌛ RETENTION DI MR. BEAST

# **TECNICHE DI RETENTION DI MR. BEAST: COME MANTENERE L'ATTENZIONE NEGLI ADS**

**Applicare i principi di YouTube con miliardi di visualizzazioni per creare pubblicità che le persone guardano fino alla fine**

## **INTRODUZIONE**

Mr. Beast ottiene decine e centinaia di milioni di visualizzazioni su ogni video, portando le persone a guardare dall'inizio alla fine. Questo è un vero dominio dell'attenzione. Anche se non stiamo creando video YouTube di 30 minuti, i principi che usa per mantenere l'attenzione delle persone sono oro puro per le pubblicità. Che tu abbia tre secondi, tre minuti o trenta minuti, la psicologia per mantenere l'attenzione rimane la stessa. Questa lezione analizza le tecniche di retention che generano miliardi di visualizzazioni e come applicarle ai tuoi ads.

## **1. OPEN LOOPS: CICLI APERTI CHE CREANO DIPENDENZA**

Il cervello umano è programmato per prestare attenzione alle cose che creano **loop aperti** nella nostra mente. È come quando qualcuno inizia a raccontarti una storia interessante, sei completamente coinvolto, e poi viene interrotto da una chiamata. Il tuo cervello sente un prurito irresistibile di sapere come finisce la storia.

### **Come Mr. Beast stratifica i loop aperti**

**Esempio: "Ho passato 50 ore sepolto vivo"**

Il team di Mr. Beast è maestro nel creare questi cicli:

- **Loop principale:** Sopravviverà 50 ore sepolto vivo?

- **Loop secondario:** Sta arrivando una tempesta e la bara potrebbe allagarsi

- **Loop terziario:** I suoi livelli di ossigeno stanno calando, cosa succederà?

- **Loop quaternario:** Il team di supporto sta considerando di tirarlo fuori

Ogni nuovo problema crea un altro loop che il tuo cervello ha bisogno di vedere chiuso.

### **Applicazione agli ads: stratificare i loop**

**Esempio pratico - Integratore per perdita di peso:**

**Loop 1:** Mostriamo qualcuno che ha perso 50 kg → Apre la domanda: "Come hanno fatto?"

**Loop 2:** Li mostriamo mentre demoliscono una scatola di pizza pur essendo magri → Crea la domanda: "Aspetta, possono mangiare quello e rimanere così?"

**Loop 3:** Mostriamo foto prima/dopo e la foto "prima" è di soli 90 giorni fa → Il cervello cerca di capire: "Come è possibile un cambiamento così drammatico in così poco tempo?"

**Loop 4:** Mostriamo testimonianze di altre persone con gli stessi risultati → Apre la domanda: "Funziona per tutti, non solo per questa persona?"

### **Il potere strategico dei loop**

**Cosa abbiamo fatto:**

- Ogni nuova rivelazione non aggiunge solo informazioni

- Distrugge completamente ciò che lo spettatore pensava fosse possibile

- Il cervello ora corre: "Come può qualcuno perdere tanto peso mangiando quello che vuole in soli 90 giorni? E funziona per tutti?"

**Nota cruciale:** Non abbiamo ancora rivelato il prodotto. Stiamo intenzionalmente costruendo tensione, accumulando risultati che sembrano impossibili, rendendo le persone emotivamente investite **prima** ancora di mostrare la soluzione.

## **2. SCETTICISMO VS INVESTIMENTO EMOTIVO**

### **Il problema di rivelare il prodotto troppo presto**

Quando le persone vedono il tuo prodotto troppo presto in un ad, il loro cervello entra in **modalità scettica:**

- "Oh, è solo un altro integratore"

- "Oh, è solo un altro programma truffa per perdere peso"

### **La strategia dei loop aperti**

Quando costruisci prima questi loop, quando fai loro mettere in discussione tutto ciò che pensavano di sapere sulla perdita di peso, **non stanno solo guardando il tuo ad - sono emotivamente investiti** nel scoprire come questo sia possibile.

**Pensieri dello spettatore durante i loop:**

- "Non è possibile che questo funzioni" (scetticismo naturale)

- "E se fosse quella cosa che mi mancava?"

- "E se funzionasse davvero per tutte quelle persone?"

- Stanno provando **speranza** che potrebbe risolvere il loro problema

**Momento cruciale:** Quando riveli il prodotto, non stanno solo guardando - **stanno aspettando la risposta**. È esattamente quando sono più pronti a sentire parlare del tuo prodotto.

## **3. PRINCIPIO DI EDITING \#1: VARIETÀ VISIVA E RITMO**

### **L'errore fatale nell'editing degli ads**

Iniziare con un hook forte, editing dinamico e ritmo veloce, ma poi **sgonfiarsi**:

- L'energia cala

- Il ritmo diventa strano

- Il resto dell'ad è fatto con poca cura

**Gli spettatori non sono stupidi.** Possono capire quando hai messo tutto lo sforzo nei primi tre secondi e poi hai fatto il resto con superficialità. Nel momento in cui lo percepiscono, la loro fiducia scompare e se ne vanno.

### **Come Mr. Beast mantiene gli occhi impegnati**

**Regola fondamentale:** Non lasciare mai che gli occhi dello spettatore si mettano comodi.

**Pattern di cambiamento visivo:**

- **Ogni 3-5 secondi:** Nuova angolazione della camera

- **Ogni 10 secondi:** Nuova scena o sviluppo

- **Ogni 20-30 secondi:** Nuova mini storia o sviluppo della sfida

**Ogni cambio visivo ha uno scopo strategico:**

- **Primi piani:** Per momenti emotivi

- **Inquadrature larghe:** Per scala e impatto (zoom out per mostrare l'intera area)

- **Reaction shot:** Per autenticità (footage grezzo della camera, dietro le quinte)

- **Velocità variabile:** Il team sa esattamente quando accelerare o rallentare

### **Comprimere il principio per gli ads**

Non abbiamo minuti, abbiamo secondi. **Qualcosa deve succedere ogni 1-3 secondi del tuo ad:**

- Un B-roll deve cambiare

- Una nuova animazione

- Nuovo testo che appare

- Qualcosa deve cambiare

Le persone scorrono a velocità della luce attraverso il feed. Se il tuo ad non continua a dare loro nuove informazioni visive ogni paio di secondi, se ne vanno.

### **Adattare il ritmo al pubblico**

**NON è una regola universale:**

**Target Gen Z:**

- Qualcosa che succede ogni singolo secondo

- Edit veloci

- "Brain rot editing"

**Target over 60:**

- Editing veloce ed eretico sarebbe il peggior errore possibile

- Non riescono a tenere traccia di tutto

**Chiave del successo:** Capire il tuo pubblico e far sembrare l'editing come il contenuto che consumano già ogni giorno.

## **4. PRINCIPIO \#2: PSICOLOGIA DELLA PROGRESS BAR**

Mr. Beast usa un trucco psicologico con le barre di progresso, specialmente nei segmenti sponsorizzati. È assolutamente geniale.

### **Come funziona la tecnica**

**Fase 1 - Partenza rapida:**

- La barra di progresso si muove super velocemente all'inizio

- Nei primi 10 secondi è già al 50%

- Il cervello vede questo e pensa: "Oh, sarà veloce, guardalo"

**Fase 2 - Rallentamento strategico:**

- La seconda metà richiede molto più tempo

- Ma sei già investito - hai guardato metà

- Il cervello pensa: "Beh, tanto vale finirlo ora"

### **Applicazioni pratiche per gli ads**

**Esempio 1 - Prodotto skincare:**

- Hook: "Questo prodotto dà risultati in sole due settimane"

- Invece di saltare direttamente al prima/dopo

- Inizi a parlare d'altro e aggiungi un timer: "Vedi i risultati tra 15 secondi"

- Il timer parte

- Lo spettatore ha ora un'aspettativa chiara: sa esattamente quanto tempo deve prestare attenzione prima di essere ricompensato

**Esempio 2 - Testimonianze:**

- Invece di metterle una dopo l'altra

- Aggiungi una piccola barra di progresso che si riempie con ognuna

- Mostra avanzamento visibile

**Esempio 3 - VSL (Video Sales Letter):**

- Prima parte: approfondisci il problema, i pain point, le difficoltà

- Menzioni qua e là una "soluzione rivoluzionaria" ma non riveli mai cosa sia

- Mai rivelare il prodotto fino a più tardi nell'ad

- Proprio prima di rivelare il prodotto: **"Soluzione rivoluzionaria rivelata tra 20 secondi"**

- Parte il timer

- Mentre conta alla rovescia, rinforzi tutto ciò di cui hai parlato

- Quando il timer arriva a zero, sono sul bordo della sedia in attesa di vedere la soluzione

### **Il principio psicologico**

**Le persone rimangono più a lungo quando sanno esattamente quanto tempo devono prestare attenzione.**

Sono molto più propense a guardare il video o parte del video fino alla fine perché:

- Possono vedere che stanno facendo progressi

- Vengono ricompensate mentre guardano

## **5. RIEPILOGO: LEZIONI DA MR. BEAST PER GLI ADS**

### **I tre pilastri della retention**

**1. OPEN LOOPS (Cicli aperti)**

- Fai in modo che le persone abbiano bisogno di sapere cosa succede dopo

- Stratifica rivelazione dopo rivelazione

- Ognuna più intrigante della precedente

**2. VARIETÀ VISIVA** (Il più importante)

- Non lasciare mai che gli occhi degli spettatori si mettano comodi

- Cambia sempre qualcosa ogni 1-3 secondi

- Abbina il ritmo di editing al tuo pubblico target

**3. PSICOLOGIA DEL PROGRESSO**

- Usa segnali visivi, timer o barre di progresso

- Mantieni le persone investite fino alla fine

- Dai loro ricompense per aver completato parti del video o l'intero video

### **La verità sull'attenzione**

**Un hook che ferma lo scroll potrebbe far fermare le persone, ma sono questi principi di retention che le mantengono a guardare il tuo ad.**

In un mondo dove l'attenzione è la valuta più preziosa, è così che vinci.

## **CONCLUSIONE**

Le tecniche di Mr. Beast non sono magia, sono psicologia applicata. Ogni secondo di un video da miliardi di visualizzazioni è progettato per mantenere l'attenzione. Negli ads, dobbiamo essere altrettanto ossessivi su ogni frame.

**Principi chiave da ricordare:**

- Gli open loops creano dipendenza mentale e investimento emotivo

- La varietà visiva costante impedisce la noia e l'abbandono

- Le barre di progresso e i timer creano aspettative chiare e ricompense psicologiche

- L'editing deve essere adattato al pubblico specifico, non universale

**Applicazione pratica:** Non basta fermare lo scroll con un buon hook. Devi mantenere l'attenzione per tutto il video usando stratificazione strategica, cambio visivo costante e psicologia del progresso. Solo così trasformi viewer in clienti.

L'attenzione è la valuta più preziosa del marketing moderno. Questi principi sono il modo per vincere quella battaglia.

🏹 SCRIPT

# **GUIDA STEP-BY-STEP PER CREARE UN SCRIPT ADV**

## **1️⃣ FASE DI BOZZA**

**Obiettivo:** Gettare le fondamenta dello script identificando chi è il tuo pubblico, cosa desidera e come catturare la sua attenzione. In questa fase crei la struttura base e raccogli più opzioni di hook per testare cosa funziona meglio.

**Cosa fare:** Definisci il concept, identifica la persona target e il suo desiderio principale, seleziona il livello di consapevolezza del pubblico (quanto sanno già del problema/soluzione), scrivi multipli hook per ogni livello di consapevolezza e costruisci un flusso logico che accompagna il pubblico da dove si trova ora a dove vuoi portarlo.

### **Descrizione del Concept**

\[Scrivi qui una descrizione chiara e concisa del concept pubblicitario\]

### **Persona Avatar e Desiderio**

**Persona Avater:** \[Definisci chi è il tuo pubblico target\]

**Desiderio Principale:** \[Identifica il desiderio centrale della persona target\]

### **Fase di Consapevolezza Iniziale**

**Fase selezionata:**

- \[ \] Non consapevole

- \[ \] Consapevole del problema

- \[ \] Consapevole della soluzione

- \[ \] Consapevole del prodotto

- \[ \] Massima consapevolezza

### **Hook per Fase di Consapevolezza**

**Non Consapevole:** \[Hook 1\] \[Hook 2\] \[Hook 3\]

**Consapevole del Problema:** \[Hook 1\] \[Hook 2\] \[Hook 3\]

**Consapevole della Soluzione:** \[Hook 1\] \[Hook 2\] \[Hook 3\]

**Consapevole del Prodotto:** \[Hook 1\] \[Hook 2\] \[Hook 3\]

### **Flusso dello Script**

**Introduzione (Non Consapevole → Consapevole del Problema):** \[Testo\]

**Sviluppo (Consapevole del Problema → Consapevole della Soluzione):** \[Testo\]

**Presentazione (Consapevole della Soluzione → Consapevole del Prodotto):** \[Testo\]

**Conclusione (Massima Consapevolezza + CTA):** \[Testo\]

## **2️⃣ FASE DI RAFFORZAMENTO**

**Obiettivo:** Dare profondità emotiva allo script. Qui trasformi una bozza funzionale in un messaggio che tocca il cuore e la mente del pubblico, creando immagini vivide che fanno sentire il dolore del problema e il desiderio della soluzione.

**Cosa fare:** Espandi il desiderio con dettagli specifici, crea contrasti forti tra lo scenario "paradiso" (come sarà la vita con la soluzione) e "inferno" (cosa succede se non agiscono), usa parole cariche emotivamente, aggiungi dettagli che stimolano curiosità e rendono i benefici tangibili e desiderabili.

### **Approfondimento del Desiderio**

\[Espandi e approfondisci il desiderio target con dettagli specifici\]

### **Immagini Mentali Vivide**

**Paradiso (Soluzioni - Scenario Ideale):** \[Descrivi con parole emotive e descrittive lo scenario ideale dopo aver risolto il problema\]

**Inferno (Problemi - Scenario Negativo):** \[Descrivi con parole emotive e descrittive le conseguenze di non agire\]

### **Elementi Emozionali**

**Parole Emotive:** \[Lista di parole potenti da utilizzare\]

**Dettagli che Aumentano la Curiosità:** \[Elementi specifici che creano interesse\]

**Promesse di Benefici:** \[Benefici concreti e tangibili\]

## **3️⃣ FASE DI RIFINITURA**

**Obiettivo:** Rendere lo script scorrevole, naturale e potente. Questa fase elimina tutto ciò che non serve e perfeziona ogni parola perché suoni come una conversazione vera, non come pubblicità scritta.

**Cosa fare:** Leggi lo script ad alta voce per sentire se suona naturale, togli tutto il "filler" (parole che riempiono ma non aggiungono valore), semplifica frasi complesse, assicurati che il tono sia conversazionale come se parlassi a un amico, verifica che ogni parola abbia uno scopo preciso (vendere, emozionare, convincere).

### **Checklist di Rifinitura**

- \[ \] Script letto ad alta voce

- \[ \] Linguaggio naturale e conversazionale

- \[ \] Parole superflue eliminate

- \[ \] Ogni parola conta

- \[ \] Testo autentico e credibile

### **Script Rifinito**

\[Inserisci qui la versione finale dello script dopo la rifinitura\]

## **4️⃣ VISUALIZZAZIONE**

**Obiettivo:** Abbinare elementi visivi che amplificano il messaggio dello script. I visual devono sembrare nativi per il pubblico (come contenuti che vedono già) e rinforzare emotivamente ogni parte del messaggio.

**Cosa fare:** Scegli uno stile visivo che il tuo target già conosce e in cui si riconosce, fai riferimento a contenuti simili che guardano già (es. se il target guarda video fitness, usa quello stile), crea visual accattivanti e a volte esagerati per catturare l'attenzione, abbina ogni sezione dello script con visual specifici che rafforzano quel messaggio.

## **🧐 RIFLESSIONE FINALE E CONTROLLO QUALITÀ**

**Obiettivo:** Verificare che tutto funzioni insieme prima di lanciare. Questo controllo finale assicura che l'hook sia potente, i visual siano appropriati, il linguaggio sia autentico e l'annuncio sembri naturale per il pubblico target.

**Cosa fare:** Verifica che l'hook catturi immediatamente l'attenzione del target giusto, controlla che font e design siano leggibili e adatti, assicurati che l'annuncio non sembri "pubblicità" ma contenuto che il pubblico vede normalmente, conferma che il linguaggio sia naturale e relazionabile per quel pubblico specifico.

### **Elementi Visivi Scelti**

**Tipo di contenuto:** \[Descrivi lo stile visivo che si adatta alla persona target\]

**Riferimenti nativi:** \[Contenuti simili che il pubblico già guarda\]

### **Piano Visuale per Sezioni**

**Sezione 1 - Hook:** \[Descrizione visual\]

**Sezione 2 - Problema:** \[Descrizione visual\]

**Sezione 3 - Soluzione:** \[Descrizione visual\]

**Sezione 4 - CTA:** \[Descrizione visual\]

### **Note Visive**

**Stile:** \[Accattivante, esagerato, realistico, ecc.\]

**Messaggi Rinforzati:** \[Come i visual supportano il testo\]

## **🧐 RIFLESSIONE FINALE E CONTROLLO QUALITÀ**

### **Checklist Finale**

**Hook:**

- \[ \] Richiama il pubblico target?

- \[ \] Mostra chiaramente il problema?

**Font e Leggibilità:**

- \[ \] Font leggibile?

- \[ \] Adatto alla persona specifica?

**Naturalezza:**

- \[ \] L'annuncio assomiglia a contenuto nativo?

- \[ \] Il pubblico lo vede già in altri contesti?

**Linguaggio:**

- \[ \] Linguaggio nativo?

- \[ \] Relazionabile per il pubblico?

- \[ \] Autentico e credibile?

### **Note Finali per Ottimizzazione**

\[Aggiungi qui eventuali note finali o modifiche da apportare\]

**Data di Creazione:** \[Data\] **Versione:** \[Numero versione\]

1️⃣ THE RULE OF ONE

THE RULE OF ONE

# **LA REGOLA DELL'UNO: Come Creare Annunci che Convertono**

## **Cos'è la Regola dell'Uno**

La Regola dell'Uno è il principio fondamentale dietro agli annunci pubblicitari che generano milioni di dollari. Si basa su tre elementi:

1.  **Un Avatar** (una sola persona target)

2.  **Un Desiderio** (un solo obiettivo specifico)

3.  **Un Messaggio** (una sola comunicazione coerente)

## **Perché Funziona**

**Il problema comune:** L'80% dei brand e-commerce cerca di inserire tutto in un singolo annuncio: tutti i benefici, tutti i target possibili, tutte le soluzioni. Questo approccio fallisce perché:

- **La confusione uccide le conversioni**

- Più cose aggiungi, più indebolisci il messaggio

- Chi legge non si riconosce completamente e abbandona

**Esempio negativo:** Un annuncio che parla di nebbia mentale, mal di schiena E menopausa insieme. Chi soffre solo di menopausa penserà "questo non è per me" perché le altre due cose non la riguardano.

## **COME APPLICARE LA REGOLA DELL'UNO**

### **1. DEFINISCI UN AVATAR SPECIFICO (Non un Demografico)**

**❌ SBAGLIATO - Avatar Troppo Generico:** "Donne che soffrono di dolore al ginocchio"

Questo è solo un demografico, non un avatar. È troppo ampio e ci sono milioni di prodotti che competono per lo stesso pubblico.

**✅ GIUSTO - Avatar Specifico e Dettagliato:**

**Nome:** Sarah, 45 anni

**Storia passata:** Ha appena fatto un intervento al ginocchio, ha speso \$2.000 in fisioterapia che non ha funzionato

**Dolore emotivo:** Amava pattinare sul ghiaccio con le amiche ma non può più farlo. Si sente frustrata perché ha perso una parte della sua identità

**Vita quotidiana:** Si alza la mattina con dolore, quando va al lavoro deve fingere con i colleghi che non le fa male per non sembrare debole

**Obiettivo desiderato:** Vuole una soluzione olistica che si integri nella sua vita quotidiana

### **Come Costruire un Avatar Specifico**

Devi rispondere a queste domande:

- Qual è il loro **dolore emotivo specifico**?

- Quali **tentativi passati** hanno già fatto (che non hanno funzionato)?

- Quali sono i loro **obiettivi desiderati** precisi?

- Quali sono le loro **abitudini quotidiane**?

- Che tipo di **contenuti consumano**?

- Su cosa **spendono il tempo libero**?

- Quali **hobby sono limitati** dal loro problema?

**Regola importante:** Crea UN avatar per annuncio. Non passare da Sarah che ha fatto l'intervento al ginocchio a Giovanni che non può giocare a golf. Sono due avatar diversi = due annunci diversi.

### **2. IDENTIFICA IL VERO DESIDERIO (Non Quello Superficiale)**

La maggior parte delle persone si ferma al desiderio superficiale. Devi scavare più a fondo usando la tecnica dei "5 Perché".

**❌ SBAGLIATO - Desiderio Superficiale:** "Voglio sembrare meglio"

**✅ GIUSTO - Desiderio Profondo:**

**Esempio 1 - Shapewear:**

- Superficie: "Voglio sembrare più magra"

- Perché? "Per sentirmi più sicura"

- Perché? "Per fare colpo alla riunione degli ex compagni"

- Perché? "Per far capire al mio ex cosa ha perso"

- Perché? "Perché voglio sentirmi **desiderata e voluta di nuovo**"

**DESIDERIO VERO:** Sentirsi desiderata e amata

**Esempio 2 - True Classic (magliette da uomo):**

- Superficie: "Voglio sembrare bene"

- **DESIDERIO VERO:** Attrarre l'altro sesso, ottenere un secondo appuntamento

Nota come True Classic non vende solo "magliette che stanno bene". Il loro hook è: "Sei sicuro di ottenere un secondo appuntamento". Parlano al desiderio intrinseco: gli uomini vogliono piacere alle donne.

### **Come Trovare il Vero Desiderio**

Continua a chiederti "Perché?" fino a raggiungere un'emozione universale:

- Essere amati

- Sentirsi desiderati

- Essere rispettati

- Sentirsi sicuri

- Appartenere a un gruppo

- Essere ammirati

### **3. MANTIENI UN SOLO MESSAGGIO COERENTE**

Il messaggio deve essere lo stesso dall'inizio alla fine del customer journey.

**Congruenza attraverso il funnel = Zero frizioni**

Pensa al customer journey come a un appuntamento:

- **L'annuncio è il tuo "pick-up line"** su Tinder

- **La landing page è l'appuntamento vero**

Se il profilo Tinder promette una cosa e poi l'appuntamento è completamente diverso (catfish), la persona scappa.

**❌ ESEMPIO DI INCONGRUENZA:**

- **Annuncio:** "Ginocchiera per nonne che vogliono giocare con i nipoti"

- **Landing page:** Parla di uomini che vanno in palestra

**✅ ESEMPIO DI CONGRUENZA:**

- **Annuncio:** Sarah, 45 anni, vuole tornare a pattinare dopo l'intervento al ginocchio

- **Landing page:** Parla esattamente di come questa ginocchiera aiuta donne di 40-50 anni che hanno fatto interventi e vogliono tornare ai loro hobby preferiti

**Lo stesso scenario, le stesse emozioni, lo stesso linguaggio.**

## **APPLICAZIONE PRATICA COMPLETA**

### **Step 1: Scegli UNO scenario specifico per il tuo Avatar**

Invece di dire "aiuta con il dolore al ginocchio", scegli:

- La nonna che non può giocare con i nipoti

- OPPURE l'atleta che non può più allenarsi

- OPPURE la donna che non può più ballare

**Non mescolarli mai nello stesso annuncio.**

### **Step 2: Identifica il linguaggio del tuo Avatar**

- **Se il tuo avatar è Gen Z:** usa il loro slang, mostra situazioni a scuola, parlare con coetanei

- **Se è un padre di mezza età:** usa linguaggio diverso, scenari familiari

- **Se sono anziani:** evita linguaggio giovanile, parla di scenari rilevanti per loro

### **Step 3: Mostra scenari relazionabili**

Non dire solo "questo prodotto è buono". Mostra:

- **Momenti specifici** della loro giornata

- **Problemi reali** che hanno affrontato

- **Tentativi falliti** del passato

- **Come si sentiranno** dopo aver risolto il problema

**Esempio balsamo labbra (cosa NON fare):** L'annuncio nel documento dice semplicemente "se hai labbra screpolate, prova questo". Ma:

- La persona nell'annuncio non ha nemmeno labbra screpolate visibili

- Non mostra scenari specifici (es: Gen Z a scuola imbarazzata per le labbra)

- Non spiega come è diverso dagli altri balsami già provati

- Dice solo "mi piace come si sente" (chiunque può dirlo)

### **Step 4: Verifica la congruenza**

Controlla che dal primo secondo dell'annuncio all'ultimo paragrafo della landing page:

- Parli alla **stessa persona**

- Con lo **stesso desiderio**

- Usando lo **stesso linguaggio**

- Mostrando gli **stessi scenari**

## **RISULTATI ATTESI**

Quando applichi correttamente la Regola dell'Uno:

✅ Il cliente si **riconosce completamente** nell'annuncio

✅ Pensa "questo prodotto è fatto **solo per me**"

✅ Si crea **fiducia** (trust)

✅ La **conversione aumenta drasticamente**

✅ Puoi scalare oltre il milione di dollari con un singolo creativo

## **ERRORI DA EVITARE**

❌ "Mi rivolgo a donne 25-55 anni" → Troppo ampio

❌ "Risolve 5 problemi diversi" → Troppo confuso

❌ Annuncio per giovani + landing page per anziani → Incongruente

❌ "Voglio sembrare meglio" → Desiderio troppo superficiale

❌ Cercare di piacere a tutti → Finisci per non piacere a nessuno

VIDEO EDITING TIPS

VIDEO EDITING TIPS

[<u>https://app.milanote.com/1QIvii1eR1hg9m?p=wDv1vmDwhPi</u>](https://app.milanote.com/1QIvii1eR1hg9m?p=wDv1vmDwhPi)

IDEE INFINITE PER AD

# **FRAMEWORK PER NON RIMANERE MAI SENZA IDEE PER ADV**

<img src="/tmp/pandoc_media_discard/media/image23.png" style="width:8.71875in;height:11.05208in" />

## **STRUTTURA A 6 LIVELLI**

Questo framework ti permette di creare infinite combinazioni di ads testando un elemento alla volta.

## **1️⃣ PRODUCT (Livello Base)**

**Cosa fare:** Scegli quale prodotto pubblicizzare

- Se hai più prodotti, testa prodotti diversi

- Se hai un solo prodotto, puoi testare colori diversi dello stesso prodotto

- Anche mostrare lo stesso prodotto in modo diverso conta come variazione

**Esempio:** Asciugacapelli rosa vs nero vs bianco

## **2️⃣ AD CONCEPT (Tipo di Concetto)**

**Cosa fare:** Decidi come approcciarti all'idea dell'ad

**3 Tipi di Ad Concept:**

### **Imitation (Imitazione)**

Ricrea ads che hai visto funzionare per altri

### **Iteration (Iterazione)**

Ricrea varianti di ads che HAI GIÀ FATTO tu stesso

### **Ideation (Ideazione)**

Crea ads completamente da zero, nuove idee

## **3️⃣ DESIRE (Desiderio Target)**

**Cosa fare:** Identifica quale desiderio del cliente vuoi colpire

Ogni prodotto ha **multipli desideri** che può soddisfare.

**Esempio Asciugacapelli:**

- **Desiderio \#1:** Asciugare i capelli velocemente (risparmio tempo)

- **Desiderio \#2:** Non svegliare i bambini (silenziosità)

- **Desiderio \#3:** Non danneggiare i capelli (protezione termica)

**Importante:** I desideri non sono solo features/benefici, ma bisogni emotivi profondi (es. "voglio essere più attraente", "voglio muovermi veloce nella vita")

## **4️⃣ MARKET AWARENESS (Livello di Consapevolezza)**

**Cosa fare:** Scegli quanto il tuo pubblico è già informato

**5 Livelli:**

1.  **Unaware** - Non sanno nemmeno di avere il problema

2.  **Problem Aware** - Sanno di avere il problema

3.  **Solution Aware** - Conoscono tipi di soluzioni generiche

4.  **Product Aware** - Conoscono il tuo tipo di prodotto

5.  **Aware** - Conoscono già il tuo brand (retargeting/vendita diretta)

**Esempio per Desiderio "Asciugare Veloce":**

- **Unaware:** "Sai che mediamente passi 15 minuti ad asciugare i capelli?"

- **Problem Aware:** "Stanco di perdere tempo ad asciugare i capelli?"

- **Solution Aware:** "Hai provato asciugamani riscaldati? Prova invece questo..."

- **Product Aware:** "Confronto con altri asciugacapelli costosi"

## **5️⃣ MESSAGING (Come Lo Dici)**

**Cosa fare:** Testa modi diversi di comunicare lo STESSO concetto

Questo è uno dei test più importanti perché il messaging può cambiare drasticamente i risultati.

**Esempio per lo stesso concept:**

- **Messaging \#1:** "I migliori capelli vengono dalla migliore tecnologia"

- **Messaging \#2:** "Paga per la performance, non per il brand"

- **Messaging \#3:** "Non ti serve un altro asciugacapelli, ti serve nuova tecnologia"

**Stesso messaggio, parole diverse = risultati diversi**

## **6️⃣ VISUAL (Elemento Visivo)**

**Cosa fare:** Per ogni messaging, testa 3 visual diversi

**Esempi di Visual:**

- Foto prodotto su sfondo bianco

- Persona che usa il prodotto

- Before/After

- Grafica con testo

- Video testimonial

- Etc.

**Importante:** Una volta trovato il messaging vincente, testalo su multipli visual per trovare la combinazione perfetta.

## **📊 COME TESTARE (Metodologia 3-2-2)**

**Regola d'Oro:** Testa UN solo elemento alla volta, mantieni tutto il resto costante.

### **Esempio Pratico:**

**Se testi 3 Desideri diversi:**

- Mantieni stesso: Ad Concept + Awareness Level + Messaging + Visual

- Cambia solo: Il Desiderio (Desiderio \#1 vs \#2 vs \#3)

**Se testi 3 Messaging diversi:**

- Mantieni stesso: Product + Ad Concept + Desire + Awareness + Visual

- Cambia solo: Il Messaging

**Se testi 3 Visual diversi:**

- Mantieni stesso: Product + Ad Concept + Desire + Awareness + Messaging

- Cambia solo: Il Visual

## **🔄 FLUSSO DI LAVORO**

1.  Inizia da: **Product** → **Ad Concept** → **Desire**

2.  Scegli: **Awareness Level**

3.  Testa: **3 Messaging** (mantieni tutto il resto uguale)

4.  Trova il vincente

5.  Testa: **3 Visual** con quel messaging vincente

6.  Trova la combinazione vincente

7.  Ricomincia testando un **Desire diverso** o **Awareness Level diverso**

## **💡 PERCHÉ FUNZIONA**

Con questo framework hai **INFINITE COMBINAZIONI**:

- 1 Prodotto

- × 3 Tipi di Concept (Imitation/Iteration/Ideation)

- × 3+ Desideri

- × 5 Livelli di Awareness

- × 3+ Messaging

- × 3+ Visual

= **405+ combinazioni diverse per UN solo prodotto!**

## **✅ RIEPILOGO RAPIDO**

1.  **Product** - Cosa vendi

2.  **Ad Concept** - Imitare/Iterare/Ideare

3.  **Desire** - Quale bisogno soddisfi

4.  **Awareness** - Quanto sanno già

5.  **Messaging** - Come lo dici

6.  **Visual** - Come lo mostri

**Testa un livello alla volta. Non riuscirai MAI più a rimanere senza idee.**

💸 Campagne PROMO

**GUIDA STEP-BY-STEP PER CAMPAGNE PROMOZIONALI**

STEP 1: STRUTTURA DELLA CAMPAGNA

Crea 1 SINGOLA CAMPAGNA CBO (Campaign Budget Optimization) con 3 ad set:

**<u>Ad Set 1 - BROAD (Pubblico Freddo)</u>**

• Target: Solo età, genere e paese

• NO lookalike

• NO interessi

**<u>Ad Set 2 - WARM 60s (Pubblico Tiepido - ultimi 60 giorni)</u>**

• Engager pagina Facebook

• Engager profilo Instagram

• Visualizzatori video al 95%

• ESCLUDERE: Pubblico Hot 90s

**<u>Ad Set 3 - HOT 90s (Pubblico Caldo - ultimi 90 giorni)</u>**

• Visitatori sito web

• Aggiunti al carrello

• Inizio checkout

• Visualizzazione contenuto

STEP 2: CREAZIONE PUBBLICI PERSONALIZZATI

**Per il pubblico WARM 60s:**

1\. Vai su Business Manager → Menu → Pubblici

2\. Crea pubblico → Pubblico personalizzato

3\. Crea 3 pubblici separati:

• Pagina Facebook → Ultimi 60 giorni

• Account Instagram → Ultimi 60 giorni

• Video → Visualizzazioni al 95% → Ultimi 60 giorni

**Per il pubblico HOT 90s:**

1\. Crea pubblico → Pubblico personalizzato → Sito web

2\. Seleziona tutti gli eventi:

• Visitatori del sito web

• Visualizzazione contenuto

• Aggiunti al carrello

• Inizio checkout

3\. Imposta durata: 90 giorni

STEP 3: CREATIVITÀ PER LE PROMO

**Metodo Semplice ed Efficace:**

1\. Prendi le tue migliori creatività esistenti (video/immagini)

2\. Aggiungi un banner con l'offerta (es: "BLACK FRIDAY -50%")

3\. Crea grafiche semplici: prodotto + testo offerta

Nota: Le creatività per le promo sono semplici perché il pubblico è già consapevole. Non serve convincere, solo annunciare l'offerta.

STEP 4: SCALING DELLA CAMPAGNA

**Scaling Standard (Budget \< \$3.000/giorno):**

• Se performance sopra obiettivo del 20-50% → Aumenta budget del 20%

• Se performance sopra obiettivo del 50-100% → Raddoppia il budget

• Se performance sotto obiettivo → Riduci budget del 20%

**Surf Scaling (Budget \> \$3.000/giorno):**

Richiede software di attribuzione (TripleWhale, Hyros, WeTrack)

Frequenza controlli:

• \< \$50k/giorno: ogni 4 ore

• \> \$50k/giorno: ogni 2 ore

Regole di scaling ogni intervallo:

• Risultati 50-100% sopra KPI → Raddoppia budget

• Risultati 20-50% sopra KPI → Aumenta 20%

• Risultati al KPI → Mantieni

• Risultati sotto KPI → Riduci 20%

IMPORTANTE: A mezzanotte resetta il budget a un valore intermedio basato sulla performance del giorno.

STEP 5: PUNTI CHIAVE

✓ Una sola campagna CBO per semplicità di gestione

✓ Facebook allocherà automaticamente il budget dove performa meglio

✓ Il retargeting funziona particolarmente bene durante le promo

✓ Non complicare le creatività - l'offerta è il messaggio principale

✓ Monitora e scala in base ai dati, non alle sensazioni

**Formula riassuntiva:** Annuncia la promo → Struttura campagna semplice → Aggiungi banner alle migliori creatività → Scala in base ai risultati

## **REGOLE AUTOMATICHE PER CAMPAGNE PROMO**

### **QUANDO USARE LE REGOLE**

Le regole servono per automatizzare l'accensione/spegnimento di campagne con date specifiche (es: San Valentino, Black Friday) senza dover intervenire manualmente.

### **STEP 1: ACCEDI ALLE REGOLE**

• Vai nel tuo Ad Account • Nella barra centrale trova e clicca su "Rules" (Regole) • Clicca "Create New Rule" (Crea nuova regola) • Seleziona "Custom Rule" (Regola personalizzata) • Clicca "Next"

### **STEP 2: CONFIGURA LA REGOLA**

**Nome della Regola:** Usa un nome descrittivo, esempio: "San Valentino Promo 2024 - Auto Off"

**Applicazione della Regola:** Scegli su cosa applicare la regola: • Campagne intere • Ad Set specifici\
• Singoli annunci • Tutte le campagne attive

**Suggerimento:** Se hai già la campagna attiva, selezionala prima di creare la regola così si applicherà automaticamente solo a quella.

### **STEP 3: IMPOSTA L'AZIONE**

**Azione principale:** Turn Off (Spegni)

Puoi anche usare le regole per: • Turn On (Accendi) • Aumentare budget • Diminuire budget

### **STEP 4: DEFINISCI LE CONDIZIONI**

1.  Clicca su "Cost per result" nel menu condizioni

2.  Scorri e trova "Settings"

3.  Clicca su "Time"

4.  Seleziona "Current time is greater than"

5.  Imposta data e ora di fine promo (es: 14 Febbraio, mezzanotte)

### **STEP 5: FINALIZZA LA REGOLA**

**Impostazioni finali:** • Time Range: Lascia default • Schedule: "Continuously" (Continuamente) • Verifica che la data sia corretta • Clicca "Create"

### **COME FUNZIONA**

• La regola controlla automaticamente ogni 30 minuti • Quando l'ora corrente supera quella impostata, esegue l'azione • Puoi vedere lo stato in "View Active Rules" • Il cambio di stato richiede circa 20-30 minuti

### **ESEMPIO PRATICO**

**Scenario:** Promo San Valentino che finisce il 14 febbraio a mezzanotte

1.  Seleziona la campagna "San Valentino 2024"

2.  Crea regola → Custom Rule

3.  Nome: "Auto Off San Valentino 14/02"

4.  Azione: Turn Off

5.  Condizione: Current time \> 14/02/2024 00:00

6.  Schedule: Continuously

7.  Create

**Risultato:** La campagna si spegnerà automaticamente dopo mezzanotte del 14 febbraio senza nessun intervento manuale.

### **PUNTI CHIAVE DA RICORDARE**

✓ Le regole sono perfette per campagne con date di inizio/fine precise ✓ Controllano ogni 30 minuti circa ✓ Possono gestire campagne, ad set o singoli annunci ✓ Eliminano errori umani (dimenticarsi di spegnere una promo) ✓ Puoi creare regole anche per scaling automatico basato su performance

**Formula veloce:** Seleziona campagna → Rules → Custom Rule → Turn Off → Time greater than \[data fine\] → Create

## **METODO SURF SCALING AVANZATO**

### **COS'È IL SURF SCALING**

Metodo di scaling che permette di aumentare/diminuire il budget più volte al giorno invece che una sola volta. Utilizzato per massimizzare i profitti durante periodi ad alta conversione (Black Friday, Cyber Monday, etc.).

### **QUANDO USARE IL SURF SCALING**

**Requisiti essenziali:** • Periodi di vendita importanti (Black Friday, saldi stagionali) • Software di attribuzione third-party (TripleWhale, Hyros, Northbeam) • Budget minimo di \$3.000/giorno • Team disponibile per monitorare ogni periodo

### **STEP 1: DETERMINA LA FREQUENZA DI SCALING**

**Base la frequenza sul tuo budget giornaliero:**

• **\$100-1.000/giorno** → Ogni 6-8 ore • **\$1.000-5.000/giorno** → Ogni 4-6 ore\
• **\$5.000-20.000/giorno** → Ogni 4 ore • **\$20.000-50.000/giorno** → Ogni 2-4 ore • **\$50.000-100.000/giorno** → Ogni 1-2 ore

**Perché:** Budgets più alti generano più dati, permettendo ottimizzazione più frequente.

### **STEP 2: IMPOSTA IL FOGLIO DI TRACKING**

**Crea un foglio con queste colonne:**

1.  Orario periodo (ogni 2/4/6 ore)

2.  Revenue Shopify del periodo

3.  Revenue Meta del periodo

4.  Spesa pubblicitaria

5.  ROAS Meta (Revenue Meta / Spesa)

6.  Blended ROAS (Revenue totale / Spesa totale)

7.  Decisione presa (scala su/giù/mantieni)

**IMPORTANTE:** Usa SEMPRE il fuso orario dell'ad account, non il tuo locale.

### **STEP 3: REGOLE DI SCALING PER OGNI PERIODO**

**Analizza le performance e applica queste regole:**

• **Blended ROAS 50-100% sopra obiettivo** → Raddoppia il budget • **Blended ROAS 20-50% sopra obiettivo** → Aumenta budget del 20-50% • **Blended ROAS al target** → Mantieni budget attuale • **Blended ROAS sotto target** → Riduci budget del 20%

**Metrica chiave:** Il Blended ROAS (Revenue Shopify / Spesa totale) è più affidabile del ROAS in-platform di Facebook.

### **STEP 4: ESEGUI LO SCALING**

**Esempio pratico:** • 6:00 - Performance 2x target → Budget da \$10k a \$20k • 8:00 - Performance 1.5x target → Budget da \$20k a \$30k • 10:00 - Performance 0.8x target → Budget ridotto a \$24k • 12:00 - Performance 3x target → Budget raddoppiato a \$48k

### **STEP 5: RESET DEL BUDGET A MEZZANOTTE**

**CRITICO - Non dimenticare questo passaggio!**

A mezzanotte (fuso orario ad account):

1.  Calcola quanto hai speso effettivamente oggi

2.  Dividi per 2 quella cifra

3.  Imposta quello come budget iniziale per domani

**Esempio:** • Budget finale oggi: \$100k • Spesa effettiva: \$48k • Budget reset per domani: \$24k

**Perché:** Se non resetti, Facebook spenderà il budget massimo raggiunto il giorno prima, potenzialmente bruciando tutto il budget.

### **STEP 6: TRACCIAMENTO CONTINUO**

**Per ogni periodo registra:** • Revenue esatto del periodo (non cumulativo) • Spesa esatta del periodo • Calcola ROAS del periodo • Prendi decisione basata sui dati • Documenta la decisione presa

### **ERRORI COMUNI DA EVITARE**

❌ Scalare basandosi sul "feeling" invece che sui dati

❌ Usare il proprio fuso orario invece di quello dell'ad account

❌ Dimenticare di resettare il budget a mezzanotte

❌ Scalare troppo frequentemente con budget bassi

❌ Guardare solo il ROAS di Facebook invece del Blended ROAS

### **FORMULA RIASSUNTIVA**

1.  **Determina frequenza** basata sul budget

2.  **Traccia ogni periodo** con dati precisi

3.  **Scala aggressivamente** quando performance \> target

4.  **Proteggi i profitti** riducendo quando performance \< target

5.  **Resetta a mezzanotte** per non bruciare budget

6.  **Ripeti ogni giorno** del periodo promozionale

### **RISULTATO ATTESO**

Utilizzando questo metodo durante Black Friday: • Massimizzi la spesa quando le conversioni sono alte • Proteggi i margini quando le performance calano • Puoi scalare da \$10k a \$70k+ in 24 ore mantenendo profittabilità

**Nota finale:** Questo metodo richiede attenzione costante ma può moltiplicare i risultati durante i periodi di vendita critici.

COME TROVARE PRODOTTI VINCENTI

## **COME TROVARE PRODOTTI VINCENTI (BRAND BUILDING) - GUIDA COMPLETA**

### **MENTALITÀ ESSENZIALE**

**Verità fondamentali:** • Qualsiasi prodotto può funzionare - Non esiste il "prodotto magico" • Il successo richiede più tempo di quanto pensi (mesi o anni, non giorni) • Lo spam testing è inutile - Testare a caso = affidarsi alla fortuna • Costruire un brand è una skill che si sviluppa con la pratica

**Aspettative realistiche per principianti:** • Prime 100 ore = Fallirai molto • Ogni test è un'opportunità di apprendimento • Il tasso di successo iniziale può essere 1%, ma migliora con l'esperienza • Servono feedback loops costanti per migliorare

### **CRITERI DI SELEZIONE PRODOTTO**

**1. AOV (Average Order Value) e Margini:** • AOV minimo dopo bundle: \$60+ • Markup minimo: 3x su costo prodotto + spedizione • Ideale: 5x markup • Esempio: Se costo + spedizione = \$10, prezzo minimo = \$30

**2. Trend di mercato (Google Trends):** • Evita trend in declino costante (ultimi 5 anni) • Cerca mercati stabili o in crescita • Anche mercati piatti vanno bene

**3. Peso prodotto:** • Per principianti: evita prodotti pesanti/voluminosi • Preferisci prodotti leggeri (supplements, skincare, accessori)

### **CONCETTO CHIAVE: MASS DESIRE**

Un prodotto vincente soddisfa un **desiderio di massa forte**.

**Desideri deboli (evita):** • Organizzare la scrivania • Piccole comodità quotidiane → AOV troppo basso, impossibile scalare con ads

**Desideri forti (cerca):** • Perdere peso per il matrimonio • Attrarre il partner • Status sociale → Le persone pagano prezzi premium

### **I 3 FATTORI PER VALUTARE LA DIFFICOLTÀ**

**1. Magnitude of Desire (Quanto è forte il desiderio)** • Forte = Più facile vendere a prezzi alti • Debole = Margini troppo bassi per ads

**2. Market Awareness (Consapevolezza del mercato)** Scala dal più facile al più difficile: • Product-aware (sanno del tuo prodotto) = FACILE • Solution-aware (conoscono la soluzione) = MEDIO • Problem-aware (sanno del problema) = DIFFICILE • Unaware (non sanno di avere un problema) = EVITA

**3. Market Sophistication (Saturazione del mercato)** • Livello 1-2 = Puoi fare claim semplici • Livello 3-4 = Servono prove e meccanismi • Livello 5 = Molto difficile, serve innovazione

### **COME DISTINGUERSI IN MERCATI SATURI**

**Due strategie vincenti:**

**1. INNOVAZIONE SUL PRODOTTO/MECCANISMO** • Non serve inventare - basta repackaging • Esempio: Shilajit resina → Shilajit gummies • Esempio: "Acciaio inossidabile" → "Stanley Cooling Technology" • Resetta la sophistication al livello 1

**2. INNOVAZIONE SULL'AVATAR (TARGET)** • Trova un pubblico non servito • Esempio Stanley: Da operai edili → Ragazze Gen Z • Esempio True Classic: Da atleti → "Dad bods" • Stesso prodotto, nuovo pubblico = nuovo mercato

### **ESEMPI PRATICI DI SUCCESSO**

**Stanley Cup:** • Prodotto identico dal 1913 • Cambio avatar: operai → giovani donne • Nuovo messaggio: da "resistente" a "emotional support water bottle" • Risultato: Miliardi in vendite

**True Classic T-Shirts:** • Mercato saturo di t-shirt • Avatar non servito: uomini 30-55 con "dad bod" • Meccanismo: "nasconde la pancia, esalta le spalle" • Risultato: 9-figure brand

**Astronaut Projector:** • Prodotto vecchio 5+ anni • Continua a fare \$10M/anno • Segreto: Nuovi avatar ogni volta (Gen Z trendy)

### **PROCESSO DI SELEZIONE STEP-BY-STEP**

**Step 1: Analisi personale** • Scegli qualcosa in cui credi • Allinea con i tuoi interessi • Deve avere senso per te (no prodotti truffa)

**Step 2: Verifica criteri base** ✓ AOV \> \$60 ✓ Markup minimo 3x ✓ Trend non in declino ✓ Prodotto leggero

**Step 3: Identifica il mass desire** • Quale problema forte risolve? • Quanto è urgente/importante per il target?

**Step 4: Analisi competitiva** • Che livello di awareness ha il mercato? • Quanto è sofisticato (saturo)? • Come puoi distinguerti?

**Step 5: Trova il tuo angolo unico** Scegli UNA strategia: • Nuovo meccanismo/feature (rinomina, repackage) • Nuovo avatar non servito • Se non trovi nessuno dei due → Cambia prodotto

### **ERRORI DA EVITARE**

❌ Cercare il "prodotto segreto" su AliExpress ❌ Copiare e incollare senza strategia ❌ Testare per 2-3 giorni e mollare ❌ Vendere prodotti in cui non credi ❌ Ignorare i margini e l'AOV ❌ Entrare in mercati in declino ❌ Non avere un piano per distinguersi

### **FORMULA FINALE PER IL SUCCESSO**

1.  **Scegli un avatar** e diventa esperto di quel pubblico

2.  **Approfondisci** invece di saltare da una nicchia all'altra

3.  **Accumula esperienza** - Le skill si compongono nel tempo

4.  **Test con intenzione** - Sempre sapere PERCHÉ testi qualcosa

5.  **Feedback loops** - Analizza cosa funziona e cosa no

**Ricorda:** RX Bar ci ha messo 4 anni per arrivare a \$600M di exit. Il secondo brand del fondatore? 1 anno per \$700M di valutazione. L'esperienza si accumula.

### **PROSSIMO PASSO**

Questa è la teoria. Il successo viene dalla pratica deliberata: • Dedica 8 ore max per ricerca e lancio • Non cercare la perfezione • Lancia, testa, impara, ripeti • Ogni fallimento aumenta il tuo tasso di successo futuro

**Il segreto non è trovare il prodotto giusto, ma capire come posizionare qualsiasi prodotto nel modo giusto per il pubblico giusto.**

Cart Optimization

# **Perché il tuo carrello Shopify ha un basso tasso di conversione e come risolverlo nel 2025**

Video: [<u>https://youtu.be/pI-bs2MeL8M?si=KZ_7oUI-P0AdsIFB</u>](https://youtu.be/pI-bs2MeL8M?si=KZ_7oUI-P0AdsIFB)

<img src="/tmp/pandoc_media_discard/media/image21.png" style="width:6.58854in;height:6.93876in" />

## **Strategie pratiche per trasformare il carrello in uno strumento di vendita che gestisce obiezioni e aumenta le conversioni**

### **INTRODUZIONE**

## **1. IL PRINCIPIO FONDAMENTALE: IL CARRELLO DEVE GESTIRE LE OBIEZIONI**

### **Un carrello efficace non si limita a mostrare gli articoli**

Il carrello non dovrebbe essere semplicemente un elenco di prodotti, ma deve **anticipare e risolvere le domande e obiezioni** che i clienti hanno nella loro mente subconscia prima ancora che emergano consapevolmente.

### **Domande comuni che il carrello deve affrontare:**

- Quanto costa la spedizione?

- Quanto durano i prodotti (nel caso di integratori)?

- Cosa succede se non mi piacciono?

- Il negozio è affidabile?

- Spediscono nel mio paese?

- Posso pagare con Klarna, AMEX, Ideal o altri metodi?

**Obiettivo**: progettare il carrello (sia nella versione slide-out che nella pagina dedicata) in modo che risponda proattivamente a tutte queste domande.

## **2. CHIAREZZA INFORMATIVA E PROSPETTIVA DEL CLIENTE**

### **Mostrare informazioni chiare e contestualizzate**

Invece di ripetere semplicemente il titolo del prodotto due volte, il carrello deve comunicare:

- **Quale prodotto** hanno selezionato

- **Quanto ne ricevono** (quantità)

- **Cosa significa** in termini pratici

- **Quante capsule servono** (per integratori)

- **Quanto dura** la scorta

### **Esempio pratico:**

"Scorta per 3 mesi - 35€"

Questo fornisce al cliente una **prospettiva chiara del valore** e gli permette di capire immediatamente il rapporto qualità-prezzo e la durata del prodotto.

## **3. DESIGN VISIVO E GERARCHIA DELL'ATTENZIONE**

### **Il problema del contrasto inadeguato**

Nel design "prima", tutti gli elementi avevano lo stesso colore e quindi la **stessa importanza visiva**, creando confusione su dove cliccare.

### **Soluzione: gerarchia visiva chiara**

- Utilizzare **contrasti cromatici** più marcati

- Dirigere **l'attenzione verso il pulsante principale** (checkout/acquista)

- Rendere immediatamente evidente **l'azione desiderata**

Il design "dopo" mostra come tutta l'attenzione fluisca naturalmente verso il punto di conversione principale.

## **4. UPSELL STRATEGICI CON RAGIONI CONCRETE**

### **Non upsell casuali, ma complementari e motivati**

Gli upsell nel carrello devono avere una **logica chiara** e fornire **ragioni concrete** per l'aggiunta.

### **Il caso studio: soglia di spedizione gratuita**

Il brand offre spedizione gratuita a partire da 35-40€. L'upsell viene presentato così:

"Pratico da combinare con... + aggiungi questo barattolo e ottieni la spedizione gratuita"

### **Principi per upsell efficaci:**

**Devono complementare il prodotto principale**

- Se vendi magliette (moda) → aggiungi pantaloncini (estate) o cappellino

- Se vendi integratori per il sonno → aggiungi mascherina per dormire

- Se vendi prodotti per capelli → aggiungi accessori correlati

**Devono aiutare il cliente a raggiungere il suo obiettivo più velocemente**

**Caratteristiche ideali:**

- Basso AOV (valore medio dell'ordine)

- Basso prezzo

- Alto valore percepito

- Complementarità con l'obiettivo finale del cliente

## **5. CONOSCENZA PROFONDA DEL CLIENTE E RICERCA**

### **L'importanza della customer research**

Per creare upsell veramente efficaci è necessario **conoscere a fondo i desideri** dei clienti attraverso ricerche approfondite.

### **Esempio: integratori per il sonno**

**Cosa vogliono veramente i clienti?**

- Sonno più profondo

- Svegliarsi riposati

- Eliminare le borse sotto gli occhi

- Sentirsi energici al mattino

### **Processo strategico:**

1.  Fare una lista di cosa vogliono i clienti

2.  Identificare altri prodotti che possono aiutarli a raggiungere questi obiettivi

3.  Combinare con soglie di spedizione gratuita

4.  Presentare come "costruzione della routine ideale"

**Principio chiave**: un buon upsell porta il cliente **dove vuole arrivare più velocemente**.

## **6. SOCIAL PROOF: COSTRUIRE FIDUCIA E CREDIBILITÀ**

### **Perché il social proof è essenziale**

Le persone cercano sempre conferme che il negozio sia affidabile. Dati di ricerca dimostrano che il **secondo termine di ricerca più comune** dopo il nome del brand è sempre "**nome brand + recensioni**".

### **Esempio concreto dal caso studio:**

Digitando il nome del brand, Google suggerisce automaticamente "\[nome brand\] + review"

### **Strategia ottimale: Trustpilot o piattaforme terze**

**Vantaggi:**

- Credibilità indipendente

- Previene l'abbandono per cercare recensioni altrove

- Evita che i clienti trovino concorrenti durante la ricerca

### **Dove inserire il social proof nel carrello:**

**Opzione minima:**

- Valutazione a stelle visibile

**Opzione avanzata (prodotti trasformazionali):**

- Recensioni complete

- Testimonianze con foto prima/dopo (es. prodotti per crescita capelli)

- Storie di successo

**Obiettivo**: convincere il cliente che **"questo è quello che ti serve dopo anni di ricerche"** e costruire fiducia direttamente nel carrello.

## **7. GEOLOCALIZZAZIONE E INFORMAZIONI SULLA SPEDIZIONE**

### **Gestire l'obiezione: "Spediscono nel mio paese?"**

Includere una sezione che indichi chiaramente:

**"Consegniamo in: \[paese del cliente\]"**

### **Implementazione tecnica:**

**Se spedisci in un solo paese:**

- Emoji della bandiera + testo fisso

**Se spedisci in tutto il mondo:**

- Geolocalizzazione automatica

- Mostra il paese del visitatore

### **Informazioni da includere:**

- Paese di destinazione

- Tempi di consegna stimati

- Costi (se non gratuita)

**Beneficio**: rassicura immediatamente il cliente e costruisce fiducia mostrando trasparenza.

## **8. METODI DI PAGAMENTO E OPZIONI RATEALI**

### **Mostrare tutti i metodi di pagamento disponibili**

Includere icone chiare di:

- Carte di credito

- PayPal

- Klarna

- Afterpay

- Clearpay

- AMEX

- Ideal

- Altri metodi locali

### **Strategia per AOV elevati (oltre 200€-1000€)**

**Mostrare il prezzo rateale in modo prominente:**

Invece di mostrare solo: **"Totale: €1000"**

Mostrare anche: **"3 rate da €333 con Klarna"**

### **Benefici del price anchoring:**

- Riduce la percezione del costo

- Rende accessibili prodotti high-ticket

- Aumenta il tasso di conversione per prodotti costosi

**Applicabile a:** e-commerce con AOV alto, prodotti premium, articoli oltre i 200€

## **9. CASO STUDIO: TRUE CLASSIC**

### **Elementi efficaci da questo esempio**

Il brand True Classic implementa diverse best practice nel carrello:

**Consegna prevista:**

- Mostra chiaramente i tempi di arrivo

**Evidenziare il risparmio:**

- "Stai risparmiando X€"

**Collezioni più vendute:**

- Invece di upsell generici, mostra categorie: "Consigliati", "Saldi", "T-shirt"

- Permette ai clienti di esplorare senza essere limitati agli upsell predefiniti

**Basato sui dati di vendita:**

- Le raccomandazioni sono guidate dalle performance reali dei prodotti

## **10. OFFERTE PROGRESSIVE E INCENTIVI VOLUME**

### **Strategia: "Aggiungi X, ottieni Y gratis"**

Particolarmente efficace quando si può vendere **più unità dello stesso prodotto**.

### **Esempio pratico:**

**"Aggiungi la seconda confezione, ricevi la terza GRATIS"**

### **Implementazione visiva:**

- Rendere l'offerta **molto visibile** (nel wireframe viene evidenziata)

- Aggiungere automaticamente il prodotto gratuito al carrello

- Mostrare chiaramente il valore del risparmio

**Quando usare questa strategia:**

- Prodotti consumabili (integratori, cosmetici)

- Prodotti con alto tasso di riordine

- Quando il margine permette offerte volume

## **11. URGENZA E SCARCITÀ NEL CARRELLO**

### **Quando implementare elementi di urgenza**

Se i dati mostrano **alto tasso di carrelli abbandonati**, è opportuno aumentare l'urgenza.

### **Tecniche efficaci:**

**Timer di scadenza carrello:**

- "Il carrello scadrà tra 10 minuti"

- Crea pressione positiva per completare l'acquisto

**Avvisi di disponibilità limitata:**

- "Solo X pezzi rimasti"

- "Altri Y clienti stanno guardando questo prodotto"

**Attenzione**: usare con moderazione e solo se supportato da dati reali. L'urgenza falsa danneggia la fiducia.

## **12. CHECKLIST COMPLETA PER UN CARRELLO AD ALTA CONVERSIONE**

### **Elementi essenziali da implementare:**

**Informazioni prodotto:**

- Descrizione chiara e contestualizzata

- Quantità e durata (per consumabili)

- Valore per il cliente (prospettiva pratica)

**Design e usabilità:**

- Gerarchia visiva chiara

- Contrasto cromatico adeguato

- Call-to-action prominente

**Gestione obiezioni:**

- Costi di spedizione chiari

- Tempi di consegna

- Paesi serviti (geolocalizzati)

- Metodi di pagamento visibili

**Fiducia e credibilità:**

- Social proof (Trustpilot, recensioni)

- Valutazioni a stelle

- Testimonianze (per prodotti trasformazionali)

**Ottimizzazione vendite:**

- Upsell strategici e complementari

- Soglia spedizione gratuita

- Incentivi volume

- Opzioni rateali (per high-ticket)

**Elementi di urgenza (se necessario):**

- Timer scadenza carrello

- Indicatori di disponibilità

## **CONCLUSIONE**

Un carrello Shopify ad alta conversione va ben oltre la semplice visualizzazione dei prodotti nel cestello. Deve funzionare come un **venditore virtuale attivo** che:

1.  **Anticipa e risolve le obiezioni** prima che emergano nella mente del cliente

2.  **Costruisce fiducia** attraverso social proof, trasparenza e informazioni chiare

3.  **Aumenta l'AOV** con upsell strategici, incentivi volume e soglie di spedizione

4.  **Facilita la decisione** mostrando opzioni di pagamento, tempi di consegna e disponibilità geografica

5.  **Crea urgenza positiva** quando i dati lo giustificano

La differenza tra un carrello "pulito ma inefficace" e uno "ottimizzato per la conversione" risiede nella capacità di rispondere proattivamente a tutte le domande subconscie del cliente, trasformando l'esperienza del carrello da momento di esitazione a conferma di un acquisto intelligente.

**Principio finale**: più conosci i tuoi clienti (attraverso ricerca approfondita), più efficace sarà il tuo carrello nell'accompagnarli verso l'acquisto.

🧑‍💼 ELON MOOSE

ELON MOOSE

Youtube: [<u>https://www.youtube.com/@ecommmoose</u>](https://www.youtube.com/@ecommmoose)

PRE-LANDING

PRE-LANDERS

OTTIMIZZAZIONE DEL PRE-LANDER

Il pre-lander è la pagina intermedia tra l'annuncio e la pagina prodotto. Ha un impatto enorme su due metriche:

\- CTR (Click-Through Rate): percentuale di clic dalla pagina pre-lander alla pagina prodotto

\- Tasso di conversione complessivo: dal primo atterraggio all'acquisto finale

STRATEGIA CENTRALIZZATA VS. MULTIPLA

Approccio consigliato:

\- Avere una pagina pre-lander centralizzata che riceve la maggior parte del traffico

\- Aggregare tutti gli angoli vincenti delle creatività in questa singola pagina

\- Ottimizzare intensamente questa pagina piuttosto che disperdere gli sforzi su molte landing page diverse

Vantaggio: ogni miglioramento sulla pagina centralizzata si riflette su tutto il traffico e tutte le campagne collegate, moltiplicando l'impatto.

TEST RECENTI VINCENTI

Test sulla pagina centralizzata:

\- Aggregazione di 5 angoli principali in un'unica pagina

\- Miglioramento significativo del tasso di conversione complessivo

\- Circa 50% del traffico va al pre-lander, 50% diretto alla pagina prodotto

Nuovo formato di funnel:

\- Testato come campagna indipendente (non come split test)

\- Ha prodotto il miglior ROAS (Return On Ad Spend) nelle ultime due settimane

\- Ora in fase di scaling con ulteriori test interni

ESEMPIO PRATICO: RISE COFFEE

Rise Coffee utilizza una strategia di pre-lander centralizzata eccellente:

\- Tutto il traffico per un prodotto va a una singola pagina ottimizzata

\- La pagina copre circa 30 angoli diversi utilizzati nelle pubblicità

\- Struttura: breakdown di tutti gli ingredienti del caffè e benefici correlati

\- Approccio ampio per supportare tutti gli angoli testati nelle creatività

\- Permette al team di concentrarsi sui test creativi, sapendo che il pre-lander supporta qualsiasi angolo

APPROCCIO AI FORMATI

Diversi formati di pre-lander:

\- Advertorial (articolo pubblicitario)

\- Listicle (lista di motivi)

\- Homepage generalista

\- Altri formati personalizzati

Regola importante: non testare formati completamente diversi l'uno contro l'altro in split test. Meglio lanciare ogni nuovo formato come campagna indipendente, vedere se funziona, e poi ottimizzarlo internamente.

IMITAZIONE E ITERAZIONE CON IA

# **IMITAZIONE E ITERAZIONE CON IA**

## **Un sistema completo per creare script pubblicitari vincenti analizzando video e visuals**

### **INTRODUZIONE**

Questa lezione presenta un metodo in tre passaggi per incrementare drasticamente la produzione di contenuti pubblicitari utilizzando l'intelligenza artificiale. L'approccio si basa sull'analisi completa degli annunci più performanti (propri o della concorrenza), includendo non solo il testo ma anche le componenti visive scena per scena, per fornire all'AI il massimo contesto possibile.

## **1. IL PRINCIPIO FONDAMENTALE: DARE ALL'AI IL MASSIMO CONTESTO**

L'errore comune quando si usa l'AI per creare contenuti pubblicitari è limitarsi a fornire solo il testo o la trascrizione dell'annuncio. Questo metodo rivoluziona l'approccio includendo:

- **Trascrizione completa dello script**

- **Analisi visiva scena per scena**

- **Descrizione dettagliata del B-roll**

- **Movimenti e dettagli delle riprese**

- **Dati di performance (quando disponibili)**

Quando l'AI ha accesso a tutte queste informazioni, può "connettere i punti" e comprendere realmente cosa rende efficace un annuncio.

## **2. PASSO 1: IDENTIFICARE GLI ANNUNCI MIGLIORI**

### **Due approcci possibili:**

**A) Annunci dal proprio account pubblicitario**

- Ideale per creare variazioni

- Selezionare i 5-10 creativi con le migliori performance settimanali

- Utile per generare "variazioni vincenti"

**B) Annunci della concorrenza**

- Usato nell'esempio pratico della lezione

- Richiede strumenti di ricerca pubblicitaria

### **Strumento consigliato: AdSpy**

Vantaggi rispetto ad alternative come Atria:

- Filtri per metriche di engagement (like, condivisioni)

- Ricerca per intervalli di tempo specifici

- Identificazione degli annunci realmente performanti (non solo "in corso da più tempo")

### **Processo di ricerca dimostrato:**

1.  Cercare il brand (esempio: EarthBreeze)

2.  Filtrare per advertiser specifico

3.  Impostare soglia minima di like (es. 3000)

4.  Definire intervallo temporale (es. ultimi 4-5 mesi)

5.  Ordinare per maggior numero di like

6.  Risultato: l'annuncio con più like è quello più performante

## **3. PASSO 2: SCARICARE IL VIDEO**

### **Strumenti necessari:**

- Utilizzare un "Facebook Video Downloader" (qualsiasi tool online)

- Copiare il link dell'annuncio identificato

- Scaricare il video (risoluzione consigliata: 720p)

**Nota**: questo passaggio è semplice ma essenziale per l'analisi successiva.

## **4. PASSO 3: ANALISI COMPLETA CON GOOGLE AI STUDIO**

Questo è il cuore del metodo e ciò che lo rende unico.

### **Prompt utilizzato per l'analisi:**

Puoi per favore scomporre tutti questi video scena per scena?

Descrivi in dettagli vividi cosa succede nei visuals per ogni scena,

fino ai minimi movimenti. Più dettagli, meglio è.

Dovrebbe essere così chiaro che qualcuno che non lo sta guardando

possa leggere e avere un'immagine chiara di cosa sta succedendo.

Indica il testo esatto che appare sullo schermo.

Crea una tabella con:

\- Testo/voiceover da un lato

\- B-roll dall'altro

Assicurati di usare i timestamp per ogni scena.

### **Risultato dell'analisi:**

L'AI produce una descrizione estremamente dettagliata, ad esempio:

> "L'inquadratura si apre con un uomo in felpa scura e cappellino da baseball verde 'Undefeated' che si china su un tavolo di legno. Guarda in basso con espressione perplessa e incuriosita. Nella mano destra, tenuto tra pollice e indice, penzola una capsula di detersivo tricolore (blu, viola e centro bianco-argento). Sotto la sua mano ci sono due bicchieri trasparenti. Il bicchiere a destra contiene acqua limpida, quello a sinistra contiene un liquido bianco lattiginoso. Lo sfondo è una stanza luminosa con una grande finestra che mostra alberi verdi e colline. Tre punti interrogativi appaiono sullo schermo accanto alla capsula..."

Questo livello di dettaglio include persino elementi dello sfondo che potrebbero passare inosservati.

## **5. ORGANIZZAZIONE E PREPARAZIONE PER L'AI**

### **Perché usare Google Docs come passaggio intermedio:**

Se si incolla direttamente in ChatGPT, il testo appare come "un grande blob" difficile da leggere.

### **Processo:**

1.  Copiare l'analisi completa da Google AI Studio

2.  Incollarla in un Google Doc

3.  Dare un titolo (es. "EarthBreeze Recreation")

4.  Scaricare come PDF

5.  Caricare il PDF in ChatGPT (o Claude)

## **6. CREARE NUOVI SCRIPT CON CHATGPT**

### **Esempio di prompt utilizzato:**

Hey Chat, voglio che tu sappia che sei il miglior stratega creativo

mai esistito. Sei il copywriter più forte mai vissuto, nel 2025, ma ancora meglio -

lo fai sembrare un dilettante.

Sei il miglior stratega creativo di tutti i tempi e riscriverai questo annuncio.

Ho inviato una scomposizione completa di un creativo top da EarthBreeze.

EarthBreeze è un brand e-commerce a 9 cifre e il loro formato funziona molto bene.

Ricrea questo formato per il nostro nuovo prodotto: un deodorant naturale.

\[Possiamo trovare un nome migliore\]

Il nostro brand sarà l'alternativa più naturale e sana al deodorant.

Dobbiamo parlare di tutte le sostanze chimiche tossiche nei deodorant tradizionali

in modo simile a come viene presentato nell'annuncio EarthBreeze.

Pensa a una scomposizione visuale intelligente per la scena introduttiva

che mostri questo nella stessa modalità del B-roll dell'annuncio EarthBreeze.

Costruisci il problema nello stesso modo.

Crea un flusso e un'atmosfera molto simili.

Segui il più possibile da vicino.

Crea uno script in formato tabella:

\- Lato sinistro: visuals scomposti

\- Lato destro: testo e script

Pensa attentamente ai visuals che mostreremo e sii creativo nel modo

in cui possiamo mostrare i visuals in modo convincente, con molti

meccanismi di vendita integrati, proprio come nell'annuncio EarthBreeze.

Assicurati che anche il nostro script sia di alto livello.

### **Suggerimento chiave sulla creazione di prompt:**

**"Più parli, più probabilmente otterrai qualcosa di decente"** - riempire il prompt di dettagli, contesto e direzione migliora drasticamente i risultati.

## **7. RISULTATO: SCRIPT COMPLETO CON VISUALS**

### **Esempio di output generato:**

**Nome prodotto proposto**: Clear Root

**Concetto**: "Test di dissoluzione stile EarthBreeze ma per deodorant naturale"

**Angolo principale**: La maggior parte dei deodorant è piena di alluminio, parabeni e sostanze chimiche tossiche

### **Estratto dello script generato:**

**VISUALS:**

- Primo piano di qualcuno che tiene due tipi di deodorant: stick bianco (tradizionale) e stick morbido (Clear Root)

- Due piastre di Petri sul tavolo

- La persona applica il deodorant convenzionale su una e Clear Root sull'altra

**SCENA SUCCESSIVA:**

- Aggiungere lampada termica/asciugacapelli su entrambe le piastre simulando il calore corporeo

- Il deodorant tradizionale inizia a sciogliersi in una fanghiglia cerosa e torbida

- Clear Root si scioglie uniformemente e resta pulito

- Animazione su schermo: lista di ingredienti tossici con avviso rosso (alluminio, fragranze sintetiche)

**VOICEOVER:** "Oggi facciamo un test affiancato tra Clear Root, il nostro deodorant naturale, e il tipico antitraspirante da supermercato. Vediamo cosa succede realmente quando questi prodotti toccano la tua pelle."

## **8. ANALISI AVANZATA: IDENTIFICARE PUNTI DI FORZA E DEBOLEZZA**

Oltre a creare nuovi script, il metodo permette di analizzare criticamente gli annunci esistenti.

### **Domande da porre all'AI:**

1.  **Quali sono le caratteristiche e i benefici principali mostrati nell'annuncio che lo rendono così convincente?\**

2.  **Quali sono i componenti che pensi funzionino bene qui?\**

3.  **Quali sarebbero i colli di bottiglia identificati nell'annuncio (da un punto di vista visivo, dello script, o entrambi)?\**

4.  **Se dovessimo ricreare questo annuncio esattamente per EarthBreeze, cosa miglioreresti?\**

## **9. LIVELLO SUCCESSIVO: AGGIUNGERE DATI DI PERFORMANCE**

Quando si analizzano i propri annunci, il metodo diventa ancora più potente aggiungendo metriche:

### **Dati da includere:**

- **CTR** (Click-Through Rate - tasso di clic)

- **Tempo medio di visualizzazione video**

- **Hook rate** (tasso di aggancio iniziale)

- **Hold rate** (tasso di mantenimento dell'attenzione)

- **Spesa totale dell'annuncio**

- **ROAS** (Return On Ad Spend - ritorno sulla spesa pubblicitaria)

### **Vantaggi:**

L'AI può correlare le lacune nelle metriche con specifici elementi dell'annuncio, identificando esattamente dove migliorare.

## **10. SCALING: ANALIZZARE MULTIPLI ANNUNCI CONTEMPORANEAMENTE**

### **Per velocizzare il processo:**

1.  Scaricare tutti i migliori annunci in una volta

2.  Caricare tutti i video contemporaneamente in Google AI Studio

3.  Espandere il prompt per richiedere l'analisi di tutti i video

4.  Copiare tutte le analisi nel Google Doc contemporaneamente

### **Quando usare questo approccio:**

- Annunci con **stesso formato** o **stesso angolo**

- Per identificare **pattern comuni** tra i migliori performer

### **Attenzione:**

Analizzare uno per uno dà generalmente risultati migliori, ma il batch processing è utile per velocità quando si cercano pattern generali.

## **11. CREAZIONE DI VARIAZIONI INFINITE**

Una volta stabilito il sistema, diventa facile generare molte varianti:

### **Processo per variazioni:**

1.  Identificare gli elementi che funzionano dall'analisi

2.  Copiare e incollare questi elementi

3.  Chiedere all'AI: "Ricrea questa versione" o "Ricrea quest'altra versione"

4.  Ottenere idee infinite per 10X l'output creativo

### **Perché funziona:**

Si è sbloccato un **nuovo livello di contesto** per l'AI, che ora comprende:

- Cosa dire (script)

- Come mostrarlo (visuals)

- Perché funziona (metriche)

## **12. RIEPILOGO DEL PROCESSO COMPLETO**

### **I tre passaggi fondamentali:**

**PASSO 1: Selezionare gli annunci**

- Migliori 5-10 creativi dal proprio account pubblicitario, OPPURE

- Migliori annunci competitor (usando AdSpy o simili)

- Filtrare per engagement e data recente

**PASSO 2: Scaricare i video**

- Usare Facebook Video Downloader

- Salvare i file video localmente

**PASSO 3: Analisi e creazione**

- Caricare in Google AI Studio per analisi scene-by-scene

- Trasferire in Google Docs e convertire in PDF

- Caricare in ChatGPT/Claude

- Creare prompt dettagliati con massimo contesto

- Generare nuovi script completi di visuals

## **13. PRINCIPI CHIAVE PER IL SUCCESSO**

### **Il segreto: massimizzare il contesto**

**Invece di dare solo:** testo/trascrizione

**Dare all'AI:**

- Visuals + testo

- Metriche di performance

- Indicazioni dettagliate tramite prompt

- Ruolo e obiettivo chiaro ("sei il miglior stratega creativo...")

### **La regola della prompting:**

**Più dettagli fornisci, migliori risultati ottieni.**

### **Competenza necessaria:**

Comprendere il copywriting e saper "parlare in termini di copy" permette di guidare l'AI in modo molto più efficace. Saper articolare esattamente cosa si vuole produce output superiori.

## **14. SVILUPPI FUTURI**

### **Obiettivo a lungo termine:**

Trasformare questo processo manuale in un **agente automatizzato** che possa:

- Analizzare automaticamente i migliori annunci

- Identificare pattern di successo

- Generare variazioni senza intervento manuale

- Funzionare come "stratega creativo automatico"

Attualmente il processo richiede passaggi manuali, ma l'automazione completa è l'obiettivo futuro.

## **CONCLUSIONE**

Questo metodo rappresenta un salto qualitativo nell'uso dell'AI per la creazione pubblicitaria perché:

1.  **Va oltre il solo testo** - include l'analisi visiva completa

2.  **Fornisce contesto massimo** - l'AI "vede" l'annuncio come un umano

3.  **Integra dati di performance** - collega risultati a elementi specifici

4.  **Scala facilmente** - da 1 a 10+ annunci analizzati

5.  **Genera variazioni infinite** - sblocca creatività 10X

**La chiave del successo**: più dati e contesto fornisci all'AI (visuals + script + metriche + prompt dettagliati), migliori saranno i risultati.

L'autore della lezione gestisce brand e-commerce a 8 cifre e utilizza attivamente questo processo settimanalmente per la produzione creativa.

Brain Diversification e Data Clarity

# **Brain Diversification e Data Clarity: Il Framework per Scalare l'E-commerce**

## **Una guida operativa per scalare l'e-commerce attraverso creatività, funnel, dati, diversificazione e offerte multiple**

## **INTRODUZIONE**

Questa lezione presenta cinque strategie fondamentali per scalare un'attività e-commerce fino a raggiungere \$100.000 di fatturato giornaliero durante il quarto trimestre dell'anno. L'autore condivide l'esperienza diretta nella gestione di brand e-commerce a otto cifre, con picchi fino a \$300.000 al giorno, spiegando come amplificare i processi già esistenti attraverso un approccio strutturato e basato sui dati.

## **1. CREATIVITÀ: DIVERSIFICAZIONE DEI "CERVELLI"**

La creatività pubblicitaria non dipende solo da angoli, formati e variazioni, ma soprattutto dalla **diversificazione delle menti** che generano le idee.

### **Il concetto di "brain diversification"**

Affidarsi a un'unica persona (o a un unico team ristretto) per generare tutte le creatività crea bias cognitivi:

- Stesse modalità di ricerca

- Stessi angoli preferiti

- Stessa struttura di scripting

- Ridotta capacità di innovazione

**Soluzione:** Moltiplicare i "cervelli" che pensano e creano contenuti pubblicitari.

### **Quattro modi per diversificare le creatività**

**1. Team interno strutturato in pod**

Ogni pod è composto da:

- **Creative strategist** (il "cervello"): fa ricerca, scrive script, definisce angoli e formati

- **Video editor** (1 o più)

- **Graphic designer** (1 o più)

- **Content outreach** (per influencer/affiliati)

- **Copywriter** (opzionale)

Per scalare:

- Creare più pod indipendenti

- Ogni pod ha il proprio creative strategist

- Ogni strategist genera angoli e formati unici

**2. Agenzie creative esterne**

Trattare le agenzie **come membri interni del team**, non come fornitori occasionali:

- Dare loro attenzione e feedback costante

- Condividere processi interni e linee guida

- Monitorare le performance come con il team interno

- Ogni agenzia rappresenta un pod completo già assemblato

**Vantaggi:** Rapidità nell'espansione senza dover reclutare singole figure.

**3. Sistema di flywheel organico (affiliati e creator)**

Questo approccio si basa su:

- **Outreach massivo** verso influencer, affiliati, creator TikTok

- **Invio prodotto** con brief generale (non script completi)

- **Autonomia creativa**: il creator sceglie angolo, scripting, editing, posting organico

Ogni creator diventa un "pod autonomo" che:

- Genera contenuto unico

- Pubblica organicamente per testare trazione

- Fornisce contenuto utilizzabile come advertising a pagamento

**Vantaggi principali:**

- Scalabilità quasi infinita

- Test senza budget pubblicitario iniziale

- Diversità di voci e prospettive

**4. Sistemi AI**

L'intelligenza artificiale elimina i bias umani e permette variazioni oggettive basate sui dati.

**Uso attuale:**

L'autore utilizza un sistema AI che:

- Ha accesso alla libreria completa degli annunci

- Analizza trascrizioni e video

- Si connette a Facebook per metriche (hook rate, hold rate, CTR)

- Genera variazioni ottimizzate automaticamente

**Esempio pratico:**

Se un annuncio ha basso hook rate, l'AI:

- Identifica annunci con hook rate alto

- Estrae l'hook performante

- Lo integra nel nuovo annuncio

- Genera la variazione automaticamente

**Visione futura:**

- Scripting completamente autonomo

- Ricerca indipendente tramite agenti AI

- Video generati end-to-end (con strumenti come VO3)

- Scalabilità infinita senza intervento umano

## **2. FUNNEL: OTTIMIZZAZIONE E TESTING CONTINUO**

Il funnel è il punto di centralizzazione di tutto il traffico generato dalle creatività. Non serve diversificazione di "cervelli", ma **processo rigoroso e sistematico**.

### **Principi chiave**

**Calcolare la capacità di testing**

Basarsi su:

- Volume di traffico attuale e previsto

- Significatività statistica richiesta

- Numero di test eseguibili settimanalmente (es. 2-3 split test/settimana)

**Pianificare test progressivi**

- Test incrementali: CTA, colori, copy, layout

- Test monumentali: nuovi formati (quiz funnel, pre-lander, VSL)

**Ottimizzare prima del Q4**

Obiettivo: avere il funnel massimamente performante **prima di novembre**, quando il traffico cresce esponenzialmente.

### **Metriche da ottimizzare**

- **Tasso di conversione:** percentuale di visitatori che completano l'acquisto

- **Average Order Value (AOV):** valore medio dell'ordine per cliente

- **Subscription take rate:** percentuale di clienti che sottoscrivono abbonamenti

### **Quality Assurance (QA)**

Fondamentale avere un sistema di controllo qualità per:

- Monitorare bug o interruzioni del funnel

- Verificare test in corso

- Prevenire perdite di fatturato durante il Q4

**Soluzioni:**

- Developer interno dedicato

- Agenzia dev esterna

- Software di monitoraggio automatico

## **3. DATA CLARITY: MONITORAGGIO DETTAGLIATO E CONTINUO**

Avere chiarezza sui dati significa **sapere esattamente cosa sta succedendo** nel business in tempo reale.

### **Sistema di monitoraggio implementato**

L'autore utilizza un sistema di reportistica su tre livelli:

**1. Report giornaliero completo**

Metriche tracciate ogni giorno:

- Fatturato DTC (direct-to-consumer)

- Fatturato nuovi clienti vs. clienti di ritorno

- Ordini totali

- **Blended MER** (Marketing Efficiency Ratio totale, include Amazon e subscription)

- **NMER** (New customer MER): metrica più importante

- Subscription take rate

- Nuove sottoscrizioni vs. churn

**2. Report orario**

Aggiornato ogni ora durante la giornata:

- MER in tempo reale

- CAC (Customer Acquisition Cost)

- Ritorni/rimborsi

- Nuovi clienti

**3. Report analytics del funnel**

- Metriche delle pagine principali ad alto traffico

- Conversion rate per pagina

- Drop-off points

### **Utilizzo dei dati**

I dati guidano le decisioni su:

- **Creatività:** se le performance calano, analizzare Facebook Ads Manager

- **Funnel:** se il conversion rate cala, analizzare analytics del sito

- **Proiezioni:** impostare target realistici per canale e per blended NMER

## **4. CHANNEL DIVERSIFICATION: SUPPORTO MULTI-CANALE**

Facebook è solitamente il **driver principale** (80%+ del budget), ma altri canali forniscono supporto strategico.

### **Logica della diversificazione**

**Scenario tipico:**

- Facebook: ROAS target 1.0 (per scalare volume)

- Google: ROAS 1.6 (minor volume, maggiore efficienza)

- **Risultato blended:** NMER 1.3 (target raggiunto)

### **Canali da considerare**

- **Google Ads:** Search, Shopping, YouTube

- **Native ads:** Taboola, Outbrain

- **TikTok Ads**

- **Amazon:** aumenta il fatturato del ~20% senza cannibalizzare (traffico organico parallelo)

### **Benefici**

- Maggiore stabilità complessiva

- Possibilità di scalare Facebook a ROAS più bassi

- Diversificazione del rischio

## **5. OFFERS TO CIRCULATE: MOLTIPLICARE LE OFFERTE**

Scalare da \$100K a \$200K al giorno può essere **più facile con due offerte forti** che raddoppiando il volume su una sola.

### **Concetto chiave**

Creare più punti di ingresso per lo stesso pubblico:

- Stesso brand

- Stesso tipo di cliente

- Benefici complementari o alternativi

- Infrastruttura condivisa

### **Vantaggi strategici**

- **Facilità di scaling:** nuovi prodotti = nuovi angoli creativi

- **Apprendimenti condivisi:** stesso team, stessa audience, stessi processi

- **Valorizzazione del brand:** revenue consolidato sotto un unico ombrello

- **Espansione del TAM** (Total Addressable Market)

### **Esempio pratico**

Se un cliente non ha bisogno del prodotto principale ma è interessato a un beneficio specifico alternativo, una seconda offerta può:

- Convertirlo comunque

- Inserirlo nell'ecosistema del brand

- Aumentare lifetime value complessivo

## **CONCLUSIONE**

Per raggiungere \$100K+ al giorno nel Q4, è necessario lavorare su **cinque pilastri integrati:**

1.  **Creatività diversificata:** moltiplicare i "cervelli" (team interno, agenzie, creator, AI)

2.  **Funnel ottimizzato:** testing continuo e quality assurance rigorosa

3.  **Chiarezza dei dati:** monitoraggio giornaliero, orario e per funnel

4.  **Diversificazione canali:** supportare Facebook con Google, native ads, Amazon

5.  **Offerte multiple:** creare più punti di ingresso nello stesso brand

Questi elementi non funzionano in isolamento: i dati guidano le decisioni su creatività e funnel; la diversificazione dei canali permette di scalare con margini più bassi; le offerte multiple amplificano l'infrastruttura esistente.

La preparazione deve iniziare **prima di novembre**, per arrivare al picco del Q4 con tutti i sistemi già rodati e performanti.

👍 TRASFORMARE ANNUNCI PERDENTI IN WINNER

# **STRATEGIA STEP BY STEP: TRASFORMARE ANNUNCI PERDENTI IN WINNER**

## **STEP 1: SELEZIONE ANNUNCIO**

Scegli annunci che:

- Hanno speso \>€500 poi sono crollati

- Hanno mostrato "segnali di vita" (7+ giorni attivi)

- Erano top spender prima di morire

## **STEP 2: ANALISI STRUTTURATA**

Guarda l'annuncio e identifica:

**✅ Cosa ha funzionato:**

- Hook che ha catturato attenzione?

- Meccanismo nuovo interessante?

- Rimozione senso di colpa?

- Empatia con il target?

**❌ Cosa NON ha funzionato:**

- Salto logico troppo veloce?

- Poca educazione pre-prodotto?

- Meccanismo unico non sfruttato?

- Script superficiale?

## **STEP 3: SINTESI CON AI**

Usa questo prompt ( VEDI ALLA FINE)

Ho un annuncio che è partito bene poi è crollato.

ANNUNCIO ORIGINALE:

\[incolla script\]

Analizza e dimmi:

1\. Cosa ha funzionato (da mantenere)

2\. Cosa non ha funzionato (da sistemare)

3\. Dove c'è il "salto logico"

4\. Come migliorarlo

## **STEP 4: RICERCA TARGET (CRITICO)**

Prima di riscrivere, fai ricercare all'AI:

Cerca su Reddit/forum italiani cosa dice il mio target riguardo:

\- Il loro problema principale

\- Linguaggio che usano

\- Frustrazioni specifiche

\- Soluzioni già provate

Trova 10-15 esempi reali

**Questo "riscalda" l'AI e migliora il copy del 300%**

## **STEP 5: RISCRITTURA STRATEGICA**

Usa questo prompt:

ANNUNCIO ORIGINALE:

\[script\]

PROBLEMI IDENTIFICATI:

\[analisi\]

RICERCA TARGET:

\[risultati ricerca\]

Riscrivi lo script seguendo questa struttura:

Hook (3 sec) - \[mantieni se funziona\]

↓

Problema + Empatia (7 sec)

↓

EDUCAZIONE + MECCANISMO (15 sec) ← ESPANDI QUI

↓

Soluzione unica (5 sec)

↓

Prodotto + USP (8 sec)

↓

CTA + Garanzia (2 sec)

Requisiti:

\- 15+ secondi di educazione PRIMA del prodotto

\- Narrativa emotiva forte

\- Meccanismo unico ben spiegato

\- Linguaggio del target dalla ricerca

\- Spostare credenza da "colpa mia" a "meccanismo specifico"

## **STEP 6: BRIEF PER PRODUZIONE**

Fornisci per ogni segmento:

- Testo dello script

- Indicazioni visive

- Obiettivo del segmento

## **STEP 7: TEST E DOCUMENTAZIONE**

- Budget test: €150-200

- Durata minima: 3-5 giorni

- Documenta i risultati

- Aggiungi al database learnings

## **CHECKLIST RAPIDA**

Prima di lanciare il nuovo annuncio:

- Hai fatto ricerca Reddit/forum sul target?

- Lo script ha 15+ sec di educazione pre-prodotto?

- Il meccanismo unico è spiegato chiaramente?

- Usi il linguaggio esatto del target?

- Hai 3 varianti di hook?

## **ERRORI DA EVITARE**

❌ **Salto logico**: Hook → Prodotto (troppo veloce)\
✅ **Fix**: Hook → Problema → Meccanismo → Educazione → Soluzione → Prodotto

❌ **Meccanismo generico**: "Il nostro prodotto fa X"\
✅ **Fix**: "Unico con \[ingrediente/tecnologia\] che \[meccanismo specifico\]"

❌ **Poca educazione**: 1 frase sul problema\
✅ **Fix**: 15 secondi per far CREDERE che quello è davvero il problema

**Principio chiave:** Ogni annuncio sta comunicando qualcosa. Analizza, impara, migliora sistematicamente.

PROMPT:

**Ad Learnings Call Analysis Prompt**

**Goal**

Your task is to extract and organize key insights from our weekly ad learnings call transcription and format it as a straightforward client report summarizing what we found, learned, and decided during our analysis of the ads we're running for them.

**Return Format**

You will provide a client-by-client summary with the following structure for each client:

**Client Name**

- Executive Summary (3-5 sentences summarizing what we discovered this week for this specific client, key insights we identified, and major strategic decisions we made)

<!-- -->

- Performance Overview (high-level metrics and trends we observed for this client)

<!-- -->

- Individual Ad Analysis (detailed breakdown of each ad we reviewed for this client)

<!-- -->

- Key Learnings & Insights (patterns and insights we identified for this client)

<!-- -->

- Next Steps & Recommendations (actions we're taking for this client based on our analysis)

**Context/Data**

You will analyze the complete call transcription from our weekly ad learnings meeting. As a performance marketing agency, we run and analyze social media ads (primarily on Meta platforms) for our clients. Here's our workflow context:

- We first have strategy calls with clients where we develop creative concepts

<!-- -->

- We create ads based on these concepts and run them for 4-7 days

<!-- -->

- Each ad is then reviewed in our weekly "ad learnings call" to determine if it's a "loser," "winner," or "super winner"

<!-- -->

- We track all ads in ClickUp, and only review ads in the "learnings" phase during this call

<!-- -->

- We organize our discussion client by client, reviewing each ad's performance

<!-- -->

- We use CBO (Campaign Budget Optimization) in Meta ad accounts, so an important initial indicator is whether an ad received significant spend

<!-- -->

- Key metrics we typically discuss include: profitability (ROAS), hook rate (3-second views), hold rate (watch time), CTR (Click-Through Rate), and other relevant engagement metrics

**Instructions**

Please analyze the following ad learnings call transcription and:

- Identify all clients discussed in the meeting

<!-- -->

- For each client, provide a separate section written in first-person plural ("we") as if reporting to that specific client:

<!-- -->

- Client name as header

<!-- -->

- Executive summary paragraph (3-5 sentences) written as: "This week, we reviewed \[X\] ads and found that..." Focus on what we learned and decided for this specific client

<!-- -->

- Performance overview written as: "Here's what we saw in the account..."

<!-- -->

- Total number of ads we reviewed for this client

<!-- -->

- Distribution of winners/losers/super winners we identified for this client

For each ad we discussed under each client:

- Ad name/identifier (if mentioned)

<!-- -->

- Performance metrics we analyzed (spend, profitability, key metrics)

<!-- -->

- Our classification as winner/loser/super winner

<!-- -->

- Key insights we discovered about success/failure reasons

<!-- -->

- Specific creative elements we highlighted (hooks, visuals, etc.)

<!-- -->

- Extract patterns and insights for each client in simple, direct language:

<!-- -->

- Write as "We noticed that..." or "We found that..."

<!-- -->

- Creative elements we found consistently perform well/poorly for this client

<!-- -->

- Trends we identified in this client's data

<!-- -->

- Testing ideas and optimizations we're recommending for this client

Document our action items and next steps for each client:

- Write as "We're going to..." or "We'll..."

<!-- -->

- Specific tasks we're assigning to team members for this client

<!-- -->

- New creative concepts we're developing for this client

<!-- -->

- Optimization strategies we're planning for this client

<!-- -->

- Highlight exceptional performances or critical issues for each client that need attention

**Tone & Style Guidelines**

- Write from the agency's perspective using "we," "our team"

<!-- -->

- Use simple, straightforward language - avoid overly formal or complex phrases

<!-- -->

- Focus on insights and learnings rather than just raw data

<!-- -->

- Present findings as discoveries and decisions we made

<!-- -->

- Avoid jargon - explain technical terms simply when necessary

<!-- -->

- Remember: WE create and run the ads, not the client

<!-- -->

- Keep the tone conversational

<!-- -->

- Maintain the client-by-client structure throughout the entire report

**Warnings**

If an ad's status is unclear from the transcript, note this rather than guessing

If specific metrics are mentioned but not clearly attributed to a particular ad, note this in that client's summary

Focus on extracting factual information rather than making recommendations not present in the transcript

Our discussions may contain jargon and casual conversation - translate this into simple client-facing language

Team members may disagree about an ad's classification - present the final decision we reached

Keep each client's section completely separate and focused only on their ads and performance

Always remember that WE are the ones creating, running, and analyzing the ads - not the client

⚡ STRATEGIA DI LANCIO ADV LWAY

Strategia di Testing per Campagne ADV: Concept, Iterazioni e Imitazioni\
[<u>Watch Video</u>](https://kommodo.ai/recordings/pHGn44y4HpR472i905Az)

<img src="/tmp/pandoc_media_discard/media/image32.png" style="width:20in;height:11.25in" />

⚒️ TOOLS & APP

## **SHOPIFY**

A/B Test:

[<u>https://apps.shopify.com/shoplift</u>](https://apps.shopify.com/shoplift)

Servizio per size: [<u>https://faslet.me/solutions/</u>](https://faslet.me/solutions/)

## **🎬 VIDEO EDITING TECH STACK**

### **EDITING SOFTWARE**

- [**<u>Final Cut Pro</u>**](https://www.apple.com/final-cut-pro/) – Software professionale per editing video su Mac, ideale per velocità e precisione.

- (Or any other editing software like Premiere Pro, After Effects Davinci Resolve, CapCut)

- Plugins (Per essere più veloce)

- Captions

### **FOOTAGE SOURCES**

- [**<u>ssstik - TikTok Downloader</u>**](https://ssstik.io/) – Scarica video da TikTok senza watermark.

- [**<u>Earlybird</u>**](https://urlebird.com/) – Strumento per analizzare e scaricare video TikTok virali.

- [**<u>the daily virals</u>**](https://www.thedailyvirals.com/) - trovare prodotti virali e idee video da replicare

- [**<u>Instagram Downloader</u>**](https://igram.world/) – Scarica contenuti da profili o Reels Instagram.

- [**<u>YouTube Downloader</u>**](https://www.y2mate.com/) – Salva video YouTube per reference o tagli di montaggio.

- [**<u>Envato Elements</u>**](https://elements.envato.com/) – Libreria premium di stock footage, template e asset grafici.

- [**<u>Pexels</u>**](https://www.pexels.com/) – Raccolta gratuita di video e immagini stock ad alta qualità.

- [**<u>Artlist Stock Footage</u>**](https://artlist.io/) – Video professionali con licenza commerciale inclusa.

⚠️ **Extra UGC / Organic Stock Footage**

- [**<u>Gridbank.io</u>**](https://gridbank.io/) – Libreria di UGC autentici e realistici per brand.

- [**<u>The Content Cove</u>**](https://www.the-content-cove.com/) – Marketplace di video lifestyle e UGC di alta qualità.

- [**<u>Packsia</u>**](https://www.packsia.com/) – Raccolte curate di UGC e short video per advertising e social media.

### **MUSIC & SOUND EFFECTS**

- [**<u>TikTok</u>**](https://www.tiktok.com/) – Ottima fonte per trend musicali e ispirazione sonora.

- [**<u>Instagram</u>**](https://www.instagram.com/) – Scopri musica popolare nei Reel.

- [**<u>YouTube</u>**](https://www.youtube.com/) – Trova brani virali o SFX di tendenza.

- [**<u>Artlist</u>**](https://artlist.io/) – Catalogo professionale di musica e SFX con licenza illimitata per uso commerciale.

### **INSPIRATION & RESEARCH**

- [**<u>TikTok</u>**](https://www.tiktok.com/) – Scopri trend visivi e format di contenuti ad alta performance.

- [**<u>Instagram</u>**](https://www.instagram.com/) – Analizza stili visivi, editing e storytelling per Reel.

- [**<u>Atria</u>**](https://tryatria.com/) – Tool di analisi per creatività pubblicitarie top-performing.

- [**<u>Meta Ad Library</u>**](https://web.facebook.com/ads/library/) – Libreria ufficiale delle inserzioni Facebook/Instagram per studiare le strategie dei competitor.

Vuoi che te la impagini anche in **formato tabella Notion** (2 colonne: Tool \| Descrizione + link), così da copiarla direttamente nel tuo workspace team?

STATIC AD TEMPLATES PER FIGMA

STATIC AD TEMPLATES PER FIGMA

[<u>https://www.figma.com/design/YeRz9qWJm3pmed0Q85dPkH/Static-Ad-Templates</u>](https://www.figma.com/design/YeRz9qWJm3pmed0Q85dPkH/Static-Ad-Templates)
