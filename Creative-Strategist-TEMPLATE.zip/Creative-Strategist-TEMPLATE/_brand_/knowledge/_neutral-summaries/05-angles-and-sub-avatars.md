---
name: Angles and Sub-Avatars
type: knowledge
status: read-only
topic: how to sell the same product many different ways
---

# Angles and Sub-Avatars

The single biggest lever for scaling creative output: the same product sold through many distinct
**angles**, each aimed at a specific **sub-avatar**. This is how one product fuels dozens of ads.

---

## What an angle actually is

An angle is *how you choose to sell the product* — the specific reason-to-buy you lead with.
It is defined from the **customer's** point of view, not the marketer's.

These are **not** angles — they're formats or concepts:
- "Us vs. them," "before & after," "problem-aware ad," "testimonial." These describe the *shape* of
  the ad. The angle is the *what*: comparing **what**, transforming **what**, which **specific problem**.

An angle answers: *for this specific person, what is the most painful or desirable thing this product
touches, framed as a reason they'd buy?*

---

## Sub-avatars: same product, different people

One product serves several distinct sub-avatars. Each has a different dominant pain, desire, and
identity — so each needs a different angle, even though the product is identical.

Build a sub-avatar profile with:
- **Who** — age, situation, identity.
- **Dominant pain** — the specific, often embarrassing or urgent problem.
- **Dominant desire** — what they really want underneath the pain.
- **Trigger moment** — when the want spikes (the season, event, or situation).
- **Objection** — the reason they'd hesitate.

The more specific the sub-avatar, the sharper the angle. "Women 25–45" is not a sub-avatar.
"New mom avoiding the pool because of stretch marks" is.

---

## Generating angles (per sub-avatar)

For each sub-avatar, mine their most painful or most specific attributes, then convert each into a
reason-to-buy:

1. List the sub-avatar's sharpest pains and desires (use real customer language — verbatim beats paraphrase).
2. Reframe each as a problem *from their perspective*.
3. Turn each problem into a relatable reason-to-buy statement.
4. Rank angles strongest-first. The strongest angle leads.

Aim for a handful of *distinct* angles — distinct means a different pain/desire/identity, not a
cosmetic wording change. "Cheaper" and "more affordable" are the same angle.

---

## From angle to hooks

Each angle spawns several hooks (see `04-copywriting-fundamentals.md` for hook patterns).
Hold the angle constant and vary only the hook, so a test isolates one variable at a time.
You don't have to test every angle separately — a single concept can carry the best hook for one
strong angle and still validate the underlying desire.

---

## Isolate the variable when testing

When producing a batch, keep everything constant except the one thing you're testing.
- Testing angles? Same hook style, same offer, vary the angle.
- Testing hooks? Same angle, vary the opening line.
- Same closing line across a batch isolates the variable cleanly.

---

## How to use this file

1. From `brand.md`, pull the sub-avatars (or define them if missing — ask for real data, don't invent).
2. For the target sub-avatar, generate distinct angles from their sharpest pains/desires.
3. Pick the strongest angle, then spin hooks off it, isolating one variable per test.
4. Ground every angle in real customer language where available.
