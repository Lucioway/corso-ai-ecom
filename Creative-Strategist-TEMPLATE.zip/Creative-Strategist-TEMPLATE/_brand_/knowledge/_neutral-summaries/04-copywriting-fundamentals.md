---
name: Copywriting Fundamentals
type: knowledge
status: read-only
topic: the craft — headlines, hooks, bullets, proof
---

# Copywriting Fundamentals

The mechanics of getting read, kept, and convinced. Every framework here is a tool — apply the one
the brief needs, not all of them at once.

---

## The job of each part

- **Headline / hook** — buy the next line. Its only job is to stop the scroll and earn attention.
- **Lead** — buy the body. Deepen the hook, name the stakes, promise the payoff.
- **Body** — build belief. Proof, mechanism, story, objection-handling.
- **Close** — drive the action. Offer, risk reversal, urgency, single clear call to action.

If any part tries to do another's job, it fails at its own.

---

## Headlines and hooks

A hook stops the scroll by creating tension the reader must resolve. The reliable patterns:

- **Curiosity gap** — open a loop the reader needs closed ("The one thing nobody tells you about X").
- **Pattern interrupt** — say the unexpected; break the expected script of the category.
- **Contrarian** — challenge a held belief ("Stop doing X — it's why Y").
- **Specificity** — concrete and odd-numbered beats round and vague ("in 11 days," not "fast").
- **Direct benefit** — state the dream outcome plainly (works best at low sophistication).
- **Demonstration** — show the result happening, no claim needed.
- **Identity callout** — name the exact person ("If you've ever Z, this is for you").

**Test:** read the hook cold. If it doesn't make *you* want the next line, it isn't a hook.

---

## Bullets (fascinations)

Bullets sell the unseen — the curiosity-loaded benefits inside the product. Each bullet should:

- Lead with the benefit, not the feature.
- Carry a small mystery the reader can only resolve by buying ("...and the counter-intuitive reason it works").
- Be specific and concrete.

Turn fear into a bullet too: name the bad thing the product *prevents*, then dissolve the fear.

---

## Proof

Belief is the bottleneck. Supply proof in order of strength:

1. **Demonstration** — show it working (strongest).
2. **Specifics** — exact numbers, mechanisms, dates.
3. **Third-party** — testimonials, reviews, social proof, authority.
4. **Reason-why** — explain *why* the claim is true; an explained claim is a believed claim.

Vague claims raise suspicion. The more specific the claim, the more it's believed — so specify.

---

## Clarity over cleverness

Confused readers don't buy. Plain beats clever. Short words, short sentences, one idea per line.
Cut every word that doesn't earn its place. If a clever line risks being misread, kill it.

---

## Structure patterns (pick one per piece)

- **AIDA** — Attention → Interest → Desire → Action.
- **PAS** — Problem → Agitate → Solution.
- **Before / After / Bridge** — current pain → desired state → your product as the bridge.
- **Hook → Story → Offer** — stop them, take them somewhere, make the ask.

---

## How to use this file

1. Match the piece's parts to their jobs (hook stops, lead deepens, body proves, close acts).
2. Pick one hook pattern and one structure — don't blend five.
3. Lead bullets with benefit + curiosity; back every claim with the strongest proof available.
4. Run the clarity pass last: cut, simplify, read aloud.
