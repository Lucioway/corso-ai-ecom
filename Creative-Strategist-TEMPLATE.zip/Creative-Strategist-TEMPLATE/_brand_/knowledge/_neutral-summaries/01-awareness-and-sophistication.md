---
name: Awareness and Sophistication
type: knowledge
status: read-only
topic: where the prospect is + where the market is
---

# Awareness and Sophistication

Two independent dials decide how you open a message. Read both before writing any headline.

- **Awareness** = what the *prospect* knows (about their problem, your solution, your brand).
- **Sophistication** = what the *market* has already heard (how many competitors made similar claims).

Get the dial wrong and the copy feels either insulting (over-explaining to an aware buyer) or
baffling (pitching a solution to someone who doesn't know they have the problem).

---

## Dial 1 — Awareness stages

Five stages, from coldest to hottest. The opening line must meet the prospect where they are,
then move them one stage warmer.

1. **Unaware** — doesn't know they have a problem. Open with a story, a startling fact, or an
   identity statement that makes them recognize themselves. You cannot sell yet — you can only
   create recognition.
2. **Problem-aware** — feels the pain, doesn't know solutions exist. Open by naming the pain
   precisely (more precisely than they could themselves). Don't explain the problem — *validate* it.
3. **Solution-aware** — knows solutions like yours exist, doesn't know your product. Open with the
   *mechanism*: how your approach gets the result, and why it beats the generic category.
4. **Product-aware** — knows your product, hasn't bought. Open with proof, differentiation, and the
   reason to act now. Handle the specific objection keeping them on the fence.
5. **Most aware** — ready to buy, needs a nudge. Open with the offer and the deadline. Keep it short.

**Rule:** the colder the stage, the longer the runway before the pitch. The hotter the stage, the
faster you get to the offer.

---

## Dial 2 — Market sophistication levels

As a market hears the same promise repeated, claims stop working and you must escalate.

1. **Level 1 — be first.** Nobody has made the claim. State the benefit plainly: "Does X."
2. **Level 2 — be bigger.** Others claim it now. Outbid them: "Does X better / faster / more."
   (This stops working once everyone is shouting the biggest number.)
3. **Level 3 — introduce the mechanism.** The claim is tired, so explain *how* you deliver it.
   A credible mechanism makes an old promise believable again.
4. **Level 4 — better mechanism.** Competitors copied your mechanism. Differentiate the mechanism
   itself: a new method, a cleaner process, the honest flaw others hide.
5. **Level 5 — identity.** Mechanisms are exhausted. Stop arguing features and sell identity:
   who the buyer becomes, what tribe they join. The product becomes a badge.

**Rule:** you cannot skip levels upward without losing believability, and you cannot drop to a
lower level than the market has reached — a bare claim in a Level-4 market reads as naive.

---

## Depositioning

When you enter a crowded category (Levels 4–5), you win by *repositioning the alternative*, not by
out-claiming it. Name the hidden flaw in the obvious choice, then position your mechanism as the fix.
This reframes the buyer's existing solution as the problem.

---

## How to use this file

1. Identify the prospect's **awareness stage** → sets the opening move.
2. Identify the market's **sophistication level** → sets whether you lead with claim, mechanism, or identity.
3. The intersection of the two is your angle's *entry point*. Write the first line for that exact cell.
