---
name: Mass Desire and Emotion
type: knowledge
status: read-only
topic: the force the copy channels
---

# Mass Desire and Emotion

Copy does not *create* desire. It *channels* desire that already exists in the prospect, onto your
product. Trying to manufacture a want from nothing is the most expensive mistake in marketing.
Find the existing mass want, then attach your product to it.

---

## The core principle

A mass desire is a pre-existing, widely shared want — for status, security, health, belonging,
attraction, relief, ease. It lives in the prospect before your ad arrives. Your job:

1. **Identify** the strongest desire your product can plausibly satisfy.
2. **Channel** it — make your product the obvious vehicle for that want.
3. **Intensify** it — sharpen and concretize the want so action feels urgent.

You can intensify a desire. You cannot install one. If the want isn't there, change the audience,
not the volume.

---

## Measuring a desire (before you bet on it)

Rank a candidate desire on three dimensions:

- **Urgency / intensity** — how badly do they want it *right now*?
- **Staying power** — does the want fade fast, or recur?
- **Reach** — how many people share it?

The best angle sits on a desire that is intense, durable, and widely held. A niche-but-burning
desire can beat a broad-but-lukewarm one — narrow and on fire outperforms wide and tepid.

---

## Emotion drives action; logic justifies it

People decide on emotion and rationalize with logic. So the structure of persuasive copy is:

1. **Emotional hook** — hit the feeling (fear of loss, desire for gain, status, relief).
2. **Logical scaffolding** — give them the facts, proof, and reasons to defend the decision they
   already made emotionally.

Lead with feeling, close with proof. Reverse the order and you get a brochure nobody acts on.

---

## The recurring emotional drivers

Most direct-response angles pull one of these levers:

- **Fear** — of loss, of missing out, of staying stuck, of judgment.
- **Desire / aspiration** — the better life, body, status, ease.
- **Belonging / identity** — being seen as the kind of person who owns this.
- **Pride / vanity** — looking good to others and to oneself.
- **Guilt / responsibility** — duty to family, health, future self.
- **Greed / advantage** — getting more, sooner, for less.

Pick the *one* dominant driver for a given creative. Stacking three emotions dilutes all three.

---

## How to use this file

1. From `brand.md`, find the audience's dominant desire — pick the single strongest one.
2. Frame the product as the vehicle that satisfies it.
3. Choose one emotional driver to lead the hook; reserve proof and logic for the body.
4. Pressure-test the desire on urgency × staying power × reach before committing the batch to it.
