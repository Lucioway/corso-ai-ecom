---
name: DTC Funnel and Landing
type: knowledge
status: read-only
topic: where the click lands and how it converts
---

# DTC Funnel and Landing

The ad earns the click; the landing page earns the order. A great ad pointed at a weak page is
wasted spend. The page must continue the ad's promise without a jarring gap.

---

## Message match

The first screen of the landing page must echo the ad that sent the visitor there — same promise,
same angle, same language. A mismatch ("I clicked an ad about X, this page is about Y") spikes the
bounce. One angle = one matched landing experience.

---

## Landing-page section order (mobile-first)

A reliable above-to-below sequence for a direct-response product page:

1. **Hero** — headline (the promise/angle) + product shot + primary call to action, all on first screen.
2. **Problem / agitation** — name the pain the visitor feels; show you understand it.
3. **Solution + mechanism** — how the product solves it, and *why* it works (the mechanism).
4. **Proof** — demonstration, before/after, reviews, social proof, authority.
5. **Benefits / features** — benefit-led, each tied to the visitor's desire.
6. **Comparison** — you vs. the obvious alternative (depositioning the status quo).
7. **Offer** — price, what's included, bonuses, guarantee.
8. **Objection handling / FAQ** — kill the specific reasons not to buy.
9. **Risk reversal** — restate the guarantee right before the ask.
10. **Final call to action** — repeat the offer and a real reason to act now.

Repeat the call to action at every natural decision point — don't make them scroll back to buy.

---

## Friction removal

Every step between desire and purchase leaks conversions. Remove friction:

- Fewer form fields, fewer clicks to checkout.
- Fast load (especially on mobile — slow pages lose buyers before they read).
- Obvious, high-contrast call-to-action buttons.
- Pre-empt anxiety at the point of action: shipping, returns, security, payment options.
- A low-commitment first step (small first "yes") can pull hesitant buyers into the flow.

---

## Mobile-first reality

Most direct-response traffic is mobile. Design for the thumb and the small screen first:
short paragraphs, stacked sections, thumb-reachable buttons, legible type, and keep any critical
text inside the safe zone (platform UI and ad chrome cover the screen edges).

---

## Match the page to awareness

- **Colder traffic** → longer page, more education, more proof before the offer.
- **Hotter traffic** → shorter page, faster to the offer.

(Cross-reference `01-awareness-and-sophistication.md` — the awareness stage sets page length.)

---

## How to use this file

1. Confirm the page's hero matches the ad's angle and promise (message match).
2. Order sections by the sequence above, adjusting length to the traffic's awareness stage.
3. Audit for friction: load speed, form length, button clarity, point-of-action anxiety.
4. Repeat the call to action at each decision point.
