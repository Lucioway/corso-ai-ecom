---
name: Copywriting Fundamentals
type: knowledge
status: read-only
topic: the craft of direct-response copy — original synthesis, no third-party text
---

# Copywriting Fundamentals

Original, name-free synthesis of the direct-response craft. These are general principles — how
persuasive copy is researched, structured, and sharpened. Apply the tool the brief needs; don't
run every framework at once.

---

## 1. What copy is actually doing

Copy is salesmanship in print. Its job is not to "sound good" — it's to move one specific reader
one step closer to a decision. Three consequences:

- **One reader, one desire, one action.** Write to a single person about a single want, asking for
  a single next step. Copy that tries to please everyone persuades no one.
- **You channel desire, you don't create it.** Find the want the reader already has and connect your
  product to it. Manufacturing a brand-new desire from scratch is the most expensive failure mode.
- **Attention is rented, not owned.** Every line's only job is to earn the next line. The moment the
  reader stops being pulled forward, you've lost.

---

## 2. Research comes before writing

Great copy is assembled from what you discover, not invented at the keyboard. Before writing:

- **Mine the customer's own language.** Reviews, comments, DMs, support tickets, surveys. The exact
  words customers use to describe the pain and the dream are your raw material — verbatim beats
  paraphrase, because it already passed the believability test in a real mouth.
- **Find the dominant emotion.** Behind every purchase is a feeling: fear of loss, desire for gain,
  status, belonging, relief, pride. Identify the single strongest one for this reader.
- **Locate the reader's starting point.** What do they already know and believe? (See the awareness
  and sophistication file — it sets where the copy must open.)

The research-to-writing ratio is heavily weighted toward research. If writing feels hard, you
usually haven't researched enough.

---

## 3. The message hierarchy (what each part does)

| Part | Only job |
|---|---|
| Headline / hook | Stop the reader and earn the next line |
| Lead | Deepen the hook; name the stakes; promise the payoff |
| Body | Build belief: mechanism, proof, story, objection-handling |
| Close | Make the ask: offer, risk reversal, urgency, one clear action |

If any part tries to do another's job, it fails at its own. A headline that explains is not a
headline; a body that doesn't prove is not a body.

---

## 4. Headlines and hooks

The headline is the ad for the ad — most readers decide here. Reliable ways to create the pull:

- **Curiosity gap** — open a loop the reader must close.
- **Direct benefit** — state the dream outcome plainly (best when the market is young/unsophisticated).
- **Pattern interrupt** — say the unexpected; break the category's expected script.
- **Contrarian** — challenge a belief the reader holds.
- **Specificity** — concrete and odd-numbered beats round and vague.
- **Identity call-out** — name the exact person ("if you've ever…").
- **Demonstration** — show the result; let the proof be the hook.
- **News / mechanism** — reveal the *how* when the market has heard every promise already.

Test: read the headline cold, out of context. If it doesn't make *you* need the next line, rewrite it.

---

## 5. The lead

The lead is the first paragraph(s) after the headline. It either deepens the promise and pulls the
reader in, or it loses everyone the headline won. A strong lead does three things fast: confirms the
reader is in the right place, raises the stakes of the problem, and promises a specific payoff for
reading on. Match the lead's length to the reader's awareness: colder readers need a longer runway;
hotter readers want you to get to the point.

---

## 6. The body — building belief

Belief is the real bottleneck; most readers want the thing but don't believe it'll work for them.
Supply belief in order of strength:

1. **Demonstration** — show it working (strongest).
2. **Specifics** — exact numbers, mechanisms, timeframes. The more specific the claim, the more it's
   believed; vague claims invite suspicion.
3. **Mechanism** — explain *how* it works and *why* that's credible. A clear mechanism revives a
   tired promise.
4. **Social proof & authority** — testimonials, track record, credentials, demonstrations of trust.
5. **Reason-why** — give the reason behind every claim. An explained claim is a believed claim.

Handle objections inside the body, before they harden. Name the reader's hesitation out loud and
dissolve it — unspoken objections don't disappear, they just stop the sale silently.

---

## 7. Bullets

Bullets sell the unseen — the curiosity-loaded benefits hidden inside the product. Each strong bullet:

- Leads with the **benefit**, not the feature.
- Carries a small **open loop** the reader can only close by acting ("…and the counter-intuitive
  reason it works even if everything else failed").
- Is **specific and concrete**.

Turn fear into bullets too: name the bad outcome the product prevents, then dissolve it.

---

## 8. Tie copy to the offer

Copy earns attention and belief; the offer closes. Even great copy stalls against a weak offer. Make
the deal easy to say yes to: raise the perceived value (bigger dream, higher believability) and lower
the perceived cost (less time, less effort, less risk). Reverse risk with a guarantee, and add a real
reason to act now. (See the offers/value file for the full treatment.)

---

## 9. Clarity over cleverness

Confused readers don't buy. Plain beats clever every time:

- Short words, short sentences, one idea per line.
- Write the way the reader talks — pass the read-aloud test.
- Cut every word that doesn't earn its place. First drafts are always too long.
- If a clever line risks being misread, kill it. Clarity is the cleverness that matters.

Readability is a conversion lever, not a style preference. The easier copy is to read, the more of
it gets read, and reading is a prerequisite for buying.

---

## 10. Structure frameworks (pick one per piece)

- **AIDA** — Attention → Interest → Desire → Action.
- **PAS** — Problem → Agitate → Solution.
- **Before / After / Bridge** — current pain → desired state → product as the bridge.
- **Hook → Story → Offer** — stop them, take them somewhere, make the ask.

Choose one spine and commit. Blending five structures produces mush.

---

## 11. The edit pass (where copy is won)

Writing is assembly; editing is where it becomes persuasive. On the second pass:

1. **Cut** — remove every line that doesn't move the reader forward.
2. **Sharpen** — make vague claims specific, weak verbs strong, abstract benefits concrete.
3. **Flow** — every sentence should make the next one inevitable (the "slippery slide").
4. **Read aloud** — fix anything you'd never say to a real person.
5. **One CTA** — make the single next action obvious and repeat it at each decision point.

---

## How to use this file

1. Research first: pull the reader's real language, dominant emotion, and starting awareness.
2. Map the piece to the hierarchy (§3); give each part only its job.
3. Pick one hook pattern (§4) and one structure (§10) — don't blend.
4. Back every claim with the strongest available proof (§6); lead bullets with benefit + curiosity (§7).
5. Run the clarity (§9) and edit (§11) passes last.
