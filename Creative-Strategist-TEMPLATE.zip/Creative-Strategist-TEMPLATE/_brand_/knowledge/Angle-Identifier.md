---
name: Angle Identifier
type: knowledge
status: read-only
topic: turning sub-avatars into testable angles and direct hooks
---

# Angle Identifier

A method for generating marketing angles from sub-avatar profiles, then writing direct hooks that
communicate each angle. Use it to produce a ranked set of angles + hooks for a given product and
audience.

## What you produce

For each sub-avatar:
- **3 angles** — drawn from their most painful or most specific attributes, reframed as a reason to buy.
- **3 hooks/headlines** per angle — the line that communicates the angle and earns attention.
- A ranked output: strongest angle and strongest hook at the top.

You do **not** have to test every angle separately. A single concept can test "multiple angles"
behind the best hook — lead with the strongest, support with the rest in the body.

---

## Concept vs. Angle (the distinction that fixes most bad ads)

- **Concept** = the big idea you're testing. Internally focused — about you and your test strategy.
  ("Test a video version," "test us-vs-them," "do an iteration.")
- **Angle** = *how you choose to sell the product to the customer*. Externally focused — the reason
  the customer should buy.

Most marketers think only about the concept (the idea they want to test) and never define the angle
(how the product is positioned for the customer). That's why most ads miss.

These are **not** angles — they're concepts or formats:
- "Us vs. them" → comparison of **what**? The *what* is the angle.
- "Before & after" → transformation of **what**? The *what* is the angle.
- "Problem-aware ad" → of **which** problem? The *what* is the angle.
- "Sticky-note ad" → that's a *format*, with zero thought given to the angle.

The test: **if the concept doesn't give the customer a reason to buy, it isn't an angle yet.**
- "Video version" → no reason to buy → identify the angle.
- "Stops you tossing and turning" → gives a reason (solves their problem) → that's an angle.

Best practice: for **every** concept, write down "what the angle is" — i.e. the reason someone
should buy — before producing anything.

When your concept *is* "test angle(s)", concept and angle line up:
- Concept: "Test the buy-it-for-life angle" → Angle: "Buy it for life."

---

## Angles live on a spectrum (broad → specific)

The same desire yields angles at different resolutions:

- Core avatar desire: *wants better sleep.*
- Broad angle: "Want better sleep?" — yes, technically an angle, but weak *because* it's broad.
- Broad avatars are harder to sell to: they force broad angles.

Doing the work of identifying **sub-avatars** automatically surfaces angles specific enough to
relate to a real customer and actually sell — which is the whole point.

---

## Hooks vs. angles

- **Angle** = how you choose to sell the product (the reason to buy).
- **Hook / headline** = how you get attention — how you *communicate* the angle.

Until you're advanced, keep hooks **direct**, not indirect — the hook should state the angle plainly:

| Angle | Direct hook |
|---|---|
| Stops swelling | "14+ hours. No swelling." |
| Keeps you full like a meal | "This is a meal. Not a protein shake." |
| Stops you snapping at people | "5 minutes to install. No more snapping." |

Direct hooks are the easiest to write well and the safest default.

---

## The key to extracting angles: keep them ACTIONABLE

Angles are effectively limitless (anything the product can do for the customer). As long as each
angle is **actionable**, writing gets easier — and making winning ads easier is the entire goal.

---

## Output template (per product)

```
Marketing Angles & Hooks — <Product> / <Avatar>

PRIORITY NOTE: You don't have to test each angle separately. Test the #1 hook from the strongest
sub-avatar first. Layer supporting benefits from other angles into the body copy.

SUB-AVATAR #<n>: <name>  ⭐ STRONGEST
  Angle 1: <angle>
    Reason to buy: <relatable, customer-framed reason>
    Hook: "<direct hook>"
    Hook pattern: <which structure it uses — e.g. timeline + outcome, "this/this" redefinition>
  Angle 2: ...
  Angle 3: ...

(repeat per sub-avatar, ranked strongest → weakest)

TESTING PRIORITY: Start with the strongest sub-avatar's Angle 1. Test that hook first. If it hits,
run variations. If not, move to the next sub-avatar's Angle 1.
```

## Recurring hook patterns (to vary execution)

- **Timeline + specific outcome** — "14+ hours. No swelling."
- **"This / This" redefinition** — "This is bread. This is breakfast."
- **Percentage outcome** — "Seals 100% of light. Restores 100% of patience."
- **Minimal change, max impact** — "Don't change your life, just change lunch."
- **Identity call-out** — name the exact avatar.
- **Dual timeline** — speed + result in one line ("Cool room in 5 minutes. Deep sleep in 8 hours.").

---

## How to use this file

1. Start from sub-avatar profiles (see `05`-equivalent angle/sub-avatar material in your knowledge base).
2. For each sub-avatar, mine sharpest pains/desires → 3 actionable, customer-framed angles.
3. Write 3 direct hooks per angle; rank strongest-first.
4. Lead the test with the single strongest hook; isolate one variable at a time.
